let handler = async (m, { conn, args, usedPrefix = '.' }) => {
  try {
    // Deteksi mode berdasarkan command atau argument
    const mode = args[0]?.toLowerCase();
    
    // ===== UTILITY FUNCTIONS =====
    
    // Extract nomor bersih dari JID
    const extractCleanNumber = (jid) => {
      if (!jid) return null;
      const match = jid.match(/^(\d+)/);
      return match ? match[1] : null;
    };
    
    // Convert LID to proper JID
    const lidToJID = (lid) => {
      if (!lid || !lid.includes('@lid')) return lid;
      // Extract number from LID: 134479771373585@lid
      const number = extractCleanNumber(lid);
      if (!number) return lid;
      
      // Check if it's a valid phone number (starts with country code)
      // LID numbers are device IDs, we need to find the real phone number
      // For now, we'll check if there's a participant key
      if (m.key?.participant && !m.key.participant.includes('@lid')) {
        return m.key.participant;
      }
      
      // If no participant, return formatted JID
      return `${number}@s.whatsapp.net`;
    };
    
    // Format nomor untuk display (+62 812-3456-789)
    const formatDisplayNumber = (jid) => {
      const clean = extractCleanNumber(jid);
      if (!clean) return 'Unknown';
      if (clean.length < 10) return clean;
      
      // Format Indonesia: +62 812-3456-789
      if (clean.startsWith('62')) {
        return `+${clean.slice(0,2)} ${clean.slice(2,5)}-${clean.slice(5,9)}-${clean.slice(9)}`;
      }
      // Format umum
      return `+${clean}`;
    };
    
    // Deteksi tipe JID
    const getJIDType = (jid) => {
      if (!jid) return 'unknown';
      if (jid.includes('@s.whatsapp.net')) return 'user';
      if (jid.includes('@g.us')) return 'group';
      if (jid.includes('@lid')) return 'linked-device';
      if (jid.includes('@broadcast')) return 'broadcast';
      return 'unknown';
    };
    
    // Validate JID format
    const isValidJID = (jid) => {
      if (!jid) return false;
      return /^\d+@(s\.whatsapp\.net|g\.us|lid|broadcast)$/.test(jid);
    };
    
    // Get connection info
    const getConnectionInfo = () => {
      const botJid = conn.user?.id || conn.authState?.creds?.me?.id || 'Unknown';
      const botNumber = extractCleanNumber(botJid);
      // Extract real JID if it's a LID format (e.g., "6287874983278:7@s.whatsapp.net")
      const botRealJID = botJid.includes(':') ? botJid.split(':')[0] + '@s.whatsapp.net' : botJid;
      const botRealNumber = botJid.includes(':') ? botJid.split(':')[0] : botNumber;
      
      return {
        jid: botJid,
        realJID: botRealJID,
        number: botNumber,
        realNumber: botRealNumber,
        formatted: formatDisplayNumber(botRealNumber || botJid),
        type: getJIDType(botJid),
        valid: isValidJID(botRealJID),
        isMultiDevice: botJid.includes(':')
      };
    };
    
    // ===== MODE 1: INFO DASAR (DEFAULT) =====
    if (!mode || mode === 'basic') {
      // Jika user adalah bot, ambil dari conn.user.id
      let userRealJID = m.sender;
      
      if (m.fromMe || m.key?.fromMe) {
        // Ini pesan dari bot sendiri
        userRealJID = conn.user?.id || conn.authState?.creds?.me?.id || m.sender;
      } else if (m.sender.includes('@lid')) {
        // User menggunakan linked device, JID asli tidak tersedia
        // Tetap tampilkan LID sebagai identifier
        userRealJID = `${m.sender} (Linked Device - JID unavailable)`;
      }
      
      let text = `*Your Info:*\n`;
      text += `• Name: ${m.pushName}\n`;
      text += `• ID: ${m.sender}\n`;
      
      // Tambahkan Bot JID jika user adalah bot atau untuk referensi
      const botInfo = getConnectionInfo();
      text += `• JID: ${botInfo.jid}`;
      
      // Extract dan format nomor
      let displayNumber = extractCleanNumber(m.sender);
      if (botInfo.jid.includes(':')) {
        displayNumber = botInfo.jid.split(':')[0];
      } else if (!userRealJID.includes('unavailable')) {
        displayNumber = extractCleanNumber(userRealJID);
      }
      
      text += `\n• Number: ${formatDisplayNumber(displayNumber || m.sender)}`;
      
      if (m.isGroup) {
        text += `\n• Group: ${m.metadata?.subject}`;
        text += `\n• Group ID: ${m.chat}`;
      }
      
      text += `\n\n_Gunakan:_`;
      text += `\n• _${usedPrefix}myid full_ - Info lengkap`;
      text += `\n• _${usedPrefix}myid stats_ - Statistik pesan`;
      text += `\n• _${usedPrefix}myid jid_ - Detail JID`;
      text += `\n• _${usedPrefix}myid json_ - Format JSON`;
      text += `\n• _${usedPrefix}myid copy_ - Copy ID`;
      
      return m.reply(text);
    }
    
    // ===== MODE 2: INFO LENGKAP =====
    if (mode === 'full') {
      let text = `╭━━━『 *USER INFO* 』━━━╮\n`;
      text += `│\n`;
      text += `│ 👤 *Profile*\n`;
      text += `│ • Name: ${m.pushName || 'Unknown'}\n`;
      text += `│ • JID: ${m.sender}\n`;
      text += `│ • Number: ${extractCleanNumber(m.sender)}\n`;
      text += `│ • Formatted: ${formatDisplayNumber(m.sender)}\n`;
      text += `│ • Type: ${getJIDType(m.sender)}\n`;
      text += `│ • Bot Contact: ${m.fromMe ? 'Yes' : 'No'}\n`;
      text += `│\n`;
      
      // Info Perangkat
      text += `│ 📱 *Device*\n`;
      text += `│ • Platform: ${m.device || 'Unknown'}\n`;
      text += `│ • Message Type: ${m.mtype || 'text'}\n`;
      text += `│ • Is Media: ${m.isMedia ? 'Yes' : 'No'}\n`;
      text += `│\n`;
      
      // Info Connection
      const connInfo = getConnectionInfo();
      text += `│ 🤖 *Bot Info*\n`;
      text += `│ • Bot JID: ${connInfo.jid}\n`;
      text += `│ • Bot Number: ${connInfo.formatted}\n`;
      text += `│ • Type: ${connInfo.type}\n`;
      text += `│\n`;
      
      // Info Group (jika ada)
      if (m.isGroup) {
        text += `│ 👥 *Group Info*\n`;
        text += `│ • Name: ${m.metadata?.subject}\n`;
        text += `│ • JID: ${m.chat}\n`;
        text += `│ • Type: ${getJIDType(m.chat)}\n`;
        text += `│ • Members: ${m.metadata?.participants?.length || 0}\n`;
        text += `│ • Admin: ${m.isAdmin ? 'Yes' : 'No'}\n`;
        text += `│ • Bot Admin: ${m.isBotAdmin ? 'Yes' : 'No'}\n`;
        text += `│ • Created: ${new Date(m.metadata?.creation * 1000).toLocaleDateString('id-ID')}\n`;
        text += `│\n`;
      }
      
      // Info Pesan
      text += `│ 💬 *Message*\n`;
      text += `│ • ID: ${m.id}\n`;
      text += `│ • Key: ${m.key?.id || 'N/A'}\n`;
      text += `│ • Timestamp: ${new Date(m.messageTimestamp * 1000).toLocaleString('id-ID')}\n`;
      text += `│ • Quoted: ${m.quoted ? 'Yes' : 'No'}\n`;
      text += `│ • From Me: ${m.key?.fromMe ? 'Yes' : 'No'}\n`;
      text += `│\n`;
      text += `╰━━━━━━━━━━━━━━━━╯`;
      
      return m.reply(text);
    }
    
    // ===== MODE 3: STATISTIK PESAN =====
    if (mode === 'stats') {
      let text = `╭━━━『 *MESSAGE STATS* 』━━━╮\n`;
      text += `│\n`;
      text += `│ 📊 *User: ${m.pushName}*\n`;
      text += `│ • Number: ${formatDisplayNumber(m.sender)}\n`;
      text += `│\n`;
      
      // Hitung statistik dari database global
      const userChats = global.db?.data?.chats?.[m.chat];
      const userData = global.db?.data?.users?.[m.sender];
      
      if (userData) {
        text += `│ 💬 *Activity*\n`;
        text += `│ • Total Messages: ${userData.chat || 0}\n`;
        text += `│ • Commands Used: ${userData.hit || 0}\n`;
        text += `│ • Level: ${userData.level || 0}\n`;
        text += `│ • Experience: ${userData.exp || 0} XP\n`;
        text += `│ • Money: ${userData.money || 0}\n`;
        text += `│\n`;
        text += `│ 🎖️ *Status*\n`;
        text += `│ • Premium: ${userData.premium ? '✅ Yes' : '❌ No'}\n`;
        text += `│ • Banned: ${userData.banned ? '⛔ Yes' : '✅ No'}\n`;
        text += `│ • Verified: ${userData.verified ? '✅ Yes' : '❌ No'}\n`;
        text += `│ • Register Date: ${userData.regTime ? new Date(userData.regTime).toLocaleDateString('id-ID') : 'N/A'}\n`;
      } else {
        text += `│ ⚠️ _User data not available_\n`;
        text += `│ _Database might not be initialized_\n`;
      }
      
      text += `│\n`;
      
      if (m.isGroup && userChats) {
        text += `│ 👥 *Group Stats*\n`;
        text += `│ • Group Messages: ${userChats.chat || 0}\n`;
        text += `│ • Muted: ${userChats.mute ? '🔇 Yes' : '🔊 No'}\n`;
        text += `│ • Welcome: ${userChats.welcome ? '✅ On' : '❌ Off'}\n`;
        text += `│ • Anti-Link: ${userChats.antiLink ? '🔒 On' : '🔓 Off'}\n`;
      }
      
      text += `│\n`;
      text += `╰━━━━━━━━━━━━━━━━╯`;
      
      return m.reply(text);
    }
    
    // ===== MODE 4: DETAIL JID =====
    if (mode === 'jid' || mode === 'detail') {
      let text = `╭━━━『 *JID ANALYSIS* 』━━━╮\n`;
      text += `│\n`;
      
      // User JID
      text += `│ 👤 *Your JID*\n`;
      text += `│ • Full: ${m.sender}\n`;
      text += `│ • Number: ${extractCleanNumber(m.sender)}\n`;
      text += `│ • Formatted: ${formatDisplayNumber(m.sender)}\n`;
      text += `│ • Type: ${getJIDType(m.sender)}\n`;
      text += `│ • Valid: ${isValidJID(m.sender) ? '✅' : '❌'}\n`;
      text += `│\n`;
      
      // Bot JID
      const connInfo = getConnectionInfo();
      text += `│ 🤖 *Bot JID*\n`;
      text += `│ • Full: ${connInfo.jid}\n`;
      text += `│ • Number: ${connInfo.number}\n`;
      text += `│ • Formatted: ${connInfo.formatted}\n`;
      text += `│ • Type: ${connInfo.type}\n`;
      text += `│ • Valid: ${connInfo.valid ? '✅' : '❌'}\n`;
      text += `│\n`;
      
      // Chat JID
      text += `│ 💬 *Chat JID*\n`;
      text += `│ • Full: ${m.chat}\n`;
      text += `│ • Type: ${getJIDType(m.chat)}\n`;
      text += `│ • Is Group: ${m.isGroup ? 'Yes' : 'No'}\n`;
      
      if (m.isGroup) {
        text += `│ • Group ID: ${extractCleanNumber(m.chat)}\n`;
        const owner = m.metadata?.owner;
        if (owner) {
          text += `│\n`;
          text += `│ 👑 *Group Owner JID*\n`;
          text += `│ • Full: ${owner}\n`;
          text += `│ • Number: ${extractCleanNumber(owner)}\n`;
          text += `│ • Formatted: ${formatDisplayNumber(owner)}\n`;
        }
      }
      
      text += `│\n`;
      
      // Message Key Info
      text += `│ 🔑 *Message Key*\n`;
      text += `│ • Remote JID: ${m.key?.remoteJid || 'N/A'}\n`;
      text += `│ • From Me: ${m.key?.fromMe || false}\n`;
      text += `│ • ID: ${m.key?.id || 'N/A'}\n`;
      if (m.key?.participant) {
        text += `│ • Participant: ${m.key.participant}\n`;
      }
      
      text += `│\n`;
      text += `╰━━━━━━━━━━━━━━━━╯\n\n`;
      
      text += `*📚 JID Format Guide:*\n`;
      text += `• \`number@s.whatsapp.net\` - User/Personal\n`;
      text += `• \`number@g.us\` - Group Chat\n`;
      text += `• \`number@lid\` - Linked Device\n`;
      text += `• \`number@broadcast\` - Broadcast List`;
      
      return m.reply(text);
    }
    
    // ===== MODE 5: FORMAT JSON =====
    if (mode === 'json') {
      const connInfo = getConnectionInfo();
      
      const data = {
        user: {
          name: m.pushName,
          jid: m.sender,
          number: extractCleanNumber(m.sender),
          formatted: formatDisplayNumber(m.sender),
          type: getJIDType(m.sender),
          isBot: m.fromMe,
          device: m.device || 'unknown'
        },
        bot: {
          jid: connInfo.jid,
          realJID: connInfo.realJID,
          number: connInfo.number,
          realNumber: connInfo.realNumber,
          formatted: connInfo.formatted,
          type: connInfo.type,
          valid: connInfo.valid,
          isMultiDevice: connInfo.isMultiDevice
        },
        message: {
          id: m.id,
          keyId: m.key?.id,
          type: m.mtype,
          timestamp: m.messageTimestamp,
          date: m.messageTimestamp ? new Date(m.messageTimestamp * 1000).toISOString() : null,
          hasQuoted: !!m.quoted,
          fromMe: m.key?.fromMe || false,
          isMedia: m.isMedia || false
        },
        chat: {
          jid: m.chat,
          type: getJIDType(m.chat),
          isGroup: m.isGroup
        }
      };
      
      if (m.isGroup) {
        data.group = {
          name: m.metadata?.subject,
          jid: m.chat,
          id: extractCleanNumber(m.chat),
          members: m.metadata?.participants?.length || 0,
          admins: m.metadata?.participants?.filter(p => p.admin).length || 0,
          owner: m.metadata?.owner,
          isAdmin: m.isAdmin,
          isBotAdmin: m.isBotAdmin,
          created: m.metadata?.creation,
          createdDate: m.metadata?.creation ? new Date(m.metadata.creation * 1000).toISOString() : null
        };
      }
      
      const userData = global.db?.data?.users?.[m.sender];
      if (userData) {
        data.stats = {
          messages: userData.chat || 0,
          commands: userData.hit || 0,
          level: userData.level || 0,
          exp: userData.exp || 0,
          money: userData.money || 0,
          premium: userData.premium || false,
          banned: userData.banned || false,
          verified: userData.verified || false,
          registerTime: userData.regTime || null
        };
      }
      
      if (m.key?.participant) {
        data.message.participant = {
          jid: m.key.participant,
          number: extractCleanNumber(m.key.participant),
          type: getJIDType(m.key.participant)
        };
      }
      
      if (m.key?.remoteJid) {
        data.message.remoteJid = {
          jid: m.key.remoteJid,
          number: extractCleanNumber(m.key.remoteJid),
          type: getJIDType(m.key.remoteJid)
        };
      }
      
      return m.reply('```json\n' + JSON.stringify(data, null, 2) + '\n```');
    }
    
    // ===== MODE 6: COPY ID CEPAT =====
    if (mode === 'copy') {
      return m.reply(m.sender);
    }
    
    // ===== MODE 7: COPY NUMBER ONLY =====
    if (mode === 'number' || mode === 'num') {
      return m.reply(extractCleanNumber(m.sender));
    }
    
    // ===== MODE 8: COMPARE JIDs =====
    if (mode === 'compare' || mode === 'check') {
      let text = `╭━━━『 *JID COMPARISON* 』━━━╮\n`;
      text += `│\n`;
      
      const userNum = extractCleanNumber(m.sender);
      const botNum = getConnectionInfo().number;
      const chatNum = extractCleanNumber(m.chat);
      
      text += `│ 🔍 *Number Comparison*\n`;
      text += `│ • Your Number: ${userNum}\n`;
      text += `│ • Bot Number: ${botNum}\n`;
      text += `│ • Chat ID: ${chatNum}\n`;
      text += `│\n`;
      text += `│ ✅ *Matches*\n`;
      text += `│ • You = Bot: ${userNum === botNum ? 'YES' : 'NO'}\n`;
      text += `│ • You = Chat: ${userNum === chatNum ? 'YES' : 'NO'}\n`;
      text += `│ • Bot = Chat: ${botNum === chatNum ? 'YES' : 'NO'}\n`;
      text += `│\n`;
      
      if (m.isGroup) {
        const ownerNum = extractCleanNumber(m.metadata?.owner);
        text += `│ 👑 *Group Owner*\n`;
        text += `│ • Owner Number: ${ownerNum}\n`;
        text += `│ • You = Owner: ${userNum === ownerNum ? 'YES ⭐' : 'NO'}\n`;
        text += `│ • Bot = Owner: ${botNum === ownerNum ? 'YES ⭐' : 'NO'}\n`;
        text += `│\n`;
      }
      
      text += `╰━━━━━━━━━━━━━━━━╯`;
      
      return m.reply(text);
    }
    
    // ===== MODE 9: HELP =====
    if (mode === 'help' || mode === 'menu') {
      let text = `╭━━━『 *MYID COMMANDS* 』━━━╮\n`;
      text += `│\n`;
      text += `│ 📖 *Available Modes:*\n`;
      text += `│\n`;
      text += `│ • \`${usedPrefix}myid\` or \`basic\`\n`;
      text += `│   Info dasar user\n`;
      text += `│\n`;
      text += `│ • \`${usedPrefix}myid full\`\n`;
      text += `│   Info lengkap + device\n`;
      text += `│\n`;
      text += `│ • \`${usedPrefix}myid stats\`\n`;
      text += `│   Statistik & aktivitas\n`;
      text += `│\n`;
      text += `│ • \`${usedPrefix}myid jid\`\n`;
      text += `│   Detail JID analysis\n`;
      text += `│\n`;
      text += `│ • \`${usedPrefix}myid json\`\n`;
      text += `│   Output format JSON\n`;
      text += `│\n`;
      text += `│ • \`${usedPrefix}myid copy\`\n`;
      text += `│   Copy JID lengkap\n`;
      text += `│\n`;
      text += `│ • \`${usedPrefix}myid number\`\n`;
      text += `│   Copy nomor saja\n`;
      text += `│\n`;
      text += `│ • \`${usedPrefix}myid compare\`\n`;
      text += `│   Bandingkan JID\n`;
      text += `│\n`;
      text += `╰━━━━━━━━━━━━━━━━╯`;
      
      return m.reply(text);
    }
    
    // Mode tidak dikenali
    m.reply(`❌ Mode tidak valid: *${mode}*\n\nGunakan \`${usedPrefix}myid help\` untuk melihat semua mode.`);
    
  } catch (e) {
    console.error('MyID Error:', e);
    m.reply(`❌ Error: ${e.message}\n\n_Stack:_ ${e.stack?.split('\n')[0]}`);
  }
};

handler.help = [
  "myid [mode]",
  "Modes: basic, full, stats, jid, json, copy, number, compare, help"
];
handler.tags = ["info"];
handler.command = ["cekid", "myid"];

export default handler;