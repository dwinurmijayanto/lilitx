import fetch from 'node-fetch';
import FormData from 'form-data';
import fs from 'fs';
import { promisify } from 'util';
import { tmpdir } from 'os';
import { join } from 'path';
import { downloadContentFromMessage } from 'baileys';
import sharp from 'sharp';

const writeFile = promisify(fs.writeFile);
const unlink = promisify(fs.unlink);

console.log('[SMEME Handler] Loading with integrated uploader (HF + TmpFiles + VBI + Uguu) - ESM Baileys...');

// ========== CONFIGURATION SMEME ==========
const SMEME_API_URL = 'https://api.deline.web.id/maker/smeme';
const TIMEOUT_MS = 60000;
const MAX_TEXT_LENGTH = 100;

// ========== STICKER METADATA ==========
const STICKER_PACK = 'SMEME Bot';
const STICKER_AUTHOR = 'github.com/your-bot';

// ========== UPLOADER CONFIG (4 HOST) ==========
const UPLOAD_SERVERS = {
    hf: { url: 'https://ikyy-upload-file.hf.space/upload', name: 'HF' },
    tmpfiles: { url: 'https://tmpfiles.org/api/v1/upload', name: 'TmpFiles' },
    vbi: { url: 'https://upload.vbi1.my.id/index.php', name: 'VBI' },
    uguu: { url: 'https://uguu.se/upload.php', name: 'Uguu' }
};

// ========== FUNGSI UPLOAD ==========
async function uploadImage(buffer, filename = 'smeme.jpg', mimetype = 'image/jpeg') {
    const uploadFunctions = [
        uploadToHF, uploadToTmpFiles, uploadToVBI, uploadToUguu
    ];

    for (const fn of uploadFunctions) {
        try {
            const result = await fn(buffer, filename, mimetype);
            if (result.success && result.url) {
                console.log(`[SMEME Uploader] Sukses di ${result.server}: ${result.url}`);
                return result.url;
            }
        } catch (err) {
            console.error(`[SMEME Uploader] ${err.server || 'Unknown'} gagal:`, err.message);
        }
    }
    console.warn('[SMEME Uploader] Semua host gagal, fallback ke default image');
    return null;
}

async function uploadToHF(buffer, filename, mimetype) {
    const form = new FormData();
    form.append('file', buffer, { filename, contentType: mimetype });
    const res = await fetch(UPLOAD_SERVERS.hf.url, { method: 'POST', body: form });
    if (!res.ok) throw { message: `HF HTTP ${res.status}`, server: 'HF' };
    const json = await res.json();
    if (json.fileUrl) return { success: true, server: 'HF', url: json.fileUrl };
    throw { message: 'HF no fileUrl', server: 'HF' };
}

async function uploadToTmpFiles(buffer, filename, mimetype) {
    const form = new FormData();
    form.append('file', buffer, { filename, contentType: mimetype });
    const res = await fetch(UPLOAD_SERVERS.tmpfiles.url, { method: 'POST', body: form });
    if (!res.ok) throw { message: `TmpFiles HTTP ${res.status}`, server: 'TmpFiles' };
    const json = await res.json();
    if (json.status === 'success' && json.data?.url) {
        const parts = json.data.url.split('/');
        const id = parts[parts.length - 2];
        const name = parts[parts.length - 1];
        return { success: true, server: 'TmpFiles', url: `https://tmpfiles.org/dl/${id}/${name}` };
    }
    throw { message: 'TmpFiles invalid response', server: 'TmpFiles' };
}

async function uploadToVBI(buffer, filename) {
    const form = new FormData();
    form.append('file', buffer, { filename, contentType: 'image/jpeg' });
    form.append('permanent', '1');
    form.append('never_delete', 'true');
    const res = await fetch(UPLOAD_SERVERS.vbi.url, { method: 'POST', body: form });
    if (!res.ok) throw { message: `VBI HTTP ${res.status}`, server: 'VBI' };
    const json = await res.json();
    if (json.success && json.data?.url) return { success: true, server: 'VBI', url: json.data.url };
    throw { message: 'VBI invalid response', server: 'VBI' };
}

async function uploadToUguu(buffer, filename, mimetype) {
    const tempPath = join(tmpdir(), `uguu_${Date.now()}_${filename}`);
    await writeFile(tempPath, buffer);
    try {
        const form = new FormData();
        form.append('files[]', fs.createReadStream(tempPath), { filename, contentType: mimetype });
        const res = await fetch(UPLOAD_SERVERS.uguu.url, { method: 'POST', body: form });
        if (!res.ok) throw { message: `Uguu HTTP ${res.status}`, server: 'Uguu' };
        const json = await res.json();
        if (json.files?.[0]?.url) return { success: true, server: 'Uguu', url: json.files[0].url };
        throw { message: 'Uguu no url', server: 'Uguu' };
    } finally {
        await unlink(tempPath).catch(() => {});
    }
}

// ========== KONVERSI KE STICKER (WebP) ==========
async function convertToSticker(imageBuffer) {
    try {
        // Resize ke 512x512 dan convert ke WebP menggunakan sharp
        const webpBuffer = await sharp(imageBuffer)
            .resize(512, 512, {
                fit: 'contain',
                background: { r: 0, g: 0, b: 0, alpha: 0 } // transparan
            })
            .webp({ quality: 80 })
            .toBuffer();

        console.log('[SMEME] Konversi sticker berhasil, size:', webpBuffer.length, 'bytes');
        return webpBuffer;
    } catch (err) {
        console.error('[SMEME] Konversi sticker gagal:', err.message);
        throw err;
    }
}

// ========== DOWNLOAD MEDIA ==========
async function downloadMediaFromMessage(m) {
    let source = null;
    if (m.message?.imageMessage) {
        source = m.message.imageMessage;
    } else if (m.quoted?.message?.imageMessage) {
        source = m.quoted.message.imageMessage;
    }
    if (!source) return null;
    try {
        const stream = await downloadContentFromMessage(source, 'image');
        const chunks = [];
        for await (const chunk of stream) chunks.push(chunk);
        return Buffer.concat(chunks);
    } catch (err) {
        console.error('[SMEME] Download media error:', err.message);
        return null;
    }
}

// ========== HELPER FUNGSI SMEME ==========
function generateUsageHelp(prefix, cmd) {
    return `*😂 SMEME - Meme Generator (top & bottom text)*
📌 Cara: ${prefix}${cmd} <top text> | <bottom text>
Contoh:
${prefix}${cmd} Hai Sayang | Mandala
${prefix}${cmd} when | yah

• Reply gambar atau kirim gambar + caption command
• Atau kasih URL gambar di awal
• Tanpa gambar → pakai default template
• Hasil dikirim sebagai *sticker* 🎉

Ketik ${prefix}${cmd} help untuk info lagi.`;
}

function parseText(input) {
    if (!input || input.trim().length === 0) {
        return { error: 'Teks tidak boleh kosong! Contoh: .smeme Hai | Sayang' };
    }
    const parts = input.trim().split('|').map(p => p.trim());
    const top = parts[0] || '';
    const bottom = parts.length > 1 ? parts[1] : '';
    if (top.length > MAX_TEXT_LENGTH || bottom.length > MAX_TEXT_LENGTH) {
        return { error: `Teks terlalu panjang! Max ${MAX_TEXT_LENGTH} char per baris.` };
    }
    return { top, bottom };
}

function extractImageUrlFromText(text) {
    const urlRegex = /^(https?:\/\/.*\.(?:png|jpg|jpeg|gif|webp))/i;
    const match = text.match(urlRegex);
    return match ? match[0] : null;
}

async function getImageUrl(m, text) {
    const urlFromText = extractImageUrlFromText(text);
    if (urlFromText) {
        console.log('[SMEME] Pakai URL dari teks:', urlFromText);
        return urlFromText;
    }
    const buffer = await downloadMediaFromMessage(m);
    if (buffer && buffer.length > 0) {
        console.log('[SMEME] Gambar terdeteksi (size:', buffer.length, 'bytes), mulai upload...');
        try {
            const uploadedUrl = await uploadImage(buffer, `smeme_${Date.now()}.jpg`, 'image/jpeg');
            if (uploadedUrl) return uploadedUrl;
        } catch (err) {
            console.error('[SMEME] Upload gagal:', err);
        }
    }
    const DEFAULT_IMAGE = 'https://upload.vbi1.my.id/uploads/2026/02/image_1772057778443.jpg';
    console.log('[SMEME] Pakai default image:', DEFAULT_IMAGE);
    return DEFAULT_IMAGE;
}

// ========== GENERATE SMEME ==========
async function generateSmeme(top, bottom, imageUrl) {
    try {
        console.log('[SMEME] Generate dengan:', { top, bottom, imageUrl });
        const params = new URLSearchParams({ image: imageUrl, top: top || '', bottom: bottom || '' });
        const apiUrl = `${SMEME_API_URL}?${params}`;
        console.log('[SMEME] API URL:', apiUrl);

        const response = await fetch(apiUrl, { method: 'GET', timeout: TIMEOUT_MS });
        if (!response.ok) throw new Error(`HTTP ${response.status} ${response.statusText}`);

        const contentType = response.headers.get('content-type');
        if (!contentType?.includes('image')) {
            const errText = await response.text();
            throw new Error(`Bukan gambar: ${errText.slice(0, 150)}`);
        }

        const buffer = await response.buffer();
        if (buffer.length < 2000) throw new Error('Gambar terlalu kecil/kosong');

        return { success: true, buffer };
    } catch (error) {
        console.error('[SMEME] Generate error:', error.message);
        return { success: false, message: error.message };
    }
}

// ========== MAIN HANDLER ==========
const handler = async (m, { conn, text, args, usedPrefix, command }) => {
    const prefix = usedPrefix || '.';
    const cmd = command || 'smeme';

    try {
        let inputText = (text || args.join(' ')).trim();

        if (!inputText || inputText.toLowerCase() === 'help' || inputText === '?') {
            return m.reply(generateUsageHelp(prefix, cmd));
        }

        const { top, bottom, error } = parseText(inputText);
        if (error) {
            return m.reply(`❌ ${error}\n\nKetik *${prefix}${cmd} help*`);
        }

        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        const imageUrl = await getImageUrl(m, inputText);
        const result = await generateSmeme(top, bottom, imageUrl);

        if (!result.success) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ Gagal membuat smeme!\n*Error:* ${result.message}`);
        }

        // ========== KONVERSI KE STICKER ==========
        let stickerBuffer;
        try {
            stickerBuffer = await convertToSticker(result.buffer);
        } catch (convertErr) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ Gagal konversi ke sticker!\n*Error:* ${convertErr.message}`);
        }

        await conn.sendMessage(m.chat, { react: { text: '😂', key: m.key } });

        // Kirim sebagai sticker
        await conn.sendMessage(m.chat, {
            sticker: stickerBuffer,
            mimetype: 'image/webp',
            // Metadata sticker (opsional, tidak semua lib support)
            stickerMetadata: {
                pack: STICKER_PACK,
                author: STICKER_AUTHOR
            }
        }, { quoted: m });

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (error) {
        console.error('[SMEME] Critical error:', error.message, error.stack);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        m.reply(`❌ Terjadi kesalahan: ${error.message}\nCoba lagi atau ketik *${prefix}${cmd} help*`);
    }
};

handler.help = ["smeme <top> | <bottom> - bikin meme, dikirim sebagai sticker"];
handler.tags = ["maker", "meme", "sticker"];
handler.command = ["smeme", "smock", "mockingmeme"];
handler.limit = true;

console.log('[SMEME Handler] Loaded successfully - ESM with sticker conversion');

export default handler;