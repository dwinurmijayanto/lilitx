import fetch from 'node-fetch';

console.log('[IQC Handler] Loading handler...');

// ========== CONFIGURATION ==========
const IQC_API_URL = 'https://api.deline.web.id/maker/iqc';
const TIMEOUT_MS = 60000;
const CHAT_TIME_OFFSET_MINUTES = 13; // statusBarTime - chatTime offset

// ========== TIME HELPER ==========
/**
 * Get current time string in HH:MM format
 * @param {number} offsetMinutes - Subtract this many minutes from current time
 * @returns {string} - Time string HH:MM
 */
function getCurrentTime(offsetMinutes = 0) {
    const now = new Date();
    now.setMinutes(now.getMinutes() - offsetMinutes);
    const hh = String(now.getHours()).padStart(2, '0');
    const mm = String(now.getMinutes()).padStart(2, '0');
    return `${hh}:${mm}`;
}

// ========== FORMAT FUNCTIONS ==========
function generateUsageHelp(prefix, cmd) {
    const exampleStatusBar = getCurrentTime();
    const exampleChat = getCurrentTime(CHAT_TIME_OFFSET_MINUTES);

    return `*📱 IQC - iPhone Quote Creator*

📌 *Cara Penggunaan:*

${prefix}${cmd} <text>

*Parameter:*
• *text* - Teks yang akan ditampilkan
• Waktu otomatis diambil dari waktu sekarang

*Contoh:*
${prefix}${cmd} Selamat pagi
${prefix}${cmd} Aku sayang kamu
${prefix}${cmd} Hello world

`;
}

/**
 * Parse input - only text needed, times are auto-generated
 * @param {string} input - Raw input string
 * @returns {Object} - {text, chatTime, statusBarTime, error}
 */
function parseParameters(input) {
    if (!input || typeof input !== 'string' || input.trim().length === 0) {
        return { error: 'Text tidak boleh kosong!' };
    }

    const text = input.trim();
    const statusBarTime = getCurrentTime();
    const chatTime = getCurrentTime(CHAT_TIME_OFFSET_MINUTES);

    return { text, chatTime, statusBarTime };
}

// ========== IQC GENERATION ==========
async function generateIQC(text, chatTime, statusBarTime) {
    try {
        console.log('[IQC Handler] Generating IQC with params:', { text, chatTime, statusBarTime });

        const params = new URLSearchParams({ text, chatTime, statusBarTime });
        const apiUrl = `${IQC_API_URL}?${params.toString()}`;
        console.log('[IQC Handler] API URL:', apiUrl);

        const fetchPromise = fetch(apiUrl, { method: 'GET', timeout: TIMEOUT_MS });
        const timeoutPromise = new Promise((_, reject) =>
            setTimeout(() => reject(new Error(`Timeout setelah ${TIMEOUT_MS}ms`)), TIMEOUT_MS)
        );

        const response = await Promise.race([fetchPromise, timeoutPromise]);

        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status} ${response.statusText}`);
        }

        const contentType = response.headers.get('content-type');
        console.log('[IQC Handler] Response content-type:', contentType);

        if (!contentType || !contentType.includes('image')) {
            const errorText = await response.text();
            throw new Error(`API tidak mengembalikan gambar: ${errorText}`);
        }

        const buffer = await response.buffer();

        if (!buffer || buffer.length === 0) {
            throw new Error('API mengembalikan buffer kosong');
        }

        console.log('[IQC Handler] Generation complete, result size:', buffer.length, 'bytes');
        return { success: true, imageBuffer: buffer };
    } catch (error) {
        console.error('[IQC Handler] Generation error:', error.message);
        return { success: false, message: error.message };
    }
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    let prefix = usedPrefix || '.';
    const cmd = command || 'iqc';

    try {
        let inputText = '';
        if (text) {
            inputText = text.trim();
        } else if (args && args.length > 0) {
            inputText = args.join(' ').trim();
        }

        if (!inputText || inputText.toLowerCase() === 'help' || inputText === '?') {
            return m.reply(generateUsageHelp(prefix, cmd));
        }

        const params = parseParameters(inputText);

        if (params.error) {
            return m.reply(`❌ ${params.error}\n\n💡 Ketik *${prefix}${cmd} help* untuk panduan lengkap`);
        }

        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        console.log('[IQC Handler] Starting generation process');
        const result = await generateIQC(params.text, params.chatTime, params.statusBarTime);

        if (!result.success) {
            console.error('[IQC Handler] Generation failed:', result.message);
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ Gagal membuat IQC!\n\n*Error:* ${result.message}\n\n💡 Coba lagi atau ketik *${prefix}${cmd} help* untuk bantuan`);
        }

        await conn.sendMessage(m.chat, { react: { text: '📱', key: m.key } });

        console.log('[IQC Handler] Sending result');
        await conn.sendMessage(m.chat, {
            image: result.imageBuffer
        }, { quoted: m });

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (error) {
        console.error('[IQC Handler] CRITICAL ERROR:', error.message);
        console.error('[IQC Handler] Stack:', error.stack);

        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch((e) => {
            console.error('[IQC Handler] Failed to send error reaction:', e.message);
        });

        return m.reply(`❌ Terjadi kesalahan!\n\n*Error:* ${error.message}\n\n💡 Ketik *${prefix}${cmd} help* untuk bantuan`);
    }
};

// ========== HANDLER PROPERTIES ==========
handler.help = ["iqc <text> - buat iPhone quote (waktu otomatis)"];
handler.tags = ["maker"];
handler.command = ["iqc", "iphonequote"];
handler.limit = true;

console.log('[IQC Handler] Handler loaded successfully');

export default handler;