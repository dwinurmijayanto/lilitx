import fetch from 'node-fetch';
import FormData from 'form-data';
import { downloadContentFromMessage } from 'baileys';

console.log('[Upscale Handler] Loading handler...');

// ========== CONFIGURATION ==========
const UPSCALE_API_URL = 'https://api-library-kohi.onrender.com/api/upscale';
const UPLOAD_API_URL = 'https://upload.vbi1.my.id/index.php';
const TIMEOUT_MS = 90000; // 90 detik timeout untuk upscale

// ========== DOWNLOAD MEDIA FUNCTION ==========
/**
 * Download media dari Baileys message
 * @param {Object} message - Raw Baileys message object
 * @returns {Buffer|null} - Media buffer atau null jika gagal
 */
async function downloadMedia(message) {
    try {
        const mimeMap = {
            imageMessage: 'image',
            videoMessage: 'video',
            stickerMessage: 'sticker',
            documentMessage: 'document',
            audioMessage: 'audio'
        };

        const msgKeys = Object.keys(message || {});
        if (msgKeys.length === 0) return null;

        const type = msgKeys[0];
        if (!type) return null;

        const m = message[type];
        if (!m) return null;

        const mediaType = mimeMap[type];
        if (!mediaType) return null;

        // Download media menggunakan Baileys
        const stream = await downloadContentFromMessage(m, mediaType);
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        
        return Buffer.concat(chunks);
    } catch (error) {
        console.error('[Upscale Handler] Error downloading media:', error);
        return null;
    }
}

// ========== UPSCALE FROM BUFFER ==========
/**
 * Upload buffer ke server untuk mendapat URL
 * @param {Buffer} mediaBuffer - Image buffer
 * @param {string} filename - Nama file
 * @returns {Object} - {success, url, message}
 */
async function uploadImageBuffer(mediaBuffer, filename = 'image.jpg') {
    try {
        console.log('[Upscale Handler] Uploading buffer to server, size:', mediaBuffer.length, 'bytes');
        
        const formData = new FormData();
        formData.append('file', mediaBuffer, {
            filename: filename,
            contentType: 'image/jpeg'
        });
        formData.append('permanent', '1');
        formData.append('never_delete', 'true');
        formData.append('keep_forever', 'yes');
        
        const uploadPromise = fetch(UPLOAD_API_URL, {
            method: 'POST',
            body: formData,
            headers: formData.getHeaders()
        });
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error(`Timeout setelah 30000ms`)), 30000)
        );
        
        const response = await Promise.race([uploadPromise, timeoutPromise]);
        
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status} ${response.statusText}`);
        }
        
        const result = await response.json();
        
        if (result.success && result.data?.url) {
            console.log('[Upscale Handler] Upload success:', result.data.url);
            return { success: true, url: result.data.url };
        } else {
            throw new Error('Upload failed - no URL in response');
        }
    } catch (error) {
        console.error('[Upscale Handler] Upload error:', error.message);
        return { success: false, message: error.message };
    }
}

/**
 * Upscale gambar dari URL
 * @param {string} imageUrl - URL gambar
 * @returns {Object} - {success, upscaleUrl, message}
 */
async function upscaleImageFromUrl(imageUrl) {
    try {
        console.log(`[Upscale Handler] Upscaling from URL: ${imageUrl}`);
        
        const encodedUrl = encodeURIComponent(imageUrl);
        const upscaleUrl = `${UPSCALE_API_URL}?url=${encodedUrl}`;
        
        const upscalePromise = fetch(upscaleUrl, {
            method: 'GET',
            timeout: TIMEOUT_MS
        });
        
        const timeoutPromise = new Promise((_, reject) =>
            setTimeout(() => reject(new Error(`Timeout setelah ${TIMEOUT_MS}ms`)), TIMEOUT_MS)
        );
        
        const response = await Promise.race([upscalePromise, timeoutPromise]);
        
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status} ${response.statusText}`);
        }
        
        const result = await response.json();
        
        if (result.status && result.data?.url) {
            console.log('[Upscale Handler] Upscale success');
            return { success: true, upscaleUrl: result.data.url };
        } else {
            throw new Error('Upscale failed - invalid response');
        }
    } catch (error) {
        console.error('[Upscale Handler] Upscale error:', error.message);
        return { success: false, message: error.message };
    }
}

// ========== FORMAT FUNCTIONS ==========
/**
 * Format hasil upscale menjadi pesan user-friendly
 * @param {Object} result - Result object
 * @returns {string} - Formatted message
 */
function formatUpscaleResult(result) {
    let message = `*🚀 UPSCALE RESULT*\n\n`;
    
    if (result.success && result.upscaleUrl) {
        message += `┌─「 🖼️ *Upscale* 」\n`;
        message += `├ ✅ Status: *BERHASIL*\n`;
        message += `├ 📈 Resolution: *Upscaled*\n`;
        message += `├ 🔗 URL:\n`;
        message += `│    ${result.upscaleUrl}\n`;
        message += `└─────────────\n\n`;
        message += `🎉 *Upscale berhasil!*`;
    } else {
        message += `┌─「 🖼️ *Upscale* 」\n`;
        message += `├ ❌ Status: *GAGAL*\n`;
        message += `├ ⚠️ Error: ${result.message || 'Unknown error'}\n`;
        message += `└─────────────\n\n`;
        message += `❌ *Upscale gagal, silakan coba lagi*`;
    }
    
    return message;
}

/**
 * Generate help message
 * @param {string} prefix - Command prefix
 * @param {string} cmd - Command name
 * @returns {string} - Help message
 */
function generateUsageHelp(prefix, cmd) {
    return `*🚀 UPSCALE IMAGE*

📌 *Cara Penggunaan:*

*1. Upscale dari URL:*
${prefix}${cmd} <image_url>

*2. Upscale dari Reply Gambar:*
Reply gambar, lalu ketik: ${prefix}${cmd}

*3. Upscale Langsung:*
Kirim gambar dengan caption: ${prefix}${cmd}

📋 *Supported Formats:*
- JPG/JPEG
- PNG
- GIF
- WEBP

💡 *Fitur:*
- Upscale otomatis dengan AI
- Kualitas tinggi
- Proses cepat

*Contoh:*
${prefix}${cmd} https://example.com/photo.jpg
`;
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    let prefix = usedPrefix || '.';
    const cmd = command || 'upscale';
    
    try {
        // Ambil input text
        let inputText = '';
        if (text) {
            inputText = text.trim();
        } else if (args && args.length > 0) {
            inputText = args.join(' ').trim();
        }
        
        // Cek apakah user minta help
        if (inputText.toLowerCase() === 'help' || inputText === '?') {
            return m.reply(generateUsageHelp(prefix, cmd));
        }
        
        // React dengan emoji loading
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        let result;
        let upscaleUrl = null;
        let mediaBuffer = null;
        let mime = '';
        
        // ========== EXTRACT RAW MESSAGE & CONTEXT INFO ==========
        // Sama seperti upload handler - akses raw Baileys message
        let rawMessage = m.message;
        let contextInfo = null;
        let quotedMessage = null;
        
        // Extract contextInfo berdasarkan tipe message
        if (rawMessage) {
            if (rawMessage.extendedTextMessage) {
                // Untuk pesan text dengan quote
                contextInfo = rawMessage.extendedTextMessage.contextInfo;
            } else if (rawMessage.imageMessage) {
                // Untuk pesan gambar langsung
                contextInfo = rawMessage.imageMessage.contextInfo;
            } else if (rawMessage.videoMessage) {
                // Untuk pesan video
                contextInfo = rawMessage.videoMessage.contextInfo;
            }
            
            // Extract quoted message dari contextInfo
            if (contextInfo) {
                quotedMessage = contextInfo.quotedMessage;
            }
        }
        
        // ========== SCENARIO 1: UPSCALE FROM URL ==========
        if (inputText && (inputText.startsWith('http://') || inputText.startsWith('https://'))) {
            console.log('[Upscale Handler] Processing URL upscale');
            
            try {
                new URL(inputText);
            } catch (e) {
                console.error('[Upscale Handler] Invalid URL:', e.message);
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply('❌ URL tidak valid!\n\n💡 Pastikan URL dimulai dengan http:// atau https://');
            }
            
            result = await upscaleImageFromUrl(inputText);
            if (result.success) {
                upscaleUrl = result.upscaleUrl;
            }
        }
        // ========== SCENARIO 2 & 3: UPSCALE FROM IMAGE ==========
        else {
            // Check 1: Direct image message (gambar dikirim dengan caption)
            if (rawMessage?.imageMessage) {
                console.log('[Upscale Handler] Processing direct image');
                mime = rawMessage.imageMessage.mimetype || 'image/jpeg';
                mediaBuffer = await downloadMedia(rawMessage);
            }
            // Check 2: Quoted image (reply gambar)
            // quotedMessage diambil dari contextInfo yang masih ada di raw message
            // Ini lebih reliable daripada m.quoted karena tidak bergantung pada store
            else if (quotedMessage?.imageMessage) {
                console.log('[Upscale Handler] Processing quoted image');
                mime = quotedMessage.imageMessage.mimetype || 'image/jpeg';
                mediaBuffer = await downloadMedia(quotedMessage);
            }
            // Check 3: Fallback ke m.quoted (jika ada di store)
            else if (m.quoted?.message?.imageMessage) {
                console.log('[Upscale Handler] Processing from m.quoted');
                mime = m.quoted.message.imageMessage.mimetype || 'image/jpeg';
                mediaBuffer = await downloadMedia(m.quoted.message);
            }
            else {
                console.log('[Upscale Handler] No image found');
            }
            
            // Process buffer jika ditemukan
            if (mediaBuffer && mime) {
                // Validasi format gambar
                if (!/image\/(jpe?g|png|gif|webp)/.test(mime)) {
                    console.error('[Upscale Handler] Unsupported format:', mime);
                    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                    return m.reply('⚠️ Format tidak didukung! Hanya jpg/png/gif/webp.');
                }
                
                // Generate filename
                const ext = mime.split('/')[1].replace('jpeg', 'jpg');
                const filename = `image_${Date.now()}.${ext}`;
                
                // Upload buffer ke server terlebih dahulu
                console.log('[Upscale Handler] Uploading image to server first');
                const uploadResult = await uploadImageBuffer(mediaBuffer, filename);
                
                if (uploadResult.success && uploadResult.url) {
                    // Setelah berhasil upload, upscale dari URL
                    console.log('[Upscale Handler] Now upscaling from uploaded URL');
                    result = await upscaleImageFromUrl(uploadResult.url);
                    
                    if (result.success) {
                        upscaleUrl = result.upscaleUrl;
                    }
                } else {
                    console.error('[Upscale Handler] Upload failed');
                    result = { success: false, message: uploadResult.message || 'Gagal upload gambar ke server' };
                }
            }
        }
        
        // ========== SEND RESULT ==========
        if (!result) {
            // Tidak ada input yang valid
            console.log('[Upscale Handler] No valid input');
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            
            return m.reply(`❌ Input tidak valid!\n\n💡 Cara penggunaan:\n\n*Upscale dari URL:*\n${prefix}${cmd} <image_url>\n\n*Upscale dari Reply:*\nReply gambar, lalu ketik: ${prefix}${cmd}\n\n*Upscale Langsung:*\nKirim gambar dengan caption: ${prefix}${cmd}\n\n📌 Ketik ${prefix}${cmd} help untuk panduan lengkap`);
        }
        
        const resultMessage = formatUpscaleResult(result);
        
        if (upscaleUrl) {
            // Upscale berhasil - kirim dengan preview gambar
            console.log('[Upscale Handler] Success - sending result with upscaled image');
            
            await conn.sendMessage(m.chat, {
                image: { url: upscaleUrl },
                caption: resultMessage
            }, { quoted: m });
            
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } else {
            // Upscale gagal - kirim pesan error
            console.log('[Upscale Handler] Failed - sending error message');
            
            await conn.sendMessage(m.chat, {
                text: resultMessage
            }, { quoted: m });
            
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        }
        
    } catch (error) {
        // Error handling - semua error di-log di console saja
        console.error('[Upscale Handler] CRITICAL ERROR:', error.message);
        console.error('[Upscale Handler] Stack:', error.stack);
        
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        
        // Kirim pesan error singkat ke user
        return m.reply(`❌ Terjadi kesalahan saat upscale.\n💡 Coba lagi atau ketik ${usedPrefix || '.'}${command || 'upscale'} help`);
    }
};

// ========== HANDLER PROPERTIES ==========
handler.help = ["upscale <url> atau kirim/reply gambar"];
handler.tags = ["tools"];
handler.command = ["upscale", "ups", "upimg"];
handler.limit = true;

console.log('[Upscale Handler] Handler loaded successfully');

export default handler;