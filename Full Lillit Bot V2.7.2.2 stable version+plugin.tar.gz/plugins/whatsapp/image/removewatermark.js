import fetch from 'node-fetch';
import FormData from 'form-data';
import { downloadContentFromMessage } from 'baileys';

console.log('[RemoveWatermark Handler] Loading handler...');

// ========== CONFIGURATION ==========
const GRADIO_SPACE_URL = 'https://selfit-remove-watermark.hf.space';
const TIMEOUT_MS = 120000;
const MAX_RETRIES = 3;
const RETRY_DELAY = 5000;
let DEBUG_MODE = false;
const KNOWN_FN_INDEX = 4;
const ENABLE_AUTO_DISCOVERY = false;
const MAX_FN_INDEX_SEARCH = 20;

// ========== DEBUG LOGGER ==========
function debugLog(category, message, data = null) {
    if (!DEBUG_MODE) return;
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] [${category}] ${message}`);
    if (data) {
        console.log(`[${timestamp}] [${category}] Data:`, typeof data === 'string' ? data : JSON.stringify(data, null, 2));
    }
}

// ========== TOGGLE DEBUG ==========
function toggleDebugMode(enable = null) {
    if (enable === null) {
        DEBUG_MODE = !DEBUG_MODE;
    } else {
        DEBUG_MODE = !!enable;
    }
    return DEBUG_MODE;
}

// ========== GENERATE SESSION HASH ==========
function generateSessionHash() {
    return Math.random().toString(36).substring(2, 15);
}

// ========== DOWNLOAD MEDIA ==========
async function downloadMedia(message) {
    try {
        const mimeMap = {
            imageMessage: 'image',
            videoMessage: 'video',
            stickerMessage: 'sticker',
            documentMessage: 'document',
            audioMessage: 'audio'
        };

        const msgKeys = Object.keys(message || {});
        if (msgKeys.length === 0) return null;

        const type = msgKeys[0];
        if (!type) return null;

        const m = message[type];
        if (!m) return null;

        const mediaType = mimeMap[type];
        if (!mediaType) return null;

        const stream = await downloadContentFromMessage(m, mediaType);
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        
        return Buffer.concat(chunks);
    } catch (error) {
        console.error('[RemoveWatermark] Error downloading media:', error);
        return null;
    }
}

// ========== DOWNLOAD FROM URL ==========
async function downloadFromUrl(url) {
    try {
        debugLog('DOWNLOAD', 'Downloading from URL:', url);
        
        const response = await fetch(url, {
            timeout: 30000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status}`);
        }
        
        const buffer = await response.buffer();
        debugLog('DOWNLOAD', 'Downloaded, size:', buffer.length);
        return buffer;
    } catch (error) {
        debugLog('DOWNLOAD', 'Error:', error.message);
        return null;
    }
}

// ========== VALIDATE URL ==========
function extractImageUrl(text) {
    if (!text) return null;
    
    const urlPattern = /https?:\/\/[^\s]+\.(jpg|jpeg|png|gif|webp|bmp)/i;
    const match = text.match(urlPattern);
    
    if (match) return match[0];
    
    if (/^https?:\/\//i.test(text)) {
        return text.trim();
    }
    
    return null;
}

// ========== UPLOAD IMAGE TO GRADIO ==========
async function uploadImageToGradio(imageBuffer, fileName = 'image.jpg') {
    try {
        console.log(`[UPLOAD] Uploading image: ${fileName} (${(imageBuffer.length / 1024).toFixed(2)} KB)`);
        debugLog('UPLOAD', 'Starting image upload');
        
        const uploadId = Math.random().toString(36).substring(2, 15);
        const uploadUrl = `${GRADIO_SPACE_URL}/gradio_api/upload?upload_id=${uploadId}`;
        
        debugLog('UPLOAD', 'Upload URL:', uploadUrl);
        
        const form = new FormData();
        form.append('files', imageBuffer, {
            filename: fileName,
            contentType: 'image/jpeg'
        });
        
        const uploadResponse = await fetch(uploadUrl, {
            method: 'POST',
            body: form,
            headers: form.getHeaders(),
            timeout: 60000
        });
        
        console.log(`[UPLOAD] Upload response status: ${uploadResponse.status}`);
        
        if (!uploadResponse.ok) {
            throw new Error(`Image upload failed: ${uploadResponse.status}`);
        }
        
        const uploadResult = await uploadResponse.json();
        
        if (!uploadResult || uploadResult.length === 0) {
            throw new Error('No upload result received');
        }
        
        const filePath = uploadResult[0];
        console.log(`[UPLOAD] ✓ Image uploaded successfully`);
        
        return filePath;
        
    } catch (error) {
        console.error(`[UPLOAD] Upload error:`, error.message);
        throw error;
    }
}

// ========== PARSE SSE STREAM ==========
async function parseSSEStream(response) {
    try {
        debugLog('SSE', 'Starting to parse SSE stream');
        
        const text = await response.text();
        const lines = text.split('\n');
        const events = [];
        
        for (const line of lines) {
            if (line.startsWith('data: ')) {
                try {
                    const data = JSON.parse(line.substring(6));
                    events.push(data);
                    
                    if (data.msg === 'estimation') {
                        console.log(`[SSE] Queue position: ${data.rank}, ETA: ${data.rank_eta?.toFixed(1)}s`);
                    } else if (data.msg === 'process_starts') {
                        console.log(`[SSE] Processing started!`);
                    } else if (data.msg === 'process_completed') {
                        console.log(`[SSE] Processing completed!`);
                    }
                    
                    debugLog('SSE', `Event [${data.msg}]:`, data);
                } catch (e) {
                    debugLog('SSE', 'Failed to parse line');
                }
            }
        }
        
        const completeEvent = events.find(e => e.msg === 'process_completed');
        if (completeEvent) {
            return completeEvent;
        }
        
        const errorEvent = events.find(e => e.msg === 'error' || e.success === false);
        if (errorEvent) {
            throw new Error(errorEvent.output?.error || 'Processing error occurred');
        }
        
        return events[events.length - 1];
        
    } catch (error) {
        debugLog('SSE', 'Parse error:', error.message);
        throw error;
    }
}

// ========== PROCESS GRADIO RESULT ==========
async function processGradioResult(result) {
    try {
        console.log(`[PROCESS] Processing result...`);
        
        if (!result.output || !result.output.data) {
            throw new Error('No output data in result');
        }
        
        const output = result.output.data;
        
        if (!Array.isArray(output)) {
            throw new Error('Output is not an array');
        }
        
        const imageData = output[0];
        let statusMessage = output[1];
        
        if (typeof statusMessage === 'object' && statusMessage !== null) {
            if (statusMessage.__type__ === 'update') {
                statusMessage = 'Watermark removal completed';
            } else {
                statusMessage = JSON.stringify(statusMessage);
            }
        }
        
        console.log(`[PROCESS] Status: ${statusMessage}`);
        
        if (!imageData || typeof imageData !== 'object') {
            throw new Error('Invalid image data');
        }
        
        if (imageData.__type__ === 'update') {
            throw new Error('Received update-only response');
        }
        
        let downloadUrl = '';
        
        if (imageData.url) {
            downloadUrl = imageData.url;
            console.log(`[PROCESS] Using direct URL from response`);
        } else if (imageData.path) {
            downloadUrl = `${GRADIO_SPACE_URL}/gradio_api/file=${imageData.path}`;
            console.log(`[PROCESS] Constructed URL from path`);
        } else {
            throw new Error('No URL or path in image data');
        }
        
        if (!downloadUrl.startsWith('http')) {
            throw new Error('Invalid download URL format');
        }
        
        console.log(`[PROCESS] Downloading result...`);
        
        const imageResponse = await fetch(downloadUrl, {
            timeout: 30000,
            headers: {
                'User-Agent': 'Mozilla/5.0',
                'Referer': `${GRADIO_SPACE_URL}/`
            }
        });
        
        if (!imageResponse.ok) {
            throw new Error(`Download failed: ${imageResponse.status}`);
        }
        
        const resultBuffer = await imageResponse.buffer();
        console.log(`[PROCESS] Downloaded result: ${(resultBuffer.length / 1024).toFixed(2)} KB`);
        
        if (resultBuffer.length === 0) {
            throw new Error('Downloaded buffer is empty');
        }
        
        console.log(`[PROCESS] ✓ Watermark removal completed successfully\n`);
        
        return { 
            success: true, 
            resultBuffer,
            status: statusMessage
        };
        
    } catch (error) {
        console.error(`[PROCESS] Processing error:`, error.message);
        return { success: false, message: error.message };
    }
}

// ========== REMOVE WATERMARK WITH GRADIO ==========
async function removeWatermarkWithGradio(imageBuffer, fileName, forceRemoval = false, retryCount = 0) {
    const startTime = Date.now();
    
    try {
        console.log(`\n${'='.repeat(60)}`);
        console.log(`[REMOVE-WM] Attempt ${retryCount + 1}/${MAX_RETRIES + 1}`);
        console.log(`[REMOVE-WM] Image: ${fileName}`);
        console.log(`[REMOVE-WM] Size: ${(imageBuffer.length / 1024).toFixed(2)} KB`);
        console.log(`[REMOVE-WM] Force Mode: ${forceRemoval ? 'ON' : 'OFF'}`);
        console.log(`${'='.repeat(60)}\n`);
        
        const imagePath = await uploadImageToGradio(imageBuffer, fileName);
        
        const sessionHash = generateSessionHash();
        console.log(`[REMOVE-WM] Session hash: ${sessionHash}`);
        console.log(`[REMOVE-WM] Trying fn_index: ${KNOWN_FN_INDEX}`);
        
        const joinUrl = `${GRADIO_SPACE_URL}/gradio_api/queue/join?__theme=system`;
        
        const joinPayload = {
            data: [
                {
                    path: imagePath,
                    url: `${GRADIO_SPACE_URL}/gradio_api/file=${imagePath}`,
                    orig_name: fileName,
                    size: imageBuffer.length,
                    mime_type: 'image/jpeg',
                    is_stream: false,
                    meta: { _type: 'gradio.FileData' }
                },
                forceRemoval
            ],
            event_data: null,
            fn_index: KNOWN_FN_INDEX,
            session_hash: sessionHash
        };
        
        console.log(`[REMOVE-WM] Joining queue...`);
        
        const joinResponse = await fetch(joinUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Referer': `${GRADIO_SPACE_URL}/?__theme=system`
            },
            body: JSON.stringify(joinPayload),
            timeout: 30000
        });
        
        console.log(`[REMOVE-WM] Queue join response status: ${joinResponse.status}`);
        
        if (!joinResponse.ok) {
            throw new Error(`Queue join failed: ${joinResponse.status}`);
        }
        
        const joinResult = await joinResponse.json();
        
        if (!joinResult.event_id) {
            throw new Error('No event_id received');
        }
        
        console.log(`[REMOVE-WM] Event ID: ${joinResult.event_id}`);
        console.log(`[REMOVE-WM] Waiting for processing (10-30 seconds)...`);
        
        const dataUrl = `${GRADIO_SPACE_URL}/gradio_api/queue/data?session_hash=${sessionHash}`;
        const dataResponse = await fetch(dataUrl, {
            timeout: TIMEOUT_MS,
            headers: {
                'Accept': 'text/event-stream',
                'Referer': `${GRADIO_SPACE_URL}/?__theme=system`
            }
        });
        
        if (!dataResponse.ok) {
            throw new Error(`Data fetch failed: ${dataResponse.status}`);
        }
        
        const result = await parseSSEStream(dataResponse);
        
        if (!result) {
            throw new Error('Failed to parse SSE stream');
        }
        
        const elapsedTime = ((Date.now() - startTime) / 1000).toFixed(2);
        console.log(`[REMOVE-WM] Processing completed in ${elapsedTime}s`);
        console.log(`${'='.repeat(60)}\n`);
        
        return await processGradioResult(result);
        
    } catch (error) {
        const elapsedTime = ((Date.now() - startTime) / 1000).toFixed(2);
        console.error(`[REMOVE-WM] Error after ${elapsedTime}s:`, error.message);
        
        if (retryCount < MAX_RETRIES) {
            console.log(`[REMOVE-WM] Retrying in ${RETRY_DELAY / 1000}s...`);
            await new Promise(resolve => setTimeout(resolve, RETRY_DELAY));
            return removeWatermarkWithGradio(imageBuffer, fileName, forceRemoval, retryCount + 1);
        }
        
        console.error(`[REMOVE-WM] All retry attempts failed`);
        return { success: false, message: error.message };
    }
}

// ========== HELP MESSAGE ==========
function generateUsageHelp(prefix, cmd) {
    return `*🧽 AI WATERMARK REMOVER*

📌 *Cara Penggunaan:*

*1. Reply Gambar:*
Reply gambar dengan: ${prefix}${cmd}

*2. Kirim Gambar:*
Kirim gambar dengan caption: ${prefix}${cmd}

*3. Dari URL:*
${prefix}${cmd} https://example.com/image.jpg

*4. Force Mode:*
${prefix}${cmd} force

📋 *Fitur:*
- Remove watermark otomatis
- Force Mode untuk watermark kompleks
- Support: JPG, PNG, WEBP, GIF
- Max size: 5MB

*Contoh:*
${prefix}${cmd}
${prefix}${cmd} force

⏱️ Proses: 10-30 detik
🤖 AI: Selfit Watermark Remover`;
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, text, usedPrefix, command }) => {
    const prefix = usedPrefix || '.';
    const cmd = command || 'removewm';
    
    try {
        const inputText = text?.trim() || '';
        
        if (inputText.toLowerCase() === 'debug') {
            const newStatus = toggleDebugMode();
            return m.reply(`🔧 Debug: ${newStatus ? 'ON' : 'OFF'}`);
        }
        
        if (inputText.toLowerCase().startsWith('debug ')) {
            const debugCmd = inputText.substring(6).trim().toLowerCase();
            if (debugCmd === 'on') {
                toggleDebugMode(true);
                return m.reply(`✅ Debug Enabled`);
            } else if (debugCmd === 'off') {
                toggleDebugMode(false);
                return m.reply(`❌ Debug Disabled`);
            }
        }
        
        if (inputText.toLowerCase() === 'help' || inputText === '?') {
            return m.reply(generateUsageHelp(prefix, cmd));
        }
        
        const forceRemoval = inputText.toLowerCase().includes('force');
        
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        let imageBuffer = null;
        let fromUrl = false;
        
        const cleanText = inputText.replace(/force/gi, '').trim();
        const imageUrl = extractImageUrl(cleanText);
        if (imageUrl) {
            imageBuffer = await downloadFromUrl(imageUrl);
            fromUrl = true;
        }
        
        if (!imageBuffer) {
            const rawMessage = m.message;
            let contextInfo = null;
            let quotedMessage = null;
            
            if (rawMessage) {
                if (rawMessage.extendedTextMessage) {
                    contextInfo = rawMessage.extendedTextMessage.contextInfo;
                } else if (rawMessage.imageMessage) {
                    contextInfo = rawMessage.imageMessage.contextInfo;
                }
                
                if (contextInfo) {
                    quotedMessage = contextInfo.quotedMessage;
                }
            }
            
            if (rawMessage?.imageMessage) {
                imageBuffer = await downloadMedia(rawMessage);
            } else if (quotedMessage?.imageMessage) {
                imageBuffer = await downloadMedia(quotedMessage);
            } else if (m.quoted?.message?.imageMessage) {
                imageBuffer = await downloadMedia(m.quoted.message);
            }
        }
        
        if (!imageBuffer) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ Kirim/reply gambar dengan caption *${prefix}${cmd}*\n\nKetik ${prefix}${cmd} help untuk bantuan`);
        }
        
        if (imageBuffer.length > 5 * 1024 * 1024) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply('❌ Ukuran gambar terlalu besar! Max 5MB');
        }
        
        console.log(`\n${'━'.repeat(60)}`);
        console.log(`[HANDLER] New REMOVE-WM request`);
        console.log(`[HANDLER] Chat: ${m.chat}`);
        console.log(`[HANDLER] From: ${fromUrl ? 'URL' : 'Upload'}`);
        console.log(`[HANDLER] Force: ${forceRemoval ? 'ON' : 'OFF'}`);
        console.log(`[HANDLER] Size: ${(imageBuffer.length / 1024).toFixed(2)} KB`);
        console.log(`${'━'.repeat(60)}\n`);
        
        await conn.sendMessage(m.chat, { react: { text: '🧽', key: m.key } });
        
        const startTime = Date.now();
        const fileName = `watermark_${Date.now()}.jpg`;
        
        const result = await removeWatermarkWithGradio(imageBuffer, fileName, forceRemoval);
        
        if (!result.success) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ Gagal remove watermark\n\nError: ${result.message}\n\n💡 Coba: ${prefix}${cmd} force`);
        }
        
        const totalTime = ((Date.now() - startTime) / 1000).toFixed(2);
        const sourceInfo = fromUrl ? '🔗 URL' : '📸 Upload';
        const modeInfo = forceRemoval ? '💪 Force' : '🧽 Normal';
        const caption = `*🧽 WATERMARK REMOVED*\n\n${sourceInfo} | ${modeInfo}\n⏱️ ${totalTime}s\n🤖 Selfit AI`;
        
        await conn.sendMessage(m.chat, {
            image: result.resultBuffer,
            caption: caption,
            mimetype: 'image/jpeg'
        }, { quoted: m });
        
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
        console.log(`[HANDLER] ✓ Complete! Time: ${totalTime}s`);
        console.log(`${'━'.repeat(60)}\n`);
        
    } catch (error) {
        console.error('[HANDLER] ERROR:', error.message);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        return m.reply(`❌ Terjadi error\n\nKetik ${usedPrefix}${command} help untuk bantuan`);
    }
};

handler.help = ["nowm - remove watermark"];
handler.tags = ["tools"];
handler.command = ["removewm", "removewatermark", "nowm"];
handler.limit = true;

console.log('[RemoveWatermark Handler] Handler loaded successfully');

export default handler;