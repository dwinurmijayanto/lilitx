import fetch from 'node-fetch';
console.log('[ATTP Handler] Loading handler...');

// ========== CONFIGURATION ==========
const ATTP_API_URL = 'https://api.deline.web.id/maker/attp';
const TIMEOUT_MS = 45000;           // lebih pendek karena animasi biasanya cepat
const MAX_TEXT_LENGTH = 60;         // biar tidak overflow di animasi

// ========== FORMAT FUNCTIONS ==========
function generateUsageHelp(prefix, cmd) {
    return `*🎨 ATTP - Animated Text Sticker*
📌 *Cara Penggunaan:*
${prefix}${cmd} <teks>

*Parameter:*
• *teks* - Teks yang akan dianimasikan (max ${MAX_TEXT_LENGTH} karakter)

*Contoh:*
${prefix}${cmd} Madyaa Cantik
${prefix}${cmd} Selamat Ulang Tahun!
${prefix}${cmd} Jangan Lupa Minum Air

Ketik *${prefix}${cmd}* atau *${prefix}${cmd} help* untuk info ini lagi.
`;
}

/**
 * Parse input
 * @param {string} input - Raw input
 * @returns {Object} - {text, error}
 */
function parseParameters(input) {
    if (!input || typeof input !== 'string' || input.trim().length === 0) {
        return { error: 'Teks tidak boleh kosong! Contoh: .attp Halo ganteng' };
    }
    const text = input.trim();
    if (text.length > MAX_TEXT_LENGTH) {
        return { error: `Teks terlalu panjang! Maksimal ${MAX_TEXT_LENGTH} karakter.\nKarakter sekarang: ${text.length}` };
    }
    return { text };
}

// ========== ATTP GENERATION ==========
async function generateATTP(text) {
    try {
        console.log('[ATTP Handler] Generating ATTP with text:', text);
        const params = new URLSearchParams({ text });
        const apiUrl = `${ATTP_API_URL}?${params.toString()}`;
        console.log('[ATTP Handler] API URL:', apiUrl);

        const fetchPromise = fetch(apiUrl, { 
            method: 'GET',
            timeout: TIMEOUT_MS 
        });

        const timeoutPromise = new Promise((_, reject) =>
            setTimeout(() => reject(new Error(`Timeout setelah ${TIMEOUT_MS/1000} detik`)), TIMEOUT_MS)
        );

        const response = await Promise.race([fetchPromise, timeoutPromise]);

        if (!response.ok) {
            throw new Error(`HTTP ${response.status} - ${response.statusText}`);
        }

        const contentType = response.headers.get('content-type');
        console.log('[ATTP Handler] Content-Type:', contentType);

        if (!contentType || (!contentType.includes('image') && !contentType.includes('gif'))) {
            let errorText = await response.text();
            try { const json = JSON.parse(errorText); errorText = json.error || json.message || errorText; } catch {}
            throw new Error(`API tidak mengembalikan gambar/animasi: ${errorText}`);
        }

        const buffer = await response.buffer();
        if (!buffer || buffer.length < 1000) { // minimal size check
            throw new Error('Buffer kosong atau terlalu kecil');
        }

        console.log('[ATTP Handler] Success, size:', buffer.length, 'bytes');
        return { success: true, buffer };
    } catch (error) {
        console.error('[ATTP Handler] Error:', error.message);
        return { success: false, message: error.message };
    }
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    const prefix = usedPrefix || '.';
    const cmd = command || 'attp';

    try {
        let inputText = (text || '').trim() || (args || []).join(' ').trim();

        if (!inputText || inputText.toLowerCase() === 'help' || inputText === '?') {
            return m.reply(generateUsageHelp(prefix, cmd));
        }

        const params = parseParameters(inputText);
        if (params.error) {
            return m.reply(`❌ ${params.error}\n\nKetik *${prefix}${cmd}* untuk bantuan`);
        }

        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        const result = await generateATTP(params.text);

        if (!result.success) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ Gagal membuat ATTP!\n*Error:* ${result.message}\n\nCoba lagi atau ketik *${prefix}${cmd} help*`);
        }

        await conn.sendMessage(m.chat, { react: { text: '🎨', key: m.key } });

        // Kirim sebagai sticker animated (WA support GIF → otomatis jadi sticker animasi)
        await conn.sendMessage(m.chat, {
            sticker: result.buffer,
            // caption: `ATTP: ${params.text}` // optional, kalau mau ada teks di bawah sticker
        }, { quoted: m });

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (error) {
        console.error('[ATTP Handler] CRITICAL:', error);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        m.reply(`❌ Error sistem: ${error.message}\nKetik *${prefix}${cmd} help* untuk bantuan`);
    }
};

// ========== PROPERTIES ==========
handler.help = ["attp <teks> - buat animated text sticker"];
handler.tags = ["sticker", "maker"];
handler.command = ["attp", "attptext", "texttoanimated"];
handler.limit = true; // kalau bot kamu pakai fitur limit

console.log('[ATTP Handler] Handler loaded successfully');
export default handler;