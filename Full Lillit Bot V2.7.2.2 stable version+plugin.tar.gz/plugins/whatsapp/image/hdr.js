import fetch from 'node-fetch';
import { downloadContentFromMessage } from 'baileys';

console.log('[HD Handler] Loading handler...');

// ========== CONFIGURATION ==========
const HD_API_URL = 'https://upload.vbi1.my.id/tool/picsartenhancer.php';
const TIMEOUT_MS = 120000; // 120 detik timeout

// ========== DOWNLOAD MEDIA FUNCTION ==========
/**
 * Download media dari Baileys message
 * @param {Object} message - Raw Baileys message object
 * @returns {Buffer|null} - Media buffer atau null jika gagal
 */
async function downloadMedia(message) {
    try {
        const mimeMap = {
            imageMessage: 'image',
            videoMessage: 'video',
            stickerMessage: 'sticker',
            documentMessage: 'document',
            audioMessage: 'audio'
        };

        const msgKeys = Object.keys(message || {});
        if (msgKeys.length === 0) return null;

        const type = msgKeys[0];
        if (!type) return null;

        const m = message[type];
        if (!m) return null;

        const mediaType = mimeMap[type];
        if (!mediaType) return null;

        const stream = await downloadContentFromMessage(m, mediaType);
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        
        return Buffer.concat(chunks);
    } catch (error) {
        console.error('[HD Handler] Error downloading media:', error);
        return null;
    }
}

// ========== UPLOAD IMAGE TO GET URL ==========
/**
 * Upload buffer ke temporary hosting untuk mendapat URL
 * @param {Buffer} mediaBuffer - Image buffer
 * @returns {Object} - {success, url, message}
 */
async function uploadImageToGetUrl(mediaBuffer) {
    try {
        console.log('[HD Handler] Uploading image to get URL, size:', mediaBuffer.length, 'bytes');
        
        const FormData = (await import('form-data')).default;
        const formData = new FormData();
        formData.append('file', mediaBuffer, {
            filename: 'image.jpg',
            contentType: 'image/jpeg'
        });
        
        const uploadPromise = fetch('https://tmpfiles.org/api/v1/upload', {
            method: 'POST',
            body: formData,
            headers: formData.getHeaders()
        });
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Upload timeout')), 30000)
        );
        
        const response = await Promise.race([uploadPromise, timeoutPromise]);
        
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status}`);
        }
        
        const result = await response.json();
        
        if (result.status === 'success' && result.data?.url) {
            const imageUrl = result.data.url.replace('tmpfiles.org/', 'tmpfiles.org/dl/');
            console.log('[HD Handler] Upload success:', imageUrl);
            return { success: true, url: imageUrl };
        } else {
            throw new Error('Upload failed - no URL in response');
        }
    } catch (error) {
        console.error('[HD Handler] Upload error:', error.message);
        return { success: false, message: error.message };
    }
}

// ========== HD ENHANCEMENT FROM URL ==========
/**
 * Enhance gambar menggunakan VBI Picsart API
 * @param {string} imageUrl - URL gambar yang akan di-enhance
 * @returns {Object} - {success, imageUrl, message}
 */
async function enhanceImageFromUrl(imageUrl) {
    try {
        console.log('[HD Handler] Enhancing image from URL:', imageUrl);
        
        const apiUrl = `${HD_API_URL}?url=${encodeURIComponent(imageUrl)}`;
        
        const enhancePromise = fetch(apiUrl, {
            method: 'GET',
            timeout: TIMEOUT_MS
        });
        
        const timeoutPromise = new Promise((_, reject) =>
            setTimeout(() => reject(new Error(`Timeout setelah ${TIMEOUT_MS}ms`)), TIMEOUT_MS)
        );
        
        const response = await Promise.race([enhancePromise, timeoutPromise]);
        
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status} ${response.statusText}`);
        }
        
        const result = await response.json();
        
        // Check VBI API response format
        if (result.status === true && result.result) {
            console.log('[HD Handler] Enhancement complete, result URL:', result.result);
            
            // Download enhanced image
            const imageResponse = await fetch(result.result);
            if (!imageResponse.ok) {
                throw new Error('Failed to download enhanced image');
            }
            
            const arrayBuffer = await imageResponse.arrayBuffer();
            const imageBuffer = Buffer.from(arrayBuffer);
            
            if (!imageBuffer || imageBuffer.length === 0) {
                throw new Error('Enhancement failed - empty image buffer');
            }
            
            console.log('[HD Handler] Downloaded enhanced image, size:', imageBuffer.length, 'bytes');
            return { success: true, imageBuffer: imageBuffer };
        } else {
            throw new Error(result.message || 'Enhancement failed');
        }
    } catch (error) {
        console.error('[HD Handler] Enhancement error:', error.message);
        return { success: false, message: error.message };
    }
}

// ========== FORMAT FUNCTIONS ==========
/**
 * Generate help message
 * @param {string} prefix - Command prefix
 * @param {string} cmd - Command name
 * @returns {string} - Help message
 */
function generateUsageHelp(prefix, cmd) {
    return `*🎬 HD IMAGE ENHANCEMENT*
_Powered by VBI API_

📌 *Cara Penggunaan:*

*1. HD dari Reply Gambar:*
Reply gambar, lalu ketik: ${prefix}${cmd}

*2. HD Langsung (dengan caption):*
Kirim gambar dengan caption: ${prefix}${cmd}

📋 *Supported Formats:*
- JPG/JPEG
- PNG
- GIF
- WEBP

⚙️ *Fitur:*
- Auto Upscale 4x
- Face Enhancement
- Color Correction
- High Quality Output

*Contoh:*
${prefix}${cmd}
`;
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    let prefix = usedPrefix || '.';
    const cmd = command || 'hd';
    
    try {
        // Ambil input text
        let inputText = '';
        if (text) {
            inputText = text.trim();
        } else if (args && args.length > 0) {
            inputText = args.join(' ').trim();
        }
        
        // Cek apakah user minta help
        if (inputText.toLowerCase() === 'help' || inputText === '?') {
            return m.reply(generateUsageHelp(prefix, cmd));
        }
        
        // React dengan emoji loading
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        let mediaBuffer = null;
        let mime = '';
        
        // Extract raw message & context
        let rawMessage = m.message;
        let contextInfo = null;
        let quotedMessage = null;
        
        if (rawMessage) {
            if (rawMessage.extendedTextMessage) {
                contextInfo = rawMessage.extendedTextMessage.contextInfo;
            } else if (rawMessage.imageMessage) {
                contextInfo = rawMessage.imageMessage.contextInfo;
            } else if (rawMessage.videoMessage) {
                contextInfo = rawMessage.videoMessage.contextInfo;
            }
            
            if (contextInfo) {
                quotedMessage = contextInfo.quotedMessage;
            }
        }
        
        // ========== EXTRACT IMAGE ==========
        // Check 1: Direct image message
        if (rawMessage?.imageMessage) {
            console.log('[HD Handler] Processing direct image');
            mime = rawMessage.imageMessage.mimetype || 'image/jpeg';
            mediaBuffer = await downloadMedia(rawMessage);
        }
        // Check 2: Quoted image
        else if (quotedMessage?.imageMessage) {
            console.log('[HD Handler] Processing quoted image');
            mime = quotedMessage.imageMessage.mimetype || 'image/jpeg';
            mediaBuffer = await downloadMedia(quotedMessage);
        }
        // Check 3: Fallback to m.quoted
        else if (m.quoted?.message?.imageMessage) {
            console.log('[HD Handler] Processing from m.quoted');
            mime = m.quoted.message.imageMessage.mimetype || 'image/jpeg';
            mediaBuffer = await downloadMedia(m.quoted.message);
        }
        
        // Validasi
        if (!mediaBuffer || !mime) {
            console.log('[HD Handler] No valid image found');
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            
            return m.reply(`❌ Input tidak valid!\n\n💡 Cara penggunaan:\n\n*HD dari Reply:*\nReply gambar, lalu ketik: ${prefix}${cmd}\n\n*HD Langsung:*\nKirim gambar dengan caption: ${prefix}${cmd}\n\n📌 Ketik ${prefix}${cmd} help untuk panduan lengkap`);
        }
        
        // Validasi format
        if (!/image\/(jpe?g|png|gif|webp)/.test(mime)) {
            console.error('[HD Handler] Unsupported format:', mime);
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply('⚠️ Format tidak didukung! Hanya jpg/png/gif/webp.');
        }
        
        // Update loading message
        await conn.sendMessage(m.chat, { react: { text: '📤', key: m.key } });
        
        // Step 1: Upload image to get URL
        console.log('[HD Handler] Step 1: Uploading image to get URL');
        const uploadResult = await uploadImageToGetUrl(mediaBuffer);
        
        if (!uploadResult.success) {
            console.error('[HD Handler] Upload failed:', uploadResult.message);
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ Upload gagal: ${uploadResult.message}`);
        }
        
        // Update loading message
        await conn.sendMessage(m.chat, { react: { text: '🎬', key: m.key } });
        
        // Step 2: Enhance image using URL
        console.log('[HD Handler] Step 2: Enhancing image using VBI API');
        const enhanceResult = await enhanceImageFromUrl(uploadResult.url);
        
        if (!enhanceResult.success) {
            console.error('[HD Handler] Enhancement failed:', enhanceResult.message);
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ Enhancement gagal: ${enhanceResult.message}`);
        }
        
        // Kirim hasil
        console.log('[HD Handler] Sending result');
        await conn.sendMessage(m.chat, {
            image: enhanceResult.imageBuffer,
            caption: `✅ *Gambar berhasil ditingkatkan kualitasnya!*\n\n_Powered by VBI API_`
        }, { quoted: m });
        
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (error) {
        console.error('[HD Handler] CRITICAL ERROR:', error.message);
        console.error('[HD Handler] Stack:', error.stack);
        
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        
        return m.reply(`❌ Terjadi kesalahan:\n${error.message}\n\n💡 Coba lagi atau gunakan gambar lain.`);
    }
};

// ========== HANDLER PROPERTIES ==========
handler.help = ["hd - tingkatkan kualitas gambar"];
handler.tags = ["tools"];
handler.command = ["hd", "hdr", "enhance"];
handler.limit = true;

console.log('[HD Handler] Handler loaded successfully');

export default handler;