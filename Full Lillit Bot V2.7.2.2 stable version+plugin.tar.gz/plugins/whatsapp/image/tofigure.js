import fetch from 'node-fetch';
import FormData from 'form-data';
import { downloadContentFromMessage } from 'baileys';

console.log('[ToFigura Handler] Loading handler...');

// ========== CONFIGURATION ==========
const TOFIGURA_APIS = [
    {
        name: 'ToFigura V1',
        url: 'https://api-faa.my.id/faa/tofigura',
        version: 'v1'
    },
    {
        name: 'ToFigura V2',
        url: 'https://api-faa.my.id/faa/tofigurav2',
        version: 'v2'
    },
    {
        name: 'ToFigura V3',
        url: 'https://api-faa.my.id/faa/tofigurav3',
        version: 'v3'
    }
];

const TIMEOUT_MS = 120000; // 120 detik timeout

// ========== UPLOAD SERVERS ==========
const UPLOAD_SERVERS = {
    hf: {
        url: 'https://ikyy-upload-file.hf.space/upload',
        name: 'Ikky HF'
    },
    tmpfiles: {
        url: 'https://tmpfiles.org/api/v1/upload',
        name: 'TmpFiles'
    }
};

// ========== DOWNLOAD MEDIA FUNCTION ==========
async function downloadMedia(message) {
    try {
        const mimeMap = {
            imageMessage: 'image',
            videoMessage: 'video',
            stickerMessage: 'sticker',
            documentMessage: 'document',
            audioMessage: 'audio'
        };

        const msgKeys = Object.keys(message || {});
        if (msgKeys.length === 0) return null;

        const type = msgKeys[0];
        if (!type) return null;

        const m = message[type];
        if (!m) return null;

        const mediaType = mimeMap[type];
        if (!mediaType) return null;

        const stream = await downloadContentFromMessage(m, mediaType);
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        
        return Buffer.concat(chunks);
    } catch (error) {
        console.error('[ToFigura] Error downloading media:', error);
        return null;
    }
}

// ========== UPLOAD FUNCTIONS ==========
async function uploadToHF(mediaBuffer, filename = 'image.jpg') {
    try {
        console.log('[ToFigura] Uploading to HF Space, size:', mediaBuffer.length, 'bytes');
        
        const formData = new FormData();
        formData.append('file', mediaBuffer, {
            filename: filename,
            contentType: 'image/jpeg'
        });
        
        const uploadPromise = fetch(UPLOAD_SERVERS.hf.url, {
            method: 'POST',
            body: formData,
            headers: {
                ...formData.getHeaders(),
                'Accept': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error(`Timeout setelah 30000ms`)), 30000)
        );
        
        const response = await Promise.race([uploadPromise, timeoutPromise]);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const result = await response.json();
        
        if (result.fileUrl) {
            console.log('[ToFigura] HF Upload success:', result.fileUrl);
            return { success: true, url: result.fileUrl, server: 'hf' };
        } else {
            throw new Error('Upload failed - no URL in response');
        }
    } catch (error) {
        console.error('[ToFigura] HF Upload error:', error.message);
        return { success: false, message: error.message, server: 'hf' };
    }
}

async function uploadToTmpFiles(mediaBuffer, filename = 'image.jpg') {
    try {
        console.log('[ToFigura] Uploading to TmpFiles, size:', mediaBuffer.length, 'bytes');
        
        const formData = new FormData();
        formData.append('file', mediaBuffer, {
            filename: filename,
            contentType: 'image/jpeg'
        });
        
        const uploadPromise = fetch(UPLOAD_SERVERS.tmpfiles.url, {
            method: 'POST',
            body: formData,
            headers: {
                ...formData.getHeaders(),
                'Accept': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error(`Timeout setelah 30000ms`)), 30000)
        );
        
        const response = await Promise.race([uploadPromise, timeoutPromise]);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const result = await response.json();
        
        if (result.status === 'success' && result.data && result.data.url) {
            let originalUrl = result.data.url;
            let parts = originalUrl.split('/');
            let fileId = parts[parts.length - 2];
            let fileName = parts[parts.length - 1];
            let directUrl = `https://tmpfiles.org/dl/${fileId}/${fileName}`;
            
            console.log('[ToFigura] TmpFiles Upload success:', directUrl);
            return { success: true, url: directUrl, server: 'tmpfiles' };
        } else {
            throw new Error('Upload failed - no URL in response');
        }
    } catch (error) {
        console.error('[ToFigura] TmpFiles Upload error:', error.message);
        return { success: false, message: error.message, server: 'tmpfiles' };
    }
}

// ========== MULTI-SERVER UPLOAD ==========
async function uploadImageBuffer(mediaBuffer, filename = 'image.jpg') {
    console.log('[ToFigura] Starting multi-server upload (2 servers parallel)');
    
    const results = [];
    
    // Upload ke 2 server secara paralel
    const uploadPromises = [
        uploadToHF(mediaBuffer, filename).catch(err => ({ success: false, message: err.message, server: 'hf' })),
        uploadToTmpFiles(mediaBuffer, filename).catch(err => ({ success: false, message: err.message, server: 'tmpfiles' }))
    ];
    
    const uploadResults = await Promise.all(uploadPromises);
    results.push(...uploadResults);
    
    // Cari upload yang berhasil
    const successfulUpload = results.find(r => r.success);
    
    if (successfulUpload) {
        console.log('[ToFigura] Upload success to:', successfulUpload.server);
        return { success: true, url: successfulUpload.url, server: successfulUpload.server };
    } else {
        // Semua gagal
        const errors = results.map(r => `${r.server}: ${r.message}`).join(', ');
        console.error('[ToFigura] All uploads failed:', errors);
        return { success: false, message: `All uploads failed: ${errors}` };
    }
}

// ========== SINGLE API CONVERT FUNCTION ==========
async function convertWithSingleAPI(imageUrl, api) {
    const startTime = Date.now();
    try {
        console.log(`[ToFigura] [${api.version}] Starting conversion...`);
        
        const apiUrl = `${api.url}?url=${encodeURIComponent(imageUrl)}`;
        
        const response = await fetch(apiUrl, {
            method: 'GET',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            },
            timeout: TIMEOUT_MS
        });
        
        const elapsed = Date.now() - startTime;
        
        if (!response.ok) {
            console.log(`[ToFigura] [${api.version}] Failed: HTTP ${response.status} (${elapsed}ms)`);
            throw new Error(`HTTP Error: ${response.status} ${response.statusText}`);
        }
        
        // Check Content-Type untuk menentukan apakah response berupa gambar atau JSON
        const contentType = response.headers.get('content-type') || '';
        
        // Jika response adalah gambar (binary), langsung return buffer
        if (contentType.includes('image/') || contentType.includes('application/octet-stream')) {
            const buffer = await response.buffer();
            console.log(`[ToFigura] [${api.version}] ✅ Success (Direct Image) - ${elapsed}ms - Size: ${buffer.length} bytes`);
            return { 
                success: true, 
                resultBuffer: buffer, 
                isDirect: true, 
                api: api.version,
                apiName: api.name,
                time: elapsed 
            };
        }
        
        // Jika response adalah JSON
        const result = await response.json();
        
        if (result.status && result.result) {
            console.log(`[ToFigura] [${api.version}] ✅ Success (URL) - ${elapsed}ms - URL: ${result.result}`);
            return { 
                success: true, 
                resultUrl: result.result, 
                isDirect: false, 
                api: api.version,
                apiName: api.name,
                time: elapsed 
            };
        } else {
            throw new Error('Conversion failed - no result URL in response');
        }
    } catch (error) {
        const elapsed = Date.now() - startTime;
        console.error(`[ToFigura] [${api.version}] ❌ Error (${elapsed}ms):`, error.message);
        return { 
            success: false, 
            message: error.message, 
            api: api.version,
            apiName: api.name,
            time: elapsed 
        };
    }
}

// ========== RACE CONVERT - FASTEST WINS ==========
async function convertToFiguraRace(imageUrl) {
    try {
        console.log('[ToFigura] Starting RACE conversion with 3 APIs simultaneously...');
        
        // Jalankan 3 API secara bersamaan dengan Promise.race
        // Yang tercepat dan berhasil akan menang
        const racePromises = TOFIGURA_APIS.map(api => 
            convertWithSingleAPI(imageUrl, api)
        );
        
        // Race: yang pertama selesai (sukses atau gagal) akan dikembalikan
        // Tapi kita ingin yang pertama SUKSES, bukan yang pertama selesai
        // Jadi kita gunakan Promise.any yang akan return hasil pertama yang sukses
        
        // Untuk mendapatkan hasil pertama yang sukses, kita filter hanya yang success
        const results = await Promise.allSettled(racePromises);
        
        // Ambil semua yang fulfilled dan success
        const successResults = results
            .filter(r => r.status === 'fulfilled' && r.value.success)
            .map(r => r.value)
            .sort((a, b) => a.time - b.time); // Sort by time, fastest first
        
        if (successResults.length > 0) {
            const fastest = successResults[0];
            console.log(`[ToFigura] 🏆 FASTEST API: ${fastest.apiName} (${fastest.api}) - ${fastest.time}ms`);
            
            // Log semua hasil untuk debugging
            console.log('[ToFigura] All results:');
            results.forEach((r, i) => {
                if (r.status === 'fulfilled') {
                    const result = r.value;
                    console.log(`  - ${TOFIGURA_APIS[i].version}: ${result.success ? '✅' : '❌'} ${result.time}ms`);
                } else {
                    console.log(`  - ${TOFIGURA_APIS[i].version}: ❌ Rejected`);
                }
            });
            
            return fastest;
        }
        
        // Semua gagal
        const failedResults = results
            .filter(r => r.status === 'fulfilled' && !r.value.success)
            .map(r => r.value);
        
        const errors = failedResults.map(r => `${r.api}: ${r.message}`).join(', ');
        console.error('[ToFigura] All APIs failed:', errors);
        
        return { 
            success: false, 
            message: `All APIs failed: ${errors}` 
        };
        
    } catch (error) {
        console.error('[ToFigura] Race conversion error:', error.message);
        return { success: false, message: error.message };
    }
}

// ========== DOWNLOAD RESULT IMAGE ==========
async function downloadResultImage(url) {
    try {
        console.log('[ToFigura] Downloading result from:', url);
        
        const response = await fetch(url, { 
            timeout: 60000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status} ${response.statusText}`);
        }
        
        const buffer = await response.buffer();
        console.log('[ToFigura] Download complete, size:', buffer.length, 'bytes');
        
        return buffer;
    } catch (error) {
        console.error('[ToFigura] Download error:', error.message);
        return null;
    }
}

// ========== FORMAT FUNCTIONS ==========
function generateUsageHelp(prefix, cmd) {
    return `*🎭 TOFIGURA - FIGURE STYLE CONVERTER*

📌 *Cara Penggunaan:*

*1. ToFigura dari Reply Gambar:*
Reply gambar, lalu ketik: ${prefix}${cmd}

*2. ToFigura Langsung (dengan caption):*
Kirim gambar dengan caption: ${prefix}${cmd}

📋 *Supported Formats:*
- JPG/JPEG
- PNG
- GIF
- WEBP

🎯 *Fitur ToFigura:*
- Figure/anime style conversion
- Artistic figure effect
- Professional transformation
- Creative figura processing

⚡ *Multi-API Racing:*
- Menggunakan 3 API secara bersamaan
- API tercepat yang menang
- V1, V2, V3 race untuk hasil optimal

💾 *Upload Strategy:*
- Multi-server upload (2 servers)
- Ikky HF + TmpFiles
- Auto fallback jika server gagal

*Contoh:*
${prefix}${cmd}

💡 *Perintah Lain:*
${prefix}hitamkan - Convert ke hitam putih
${prefix}putihkan - Convert ke putih
`;
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    let prefix = usedPrefix || '.';
    const cmd = command || 'tofigura';
    
    try {
        // Ambil input text
        let inputText = '';
        if (text) {
            inputText = text.trim();
        } else if (args && args.length > 0) {
            inputText = args.join(' ').trim();
        }
        
        // Cek apakah user minta help
        if (inputText.toLowerCase() === 'help' || inputText === '?') {
            return m.reply(generateUsageHelp(prefix, cmd));
        }
        
        // React dengan emoji loading - NON-BLOCKING
        conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } }).catch(() => {});
        
        let mediaBuffer = null;
        let mime = '';
        
        // Extract raw message & context
        let rawMessage = m.message;
        let contextInfo = null;
        let quotedMessage = null;
        
        if (rawMessage) {
            if (rawMessage.extendedTextMessage) {
                contextInfo = rawMessage.extendedTextMessage.contextInfo;
            } else if (rawMessage.imageMessage) {
                contextInfo = rawMessage.imageMessage.contextInfo;
            } else if (rawMessage.videoMessage) {
                contextInfo = rawMessage.videoMessage.contextInfo;
            }
            
            if (contextInfo) {
                quotedMessage = contextInfo.quotedMessage;
            }
        }
        
        // ========== EXTRACT IMAGE ==========
        // Check 1: Direct image message
        if (rawMessage?.imageMessage) {
            console.log(`[ToFigura] Processing direct image`);
            mime = rawMessage.imageMessage.mimetype || 'image/jpeg';
            mediaBuffer = await downloadMedia(rawMessage);
        }
        // Check 2: Quoted image
        else if (quotedMessage?.imageMessage) {
            console.log(`[ToFigura] Processing quoted image`);
            mime = quotedMessage.imageMessage.mimetype || 'image/jpeg';
            mediaBuffer = await downloadMedia(quotedMessage);
        }
        // Check 3: Fallback to m.quoted
        else if (m.quoted?.message?.imageMessage) {
            console.log(`[ToFigura] Processing from m.quoted`);
            mime = m.quoted.message.imageMessage.mimetype || 'image/jpeg';
            mediaBuffer = await downloadMedia(m.quoted.message);
        }
        
        // Validasi
        if (!mediaBuffer || !mime) {
            console.log(`[ToFigura] No valid image found`);
            conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
            
            return m.reply(`❌ Input tidak valid!\n💡 Cara penggunaan:\nToFigura dari Reply:\nReply gambar, lalu ketik: ${prefix}${cmd}\nToFigura Langsung:\nKirim gambar dengan caption: ${prefix}${cmd}\n📌 Ketik ${prefix}${cmd} help untuk panduan lengkap`);
        }
        
        // Validasi format
        if (!/image\/(jpe?g|png|gif|webp)/.test(mime)) {
            console.error(`[ToFigura] Unsupported format:`, mime);
            conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
            return m.reply('⚠️ Format tidak didukung! Hanya jpg/png/gif/webp.');
        }
        
        // Step 1: Upload image (multi-server) - NON-BLOCKING REACT
        conn.sendMessage(m.chat, { react: { text: '📤', key: m.key } }).catch(() => {});
        console.log(`[ToFigura] Uploading image to servers (multi-upload)`);
        
        const uploadResult = await uploadImageBuffer(mediaBuffer, 'image.jpg');
        
        if (!uploadResult.success) {
            conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
            return m.reply(`❌ Gagal upload gambar ke semua server.\n💡 Error: ${uploadResult.message}`);
        }
        
        console.log(`[ToFigura] Upload berhasil ke server: ${uploadResult.server}`);
        
        // Step 2: Convert with RACE (3 APIs simultaneously) - NON-BLOCKING REACT
        conn.sendMessage(m.chat, { react: { text: '🎭', key: m.key } }).catch(() => {});
        console.log(`[ToFigura] Starting RACE conversion with 3 APIs...`);
        
        const convertResult = await convertToFiguraRace(uploadResult.url);
        
        if (!convertResult.success) {
            conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
            return m.reply(`❌ Gagal convert gambar.\n💡 Error: ${convertResult.message}`);
        }
        
        // Step 3: Get result buffer
        let resultBuffer = null;
        
        if (convertResult.isDirect) {
            // API langsung return gambar (binary)
            console.log(`[ToFigura] Using direct buffer from API ${convertResult.api}`);
            resultBuffer = convertResult.resultBuffer;
        } else {
            // API return URL, download dulu
            conn.sendMessage(m.chat, { react: { text: '📥', key: m.key } }).catch(() => {});
            console.log(`[ToFigura] Downloading converted image from URL (API ${convertResult.api})`);
            
            resultBuffer = await downloadResultImage(convertResult.resultUrl);
            
            if (!resultBuffer) {
                conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
                return m.reply(`❌ Gagal download hasil.\n🔗 Link hasil: ${convertResult.resultUrl}`);
            }
        }
        
        // Step 4: Send result dengan mention dan info API tercepat
        console.log(`[ToFigura] Sending result`);
        
        const userTag = `@${m.sender.split('@')[0]}`;
        const caption = `✅ Gambar berhasil diubah ke figura! ${userTag}\n⚡ Diproses oleh: *${convertResult.apiName}* (${convertResult.time}ms)`;
        
        await conn.sendMessage(m.chat, {
            image: resultBuffer,
            caption: caption,
            mentions: [m.sender]
        }, { quoted: m });
        
        conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } }).catch(() => {});
        
    } catch (error) {
        console.error(`[ToFigura] CRITICAL ERROR:`, error.message);
        console.error(`[ToFigura] Stack:`, error.stack);
        
        conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        
        const msg = error.message || 'Unknown error';
        return m.reply(`❌ *Terjadi error:*\n\`\`\`\n${msg}\n\`\`\``);
    }
};

// ========== HANDLER PROPERTIES ==========
handler.help = ["tofigura - convert gambar ke figura style"];
handler.tags = ["tools"];
handler.command = ["tofigura", "tofigur", "tofigure"];
handler.limit = true;

console.log('[ToFigura Handler] Handler loaded successfully with 3-API RACE system (V1 vs V2 vs V3)');

export default handler;