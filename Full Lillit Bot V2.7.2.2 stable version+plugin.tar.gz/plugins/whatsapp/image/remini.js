import fetch from 'node-fetch';
import FormData from 'form-data';
import { downloadContentFromMessage } from 'baileys';

console.log('[Remini Handler] Loading handler...');

// ========== CONFIGURATION ==========
const UPLOAD_API_URL = 'https://uguu.se/upload.php';
const REMINI_API_URL = 'https://api.fikmydomainsz.xyz/imagecreator/remini';
const TIMEOUT_MS = 120000; // 120 detik timeout

// ========== DOWNLOAD MEDIA FUNCTION ==========
/**
 * Download media dari Baileys message
 * @param {Object} message - Raw Baileys message object
 * @returns {Buffer|null} - Media buffer atau null jika gagal
 */
async function downloadMedia(message) {
    try {
        const mimeMap = {
            imageMessage: 'image',
            videoMessage: 'video',
            stickerMessage: 'sticker',
            documentMessage: 'document',
            audioMessage: 'audio'
        };

        const msgKeys = Object.keys(message || {});
        if (msgKeys.length === 0) return null;

        const type = msgKeys[0];
        if (!type) return null;

        const m = message[type];
        if (!m) return null;

        const mediaType = mimeMap[type];
        if (!mediaType) return null;

        const stream = await downloadContentFromMessage(m, mediaType);
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        
        return Buffer.concat(chunks);
    } catch (error) {
        console.error('[Remini Handler] Error downloading media:', error);
        return null;
    }
}

// ========== UPLOAD IMAGE BUFFER ==========
/**
 * Upload buffer ke server untuk mendapat URL
 * @param {Buffer} mediaBuffer - Image buffer
 * @param {string} filename - Nama file
 * @returns {Object} - {success, url, message}
 */
async function uploadImageBuffer(mediaBuffer, filename = 'image.jpg') {
    try {
        console.log('[Remini Handler] Uploading buffer to server, size:', mediaBuffer.length, 'bytes');
        
        const formData = new FormData();
        formData.append('files[]', mediaBuffer, {
            filename: filename,
            contentType: 'image/jpeg'
        });
        
        const uploadPromise = fetch(UPLOAD_API_URL, {
            method: 'POST',
            body: formData,
            headers: formData.getHeaders()
        });
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error(`Timeout setelah 30000ms`)), 30000)
        );
        
        const response = await Promise.race([uploadPromise, timeoutPromise]);
        
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status} ${response.statusText}`);
        }
        
        const result = await response.json();
        
        if (result.success && result.files && result.files[0]?.url) {
            console.log('[Remini Handler] Upload success:', result.files[0].url);
            return { success: true, url: result.files[0].url };
        } else {
            throw new Error('Upload failed - no URL in response');
        }
    } catch (error) {
        console.error('[Remini Handler] Upload error:', error.message);
        return { success: false, message: error.message };
    }
}

// ========== REMINI ENHANCE ==========
/**
 * Enhance gambar menggunakan Remini API
 * @param {string} imageUrl - URL gambar yang akan di-enhance
 * @returns {Object} - {success, resultUrl, message}
 */
async function enhanceWithRemini(imageUrl) {
    try {
        console.log('[Remini Handler] Enhancing image from URL:', imageUrl);
        
        const apiUrl = `${REMINI_API_URL}?url=${encodeURIComponent(imageUrl)}`;
        
        const reminiPromise = fetch(apiUrl, {
            method: 'GET',
            timeout: TIMEOUT_MS
        });
        
        const timeoutPromise = new Promise((_, reject) =>
            setTimeout(() => reject(new Error(`Timeout setelah ${TIMEOUT_MS}ms`)), TIMEOUT_MS)
        );
        
        const response = await Promise.race([reminiPromise, timeoutPromise]);
        
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status} ${response.statusText}`);
        }
        
        const result = await response.json();
        
        if (result.status && result.result) {
            console.log('[Remini Handler] Enhancement success:', result.result);
            return { success: true, resultUrl: result.result };
        } else {
            throw new Error('Enhancement failed - no result URL in response');
        }
    } catch (error) {
        console.error('[Remini Handler] Enhancement error:', error.message);
        return { success: false, message: error.message };
    }
}

// ========== DOWNLOAD RESULT IMAGE ==========
/**
 * Download hasil gambar dari URL
 * @param {string} url - URL gambar hasil
 * @returns {Buffer|null} - Image buffer atau null jika gagal
 */
async function downloadResultImage(url) {
    try {
        console.log('[Remini Handler] Downloading result from:', url);
        
        const response = await fetch(url, { timeout: 60000 });
        
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status} ${response.statusText}`);
        }
        
        const buffer = await response.buffer();
        console.log('[Remini Handler] Download complete, size:', buffer.length, 'bytes');
        
        return buffer;
    } catch (error) {
        console.error('[Remini Handler] Download error:', error.message);
        return null;
    }
}

// ========== FORMAT FUNCTIONS ==========
/**
 * Generate help message
 * @param {string} prefix - Command prefix
 * @param {string} cmd - Command name
 * @returns {string} - Help message
 */
function generateUsageHelp(prefix, cmd) {
    return `*✨ REMINI IMAGE ENHANCEMENT*

📌 *Cara Penggunaan:*

*1. Remini dari Reply Gambar:*
Reply gambar, lalu ketik: ${prefix}${cmd}

*2. Remini Langsung (dengan caption):*
Kirim gambar dengan caption: ${prefix}${cmd}

📋 *Supported Formats:*
- JPG/JPEG
- PNG
- GIF
- WEBP

🎯 *Fitur Remini:*
- AI-powered enhancement
- Face enhancement
- Detail restoration
- Color correction
- Noise reduction

*Contoh:*
${prefix}${cmd}
`;
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    let prefix = usedPrefix || '.';
    const cmd = command || 'remini';
    
    try {
        // Ambil input text
        let inputText = '';
        if (text) {
            inputText = text.trim();
        } else if (args && args.length > 0) {
            inputText = args.join(' ').trim();
        }
        
        // Cek apakah user minta help
        if (inputText.toLowerCase() === 'help' || inputText === '?') {
            return m.reply(generateUsageHelp(prefix, cmd));
        }
        
        // React dengan emoji loading
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        let mediaBuffer = null;
        let mime = '';
        
        // Extract raw message & context
        let rawMessage = m.message;
        let contextInfo = null;
        let quotedMessage = null;
        
        if (rawMessage) {
            if (rawMessage.extendedTextMessage) {
                contextInfo = rawMessage.extendedTextMessage.contextInfo;
            } else if (rawMessage.imageMessage) {
                contextInfo = rawMessage.imageMessage.contextInfo;
            } else if (rawMessage.videoMessage) {
                contextInfo = rawMessage.videoMessage.contextInfo;
            }
            
            if (contextInfo) {
                quotedMessage = contextInfo.quotedMessage;
            }
        }
        
        // ========== EXTRACT IMAGE ==========
        // Check 1: Direct image message
        if (rawMessage?.imageMessage) {
            console.log('[Remini Handler] Processing direct image');
            mime = rawMessage.imageMessage.mimetype || 'image/jpeg';
            mediaBuffer = await downloadMedia(rawMessage);
        }
        // Check 2: Quoted image
        else if (quotedMessage?.imageMessage) {
            console.log('[Remini Handler] Processing quoted image');
            mime = quotedMessage.imageMessage.mimetype || 'image/jpeg';
            mediaBuffer = await downloadMedia(quotedMessage);
        }
        // Check 3: Fallback to m.quoted
        else if (m.quoted?.message?.imageMessage) {
            console.log('[Remini Handler] Processing from m.quoted');
            mime = m.quoted.message.imageMessage.mimetype || 'image/jpeg';
            mediaBuffer = await downloadMedia(m.quoted.message);
        }
        
        // Validasi
        if (!mediaBuffer || !mime) {
            console.log('[Remini Handler] No valid image found');
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            
            return m.reply(`❌ Input tidak valid!\n\n💡 Cara penggunaan:\n\n*Remini dari Reply:*\nReply gambar, lalu ketik: ${prefix}${cmd}\n\n*Remini Langsung:*\nKirim gambar dengan caption: ${prefix}${cmd}\n\n📌 Ketik ${prefix}${cmd} help untuk panduan lengkap`);
        }
        
        // Validasi format
        if (!/image\/(jpe?g|png|gif|webp)/.test(mime)) {
            console.error('[Remini Handler] Unsupported format:', mime);
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply('⚠️ Format tidak didukung! Hanya jpg/png/gif/webp.');
        }
        
        // Step 1: Upload image
        await conn.sendMessage(m.chat, { react: { text: '📤', key: m.key } });
        console.log('[Remini Handler] Uploading image to server');
        
        const uploadResult = await uploadImageBuffer(mediaBuffer, 'image.jpg');
        
        if (!uploadResult.success) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ Gagal upload gambar.\n💡 Error: ${uploadResult.message}`);
        }
        
        // Step 2: Enhance with Remini
        await conn.sendMessage(m.chat, { react: { text: '✨', key: m.key } });
        console.log('[Remini Handler] Enhancing image with Remini API');
        
        const enhanceResult = await enhanceWithRemini(uploadResult.url);
        
        if (!enhanceResult.success) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ Gagal enhance gambar.\n💡 Error: ${enhanceResult.message}`);
        }
        
        // Step 3: Download result
        await conn.sendMessage(m.chat, { react: { text: '📥', key: m.key } });
        console.log('[Remini Handler] Downloading enhanced image');
        
        const resultBuffer = await downloadResultImage(enhanceResult.resultUrl);
        
        if (!resultBuffer) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ Gagal download hasil.\n🔗 Link hasil: ${enhanceResult.resultUrl}`);
        }
        
        // Step 4: Send result
        console.log('[Remini Handler] Sending result');
        await conn.sendMessage(m.chat, {
            image: resultBuffer,
            caption: `✅ *Gambar berhasil di-enhance dengan Remini!*\n\n✨ *AI Enhancement Applied*`
        }, { quoted: m });
        
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (error) {
        console.error('[Remini Handler] CRITICAL ERROR:', error.message);
        console.error('[Remini Handler] Stack:', error.stack);
        
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        
        const msg = error.message || 'Unknown error';
        return m.reply(`❌ *Terjadi error:*\n\`\`\`\n${msg}\n\`\`\``);
    }
};

// ========== HANDLER PROPERTIES ==========
handler.help = ["remini - enhance gambar dengan AI"];
handler.tags = ["tools"];
handler.command = ["remini"];
handler.limit = true;

console.log('[Remini Handler] Handler loaded successfully');

export default handler;