import fetch from 'node-fetch';
import FormData from 'form-data';
import { downloadContentFromMessage } from 'baileys';
import { writeFileSync, unlinkSync, existsSync, mkdirSync, readFileSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';

console.log('[RemoveBG Combined Handler] Loading handler...');

// ========== CONFIGURATION ==========
const SERVICES = {
    birefnet: {
        name: 'BiRefNet',
        url: 'https://not-lain-background-removal.hf.space',
        knownFnIndex: 20,
        maxFnIndexSearch: 30,
        enabled: true
    },
    gonzalez: {
        name: 'Gonzalez BiRefNet',
        url: 'https://gonzalez16-remove-background-img.hf.space',
        fnIndexes: [19, 13, 2, 3],
        enabled: true
    }
};

const TIMEOUT_MS = 120000;
const MAX_RETRIES = 3;
const RETRY_DELAY = 5000;
let DEBUG_MODE = false;
const ENABLE_AUTO_DISCOVERY = false;

// ========== DEBUG LOGGER ==========
function debugLog(category, message, data = null) {
    if (!DEBUG_MODE) return;
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] [${category}] ${message}`);
    if (data) {
        console.log(`[${timestamp}] [${category}] Data:`, typeof data === 'string' ? data : JSON.stringify(data, null, 2));
    }
}

// ========== TOGGLE DEBUG ==========
function toggleDebugMode(enable = null) {
    if (enable === null) {
        DEBUG_MODE = !DEBUG_MODE;
    } else {
        DEBUG_MODE = !!enable;
    }
    return DEBUG_MODE;
}

// ========== GENERATE SESSION HASH ==========
function generateSessionHash() {
    return Math.random().toString(36).substring(2, 15);
}

// ========== DOWNLOAD MEDIA ==========
async function downloadMedia(message) {
    try {
        const mimeMap = {
            imageMessage: 'image',
            videoMessage: 'video',
            stickerMessage: 'sticker',
            documentMessage: 'document',
            audioMessage: 'audio'
        };

        const msgKeys = Object.keys(message || {});
        if (msgKeys.length === 0) return null;

        const type = msgKeys[0];
        if (!type) return null;

        const m = message[type];
        if (!m) return null;

        const mediaType = mimeMap[type];
        if (!mediaType) return null;

        const stream = await downloadContentFromMessage(m, mediaType);
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        
        return Buffer.concat(chunks);
    } catch (error) {
        console.error('[RemoveBG] Error downloading media:', error);
        return null;
    }
}

// ========== DOWNLOAD FROM URL ==========
async function downloadFromUrl(url) {
    try {
        debugLog('DOWNLOAD', 'Downloading from URL:', url);
        
        const response = await fetch(url, {
            timeout: 30000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status}`);
        }
        
        const buffer = await response.buffer();
        debugLog('DOWNLOAD', 'Downloaded, size:', buffer.length);
        return buffer;
    } catch (error) {
        debugLog('DOWNLOAD', 'Error:', error.message);
        return null;
    }
}

// ========== VALIDATE URL ==========
function extractImageUrl(text) {
    if (!text) return null;
    
    const urlPattern = /https?:\/\/[^\s]+\.(jpg|jpeg|png|gif|webp|bmp)/i;
    const match = text.match(urlPattern);
    
    if (match) return match[0];
    
    if (/^https?:\/\//i.test(text)) {
        return text.trim();
    }
    
    return null;
}

// ========== UPLOAD IMAGE TO GRADIO (BiRefNet Style) ==========
async function uploadImageToGradioBiRefNet(imageBuffer, fileName, serviceUrl) {
    try {
        console.log(`[UPLOAD-BIREFNET] Uploading image: ${fileName} (${(imageBuffer.length / 1024).toFixed(2)} KB)`);
        debugLog('UPLOAD', 'Starting image upload');
        
        const uploadId = Math.random().toString(36).substring(2, 15);
        const uploadUrl = `${serviceUrl}/gradio_api/upload?upload_id=${uploadId}`;
        
        debugLog('UPLOAD', 'Upload URL:', uploadUrl);
        
        const form = new FormData();
        form.append('files', imageBuffer, {
            filename: fileName,
            contentType: 'image/jpeg'
        });
        
        const uploadResponse = await fetch(uploadUrl, {
            method: 'POST',
            body: form,
            headers: form.getHeaders(),
            timeout: 60000
        });
        
        console.log(`[UPLOAD-BIREFNET] Upload response status: ${uploadResponse.status}`);
        
        if (!uploadResponse.ok) {
            throw new Error(`Image upload failed: ${uploadResponse.status}`);
        }
        
        const uploadResult = await uploadResponse.json();
        
        if (!uploadResult || uploadResult.length === 0) {
            throw new Error('No upload result received');
        }
        
        const filePath = uploadResult[0];
        console.log(`[UPLOAD-BIREFNET] ✓ Image uploaded successfully`);
        
        return filePath;
        
    } catch (error) {
        console.error(`[UPLOAD-BIREFNET] Upload error:`, error.message);
        throw error;
    }
}

// ========== UPLOAD FILE TO GRADIO (Gonzalez Style) ==========
async function uploadFileToGradioGonzalez(mediaBuffer, mime, serviceUrl) {
    try {
        debugLog('UPLOAD-GONZALEZ', 'Starting file upload to Gradio');
        
        const tempDir = join(tmpdir(), 'rmbg');
        if (!existsSync(tempDir)) {
            mkdirSync(tempDir, { recursive: true });
        }
        
        const ext = mime.split('/')[1] || 'jpg';
        const tempFile = join(tempDir, `input_${Date.now()}.${ext}`);
        writeFileSync(tempFile, mediaBuffer);
        debugLog('UPLOAD-GONZALEZ', 'Temp file created:', tempFile);
        
        const uploadId = Math.random().toString(36).substring(2, 15);
        const uploadUrl = `${serviceUrl}/gradio_api/upload?upload_id=${uploadId}`;
        
        debugLog('UPLOAD-GONZALEZ', 'Upload URL:', uploadUrl);
        
        const form = new FormData();
        form.append('files', readFileSync(tempFile), {
            filename: `image.${ext}`,
            contentType: mime
        });
        
        debugLog('UPLOAD-GONZALEZ', 'Uploading file...');
        
        const uploadResponse = await fetch(uploadUrl, {
            method: 'POST',
            body: form,
            headers: form.getHeaders(),
            timeout: 60000
        });
        
        debugLog('UPLOAD-GONZALEZ', 'Upload response status:', uploadResponse.status);
        
        if (!uploadResponse.ok) {
            const errorText = await uploadResponse.text();
            debugLog('UPLOAD-GONZALEZ', 'Upload failed:', errorText);
            throw new Error(`Upload failed: ${uploadResponse.status}`);
        }
        
        const uploadResult = await uploadResponse.json();
        debugLog('UPLOAD-GONZALEZ', 'Upload result:', uploadResult);
        
        if (existsSync(tempFile)) {
            unlinkSync(tempFile);
        }
        
        if (Array.isArray(uploadResult) && uploadResult.length > 0) {
            debugLog('UPLOAD-GONZALEZ', 'Upload successful, file path:', uploadResult[0]);
            return uploadResult[0];
        }
        
        throw new Error('Invalid upload result format');
        
    } catch (error) {
        debugLog('UPLOAD-GONZALEZ', 'Upload error:', error.message);
        return null;
    }
}

// ========== PARSE SSE STREAM ==========
async function parseSSEStream(response) {
    try {
        debugLog('SSE', 'Starting to parse SSE stream');
        
        const text = await response.text();
        const lines = text.split('\n');
        const events = [];
        
        for (const line of lines) {
            if (line.startsWith('data: ')) {
                try {
                    const data = JSON.parse(line.substring(6));
                    events.push(data);
                    
                    if (data.msg === 'estimation') {
                        console.log(`[SSE] Queue position: ${data.rank}, ETA: ${data.rank_eta?.toFixed(1)}s`);
                    } else if (data.msg === 'process_starts') {
                        console.log(`[SSE] Processing started!`);
                    } else if (data.msg === 'process_completed') {
                        console.log(`[SSE] Processing completed!`);
                    }
                    
                    debugLog('SSE', `Event [${data.msg}]:`, data);
                } catch (e) {
                    debugLog('SSE', 'Failed to parse line');
                }
            }
        }
        
        const completeEvent = events.find(e => e.msg === 'process_completed');
        if (completeEvent) {
            return completeEvent;
        }
        
        const errorEvent = events.find(e => e.msg === 'error' || e.success === false);
        if (errorEvent) {
            throw new Error(errorEvent.output?.error || 'Processing error occurred');
        }
        
        return events[events.length - 1];
        
    } catch (error) {
        debugLog('SSE', 'Parse error:', error.message);
        throw error;
    }
}

// ========== PROCESS GRADIO RESULT ==========
async function processGradioResult(result, serviceUrl) {
    try {
        console.log(`[PROCESS] Processing result...`);
        
        if (!result.output && !result.data) {
            throw new Error('No output or data in result');
        }
        
        const output = result.output || result.data;
        
        if (!Array.isArray(output) && typeof output !== 'object') {
            throw new Error('Invalid output format');
        }
        
        let imageData = Array.isArray(output) ? (output.length >= 2 ? output[1] : output[0]) : output;
        
        console.log(`[PROCESS] Output type:`, typeof imageData);
        debugLog('PROCESS', 'Image data:', imageData);
        
        if (!imageData) {
            throw new Error('No image data in output');
        }
        
        let downloadUrl = '';
        
        if (typeof imageData === 'string') {
            if (imageData.startsWith('http://') || imageData.startsWith('https://')) {
                downloadUrl = imageData;
                console.log(`[PROCESS] Using direct URL string`);
            } else if (imageData.startsWith('data:image')) {
                console.log(`[PROCESS] Converting base64 to buffer`);
                const base64Data = imageData.split(',')[1];
                const resultBuffer = Buffer.from(base64Data, 'base64');
                console.log(`[PROCESS] Base64 decoded: ${(resultBuffer.length / 1024).toFixed(2)} KB`);
                
                return { 
                    success: true, 
                    resultBuffer,
                    status: 'Background removed successfully'
                };
            } else {
                downloadUrl = `${serviceUrl}/gradio_api/file=${imageData}`;
                console.log(`[PROCESS] Constructed URL from string path`);
            }
        } else if (typeof imageData === 'object') {
            if (imageData.__type__ === 'update' && !imageData.value) {
                throw new Error('Received update-only response without value');
            }
            
            if (imageData.url) {
                downloadUrl = imageData.url;
                console.log(`[PROCESS] Using direct URL from object`);
            } else if (imageData.path) {
                downloadUrl = `${serviceUrl}/gradio_api/file=${imageData.path}`;
                console.log(`[PROCESS] Constructed URL from object path`);
            } else if (imageData.name) {
                downloadUrl = `${serviceUrl}/gradio_api/file=${imageData.name}`;
                console.log(`[PROCESS] Constructed URL from object name`);
            } else if (imageData.value && imageData.value.url) {
                downloadUrl = imageData.value.url;
                console.log(`[PROCESS] Using URL from value object`);
            } else if (imageData.value && imageData.value.path) {
                downloadUrl = `${serviceUrl}/gradio_api/file=${imageData.value.path}`;
                console.log(`[PROCESS] Constructed URL from value.path`);
            } else if (imageData.data && Array.isArray(imageData.data)) {
                debugLog('PROCESS', 'Object has nested data array, recursing...');
                imageData = imageData.data[0];
                if (imageData.url) {
                    downloadUrl = imageData.url;
                } else if (imageData.path) {
                    downloadUrl = `${serviceUrl}/gradio_api/file=${imageData.path}`;
                }
            } else {
                throw new Error('No URL or path in image data object');
            }
        } else {
            throw new Error(`Unsupported image data type: ${typeof imageData}`);
        }
        
        if (!downloadUrl) {
            throw new Error('Could not determine download URL');
        }
        
        if (!downloadUrl.startsWith('http')) {
            downloadUrl = `${serviceUrl}${downloadUrl}`;
        }
        
        console.log(`[PROCESS] Downloading result from: ${downloadUrl}`);
        
        const imageResponse = await fetch(downloadUrl, {
            timeout: 30000,
            headers: {
                'User-Agent': 'Mozilla/5.0',
                'Referer': `${serviceUrl}/`
            }
        });
        
        if (!imageResponse.ok) {
            throw new Error(`Download failed: ${imageResponse.status}`);
        }
        
        const resultBuffer = await imageResponse.buffer();
        console.log(`[PROCESS] Downloaded result: ${(resultBuffer.length / 1024).toFixed(2)} KB`);
        
        if (resultBuffer.length === 0) {
            throw new Error('Downloaded buffer is empty');
        }
        
        console.log(`[PROCESS] ✓ Background removal completed successfully\n`);
        
        return { 
            success: true, 
            resultBuffer,
            status: 'Background removed successfully'
        };
        
    } catch (error) {
        console.error(`[PROCESS] Processing error:`, error.message);
        return { success: false, message: error.message };
    }
}

// ========== REMOVE BACKGROUND WITH BIREFNET SERVICE ==========
async function removeBackgroundBiRefNet(imageBuffer, fileName, retryCount = 0) {
    const startTime = Date.now();
    const service = SERVICES.birefnet;
    
    try {
        console.log(`\n${'='.repeat(60)}`);
        console.log(`[BIREFNET] Attempt ${retryCount + 1}/${MAX_RETRIES + 1}`);
        console.log(`[BIREFNET] Image: ${fileName}`);
        console.log(`[BIREFNET] Size: ${(imageBuffer.length / 1024).toFixed(2)} KB`);
        console.log(`${'='.repeat(60)}\n`);
        
        const imagePath = await uploadImageToGradioBiRefNet(imageBuffer, fileName, service.url);
        const sessionHash = generateSessionHash();
        console.log(`[BIREFNET] Session hash: ${sessionHash}`);
        
        const fnIndex = service.knownFnIndex;
        console.log(`[BIREFNET] Using fn_index: ${fnIndex}`);
        
        const joinUrl = `${service.url}/gradio_api/queue/join?__theme=system`;
        
        const joinPayload = {
            data: [
                {
                    path: imagePath,
                    url: `${service.url}/gradio_api/file=${imagePath}`,
                    orig_name: fileName,
                    size: imageBuffer.length,
                    mime_type: 'image/jpeg',
                    is_stream: false,
                    meta: { _type: 'gradio.FileData' }
                }
            ],
            event_data: null,
            fn_index: fnIndex,
            session_hash: sessionHash
        };
        
        console.log(`[BIREFNET] Joining queue...`);
        
        const joinResponse = await fetch(joinUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Referer': `${service.url}/?__theme=system`
            },
            body: JSON.stringify(joinPayload),
            timeout: 30000
        });
        
        console.log(`[BIREFNET] Queue join response status: ${joinResponse.status}`);
        
        if (!joinResponse.ok) {
            throw new Error(`Queue join failed: ${joinResponse.status}`);
        }
        
        const joinResult = await joinResponse.json();
        
        if (!joinResult.event_id) {
            throw new Error('No event_id received');
        }
        
        console.log(`[BIREFNET] Event ID: ${joinResult.event_id}`);
        console.log(`[BIREFNET] Waiting for processing...`);
        
        const dataUrl = `${service.url}/gradio_api/queue/data?session_hash=${sessionHash}`;
        const dataResponse = await fetch(dataUrl, {
            timeout: TIMEOUT_MS,
            headers: {
                'Accept': 'text/event-stream',
                'Referer': `${service.url}/?__theme=system`
            }
        });
        
        if (!dataResponse.ok) {
            throw new Error(`Data fetch failed: ${dataResponse.status}`);
        }
        
        const result = await parseSSEStream(dataResponse);
        
        if (!result) {
            throw new Error('Failed to parse SSE stream');
        }
        
        const elapsedTime = ((Date.now() - startTime) / 1000).toFixed(2);
        console.log(`[BIREFNET] Processing completed in ${elapsedTime}s`);
        console.log(`${'='.repeat(60)}\n`);
        
        return await processGradioResult(result, service.url);
        
    } catch (error) {
        const elapsedTime = ((Date.now() - startTime) / 1000).toFixed(2);
        console.error(`[BIREFNET] Error after ${elapsedTime}s:`, error.message);
        
        if (retryCount < MAX_RETRIES) {
            console.log(`[BIREFNET] Retrying in ${RETRY_DELAY / 1000}s...`);
            await new Promise(resolve => setTimeout(resolve, RETRY_DELAY));
            return removeBackgroundBiRefNet(imageBuffer, fileName, retryCount + 1);
        }
        
        console.error(`[BIREFNET] All retry attempts failed`);
        return { success: false, message: error.message };
    }
}

// ========== REMOVE BACKGROUND WITH GONZALEZ SERVICE ==========
async function removeBackgroundGonzalez(mediaBuffer, mime = 'image/jpeg') {
    const service = SERVICES.gonzalez;
    
    try {
        debugLog('GONZALEZ', 'Starting Gradio API processing');
        
        const filePath = await uploadFileToGradioGonzalez(mediaBuffer, mime, service.url);
        if (!filePath) {
            throw new Error('File upload failed');
        }
        
        debugLog('GONZALEZ', 'File uploaded successfully:', filePath);
        
        const sessionHash = generateSessionHash();
        const joinUrl = `${service.url}/gradio_api/queue/join`;
        
        debugLog('GONZALEZ', 'Joining queue with session:', sessionHash);
        
        const attempts = [
            { 
                fn_index: 19, 
                data: [{
                    path: filePath,
                    url: null,
                    size: null,
                    orig_name: 'image.jpeg',
                    mime_type: mime
                }]
            },
            { fn_index: 13, data: [filePath] },
            { 
                fn_index: 19, 
                data: [{
                    path: filePath
                }]
            },
            { fn_index: 19, data: [filePath] },
            { fn_index: 2, data: [filePath] },
            { fn_index: 3, data: [filePath] },
        ];
        
        let result = null;
        for (const attempt of attempts) {
            debugLog('GONZALEZ', `Trying fn_index: ${attempt.fn_index}`);
            
            const joinPayload = {
                data: attempt.data,
                event_data: null,
                fn_index: attempt.fn_index,
                session_hash: sessionHash
            };
            
            debugLog('GONZALEZ', 'Join payload:', joinPayload);
            
            const joinResponse = await fetch(joinUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(joinPayload),
                timeout: 30000
            });
            
            if (!joinResponse.ok) {
                debugLog('GONZALEZ', `fn_index ${attempt.fn_index} failed with status:`, joinResponse.status);
                continue;
            }
            
            const joinResult = await joinResponse.json();
            debugLog('GONZALEZ', `fn_index ${attempt.fn_index} queue joined:`, joinResult);
            
            if (!joinResult.event_id) {
                debugLog('GONZALEZ', `fn_index ${attempt.fn_index} no event_id`);
                continue;
            }
            
            const eventId = joinResult.event_id;
            debugLog('GONZALEZ', `fn_index ${attempt.fn_index} waiting for processing, event_id:`, eventId);
            
            await new Promise(resolve => setTimeout(resolve, 3000));
            
            const dataUrl = `${service.url}/gradio_api/queue/data?session_hash=${sessionHash}`;
            debugLog('GONZALEZ', 'Fetching result from:', dataUrl);
            
            const dataResponse = await fetch(dataUrl, {
                timeout: 90000,
                headers: {
                    'Accept': 'text/event-stream'
                }
            });
            
            if (!dataResponse.ok) {
                debugLog('GONZALEZ', `fn_index ${attempt.fn_index} data fetch failed:`, dataResponse.status);
                continue;
            }
            
            debugLog('GONZALEZ', 'Response received, parsing SSE...');
            
            const parsedResult = await parseSSEStream(dataResponse);
            
            if (!parsedResult) {
                debugLog('GONZALEZ', `fn_index ${attempt.fn_index} failed to parse SSE`);
                continue;
            }
            
            debugLog('GONZALEZ', `fn_index ${attempt.fn_index} result:`, parsedResult);
            
            if (parsedResult.success === false || 
                (parsedResult.output && parsedResult.output.error)) {
                debugLog('GONZALEZ', `fn_index ${attempt.fn_index} has error:`, parsedResult.output?.error || 'unknown');
                continue;
            }
            
            if (parsedResult.output && parsedResult.output.data) {
                const outputData = parsedResult.output.data;
                if (Array.isArray(outputData) && outputData.length > 0) {
                    const firstItem = outputData[0];
                    if (typeof firstItem === 'string' && 
                        (firstItem === 'Share via Link' || 
                         firstItem === 'Link Copied!' ||
                         !firstItem.includes('/'))) {
                        debugLog('GONZALEZ', `fn_index ${attempt.fn_index} returned text, not image. Skipping...`);
                        continue;
                    }
                }
            }
            
            result = parsedResult;
            debugLog('GONZALEZ', `fn_index ${attempt.fn_index} SUCCESS!`);
            break;
        }
        
        if (!result) {
            throw new Error('All fn_index attempts failed');
        }
        
        debugLog('GONZALEZ', 'Final result:', result);
        
        return await processGradioResult(result, service.url);
        
    } catch (error) {
        debugLog('GONZALEZ', 'Error:', error.message);
        return { success: false, message: error.message };
    }
}

// ========== REMOVE BACKGROUND WITH FALLBACK ==========
async function removeBackgroundWithFallback(imageBuffer, fileName, mime = 'image/jpeg') {
    console.log(`\n${'━'.repeat(60)}`);
    console.log(`[REMOVE-BG] Starting background removal with fallback`);
    console.log(`${'━'.repeat(60)}\n`);
    
    // Try BiRefNet first
    if (SERVICES.birefnet.enabled) {
        console.log(`[REMOVE-BG] Trying ${SERVICES.birefnet.name}...`);
        const result = await removeBackgroundBiRefNet(imageBuffer, fileName);
        if (result.success) {
            console.log(`[REMOVE-BG] ✓ Success with ${SERVICES.birefnet.name}`);
            return { ...result, service: SERVICES.birefnet.name };
        }
        console.log(`[REMOVE-BG] ✗ ${SERVICES.birefnet.name} failed, trying fallback...`);
    }
    
    // Fallback to Gonzalez
    if (SERVICES.gonzalez.enabled) {
        console.log(`[REMOVE-BG] Trying ${SERVICES.gonzalez.name}...`);
        const result = await removeBackgroundGonzalez(imageBuffer, mime);
        if (result.success) {
            console.log(`[REMOVE-BG] ✓ Success with ${SERVICES.gonzalez.name}`);
            return { ...result, service: SERVICES.gonzalez.name };
        }
        console.log(`[REMOVE-BG] ✗ ${SERVICES.gonzalez.name} failed`);
    }
    
    console.log(`[REMOVE-BG] ✗ All services failed`);
    return { success: false, message: 'All background removal services failed' };
}

// ========== HELP MESSAGE ==========
function generateUsageHelp(prefix, cmd) {
    return `*🎨 AI BACKGROUND REMOVER*

📌 *Cara Penggunaan:*

*1. Reply Gambar:*
Reply gambar dengan: ${prefix}nobg

*2. Kirim Gambar:*
Kirim gambar dengan caption: ${prefix}nobg

*3. Dari URL:*
${prefix}nobg https://example.com/image.jpg

🎯 *Pilih API:*

*Auto (Fallback):*
${prefix}nobg - Otomatis coba API 1, jika gagal pakai API 2

*API 1 Only:*
${prefix}nobg1 - Paksa gunakan API 1 (BiRefNet)

*API 2 Only:*
${prefix}nobg2 - Paksa gunakan API 2 (Gonzalez)

📋 *Fitur:*
- Remove background otomatis
- Dual AI Service dengan fallback
- Support: JPG, PNG, WEBP, GIF
- Output: PNG transparent
- Max size: 5MB

*Services:*
🤖 API 1: ${SERVICES.birefnet.name}
🤖 API 2: ${SERVICES.gonzalez.name}

*Contoh:*
${prefix}nobg
${prefix}nobg1
${prefix}nobg2
${prefix}nobg https://example.com/photo.jpg

*Debug Mode:*
${prefix}nobg debug [on/off]

⏱️ Proses: 5-20 detik
🎯 High-quality AI segmentation`;
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, text, usedPrefix, command }) => {
    const prefix = usedPrefix || '.';
    const cmd = command || 'removebg';
    
    try {
        const inputText = text?.trim() || '';
        
        // Determine which service to use based on command
        let forceService = null;
        if (command === 'nobg1' || command === 'removebg1' || command === 'rmbg1') {
            forceService = 'birefnet';
        } else if (command === 'nobg2' || command === 'removebg2' || command === 'rmbg2') {
            forceService = 'gonzalez';
        }
        
        if (inputText.toLowerCase() === 'debug') {
            const newStatus = toggleDebugMode();
            return m.reply(`🔧 Debug Mode: ${newStatus ? 'ON ✅' : 'OFF ❌'}`);
        }
        
        if (inputText.toLowerCase().startsWith('debug ')) {
            const debugCmd = inputText.substring(6).trim().toLowerCase();
            if (debugCmd === 'on') {
                toggleDebugMode(true);
                return m.reply(`✅ Debug Mode Enabled`);
            } else if (debugCmd === 'off') {
                toggleDebugMode(false);
                return m.reply(`❌ Debug Mode Disabled`);
            }
        }
        
        if (inputText.toLowerCase() === 'help' || inputText === '?') {
            return m.reply(generateUsageHelp(prefix, cmd));
        }
        
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        let imageBuffer = null;
        let mime = 'image/jpeg';
        let fromUrl = false;
        
        const imageUrl = extractImageUrl(inputText);
        if (imageUrl) {
            imageBuffer = await downloadFromUrl(imageUrl);
            fromUrl = true;
        }
        
        if (!imageBuffer) {
            const rawMessage = m.message;
            let contextInfo = null;
            let quotedMessage = null;
            
            if (rawMessage) {
                if (rawMessage.extendedTextMessage) {
                    contextInfo = rawMessage.extendedTextMessage.contextInfo;
                } else if (rawMessage.imageMessage) {
                    contextInfo = rawMessage.imageMessage.contextInfo;
                    mime = rawMessage.imageMessage.mimetype || 'image/jpeg';
                }
                
                if (contextInfo) {
                    quotedMessage = contextInfo.quotedMessage;
                }
            }
            
            if (rawMessage?.imageMessage) {
                mime = rawMessage.imageMessage.mimetype || 'image/jpeg';
                imageBuffer = await downloadMedia(rawMessage);
            } else if (quotedMessage?.imageMessage) {
                mime = quotedMessage.imageMessage.mimetype || 'image/jpeg';
                imageBuffer = await downloadMedia(quotedMessage);
            } else if (m.quoted?.message?.imageMessage) {
                mime = m.quoted.message.imageMessage.mimetype || 'image/jpeg';
                imageBuffer = await downloadMedia(m.quoted.message);
            }
        }
        
        if (!imageBuffer) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ Kirim/reply gambar dengan caption *${prefix}${cmd}*\n\nKetik ${prefix}${cmd} help untuk bantuan`);
        }
        
        if (imageBuffer.length > 5 * 1024 * 1024) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply('❌ Ukuran gambar terlalu besar! Max 5MB');
        }
        
        if (!/image\/(jpe?g|png|gif|webp)/.test(mime)) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply('⚠️ Format tidak didukung! Hanya jpg/png/gif/webp.');
        }
        
        console.log(`\n${'━'.repeat(60)}`);
        console.log(`[HANDLER] New REMOVE-BG request`);
        console.log(`[HANDLER] Command: ${command}`);
        console.log(`[HANDLER] Force Service: ${forceService || 'auto-fallback'}`);
        console.log(`[HANDLER] Chat: ${m.chat}`);
        console.log(`[HANDLER] From: ${fromUrl ? 'URL' : 'Upload'}`);
        console.log(`[HANDLER] Size: ${(imageBuffer.length / 1024).toFixed(2)} KB`);
        console.log(`[HANDLER] MIME: ${mime}`);
        console.log(`${'━'.repeat(60)}\n`);
        
        await conn.sendMessage(m.chat, { react: { text: '🎨', key: m.key } });
        
        const startTime = Date.now();
        const fileName = `background_${Date.now()}.jpg`;
        
        let result;
        
        // Use specific service if forced, otherwise use fallback
        if (forceService === 'birefnet') {
            console.log(`[HANDLER] Using BiRefNet API (forced)`);
            result = await removeBackgroundBiRefNet(imageBuffer, fileName);
            result.service = SERVICES.birefnet.name;
        } else if (forceService === 'gonzalez') {
            console.log(`[HANDLER] Using Gonzalez API (forced)`);
            result = await removeBackgroundGonzalez(imageBuffer, mime);
            result.service = SERVICES.gonzalez.name;
        } else {
            console.log(`[HANDLER] Using auto-fallback mode`);
            result = await removeBackgroundWithFallback(imageBuffer, fileName, mime);
        }
        
        if (!result.success) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ Gagal remove background${forceService ? ` dengan ${forceService === 'birefnet' ? 'API 1' : 'API 2'}` : ' dari semua service'}\n\nError: ${result.message}\n\n💡 Coba lagi dalam beberapa saat\n⚠️ Kemungkinan:\n- Space Hugging Face sedang maintenance\n- Koneksi timeout\n- Gambar tidak valid${!forceService ? '\n\n💡 Atau coba gunakan:\n- ' + prefix + 'nobg1 (API 1 only)\n- ' + prefix + 'nobg2 (API 2 only)' : ''}`);
        }
        
        const totalTime = ((Date.now() - startTime) / 1000).toFixed(2);
        const sourceInfo = fromUrl ? '🔗 URL' : '📸 Upload';
        const apiInfo = forceService ? (forceService === 'birefnet' ? '🎯 API 1' : '🎯 API 2') : '🔄 Auto';
        const caption = `*🎨 BACKGROUND REMOVED*\n\n${sourceInfo}\n${apiInfo}\n⏱️ ${totalTime}s\n🤖 ${result.service || 'BiRefNet AI'}\n\n_Output: PNG Transparent_`;
        
        await conn.sendMessage(m.chat, {
            image: result.resultBuffer,
            caption: caption,
            mimetype: 'image/png'
        }, { quoted: m });
        
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
        console.log(`[HANDLER] ✓ Complete! Time: ${totalTime}s, Service: ${result.service}`);
        console.log(`${'━'.repeat(60)}\n`);
        
    } catch (error) {
        console.error('[HANDLER] ERROR:', error.message);
        console.error('[HANDLER] Stack:', error.stack);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        return m.reply(`❌ Terjadi error\n\nKetik ${usedPrefix}${command} help untuk bantuan`);
    }
};

handler.help = [
    "nobg - remove background (auto-fallback)",
    "nobg1 - remove background (API 1 only)", 
    "nobg2 - remove background (API 2 only)"
];
handler.tags = ["tools"];
handler.command = ["removebg", "removebackground", "nobg", "rmbg", "removebg1", "nobg1", "rmbg1", "removebg2", "nobg2", "rmbg2"];
handler.limit = true;

console.log('[RemoveBG Combined Handler] Handler loaded successfully');

export default handler;