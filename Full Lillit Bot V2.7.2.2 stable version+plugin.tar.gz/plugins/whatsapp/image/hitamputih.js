import fetch from 'node-fetch';
import FormData from 'form-data';
import { downloadContentFromMessage } from 'baileys';

console.log('[Image Converter Handler] Loading handler...');

// ========== CONFIGURATION ==========
const HITAMKAN_API_URL = 'https://api-faa.my.id/faa/tohitam';
const PUTIHKAN_API_URL = 'https://api-faa.my.id/faa/toputih';
const TIMEOUT_MS = 120000; // 120 detik timeout

// ========== UPLOAD SERVERS ==========
const UPLOAD_SERVERS = {
    hf: {
        url: 'https://ikyy-upload-file.hf.space/upload',
        name: 'Ikky HF'
    },
    tmpfiles: {
        url: 'https://tmpfiles.org/api/v1/upload',
        name: 'TmpFiles'
    }
};

// ========== DOWNLOAD MEDIA FUNCTION ==========
async function downloadMedia(message) {
    try {
        const mimeMap = {
            imageMessage: 'image',
            videoMessage: 'video',
            stickerMessage: 'sticker',
            documentMessage: 'document',
            audioMessage: 'audio'
        };

        const msgKeys = Object.keys(message || {});
        if (msgKeys.length === 0) return null;

        const type = msgKeys[0];
        if (!type) return null;

        const m = message[type];
        if (!m) return null;

        const mediaType = mimeMap[type];
        if (!mediaType) return null;

        const stream = await downloadContentFromMessage(m, mediaType);
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        
        return Buffer.concat(chunks);
    } catch (error) {
        console.error('[Image Converter] Error downloading media:', error);
        return null;
    }
}

// ========== UPLOAD FUNCTIONS ==========
async function uploadToHF(mediaBuffer, filename = 'image.jpg') {
    try {
        console.log('[Image Converter] Uploading to HF Space, size:', mediaBuffer.length, 'bytes');
        
        const formData = new FormData();
        formData.append('file', mediaBuffer, {
            filename: filename,
            contentType: 'image/jpeg'
        });
        
        const uploadPromise = fetch(UPLOAD_SERVERS.hf.url, {
            method: 'POST',
            body: formData,
            headers: {
                ...formData.getHeaders(),
                'Accept': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error(`Timeout setelah 30000ms`)), 30000)
        );
        
        const response = await Promise.race([uploadPromise, timeoutPromise]);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const result = await response.json();
        
        if (result.fileUrl) {
            console.log('[Image Converter] HF Upload success:', result.fileUrl);
            return { success: true, url: result.fileUrl, server: 'hf' };
        } else {
            throw new Error('Upload failed - no URL in response');
        }
    } catch (error) {
        console.error('[Image Converter] HF Upload error:', error.message);
        return { success: false, message: error.message, server: 'hf' };
    }
}

async function uploadToTmpFiles(mediaBuffer, filename = 'image.jpg') {
    try {
        console.log('[Image Converter] Uploading to TmpFiles, size:', mediaBuffer.length, 'bytes');
        
        const formData = new FormData();
        formData.append('file', mediaBuffer, {
            filename: filename,
            contentType: 'image/jpeg'
        });
        
        const uploadPromise = fetch(UPLOAD_SERVERS.tmpfiles.url, {
            method: 'POST',
            body: formData,
            headers: {
                ...formData.getHeaders(),
                'Accept': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error(`Timeout setelah 30000ms`)), 30000)
        );
        
        const response = await Promise.race([uploadPromise, timeoutPromise]);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const result = await response.json();
        
        if (result.status === 'success' && result.data && result.data.url) {
            let originalUrl = result.data.url;
            let parts = originalUrl.split('/');
            let fileId = parts[parts.length - 2];
            let fileName = parts[parts.length - 1];
            let directUrl = `https://tmpfiles.org/dl/${fileId}/${fileName}`;
            
            console.log('[Image Converter] TmpFiles Upload success:', directUrl);
            return { success: true, url: directUrl, server: 'tmpfiles' };
        } else {
            throw new Error('Upload failed - no URL in response');
        }
    } catch (error) {
        console.error('[Image Converter] TmpFiles Upload error:', error.message);
        return { success: false, message: error.message, server: 'tmpfiles' };
    }
}

// ========== MULTI-SERVER UPLOAD ==========
async function uploadImageBuffer(mediaBuffer, filename = 'image.jpg') {
    console.log('[Image Converter] Starting multi-server upload (2 servers parallel)');
    
    const results = [];
    
    // Upload ke 2 server secara paralel
    const uploadPromises = [
        uploadToHF(mediaBuffer, filename).catch(err => ({ success: false, message: err.message, server: 'hf' })),
        uploadToTmpFiles(mediaBuffer, filename).catch(err => ({ success: false, message: err.message, server: 'tmpfiles' }))
    ];
    
    const uploadResults = await Promise.all(uploadPromises);
    results.push(...uploadResults);
    
    // Cari upload yang berhasil
    const successfulUpload = results.find(r => r.success);
    
    if (successfulUpload) {
        console.log('[Image Converter] Upload success to:', successfulUpload.server);
        return { success: true, url: successfulUpload.url, server: successfulUpload.server };
    } else {
        // Semua gagal
        const errors = results.map(r => `${r.server}: ${r.message}`).join(', ');
        console.error('[Image Converter] All uploads failed:', errors);
        return { success: false, message: `All uploads failed: ${errors}` };
    }
}

// ========== CONVERT FUNCTIONS ==========
async function convertToBlackWhite(imageUrl) {
    try {
        console.log('[Image Converter] Converting image to black & white from URL:', imageUrl);
        
        const apiUrl = `${HITAMKAN_API_URL}?url=${encodeURIComponent(imageUrl)}`;
        
        const convertPromise = fetch(apiUrl, {
            method: 'GET',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        const timeoutPromise = new Promise((_, reject) =>
            setTimeout(() => reject(new Error(`Timeout setelah ${TIMEOUT_MS}ms`)), TIMEOUT_MS)
        );
        
        const response = await Promise.race([convertPromise, timeoutPromise]);
        
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status} ${response.statusText}`);
        }
        
        // Check Content-Type untuk menentukan apakah response berupa gambar atau JSON
        const contentType = response.headers.get('content-type') || '';
        
        // Jika response adalah gambar (binary), langsung return buffer
        if (contentType.includes('image/') || contentType.includes('application/octet-stream')) {
            console.log('[Image Converter] API returned image directly (Content-Type:', contentType + ')');
            const buffer = await response.buffer();
            console.log('[Image Converter] Conversion success - received image buffer, size:', buffer.length, 'bytes');
            return { success: true, resultBuffer: buffer, isDirect: true };
        }
        
        // Jika response adalah JSON
        const result = await response.json();
        
        if (result.status && result.result) {
            console.log('[Image Converter] Conversion success - got URL:', result.result);
            return { success: true, resultUrl: result.result, isDirect: false };
        } else {
            throw new Error('Conversion failed - no result URL in response');
        }
    } catch (error) {
        console.error('[Image Converter] Conversion error:', error.message);
        return { success: false, message: error.message };
    }
}

async function convertToWhite(imageUrl) {
    try {
        console.log('[Image Converter] Converting image to white from URL:', imageUrl);
        
        const apiUrl = `${PUTIHKAN_API_URL}?url=${encodeURIComponent(imageUrl)}`;
        
        const convertPromise = fetch(apiUrl, {
            method: 'GET',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        const timeoutPromise = new Promise((_, reject) =>
            setTimeout(() => reject(new Error(`Timeout setelah ${TIMEOUT_MS}ms`)), TIMEOUT_MS)
        );
        
        const response = await Promise.race([convertPromise, timeoutPromise]);
        
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status} ${response.statusText}`);
        }
        
        // Check Content-Type untuk menentukan apakah response berupa gambar atau JSON
        const contentType = response.headers.get('content-type') || '';
        
        // Jika response adalah gambar (binary), langsung return buffer
        if (contentType.includes('image/') || contentType.includes('application/octet-stream')) {
            console.log('[Image Converter] API returned image directly (Content-Type:', contentType + ')');
            const buffer = await response.buffer();
            console.log('[Image Converter] Conversion success - received image buffer, size:', buffer.length, 'bytes');
            return { success: true, resultBuffer: buffer, isDirect: true };
        }
        
        // Jika response adalah JSON
        const result = await response.json();
        
        if (result.status && result.result) {
            console.log('[Image Converter] Conversion success - got URL:', result.result);
            return { success: true, resultUrl: result.result, isDirect: false };
        } else {
            throw new Error('Conversion failed - no result URL in response');
        }
    } catch (error) {
        console.error('[Image Converter] Conversion error:', error.message);
        return { success: false, message: error.message };
    }
}

// ========== DOWNLOAD RESULT IMAGE ==========
async function downloadResultImage(url) {
    try {
        console.log('[Image Converter] Downloading result from:', url);
        
        const response = await fetch(url, { 
            timeout: 60000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status} ${response.statusText}`);
        }
        
        const buffer = await response.buffer();
        console.log('[Image Converter] Download complete, size:', buffer.length, 'bytes');
        
        return buffer;
    } catch (error) {
        console.error('[Image Converter] Download error:', error.message);
        return null;
    }
}

// ========== FORMAT FUNCTIONS ==========
function generateUsageHelp(prefix, cmd) {
    const isHitamkan = cmd === 'hitamkan' || cmd === 'bw' || cmd === 'blackwhite';
    const isPutihkan = cmd === 'putihkan' || cmd === 'white' || cmd === 'towhite';
    
    if (isHitamkan) {
        return `*⬛ HITAMKAN - BLACK & WHITE CONVERTER*

📌 *Cara Penggunaan:*

*1. Hitamkan dari Reply Gambar:*
Reply gambar, lalu ketik: ${prefix}${cmd}

*2. Hitamkan Langsung (dengan caption):*
Kirim gambar dengan caption: ${prefix}${cmd}

📋 *Supported Formats:*
- JPG/JPEG
- PNG
- GIF
- WEBP

🎯 *Fitur Hitamkan:*
- Black & white conversion
- Grayscale filter
- Professional monochrome effect
- Artistic B&W processing

💾 *Upload Strategy:*
- Multi-server upload (2 servers)
- Ikky HF + TmpFiles
- Auto fallback jika server gagal

*Contoh:*
${prefix}${cmd}

💡 *Perintah Lain:*
${prefix}putihkan - Convert ke putih
`;
    } else if (isPutihkan) {
        return `*⬜ PUTIHKAN - WHITE CONVERTER*

📌 *Cara Penggunaan:*

*1. Putihkan dari Reply Gambar:*
Reply gambar, lalu ketik: ${prefix}${cmd}

*2. Putihkan Langsung (dengan caption):*
Kirim gambar dengan caption: ${prefix}${cmd}

📋 *Supported Formats:*
- JPG/JPEG
- PNG
- GIF
- WEBP

🎯 *Fitur Putihkan:*
- White tone conversion
- Bright filter effect
- Clean white aesthetic
- Professional whitening

💾 *Upload Strategy:*
- Multi-server upload (2 servers)
- Ikky HF + TmpFiles
- Auto fallback jika server gagal

*Contoh:*
${prefix}${cmd}

💡 *Perintah Lain:*
${prefix}hitamkan - Convert ke hitam putih
`;
    }
    
    return `*🎨 IMAGE CONVERTER*

Use ${prefix}hitamkan or ${prefix}putihkan`;
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    let prefix = usedPrefix || '.';
    const cmd = command || 'hitamkan';
    
    // Deteksi mode berdasarkan command
    const isHitamkan = cmd === 'hitamkan' || cmd === 'bw' || cmd === 'blackwhite';
    const isPutihkan = cmd === 'putihkan' || cmd === 'white' || cmd === 'towhite';
    
    try {
        // Ambil input text
        let inputText = '';
        if (text) {
            inputText = text.trim();
        } else if (args && args.length > 0) {
            inputText = args.join(' ').trim();
        }
        
        // Cek apakah user minta help
        if (inputText.toLowerCase() === 'help' || inputText === '?') {
            return m.reply(generateUsageHelp(prefix, cmd));
        }
        
        // React dengan emoji loading - NON-BLOCKING
        conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } }).catch(() => {});
        
        let mediaBuffer = null;
        let mime = '';
        
        // Extract raw message & context
        let rawMessage = m.message;
        let contextInfo = null;
        let quotedMessage = null;
        
        if (rawMessage) {
            if (rawMessage.extendedTextMessage) {
                contextInfo = rawMessage.extendedTextMessage.contextInfo;
            } else if (rawMessage.imageMessage) {
                contextInfo = rawMessage.imageMessage.contextInfo;
            } else if (rawMessage.videoMessage) {
                contextInfo = rawMessage.videoMessage.contextInfo;
            }
            
            if (contextInfo) {
                quotedMessage = contextInfo.quotedMessage;
            }
        }
        
        // ========== EXTRACT IMAGE ==========
        // Check 1: Direct image message
        if (rawMessage?.imageMessage) {
            console.log(`[Image Converter] Processing direct image`);
            mime = rawMessage.imageMessage.mimetype || 'image/jpeg';
            mediaBuffer = await downloadMedia(rawMessage);
        }
        // Check 2: Quoted image
        else if (quotedMessage?.imageMessage) {
            console.log(`[Image Converter] Processing quoted image`);
            mime = quotedMessage.imageMessage.mimetype || 'image/jpeg';
            mediaBuffer = await downloadMedia(quotedMessage);
        }
        // Check 3: Fallback to m.quoted
        else if (m.quoted?.message?.imageMessage) {
            console.log(`[Image Converter] Processing from m.quoted`);
            mime = m.quoted.message.imageMessage.mimetype || 'image/jpeg';
            mediaBuffer = await downloadMedia(m.quoted.message);
        }
        
        // Validasi
        if (!mediaBuffer || !mime) {
            console.log(`[Image Converter] No valid image found`);
            conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
            
            return m.reply(`❌ Input tidak valid!\n\n💡 Cara penggunaan:\n\n*${isHitamkan ? 'Hitamkan' : 'Putihkan'} dari Reply:*\nReply gambar, lalu ketik: ${prefix}${cmd}\n\n*${isHitamkan ? 'Hitamkan' : 'Putihkan'} Langsung:*\nKirim gambar dengan caption: ${prefix}${cmd}\n\n📌 Ketik ${prefix}${cmd} help untuk panduan lengkap`);
        }
        
        // Validasi format
        if (!/image\/(jpe?g|png|gif|webp)/.test(mime)) {
            console.error(`[Image Converter] Unsupported format:`, mime);
            conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
            return m.reply('⚠️ Format tidak didukung! Hanya jpg/png/gif/webp.');
        }
        
        // Step 1: Upload image (multi-server) - NON-BLOCKING REACT
        conn.sendMessage(m.chat, { react: { text: '📤', key: m.key } }).catch(() => {});
        console.log(`[Image Converter] Uploading image to servers (multi-upload)`);
        
        const uploadResult = await uploadImageBuffer(mediaBuffer, 'image.jpg');
        
        if (!uploadResult.success) {
            conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
            return m.reply(`❌ Gagal upload gambar ke semua server.\n💡 Error: ${uploadResult.message}`);
        }
        
        console.log(`[Image Converter] Upload berhasil ke server: ${uploadResult.server}`);
        
        // Step 2: Convert based on command - NON-BLOCKING REACT
        const emoji = isHitamkan ? '⬛' : '⬜';
        conn.sendMessage(m.chat, { react: { text: emoji, key: m.key } }).catch(() => {});
        console.log(`[Image Converter] Converting image (${isHitamkan ? 'hitamkan' : 'putihkan'})`);
        
        const convertResult = isHitamkan 
            ? await convertToBlackWhite(uploadResult.url)
            : await convertToWhite(uploadResult.url);
        
        if (!convertResult.success) {
            conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
            return m.reply(`❌ Gagal convert gambar.\n💡 Error: ${convertResult.message}`);
        }
        
        // Step 3: Get result buffer
        let resultBuffer = null;
        
        if (convertResult.isDirect) {
            // API langsung return gambar (binary)
            console.log(`[Image Converter] Using direct buffer from API`);
            resultBuffer = convertResult.resultBuffer;
        } else {
            // API return URL, download dulu
            conn.sendMessage(m.chat, { react: { text: '📥', key: m.key } }).catch(() => {});
            console.log(`[Image Converter] Downloading converted image from URL`);
            
            resultBuffer = await downloadResultImage(convertResult.resultUrl);
            
            if (!resultBuffer) {
                conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
                return m.reply(`❌ Gagal download hasil.\n🔗 Link hasil: ${convertResult.resultUrl}`);
            }
        }
        
        // Step 4: Send result dengan mention
        console.log(`[Image Converter] Sending result`);
        
        const userTag = `@${m.sender.split('@')[0]}`;
        const caption = isHitamkan 
            ? `✅ Gambar berhasil di-hitamkan! ${userTag}`
            : `✅ Gambar berhasil di-putihkan! ${userTag}`;
        
        await conn.sendMessage(m.chat, {
            image: resultBuffer,
            caption: caption,
            mentions: [m.sender]
        }, { quoted: m });
        
        conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } }).catch(() => {});
        
    } catch (error) {
        console.error(`[Image Converter] CRITICAL ERROR:`, error.message);
        console.error(`[Image Converter] Stack:`, error.stack);
        
        conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        
        const msg = error.message || 'Unknown error';
        return m.reply(`❌ *Terjadi error:*\n\`\`\`\n${msg}\n\`\`\``);
    }
};

// ========== HANDLER PROPERTIES ==========
handler.help = [
    "hitamkan - convert gambar ke hitam putih",
    "putihkan - convert gambar ke putih"
];
handler.tags = ["tools"];
handler.command = ["hitamkan", "bw", "blackwhite", "putihkan", "white", "towhite"];
handler.limit = true;

console.log('[Image Converter Handler] Handler loaded successfully with multi-server upload (HF + TmpFiles)');

export default handler;