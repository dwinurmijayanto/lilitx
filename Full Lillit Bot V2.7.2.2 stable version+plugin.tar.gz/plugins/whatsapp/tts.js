import fetch from 'node-fetch';
import { writeFileSync, unlinkSync, existsSync, mkdirSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';

console.log('[TTS Handler] Loading handler...');

// ========== CONFIGURATION ==========
const GRADIO_SPACE_URL = 'https://nihalgazi-text-to-speech-unlimited.hf.space';
const TIMEOUT_MS = 360000; // 6 minutes timeout for TTS processing (usually 2-5 minutes)
const MAX_RETRIES = 3;
const RETRY_DELAY = 5000; // 5 seconds between retries
let DEBUG_MODE = false; // Can be toggled via command
const KNOWN_FN_INDEX = 1; // Confirmed working fn_index for this Space
const ENABLE_AUTO_DISCOVERY = false; // Set to true to search for fn_index if KNOWN_FN_INDEX fails

// Voice options
const VOICES = [
    "alloy", "echo", "fable", "onyx", "nova", "shimmer",
    "coral", "verse", "ballad", "ash", "sage", "amuch", "dan"
];

// ========== DEBUG LOGGER ==========
function debugLog(category, message, data = null) {
    if (!DEBUG_MODE) return;
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] [${category}] ${message}`);
    if (data) {
        console.log(`[${timestamp}] [${category}] Data:`, typeof data === 'string' ? data : JSON.stringify(data, null, 2));
    }
}

// ========== TOGGLE DEBUG ==========
function toggleDebugMode(enable = null) {
    if (enable === null) {
        DEBUG_MODE = !DEBUG_MODE;
    } else {
        DEBUG_MODE = !!enable;
    }
    return DEBUG_MODE;
}

// ========== GENERATE SESSION HASH ==========
function generateSessionHash() {
    return Math.random().toString(36).substring(2, 15);
}

// ========== PARSE SSE STREAM WITH PROGRESS ==========
async function parseSSEStream(response) {
    try {
        debugLog('SSE', 'Starting to parse SSE stream');
        
        const text = await response.text();
        debugLog('SSE', 'Raw SSE text received, length:', text.length);
        
        const lines = text.split('\n');
        const events = [];
        let estimatedTime = 0;
        let queuePosition = 0;
        
        for (const line of lines) {
            if (line.startsWith('data: ')) {
                try {
                    const data = JSON.parse(line.substring(6));
                    events.push(data);
                    
                    // Track progress
                    if (data.msg === 'estimation') {
                        estimatedTime = data.rank_eta || data.eta || 0;
                        queuePosition = data.rank || 0;
                        console.log(`[SSE] Queue position: ${queuePosition}, Estimated time: ${estimatedTime.toFixed(1)}s`);
                    } else if (data.msg === 'process_starts') {
                        console.log(`[SSE] Processing started! ETA: ${data.eta ? data.eta.toFixed(1) + 's' : 'unknown'}`);
                    } else if (data.msg === 'process_completed') {
                        console.log(`[SSE] Processing completed! Duration: ${data.output?.duration || 'unknown'}`);
                    } else if (data.msg === 'progress') {
                        console.log(`[SSE] Progress update:`, data);
                    }
                    
                    debugLog('SSE', `Event [${data.msg}]:`, data);
                } catch (e) {
                    debugLog('SSE', 'Failed to parse line:', line.substring(0, 100));
                }
            }
        }
        
        debugLog('SSE', `Parsed ${events.length} events`);
        console.log(`[SSE] Total events received: ${events.length}`);
        
        // Find the complete event
        const completeEvent = events.find(e => e.msg === 'process_completed');
        if (completeEvent) {
            debugLog('SSE', 'Found process_completed event:', completeEvent);
            return completeEvent;
        }
        
        // Check for errors
        const errorEvent = events.find(e => e.msg === 'error' || e.success === false);
        if (errorEvent) {
            debugLog('SSE', 'Found error event:', errorEvent);
            throw new Error(errorEvent.output?.error || 'Processing error occurred');
        }
        
        // Return last event if no complete event found
        const lastEvent = events[events.length - 1];
        debugLog('SSE', 'No complete event found, returning last event:', lastEvent);
        return lastEvent;
        
    } catch (error) {
        debugLog('SSE', 'Parse error:', error.message);
        throw error;
    }
}

// ========== TEXT TO SPEECH WITH GRADIO API (OPTIMIZED) ==========
async function textToSpeechWithGradio(prompt, voice = 'onyx', emotion = 'happy', retryCount = 0) {
    const startTime = Date.now();
    
    try {
        console.log(`\n${'='.repeat(60)}`);
        console.log(`[TTS] Attempt ${retryCount + 1}/${MAX_RETRIES + 1}`);
        console.log(`[TTS] Voice: ${voice} | Emotion: ${emotion}`);
        console.log(`[TTS] Prompt length: ${prompt.length} characters`);
        console.log(`${'='.repeat(60)}\n`);
        
        debugLog('GRADIO', 'Starting TTS processing');
        debugLog('GRADIO', 'Parameters:', { prompt, voice, emotion, attempt: retryCount + 1 });
        
        const sessionHash = generateSessionHash();
        const useRandomSeed = true;
        const specificSeed = Math.floor(Math.random() * 1000000);
        
        console.log(`[TTS] Session hash: ${sessionHash}`);
        console.log(`[TTS] Random seed: ${specificSeed}`);
        console.log(`[TTS] Using known fn_index: ${KNOWN_FN_INDEX}`);
        
        // Step 1: Join queue with known fn_index
        const joinUrl = `${GRADIO_SPACE_URL}/gradio_api/queue/join?__theme=system`;
        
        const joinPayload = {
            data: [
                prompt,        // prompt_input
                voice,         // voice_dropdown
                emotion,       // emotion_input
                useRandomSeed, // random_seed_checkbox
                specificSeed   // seed_input
            ],
            event_data: null,
            fn_index: KNOWN_FN_INDEX,
            session_hash: sessionHash
        };
        
        debugLog('GRADIO', 'Join payload:', joinPayload);
        console.log(`[TTS] Joining queue...`);
        
        const joinResponse = await fetch(joinUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Referer': `${GRADIO_SPACE_URL}/?__theme=system`
            },
            body: JSON.stringify(joinPayload),
            timeout: 30000
        });
        
        console.log(`[TTS] Queue join response status: ${joinResponse.status}`);
        
        if (!joinResponse.ok) {
            const errorText = await joinResponse.text();
            console.error(`[TTS] Queue join failed: ${errorText.substring(0, 200)}`);
            
            // If known fn_index fails and auto-discovery is enabled, try discovery
            if (ENABLE_AUTO_DISCOVERY) {
                console.log(`[TTS] Known fn_index failed, starting auto-discovery...`);
                return await textToSpeechWithAutoDiscovery(prompt, voice, emotion, retryCount);
            }
            
            throw new Error(`Queue join failed: ${joinResponse.status}`);
        }
        
        const joinResult = await joinResponse.json();
        debugLog('GRADIO', 'Queue joined:', joinResult);
        console.log(`[TTS] Successfully joined queue`);
        
        if (!joinResult.event_id) {
            console.error(`[TTS] No event_id in response:`, joinResult);
            
            // If no event_id and auto-discovery is enabled
            if (ENABLE_AUTO_DISCOVERY) {
                console.log(`[TTS] No event_id received, starting auto-discovery...`);
                return await textToSpeechWithAutoDiscovery(prompt, voice, emotion, retryCount);
            }
            
            throw new Error('No event_id received');
        }
        
        // Step 2: Get result from SSE stream
        const eventId = joinResult.event_id;
        console.log(`[TTS] Event ID: ${eventId}`);
        console.log(`[TTS] Waiting for processing (this may take 2-5 minutes)...`);
        debugLog('GRADIO', 'Waiting for processing, event_id:', eventId);
        
        const dataUrl = `${GRADIO_SPACE_URL}/gradio_api/queue/data?session_hash=${sessionHash}`;
        debugLog('GRADIO', 'Fetching result from:', dataUrl);
        console.log(`[TTS] Connecting to SSE stream...`);
        
        const dataResponse = await fetch(dataUrl, {
            timeout: TIMEOUT_MS,
            headers: {
                'Accept': 'text/event-stream',
                'Referer': `${GRADIO_SPACE_URL}/?__theme=system`
            }
        });
        
        console.log(`[TTS] SSE stream connected, status: ${dataResponse.status}`);
        
        if (!dataResponse.ok) {
            console.error(`[TTS] SSE stream failed with status: ${dataResponse.status}`);
            throw new Error(`Data fetch failed: ${dataResponse.status}`);
        }
        
        debugLog('GRADIO', 'Response received, parsing SSE...');
        console.log(`[TTS] Parsing SSE events...`);
        
        const result = await parseSSEStream(dataResponse);
        
        if (!result) {
            console.error(`[TTS] Failed to parse SSE stream`);
            throw new Error('Failed to parse SSE stream');
        }
        
        debugLog('GRADIO', 'SSE Result:', result);
        console.log(`[TTS] SSE Result msg: ${result.msg}`);
        
        // Check for errors
        if (result.success === false) {
            console.error(`[TTS] Processing failed:`, result);
            throw new Error('Processing failed');
        }
        
        if (!result.output || !result.output.data) {
            console.error(`[TTS] No output data received:`, result);
            console.error(`[TTS] Full result:`, JSON.stringify(result, null, 2));
            throw new Error('No output data received');
        }
        
        const elapsedTime = ((Date.now() - startTime) / 1000).toFixed(2);
        console.log(`[TTS] Processing completed in ${elapsedTime}s`);
        console.log(`[TTS] ✓ Used fn_index: ${KNOWN_FN_INDEX}`);
        console.log(`${'='.repeat(60)}\n`);
        
        return await processGradioResult(result);
        
    } catch (error) {
        const elapsedTime = ((Date.now() - startTime) / 1000).toFixed(2);
        console.error(`[TTS] Error after ${elapsedTime}s:`, error.message);
        debugLog('GRADIO', 'Error:', error.message);
        debugLog('GRADIO', 'Stack:', error.stack);
        
        // Retry logic
        if (retryCount < MAX_RETRIES) {
            console.log(`[TTS] Retrying in ${RETRY_DELAY / 1000}s... (${retryCount + 1}/${MAX_RETRIES})`);
            console.log(`${'='.repeat(60)}\n`);
            
            await new Promise(resolve => setTimeout(resolve, RETRY_DELAY));
            return textToSpeechWithGradio(prompt, voice, emotion, retryCount + 1);
        }
        
        console.error(`[TTS] All retry attempts failed`);
        console.log(`${'='.repeat(60)}\n`);
        return { success: false, message: error.message };
    }
}

// ========== AUTO DISCOVERY FALLBACK (IF ENABLED) ==========
async function textToSpeechWithAutoDiscovery(prompt, voice, emotion, retryCount) {
    const startTime = Date.now();
    
    try {
        console.log(`\n${'!'.repeat(60)}`);
        console.log(`[TTS-DISCOVERY] Starting auto fn_index discovery...`);
        console.log(`${'!'.repeat(60)}\n`);
        
        const sessionHash = generateSessionHash();
        const useRandomSeed = true;
        const specificSeed = Math.floor(Math.random() * 1000000);
        const joinUrl = `${GRADIO_SPACE_URL}/gradio_api/queue/join?__theme=system`;
        
        let result = null;
        let successfulFnIndex = null;
        
        for (let fnIndex = 0; fnIndex <= 50; fnIndex++) {
            console.log(`[TTS-DISCOVERY] Testing fn_index: ${fnIndex}...`);
            
            const testSessionHash = generateSessionHash();
            
            const joinPayload = {
                data: [prompt, voice, emotion, useRandomSeed, specificSeed],
                event_data: null,
                fn_index: fnIndex,
                session_hash: testSessionHash
            };
            
            try {
                const joinResponse = await fetch(joinUrl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Referer': `${GRADIO_SPACE_URL}/?__theme=system`
                    },
                    body: JSON.stringify(joinPayload),
                    timeout: 30000
                });
                
                if (!joinResponse.ok) {
                    console.log(`[TTS-DISCOVERY] fn_index ${fnIndex}: HTTP ${joinResponse.status} (skip)`);
                    continue;
                }
                
                const joinResult = await joinResponse.json();
                
                if (!joinResult.event_id) {
                    console.log(`[TTS-DISCOVERY] fn_index ${fnIndex}: No event_id (skip)`);
                    continue;
                }
                
                console.log(`[TTS-DISCOVERY] fn_index ${fnIndex}: Joined queue, testing response...`);
                
                const dataUrl = `${GRADIO_SPACE_URL}/gradio_api/queue/data?session_hash=${testSessionHash}`;
                const dataResponse = await fetch(dataUrl, {
                    timeout: 60000,
                    headers: {
                        'Accept': 'text/event-stream',
                        'Referer': `${GRADIO_SPACE_URL}/?__theme=system`
                    }
                });
                
                if (!dataResponse.ok) {
                    console.log(`[TTS-DISCOVERY] fn_index ${fnIndex}: SSE failed (skip)`);
                    continue;
                }
                
                const testResult = await parseSSEStream(dataResponse);
                
                if (!testResult || !testResult.output || !testResult.output.data) {
                    console.log(`[TTS-DISCOVERY] fn_index ${fnIndex}: No output data (skip)`);
                    continue;
                }
                
                const outputData = testResult.output.data;
                
                if (Array.isArray(outputData) && outputData.length > 0) {
                    const firstItem = outputData[0];
                    
                    if (firstItem && typeof firstItem === 'object' && firstItem.__type__ === 'update') {
                        console.log(`[TTS-DISCOVERY] fn_index ${fnIndex}: Returns update object only (skip)`);
                        continue;
                    }
                    
                    const hasAudioFile = outputData.some(item => {
                        if (typeof item === 'object' && item !== null) {
                            return item.url || item.path || item.name;
                        }
                        return false;
                    });
                    
                    if (hasAudioFile || (outputData.length >= 2 && typeof outputData[1] === 'string')) {
                        console.log(`[TTS-DISCOVERY] ✓✓✓ FOUND! Valid fn_index: ${fnIndex} ✓✓✓`);
                        console.log(`[TTS-DISCOVERY] UPDATE THE CODE: Set KNOWN_FN_INDEX = ${fnIndex}`);
                        result = testResult;
                        successfulFnIndex = fnIndex;
                        break;
                    } else {
                        console.log(`[TTS-DISCOVERY] fn_index ${fnIndex}: No audio file (skip)`);
                    }
                }
                
            } catch (err) {
                console.log(`[TTS-DISCOVERY] fn_index ${fnIndex}: Error - ${err.message.substring(0, 50)} (skip)`);
            }
            
            if (fnIndex % 10 === 0 && fnIndex > 0) {
                console.log(`[TTS-DISCOVERY] Checkpoint: Tested ${fnIndex} indices, pausing 2s...`);
                await new Promise(resolve => setTimeout(resolve, 2000));
            }
        }
        
        if (!result || successfulFnIndex === null) {
            console.error(`[TTS-DISCOVERY] ✗✗✗ FAILED: No valid fn_index found ✗✗✗`);
            throw new Error('Auto-discovery failed: Could not find valid fn_index (tested 0-50)');
        }
        
        const elapsedTime = ((Date.now() - startTime) / 1000).toFixed(2);
        console.log(`[TTS-DISCOVERY] Discovery completed in ${elapsedTime}s`);
        console.log(`${'!'.repeat(60)}\n`);
        
        return await processGradioResult(result);
        
    } catch (error) {
        console.error(`[TTS-DISCOVERY] Discovery error:`, error.message);
        throw error;
    }
}

// ========== PROCESS GRADIO RESULT ==========
async function processGradioResult(result) {
    try {
        console.log(`[PROCESS] Processing result...`);
        debugLog('PROCESS', 'Processing result');
        
        // Result format based on actual response:
        // {"msg":"process_completed","output":{"data":[{audio_file_object}, "status_message"]}}
        
        if (!result.output || !result.output.data) {
            console.error(`[PROCESS] No output data in result:`, result);
            throw new Error('No output data in result');
        }
        
        const output = result.output.data;
        debugLog('PROCESS', 'Output data:', output);
        
        if (!Array.isArray(output) || output.length < 2) {
            console.error(`[PROCESS] Invalid output format:`, output);
            throw new Error('Invalid output format');
        }
        
        const audioData = output[0]; // First element is audio file object
        const statusMessage = output[1]; // Second element is status message
        
        console.log(`[PROCESS] Status: ${statusMessage}`);
        debugLog('PROCESS', 'Audio data:', audioData);
        debugLog('PROCESS', 'Status:', statusMessage);
        
        if (!audioData) {
            console.error(`[PROCESS] No audio data found`);
            throw new Error('No audio data found');
        }
        
        // Extract download URL from audio data object
        let downloadUrl = '';
        
        if (typeof audioData === 'object' && audioData !== null) {
            // Based on actual response: {"path":"...", "url":"https://...", ...}
            if (audioData.url) {
                downloadUrl = audioData.url;
                console.log(`[PROCESS] Using direct URL from response`);
                debugLog('PROCESS', 'Using audioData.url:', downloadUrl);
            } else if (audioData.path) {
                // Fallback: construct URL from path
                downloadUrl = `${GRADIO_SPACE_URL}/gradio_api/file=${audioData.path}`;
                console.log(`[PROCESS] Constructed URL from path`);
                debugLog('PROCESS', 'Constructed URL from path:', downloadUrl);
            } else {
                console.error(`[PROCESS] No valid URL or path in audio data:`, audioData);
                throw new Error('No valid URL or path in audio data');
            }
        } else if (typeof audioData === 'string') {
            if (audioData.startsWith('http')) {
                downloadUrl = audioData;
                console.log(`[PROCESS] Using audio data as direct URL`);
            } else if (audioData.startsWith('/')) {
                downloadUrl = `${GRADIO_SPACE_URL}/gradio_api/file=${audioData}`;
                console.log(`[PROCESS] Constructed URL from path string`);
            } else {
                console.error(`[PROCESS] Invalid audio data string:`, audioData);
                throw new Error('Invalid audio data string format');
            }
        } else {
            console.error(`[PROCESS] Unexpected audio data type:`, typeof audioData);
            throw new Error('Unexpected audio data type');
        }
        
        console.log(`[PROCESS] Download URL: ${downloadUrl.substring(0, 80)}...`);
        debugLog('PROCESS', 'Downloading audio from:', downloadUrl);
        
        // Download the audio file with retry
        let audioResponse;
        let downloadAttempt = 0;
        const maxDownloadAttempts = 3;
        
        while (downloadAttempt < maxDownloadAttempts) {
            try {
                console.log(`[PROCESS] Download attempt ${downloadAttempt + 1}/${maxDownloadAttempts}...`);
                
                audioResponse = await fetch(downloadUrl, {
                    timeout: 60000, // 60 seconds for download
                    headers: {
                        'User-Agent': 'Mozilla/5.0',
                        'Referer': `${GRADIO_SPACE_URL}/?__theme=system`
                    }
                });
                
                console.log(`[PROCESS] Download response status: ${audioResponse.status}`);
                debugLog('PROCESS', 'Download status:', audioResponse.status);
                
                if (audioResponse.ok) {
                    break; // Success, exit retry loop
                }
                
                console.error(`[PROCESS] Download failed with status ${audioResponse.status}`);
                downloadAttempt++;
                
                if (downloadAttempt < maxDownloadAttempts) {
                    console.log(`[PROCESS] Retrying download in 2s...`);
                    await new Promise(resolve => setTimeout(resolve, 2000));
                }
            } catch (error) {
                console.error(`[PROCESS] Download error:`, error.message);
                downloadAttempt++;
                
                if (downloadAttempt < maxDownloadAttempts) {
                    console.log(`[PROCESS] Retrying download in 2s...`);
                    await new Promise(resolve => setTimeout(resolve, 2000));
                } else {
                    throw error;
                }
            }
        }
        
        if (!audioResponse.ok) {
            throw new Error(`Audio download failed after ${maxDownloadAttempts} attempts: ${audioResponse.status}`);
        }
        
        const resultBuffer = await audioResponse.buffer();
        console.log(`[PROCESS] Downloaded audio: ${(resultBuffer.length / 1024).toFixed(2)} KB`);
        debugLog('PROCESS', 'Downloaded audio buffer size:', resultBuffer.length);
        
        if (resultBuffer.length === 0) {
            console.error(`[PROCESS] Downloaded audio file is empty`);
            throw new Error('Downloaded audio file is empty');
        }
        
        console.log(`[PROCESS] ✓ Audio processing completed successfully\n`);
        
        return { 
            success: true, 
            resultBuffer, 
            status: statusMessage 
        };
        
    } catch (error) {
        console.error(`[PROCESS] Processing error:`, error.message);
        debugLog('PROCESS', 'Error:', error.message);
        return { success: false, message: error.message };
    }
}

// ========== HELP MESSAGE ==========
function generateUsageHelp(prefix, cmd) {
    return `*🎤 TEXT TO SPEECH (OpenAI TTS)*

📌 *Cara Penggunaan:*

*Basic:*
${prefix}${cmd} <text>

*Dengan Voice:*
${prefix}${cmd} <voice> <text>

*Dengan Voice & Emotion:*
${prefix}${cmd} <voice> <emotion> | <text>

📋 *Available Voices:*
${VOICES.join(', ')}

🎭 *Emotion Examples:*
- happy, sad, excited, calm
- angry, cheerful, nervous
- confident, shy, tired
- sarcastic, enthusiastic

💡 *Default Settings:*
- Voice: onyx
- Emotion: happy

*Contoh Penggunaan:*
${prefix}${cmd} Hello, how are you today?
${prefix}${cmd} nova Hello, how are you?
${prefix}${cmd} shimmer excited | This is amazing!
${prefix}${cmd} onyx calm | Good morning everyone

*Tips:*
- Gunakan [laughs], [sighs], [cry] untuk efek
- Gunakan *text* untuk emphasis
- Max 1000 karakter per request
`;
}

// ========== DEBUG HELP MESSAGE ==========
function generateDebugHelp(prefix, cmd) {
    const status = DEBUG_MODE ? '✅ ON' : '❌ OFF';
    return `*🔧 DEBUG MODE CONTROL*

*Status:* ${status}

*Cara Penggunaan:*
${prefix}${cmd} debug on   - Enable debug mode
${prefix}${cmd} debug off  - Disable debug mode
${prefix}${cmd} debug      - Toggle debug mode

*Informasi:*
Debug mode menampilkan log detail untuk troubleshooting, termasuk:
- SSE stream events
- Gradio API responses
- Session hash dan fn_index
- Request/response details

*Catatan:*
- Debug ON akan membuat console output lebih verbose
- Gunakan saat troubleshooting atau development
- Disable untuk production untuk performa lebih baik
`;
}

// ========== PARSE COMMAND ARGUMENTS ==========
function parseCommandArgs(text) {
    if (!text) return null;
    
    // Format 1: voice emotion | text
    const pipeMatch = text.match(/^(\w+)\s+(.+?)\s*\|\s*(.+)$/);
    if (pipeMatch) {
        const voice = pipeMatch[1].toLowerCase();
        const emotion = pipeMatch[2].trim();
        const prompt = pipeMatch[3].trim();
        
        if (VOICES.includes(voice)) {
            return { voice, emotion, prompt };
        }
    }
    
    // Format 2: voice text
    const words = text.split(' ');
    if (words.length >= 2) {
        const firstWord = words[0].toLowerCase();
        if (VOICES.includes(firstWord)) {
            return {
                voice: firstWord,
                emotion: 'happy',
                prompt: words.slice(1).join(' ')
            };
        }
    }
    
    // Format 3: just text
    return {
        voice: 'onyx',
        emotion: 'happy',
        prompt: text
    };
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    let prefix = usedPrefix || '.';
    const cmd = command || 'tts';
    
    try {
        let inputText = '';
        if (text) {
            inputText = text.trim();
        } else if (args && args.length > 0) {
            inputText = args.join(' ').trim();
        }
        
        // Debug control commands
        if (inputText.toLowerCase() === 'debug') {
            const newStatus = toggleDebugMode();
            return m.reply(`🔧 *Debug Mode*\n\nStatus: ${newStatus ? '✅ ON' : '❌ OFF'}\n\nKetik ${prefix}${cmd} debug help untuk info lebih lanjut`);
        }
        
        if (inputText.toLowerCase().startsWith('debug ')) {
            const debugCmd = inputText.substring(6).trim().toLowerCase();
            
            if (debugCmd === 'on') {
                toggleDebugMode(true);
                return m.reply(`✅ *Debug Mode Enabled*\n\nConsole akan menampilkan log detail.`);
            } else if (debugCmd === 'off') {
                toggleDebugMode(false);
                return m.reply(`❌ *Debug Mode Disabled*\n\nConsole normal kembali.`);
            } else if (debugCmd === 'help') {
                return m.reply(generateDebugHelp(prefix, cmd));
            }
        }
        
        if (!inputText || inputText.toLowerCase() === 'help' || inputText === '?') {
            return m.reply(generateUsageHelp(prefix, cmd));
        }
        
        if (inputText.length > 1000) {
            return m.reply('⚠️ Text terlalu panjang! Maksimal 1000 karakter.');
        }
        
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        const params = parseCommandArgs(inputText);
        
        if (!params) {
            return m.reply(`❌ Format tidak valid!\n\n💡 Contoh:\n${prefix}${cmd} Hello world\n${prefix}${cmd} nova Hai semuanya\n\nKetik ${prefix}${cmd} help untuk panduan lengkap`);
        }
        
        console.log(`\n${'━'.repeat(60)}`);
        console.log(`[HANDLER] New TTS request from user`);
        console.log(`[HANDLER] Chat: ${m.chat}`);
        console.log(`[HANDLER] Voice: ${params.voice}`);
        console.log(`[HANDLER] Emotion: ${params.emotion}`);
        console.log(`[HANDLER] Text: "${params.prompt.substring(0, 50)}${params.prompt.length > 50 ? '...' : ''}"`);
        console.log(`[HANDLER] Debug: ${DEBUG_MODE ? 'ON' : 'OFF'}`);
        console.log(`${'━'.repeat(60)}\n`);
        
        debugLog('HANDLER', 'Parsed params:', params);
        
        await conn.sendMessage(m.chat, { react: { text: '🎤', key: m.key } });
        
        // Start timer
        const startTime = Date.now();
        
        const result = await textToSpeechWithGradio(params.prompt, params.voice, params.emotion);
        
        if (!result.success) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            
            console.error(`[HANDLER] TTS generation failed: ${result.message}`);
            console.log(`${'━'.repeat(60)}\n`);
            
            return m.reply(`❌ Gagal menggenerate audio.\n\n💡 Error: ${result.message}\n\n⚠️ Kemungkinan penyebab:\n- Status sedang maintenance\n- Text mengandung konten tidak pantas\n- Server timeout (coba text lebih pendek)\n\n🔄 Coba lagi dalam beberapa saat`);
        }
        
        console.log(`[HANDLER] TTS generation successful!`);
        console.log(`[HANDLER] Audio size: ${(result.resultBuffer.length / 1024).toFixed(2)} KB`);
        debugLog('HANDLER', 'Sending audio result');
        
        // Save to temp file
        const tempDir = join(tmpdir(), 'tts');
        if (!existsSync(tempDir)) {
            mkdirSync(tempDir, { recursive: true });
        }
        
        const tempFile = join(tempDir, `tts_${Date.now()}.mp3`);
        writeFileSync(tempFile, result.resultBuffer);
        console.log(`[HANDLER] Temp file created: ${tempFile}`);
        
        // Send audio file
        console.log(`[HANDLER] Sending audio to WhatsApp...`);
        await conn.sendMessage(m.chat, {
            audio: result.resultBuffer,
            mimetype: 'audio/mpeg',
            ptt: false,
            fileName: `tts_${params.voice}_${Date.now()}.mp3`
        }, { quoted: m });
        
        // Cleanup temp file
        if (existsSync(tempFile)) {
            unlinkSync(tempFile);
            console.log(`[HANDLER] Temp file deleted`);
        }
        
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
        const totalTime = ((Date.now() - startTime) / 1000).toFixed(2);
        console.log(`[HANDLER] ✓ Complete! Total time: ${totalTime}s`);
        console.log(`${'━'.repeat(60)}\n`);
        
    } catch (error) {
        console.error('[HANDLER] CRITICAL ERROR:', error.message);
        console.error('[HANDLER] Stack:', error.stack);
        console.log(`${'━'.repeat(60)}\n`);
        
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        
        const msg = error.message || 'Unknown error';
        return m.reply(`❌ *Terjadi error:*\n\`\`\`\n${msg}\n\`\`\`\n\n💡 Coba:\n- Pastikan text tidak terlalu panjang\n- Tunggu beberapa saat lalu coba lagi\n- Ketik ${usedPrefix}${command} help untuk bantuan`);
    }
};

// ========== HANDLER PROPERTIES ==========
handler.help = ["tts <text> - convert text to speech", "tts debug - toggle debug mode"];
handler.tags = ["tools"];
handler.command = ["tts", "say", "speak"];
handler.limit = true;

console.log('[TTS Handler] Handler loaded successfully');

export default handler;