const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

// ═══════════════════════════════════════════════════════════════════
//  Pinterest Downloader — No 3rd Party API
//  Menggunakan: Pinterest JSON API + og:meta scraping
//  Support: Video, GIF, Photo
// ═══════════════════════════════════════════════════════════════════

// ─── Validators ───────────────────────────────────────────────────

function isValidPinterestUrl(url) {
    return /pinterest\.(com|co\.uk|fr|de|jp|au)|pin\.it/i.test(url);
}

function extractPinterestUrls(text) {
    const matches = text.match(/(https?:\/\/)?(www\.)?pin\.it\/[^\s]+|(https?:\/\/)?(www\.)?pinterest\.[a-z.]+\/pin\/[^\s]+/gi) || [];
    return [...new Set(matches)];
}

function normalizeUrl(url) {
    if (!url.startsWith('http')) url = 'https://' + url;
    return url;
}

function extractPinId(url) {
    return url.match(/\/pin\/(\d+)/)?.[1] || null;
}

// ─── Helpers ──────────────────────────────────────────────────────

function formatSize(bytes) {
    bytes = Number(bytes) || 0;
    if (bytes >= 1_048_576) return (bytes/1_048_576).toFixed(2) + ' MB';
    if (bytes >= 1_024)     return (bytes/1_024).toFixed(1) + ' KB';
    return bytes + ' B';
}

function decodeHtml(str) {
    if (!str) return str;
    return str
        .replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>')
        .replace(/&quot;/g,'"').replace(/&#039;/g,"'").replace(/&apos;/g,"'");
}

async function downloadBuffer(url, type = 'file') {
    const headerSets = [
        {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
            'Accept':     'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
            'Referer':    'https://www.pinterest.com/',
            'Origin':     'https://www.pinterest.com',
        },
        {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
            'Accept':     '*/*',
        },
        {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36',
            'Accept':     '*/*',
            'Referer':    'https://www.pinterest.com/',
        },
    ];

    for (const headers of headerSets) {
        try {
            const res = await fetch(url, { headers, timeout: 60000, follow: 10 });
            if (res.ok || res.status === 206) {
                const buf = Buffer.from(await res.arrayBuffer());
                console.log(`📦 ${type}: ${formatSize(buf.length)}`);
                return buf;
            }
            console.log(`⚠️  ${type} attempt HTTP ${res.status}`);
        } catch (e) {
            console.log(`⚠️  ${type} attempt error: ${e.message}`);
        }
    }
    throw new Error(`Gagal mendownload ${type} setelah 3 percobaan`);
}

// ─── Resolve short URL pin.it ─────────────────────────────────────

async function resolveShortUrl(url) {
    if (!url.includes('pin.it')) return url;
    console.log(`🔗 Resolving short URL: ${url}`);
    const res = await fetch(url, {
        timeout: 10000,
        follow: 5,
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36' }
    });
    console.log(`✅ Resolved to: ${res.url}`);
    return res.url;
}

// ─── Method 1: Pinterest Internal JSON API ────────────────────────

async function fetchViaJsonApi(pinId) {
    const endpoints = [
        // Endpoint v3 (paling reliable)
        `https://www.pinterest.com/resource/PinResource/get/?source_url=/pin/${pinId}/&data={"options":{"id":"${pinId}","field_set_key":"detailed"},"context":{}}`,
        // Endpoint alternatif
        `https://www.pinterest.com/v3/pidgets/pins/info/?pin_ids=${pinId}`,
    ];

    const headers = {
        'User-Agent':       'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
        'Accept':           'application/json, text/javascript, */*; q=0.01',
        'Accept-Language':  'en-US,en;q=0.9',
        'X-Requested-With': 'XMLHttpRequest',
        'X-Pinterest-AppState': 'active',
        'Referer':          `https://www.pinterest.com/pin/${pinId}/`,
    };

    for (const endpoint of endpoints) {
        try {
            console.log(`🔌 Trying JSON API: ${endpoint.slice(0, 80)}...`);
            const res = await fetch(endpoint, { headers, timeout: 15000, follow: 5 });
            if (!res.ok) { console.log(`⚠️  API HTTP ${res.status}`); continue; }

            const json = await res.json();

            // Parse endpoint v3 PinResource
            const pinData = json?.resource_response?.data || json?.data?.[0] || null;
            if (pinData) {
                console.log('✅ Got data from JSON API');
                return pinData;
            }
        } catch (e) {
            console.log(`⚠️  JSON API error: ${e.message}`);
        }
    }
    return null;
}

// ─── Method 2: Scrape HTML dengan ekstraksi JSON yang lebih baik ──

async function fetchViaHtmlScrape(url) {
    const uaList = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15',
        // User-agent lama kadang dapat respons berbeda
        'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)',
    ];

    let html = null;
    for (const ua of uaList) {
        try {
            const res = await fetch(url, {
                timeout: 20000,
                follow: 5,
                headers: {
                    'User-Agent':      ua,
                    'Accept':          'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.9',
                },
            });
            if (res.ok) {
                html = await res.text();
                console.log(`✅ Fetched HTML: ${html.length} chars`);
                break;
            }
        } catch (e) {
            console.log(`⚠️  Fetch failed: ${e.message}`);
        }
    }
    if (!html) return null;
    return html;
}

// ─── Extract pin data dari HTML ───────────────────────────────────

function extractPinDataFromHtml(html, pinId) {
    // Method A: __PWS_INITIAL_PROPS__
    const propsMatch = html.match(/window\.__PWS_INITIAL_PROPS__\s*=\s*({.+?});\s*<\/script>/s);
    if (propsMatch) {
        try {
            const props = JSON.parse(propsMatch[1]);
            const redux = props?.initialReduxState || props;
            const pins  = redux?.pins || {};
            if (pinId && pins[pinId]) {
                console.log('✅ Got data from __PWS_INITIAL_PROPS__');
                return pins[pinId];
            }
        } catch (e) {
            console.log(`⚠️  PWS_INITIAL_PROPS parse failed: ${e.message}`);
        }
    }

    // Method B: __PWS_DATA__
    const dataMatch = html.match(/window\.__PWS_DATA__\s*=\s*({.+?});\s*<\/script>/s);
    if (dataMatch) {
        try {
            const d = JSON.parse(dataMatch[1]);
            const pinData = d?.props?.initialProps?.pins?.[pinId] ||
                            d?.resourceResponses?.[0]?.response?.data || null;
            if (pinData) {
                console.log('✅ Got data from __PWS_DATA__');
                return pinData;
            }
        } catch (e) {
            console.log(`⚠️  __PWS_DATA__ parse failed: ${e.message}`);
        }
    }

    // Method C: Cari JSON blob di seluruh HTML yang mengandung pin data
    // Cari pattern {"id":"<pinId>",...} atau {"id":<pinId>,...}
    const pinPatterns = [
        new RegExp(`"id"\\s*:\\s*"${pinId}"[^}]{0,2000}"images"\\s*:`, 's'),
        new RegExp(`"id"\\s*:\\s*${pinId}[^}]{0,2000}"images"\\s*:`, 's'),
    ];

    for (const pattern of pinPatterns) {
        if (pattern.test(html)) {
            // Coba ekstrak JSON object yang mengandung id ini
            try {
                // Temukan posisi
                const idx = html.search(new RegExp(`"id"\\s*:\\s*["']?${pinId}["']?`));
                if (idx !== -1) {
                    // Temukan opening brace sebelum posisi ini
                    let start = idx;
                    let depth = 0;
                    for (let i = idx; i >= 0; i--) {
                        if (html[i] === '{') { start = i; break; }
                    }
                    // Ekstrak JSON dengan bracket matching
                    let end = start;
                    depth = 0;
                    for (let i = start; i < html.length; i++) {
                        if (html[i] === '{') depth++;
                        else if (html[i] === '}') {
                            depth--;
                            if (depth === 0) { end = i; break; }
                        }
                    }
                    const candidate = html.slice(start, end + 1);
                    const parsed = JSON.parse(candidate);
                    if (parsed.images || parsed.videos) {
                        console.log('✅ Got data from JSON blob extraction');
                        return parsed;
                    }
                }
            } catch { /* skip */ }
        }
    }

    return null;
}

// ─── Extract media dari pinData object ───────────────────────────

function extractMediaFromPinData(pinData) {
    let videoUrl = null, imageUrl = null, mediaType = 'image';

    // Video
    const videos = pinData?.videos?.video_list || {};
    const videoOrder = ['V_720P', 'V_HLSV4_MOB', 'V_EXP7', 'V_480P', 'V_EXP4', 'V_EXP3'];
    const videoKeys = Object.keys(videos).sort((a, b) => {
        const ai = videoOrder.indexOf(a), bi = videoOrder.indexOf(b);
        return (ai === -1 ? 999 : ai) - (bi === -1 ? 999 : bi);
    });
    if (videoKeys.length) {
        // Cari yang bukan HLS
        for (const key of videoKeys) {
            const u = videos[key]?.url || '';
            if (u && !u.includes('.m3u8')) { videoUrl = u; break; }
        }
        // Fallback ke HLS jika tidak ada MP4
        if (!videoUrl) videoUrl = videos[videoKeys[0]]?.url || null;
        if (videoUrl) mediaType = 'video';
    }

    // Image — prioritas kualitas tinggi
    const imgs = pinData?.images || {};
    imageUrl = imgs?.orig?.url
        || imgs?.['736x']?.url
        || imgs?.['564x']?.url
        || imgs?.['474x']?.url
        || null;

    return { videoUrl, imageUrl, mediaType };
}

// ─── Core: Get Pinterest Data ─────────────────────────────────────

async function getPinterestData(url) {
    // Resolve pin.it short URL
    url = await resolveShortUrl(url);

    // Normalize localized domain → www.pinterest.com
    url = url.replace(/https?:\/\/[a-z]{2,3}\.pinterest\.com/, 'https://www.pinterest.com');
    // Normalize tanpa www
    url = url.replace(/https?:\/\/pinterest\.com/, 'https://www.pinterest.com');
    console.log(`🔗 Normalized URL: ${url}`);

    const pinId = extractPinId(url);
    if (!pinId) throw new Error('Pin ID tidak ditemukan dari URL');
    console.log(`📌 Pin ID: ${pinId}`);

    let videoUrl = null, imageUrl = null, mediaType = 'image';
    let title = null, description = null, author = null;

    // ── Method 1: Pinterest JSON API ─────────────────────────────
    const apiData = await fetchViaJsonApi(pinId);
    if (apiData) {
        const media = extractMediaFromPinData(apiData);
        videoUrl    = media.videoUrl;
        imageUrl    = media.imageUrl;
        mediaType   = media.mediaType;
        title       = apiData?.title || null;
        description = apiData?.description || null;
        author      = apiData?.pinner?.username || apiData?.native_creator?.username || null;
    }

    // ── Method 2: HTML scrape jika API gagal ─────────────────────
    if (!videoUrl && !imageUrl) {
        console.log('⚠️  API failed, trying HTML scrape...');
        const html = await fetchViaHtmlScrape(url);

        if (html) {
            const pinData = extractPinDataFromHtml(html, pinId);

            if (pinData) {
                const media = extractMediaFromPinData(pinData);
                videoUrl    = media.videoUrl;
                imageUrl    = media.imageUrl;
                mediaType   = media.mediaType;
                title       = pinData?.title || null;
                description = pinData?.description || null;
                author      = pinData?.pinner?.username || pinData?.native_creator?.username || null;
            }

            // ── Method 3: Regex dari HTML ─────────────────────────
            if (!videoUrl && !imageUrl) {
                console.log('⚠️  JSON extraction failed, trying regex...');

                // Video URLs
                const videoMatches = [...html.matchAll(/https:\/\/v\.pinimg\.com\/[a-zA-Z0-9/_.-]+\.mp4[^"'\s]*/gi)].map(m => m[0]);
                const uniqueVideos = [...new Set(videoMatches)];

                // Image URLs — filter ketat agar tidak dapat icon
                const imageMatches = [...html.matchAll(/https:\/\/i\.pinimg\.com\/[a-zA-Z0-9/_.-]+\.(jpg|jpeg|png|gif|webp)/gi)].map(m => m[0]);
                const uniqueImages = [...new Set(imageMatches)].filter(u => {
                    // Exclude: icon, logo, avatar, UI asset
                    // Pinterest pin images biasanya path: /originals/, /736x/, /564x/, /474x/
                    // Icon/logo biasanya: /webapp/, /responsive-assets/, /static/
                    if (/webapp|responsive.assets|static|favicon|icon|logo|badge/i.test(u)) return false;
                    // Harus mengandung path resolusi pin yang valid
                    return /\/originals\/|\/736x\/|\/564x\/|\/474x\/|\/236x\//.test(u);
                });

                console.log(`🔍 Found ${uniqueVideos.length} video URLs, ${uniqueImages.length} image URLs`);

                // Ambil og:image untuk cross-check
                const ogImage = html.match(/<meta property="og:image" content="([^"]+)"/i)?.[1] || '';
                // Decode HTML entities di og:image
                const ogImageDecoded = decodeHtml(ogImage);

                if (uniqueVideos.length) {
                    videoUrl  = uniqueVideos[0];
                    mediaType = 'video';
                    // Coba ambil thumbnail dari og:image
                    imageUrl = ogImageDecoded || uniqueImages[0] || null;
                } else if (uniqueImages.length) {
                    // Prioritaskan gambar yang hash-nya cocok dengan og:image
                    const ogHash = ogImageDecoded.match(/\/([a-f0-9]{32})\./)?.[1] || '';
                    imageUrl = (ogHash && uniqueImages.find(u => u.includes(ogHash))) || uniqueImages[0];
                    mediaType = 'image';
                } else if (ogImageDecoded) {
                    // Fallback: gunakan og:image langsung jika bukan icon
                    if (!/webapp|static|favicon|icon|logo/i.test(ogImageDecoded)) {
                        imageUrl  = ogImageDecoded;
                        mediaType = 'image';
                        console.log(`⚠️  Using og:image as last resort`);
                    }
                }

                // Metadata dari og:meta
                if (!title) title = decodeHtml(html.match(/<meta property="og:title" content="([^"]+)"/i)?.[1] || '') || null;
                if (!description) description = decodeHtml(html.match(/<meta property="og:description" content="([^"]+)"/i)?.[1] || '') || null;
            }
        }
    }

    const mediaUrl = videoUrl || imageUrl;
    if (!mediaUrl) throw new Error('Media tidak ditemukan. Pin mungkin privat atau konten tidak didukung.');

    console.log(`✅ Pinterest data: type=${mediaType} | url=${mediaUrl.slice(0, 80)}`);

    return {
        media_url:   mediaUrl,
        video_url:   videoUrl,
        image_url:   imageUrl,
        media_type:  mediaType,
        title:       title       || 'Pinterest Pin',
        description: description || null,
        author:      author      || null,
        source_url:  url,
    };
}

// ─── Caption Builder ──────────────────────────────────────────────

function buildCaption(data) {
    let cap = '';
    if (data.title && data.title !== 'Pinterest Pin') cap += `📌 *${data.title}*\n`;
    if (data.author) cap += `👤 @${data.author}\n`;
    if (data.description && data.description !== data.title) {
        const desc = data.description.length > 120 ? data.description.slice(0, 120) + '...' : data.description;
        cap += `\n💬 ${desc}\n`;
    }
    cap += `\n📍 Pinterest`;
    return cap.trim();
}

// ─── Handler ──────────────────────────────────────────────────────

const HELP_MSG = (p, c) => `
*📥 Pinterest Downloader*
_Pinterest API + og:meta scraping_

*Penggunaan:*
${p}${c} <url>

*Contoh:*
${p}${c} https://www.pinterest.com/pin/123456789/
${p}${c} https://pin.it/abcXYZ

✅ Video, GIF, Photo
✅ Short URL pin.it support
`.trim();

let handler = async (m, { conn, args, usedPrefix, command }) => {
    const input  = args?.join(' ').trim() || '';
    const prefix = usedPrefix || m.text?.match(/^([.!#/])/)?.[1] || '.';
    const cmd    = command || 'pin';

    if (!input) return m.reply(HELP_MSG(prefix, cmd));

    const urls = extractPinterestUrls(input).filter(isValidPinterestUrl);
    if (!urls.length)
        return m.reply('❌ URL Pinterest tidak valid.\n\nContoh:\n• https://www.pinterest.com/pin/123456\n• https://pin.it/abcXYZ');

    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    for (const rawUrl of urls) {
        const url = normalizeUrl(rawUrl);
        try {
            const data = await getPinterestData(url);

            const [mediaBuf, thumbBuf] = await Promise.all([
                downloadBuffer(data.media_url, data.media_type),
                data.media_type === 'video' && data.image_url
                    ? downloadBuffer(data.image_url, 'thumbnail').catch(() => null)
                    : Promise.resolve(null),
            ]);

            const caption = buildCaption(data);

            if (data.media_type === 'video') {
                await conn.sendMessage(m.chat, {
                    video:         mediaBuf,
                    jpegThumbnail: thumbBuf ?? undefined,
                    mimetype:      'video/mp4',
                    caption,
                }, { quoted: m });
            } else {
                const ext     = (data.image_url || data.media_url || '').match(/\.(jpg|jpeg|png|gif|webp)/i)?.[1]?.toLowerCase() || 'jpeg';
                const mimeMap = { jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif', webp: 'image/webp' };
                await conn.sendMessage(m.chat, {
                    image:    mediaBuf,
                    mimetype: mimeMap[ext] || 'image/jpeg',
                    caption,
                }, { quoted: m });
            }

            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

        } catch (e) {
            console.error(`❌ Pinterest Error:`, e.message);
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            await m.reply(`❌ Gagal download Pinterest.\n*Error:* ${e.message}\n\n💡 Pastikan pin bersifat publik.`);
        }
    }
};

handler.help    = ['pin', 'pinterest', 'pindl'];
handler.tags    = ['downloader'];
handler.command = ['pin', 'pinterest', 'pindl'];

export default handler;