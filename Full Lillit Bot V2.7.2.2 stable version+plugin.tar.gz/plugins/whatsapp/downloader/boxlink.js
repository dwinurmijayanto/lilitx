const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import os from 'os';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ========== BOXLINK HANDLER (DOWNLOAD) ==========
const BOXLINK_DOMAINS = [
    'boxlinkwfe.com',
    'vidcloudoxo.com', 
    'openvideoink.com',
    'linkvideoink.com'
];

const TIMEOUT_MS = 60000; // Increased for API calls
const AUTO_DELETE_TIMEOUT = 5 * 60 * 1000;
const QUICK_DELETE_TIMEOUT = 30000;

const TEMP_DIR = path.join(os.tmpdir(), 'boxlink-downloads');
const DOWNLOAD_DIR = process.env.TEMP_DIR || TEMP_DIR || './temp/boxlink/';

const deleteTimeoutMap = new Map();

// ========== HELPER FUNCTIONS ==========
function extractBoxlinkId(url) {
    const patterns = [
        /(?:boxlinkwfe|vidcloudoxo|openvideoink|linkvideoink)\.com\/e\/([a-zA-Z0-9]+)/i,
        /\/e\/([a-zA-Z0-9]+)/i
    ];
    
    for (const pattern of patterns) {
        const match = url.match(pattern);
        if (match && match[1]) {
            return match[1];
        }
    }
    
    return null;
}

function validateBoxlinkId(id) {
    const idRegex = /^[a-zA-Z0-9]+$/;
    return idRegex.test(id) && id.length >= 6;
}

// Generate possible UUID variations based on known patterns
function generatePossibleFileIds(apiFileId, thumbnailFileId, debug = false) {
    const possibleIds = [];
    
    // Add known IDs
    if (apiFileId) possibleIds.push(apiFileId);
    if (thumbnailFileId && thumbnailFileId !== apiFileId) {
        possibleIds.push(thumbnailFileId);
    }
    
    // Try UUID v4 pattern variations (some systems use predictable UUIDs)
    // Based on the pattern: actual IDs seem to have different first segments
    if (apiFileId) {
        const parts = apiFileId.split('-');
        if (parts.length === 5) {
            // Try some common variations of the first segment
            const variations = [
                'bc78ca45', '8db3850c', // Known working patterns
                parts[0].replace(/[0-9]/g, 'a'),
                parts[0].replace(/[a-f]/g, '1')
            ];
            
            for (const firstPart of variations) {
                const variantId = `${firstPart}-${parts[1]}-${parts[2]}-${parts[3]}-${parts[4]}`;
                if (!possibleIds.includes(variantId)) {
                    possibleIds.push(variantId);
                }
            }
        }
    }
    
    if (debug) console.log(`[DEBUG] Generated ${possibleIds.length} possible IDs to test`);
    return possibleIds;
}

// Generate comprehensive hex patterns for bruteforce
function generateHexPatterns() {
    const patterns = [];
    
    // Known working patterns from real videos
    const knownPatterns = [
        'bc78ca45', '8db3850c', '9d6b1e11', '8bd55d23',
        '8db3850d', '8db3850e', '8db3850f'
    ];
    patterns.push(...knownPatterns);
    
    // Generate systematic hex patterns
    // Pattern: [8-b][a-d][7-8][0-9a-f]{4}
    const firstChars = ['8', '9', 'a', 'b', 'c'];
    const secondChars = ['a', 'b', 'c', 'd', 'e'];
    const thirdChars = ['7', '8', '9'];
    
    for (const c1 of firstChars) {
        for (const c2 of secondChars) {
            for (const c3 of thirdChars) {
                // Generate common endings
                const endings = ['3850c', '78ca45', 'd55d23', '6b1e11', '0ca45', 'b3850'];
                for (const end of endings) {
                    patterns.push(`${c1}${c2}${c3}${end}`);
                }
            }
        }
    }
    
    // Add more random but common hex combinations
    const commonHexes = [
        '00000000', 'ffffffff', '12345678', 'abcdef12',
        'deadbeef', 'cafebabe', '8badf00d', 'facade00'
    ];
    patterns.push(...commonHexes);
    
    return [...new Set(patterns)]; // Remove duplicates
}

function generateSecondSegmentPatterns() {
    return [
        // Known from videos
        '7c60', '8e58', 'b17d', '8ef8',
        // Common patterns
        '0000', 'ffff', '1234', 'abcd',
        '4364', '446e', '44d4',
        // Systematic
        '7c61', '7c62', '7c63', '8e59', '8e5a',
        'b17e', 'b17f', '8ef9', '8efa'
    ];
}

// Auto-discovery: Scan folder for the actual video file
async function autoDiscoverVideoUrl(folderId, apiFileId, thumbnailFileId, embedUrl, domain, debug = false) {
    const cdnHost = 'sm.videqqwuieyui.com';
    
    if (debug) console.log(`[DEBUG] Starting auto-discovery...`);
    
    // Strategy 1: Try directory listing (some CDNs allow this)
    const dirUrl = `https://${cdnHost}/xbox-streaming/${folderId}/`;
    try {
        if (debug) console.log(`[DEBUG] Trying directory listing: ${dirUrl}`);
        const dirResponse = await fetch(dirUrl, {
            method: 'GET',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Referer': embedUrl
            },
            timeout: 10000
        });
        
        if (dirResponse.ok) {
            const html = await dirResponse.text();
            const mp4Regex = /([a-f0-9-]{36})\.mp4/gi;
            const matches = html.match(mp4Regex);
            if (matches && matches.length > 0) {
                const fileId = matches[0].replace('.mp4', '');
                if (debug) console.log(`[DEBUG] ✅ Found file ID via directory listing: ${fileId}`);
                return `https://${cdnHost}/xbox-streaming/${folderId}/${fileId}.mp4`;
            }
        }
    } catch (e) {
        if (debug) console.log(`[DEBUG] Directory listing failed: ${e.message}`);
    }
    
    // Strategy 2: Exhaustive pattern testing with parallel requests
    if (apiFileId) {
        const parts = apiFileId.split('-');
        if (parts.length === 5) {
            const firstSegments = generateHexPatterns();
            const secondSegments = generateSecondSegmentPatterns();
            
            const maxTests = 500; // Increased limit
            const batchSize = 10; // Test 10 URLs in parallel
            let testedCount = 0;
            
            if (debug) console.log(`[DEBUG] Will test up to ${maxTests} combinations in batches of ${batchSize}`);
            
            // Test in batches for speed
            for (let i = 0; i < firstSegments.length && testedCount < maxTests; i++) {
                const firstSeg = firstSegments[i];
                
                for (let j = 0; j < secondSegments.length && testedCount < maxTests; j += batchSize) {
                    const batch = [];
                    
                    // Create batch of requests
                    for (let k = 0; k < batchSize && j + k < secondSegments.length && testedCount < maxTests; k++) {
                        const secondSeg = secondSegments[j + k];
                        const testId = `${firstSeg}-${secondSeg}-${parts[2]}-${parts[3]}-${parts[4]}`;
                        const testUrl = `https://${cdnHost}/xbox-streaming/${folderId}/${testId}.mp4`;
                        
                        batch.push({
                            id: testId,
                            url: testUrl,
                            promise: fetch(testUrl, {
                                method: 'HEAD',
                                headers: {
                                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                                    'Referer': embedUrl,
                                    'Origin': `https://www.${domain}`
                                },
                                timeout: 4000
                            }).catch(e => ({ ok: false, error: e }))
                        });
                        
                        testedCount++;
                    }
                    
                    if (debug && testedCount % 50 === 0) {
                        console.log(`[DEBUG] Progress: ${testedCount}/${maxTests} - Current: ${firstSeg.substring(0, 8)}...`);
                    }
                    
                    // Wait for batch to complete
                    const results = await Promise.all(batch.map(b => b.promise));
                    
                    // Check results
                    for (let idx = 0; idx < results.length; idx++) {
                        const response = results[idx];
                        if (response.ok || response.status === 206) {
                            if (debug) console.log(`[DEBUG] ✅ FOUND! Working URL: ${batch[idx].url}`);
                            if (debug) console.log(`[DEBUG] Working ID: ${batch[idx].id}`);
                            return batch[idx].url;
                        }
                    }
                }
            }
            
            if (debug) console.log(`[DEBUG] Tested ${testedCount} combinations, none worked`);
        }
    }
    
    // Strategy 3: Try thumbnail ID variations
    if (thumbnailFileId && thumbnailFileId !== apiFileId) {
        const thumbParts = thumbnailFileId.split('-');
        if (thumbParts.length === 5) {
            const firstPatterns = generateHexPatterns().slice(0, 20); // Top 20 patterns
            
            for (const firstSeg of firstPatterns) {
                const testId = `${firstSeg}-${thumbParts[1]}-${thumbParts[2]}-${thumbParts[3]}-${thumbParts[4]}`;
                const testUrl = `https://${cdnHost}/xbox-streaming/${folderId}/${testId}.mp4`;
                
                if (debug) console.log(`[DEBUG] Testing thumbnail variation: ${testId.substring(0, 25)}...`);
                
                try {
                    const response = await fetch(testUrl, {
                        method: 'HEAD',
                        headers: {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                            'Referer': embedUrl
                        },
                        timeout: 4000
                    });
                    
                    if (response.ok || response.status === 206) {
                        if (debug) console.log(`[DEBUG] ✅ Found via thumbnail variation!`);
                        return testUrl;
                    }
                } catch (e) {
                    // Continue
                }
            }
        }
    }
    
    return null;
}

// Try to extract file ID from thumbnail URL - sometimes there's a pattern
function extractFileIdFromThumbnail(thumbnailUrl, debug = false) {
    if (!thumbnailUrl) return null;
    
    // Pattern: https://sm.videqqwuieyui.com/thumbnails/xbox-streaming/{folder_id}/{file_id}.jpg
    const match = thumbnailUrl.match(/thumbnails\/xbox-streaming\/\d+\/([a-f0-9-]+)\.jpg/);
    if (match && match[1]) {
        if (debug) console.log(`[DEBUG] Found file ID in thumbnail: ${match[1]}`);
        return match[1];
    }
    return null;
}

// Strategy: Try multiple approaches to find the working video URL
async function findWorkingVideoUrl(folderId, apiFileId, thumbnailUrl, collageUrl, embedUrl, domain, debug = false) {
    const cdnHost = 'sm.videqqwuieyui.com';
    const possibleIds = [apiFileId];
    
    // Try to extract ID from thumbnail
    const thumbnailFileId = extractFileIdFromThumbnail(thumbnailUrl, debug);
    if (thumbnailFileId && thumbnailFileId !== apiFileId) {
        possibleIds.push(thumbnailFileId);
    }
    
    // Try to extract from collage screenshots
    if (collageUrl && collageUrl.length > 0) {
        const collageMatch = collageUrl[0].match(/thumbnails\/xbox-streaming\/\d+\/([a-f0-9-]+)\//);
        if (collageMatch && collageMatch[1] && !possibleIds.includes(collageMatch[1])) {
            possibleIds.push(collageMatch[1]);
            if (debug) console.log(`[DEBUG] Found file ID in collage: ${collageMatch[1]}`);
        }
    }
    
    // Test each possible ID
    for (const fileId of possibleIds) {
        const url = `https://${cdnHost}/xbox-streaming/${folderId}/${fileId}.mp4`;
        
        if (debug) console.log(`[DEBUG] Testing URL: ${url}`);
        
        try {
            // Do a HEAD request to check if file exists
            const response = await fetch(url, {
                method: 'HEAD',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Referer': embedUrl,
                    'Origin': `https://www.${domain}`
                },
                timeout: 10000
            });
            
            if (debug) console.log(`[DEBUG] URL test status: ${response.status}`);
            
            if (response.ok || response.status === 206) {
                if (debug) console.log(`[DEBUG] ✅ Working URL found with ID: ${fileId}`);
                return url;
            }
        } catch (e) {
            if (debug) console.log(`[DEBUG] URL test failed for ${fileId}: ${e.message}`);
        }
    }
    
    // If basic tests fail, try auto-discovery
    if (debug) console.log(`[DEBUG] Basic tests failed, trying auto-discovery...`);
    return await autoDiscoverVideoUrl(folderId, apiFileId, thumbnailFileId, embedUrl, domain, debug);
}

async function getBoxlinkVideoUrl(boxlinkId, domain = 'boxlinkwfe.com', debug = false) {
    try {
        const embedUrl = `https://www.${domain}/e/${boxlinkId}`;
        const apiBase = 'https://api.lixstreamingcaio.com';
        
        if (debug) console.log(`[DEBUG] Embed URL: ${embedUrl}`);
        if (debug) console.log(`[DEBUG] API Base: ${apiBase}`);
        
        // Step 1: Get resource info using POST method
        const resourceEndpoint = `${apiBase}/v2/s/home/resources/${boxlinkId}`;
        if (debug) console.log(`[DEBUG] Getting resource info from: ${resourceEndpoint}`);
        
        const resourceResponse = await fetch(resourceEndpoint, {
            method: 'POST',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Referer': embedUrl,
                'Origin': `https://www.${domain}`
            }
        });
        
        if (debug) console.log(`[DEBUG] Resource response status: ${resourceResponse.status}`);
        
        if (!resourceResponse.ok) {
            throw new Error(`API returned status ${resourceResponse.status}`);
        }
        
        const resourceData = await resourceResponse.json();
        if (debug) console.log(`[DEBUG] Resource data:`, JSON.stringify(resourceData, null, 2));
        
        // Extract video info
        if (!resourceData.files || resourceData.files.length === 0) {
            throw new Error('No video files found in response');
        }
        
        const videoFile = resourceData.files[0];
        const fileId = videoFile.id;
        const suid = resourceData.suid;
        const fileName = videoFile.display_name || 'video.mp4';
        
        if (debug) console.log(`[DEBUG] File ID: ${fileId}, SUID: ${suid}, Name: ${fileName}`);
        
        // Extract folder_id from thumbnail URL
        let folderId = null;
        if (videoFile.thumbnail) {
            const thumbnailMatch = videoFile.thumbnail.match(/xbox-streaming\/(\d+)\//);
            if (thumbnailMatch) {
                folderId = thumbnailMatch[1];
            }
        }
        
        if (debug) console.log(`[DEBUG] Folder ID: ${folderId}`);
        
        if (!folderId) {
            throw new Error('Could not extract folder ID from thumbnail');
        }
        
        // Step 2: Get encrypted URL (for reference, though we can't decrypt it yet)
        const assetsEndpoint = `${apiBase}/v2/s/assets/f?id=${fileId}&uid=${suid}`;
        if (debug) console.log(`[DEBUG] Getting encrypted URL from: ${assetsEndpoint}`);
        
        try {
            const assetsResponse = await fetch(assetsEndpoint, {
                method: 'GET',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Accept': 'application/json',
                    'Referer': embedUrl,
                    'Origin': `https://www.${domain}`
                }
            });
            
            if (debug) console.log(`[DEBUG] Assets response status: ${assetsResponse.status}`);
            
            if (assetsResponse.ok) {
                const assetsData = await assetsResponse.json();
                if (debug && assetsData.url) {
                    console.log(`[DEBUG] Encrypted URL received (length: ${assetsData.url.length})`);
                }
            }
        } catch (e) {
            if (debug) console.log(`[DEBUG] Assets endpoint failed: ${e.message}`);
        }
        
        // Step 3: Try to find working URL with auto-discovery
        if (debug) console.log(`[DEBUG] Attempting to find working video URL...`);
        
        const workingUrl = await findWorkingVideoUrl(
            folderId, 
            fileId, 
            videoFile.thumbnail,
            videoFile.collage_screenshots,
            embedUrl, 
            domain, 
            debug
        );
        
        if (workingUrl) {
            return {
                url: workingUrl,
                fileName: fileName,
                folderId: folderId
            };
        }
        
        // If we can't find working URL, provide detailed error
        const thumbnailId = extractFileIdFromThumbnail(videoFile.thumbnail);
        
        let errorMsg = `Tidak dapat menemukan URL video yang valid.\n\n`;
        errorMsg += `📊 Info Debug:\n`;
        errorMsg += `• API File ID: ${fileId}\n`;
        if (thumbnailId && thumbnailId !== fileId) {
            errorMsg += `• Thumbnail ID: ${thumbnailId}\n`;
        }
        errorMsg += `• Folder ID: ${folderId}\n`;
        errorMsg += `• Status: 403 Forbidden\n\n`;
        errorMsg += `🔐 Video ini menggunakan enkripsi khusus yang memerlukan:\n`;
        errorMsg += `1. Session aktif dari browser\n`;
        errorMsg += `2. Cookie authentication\n`;
        errorMsg += `3. Decryption key dari /v2/s/assets/f\n\n`;
        errorMsg += `💡 Cara manual download:\n`;
        errorMsg += `1. Buka: ${embedUrl}\n`;
        errorMsg += `2. Play video di browser\n`;
        errorMsg += `3. Buka DevTools (F12) → Network tab\n`;
        errorMsg += `4. Filter: .mp4\n`;
        errorMsg += `5. Cari URL yang dimulai dengan:\n`;
        errorMsg += `   https://sm.videqqwuieyui.com/xbox-streaming/${folderId}/\n`;
        errorMsg += `6. Salin full URL tersebut\n`;
        errorMsg += `7. Download menggunakan browser atau wget`;
        
        throw new Error(errorMsg);
        
    } catch (error) {
        throw new Error(`Gagal mendapatkan video URL: ${error.message}`);
    }
}

async function fetchBoxlinkVideo(boxlinkId, domain = 'boxlinkwfe.com', debug = false) {
    try {
        if (debug) console.log(`[DEBUG] Starting download for ID: ${boxlinkId}`);
        
        // Get video URL info
        const videoInfo = await getBoxlinkVideoUrl(boxlinkId, domain, debug);
        const videoUrl = videoInfo.url;
        
        if (debug) console.log(`[DEBUG] Video URL: ${videoUrl}`);
        
        // Download video
        if (debug) console.log(`[DEBUG] Starting video download...`);
        
        const fetchPromise = fetch(videoUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': '*/*',
                'Accept-Encoding': 'identity;q=1, *;q=0',
                'Accept-Language': 'en-US,en;q=0.9',
                'Referer': `https://www.${domain}/`,
                'Origin': `https://www.${domain}`,
                'sec-ch-ua': '"Google Chrome";v="143", "Chromium";v="143", "Not A(Brand";v="24"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"Windows"',
                'Priority': 'i'
            }
        });
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error(`Timeout setelah ${TIMEOUT_MS}ms`)), TIMEOUT_MS)
        );
        
        const response = await Promise.race([fetchPromise, timeoutPromise]);
        
        if (debug) console.log(`[DEBUG] Download response status: ${response.status}`);
        
        if (!response.ok) {
            throw new Error(`HTTP Error ${response.status}: Video tidak dapat diakses dari CDN`);
        }
        
        const contentLength = response.headers.get('content-length');
        if (debug && contentLength) console.log(`[DEBUG] Content length: ${(contentLength / 1024 / 1024).toFixed(2)} MB`);
        
        const arrayBuffer = await response.arrayBuffer();
        const buffer = Buffer.from(arrayBuffer);
        
        if (debug) console.log(`[DEBUG] Downloaded ${(buffer.length / 1024 / 1024).toFixed(2)} MB`);
        
        // Extract CDN info
        const cdnMatch = videoUrl.match(/https?:\/\/([^\/]+)/);
        const cdnHost = cdnMatch ? cdnMatch[1] : 'unknown';
        
        return { 
            buffer, 
            size: contentLength, 
            url: videoUrl,
            cdnHost: cdnHost,
            folderId: videoInfo.folderId,
            fileName: videoInfo.fileName
        };
        
    } catch (error) {
        throw new Error(`Gagal mengunduh video: ${error.message}`);
    }
}

function ensureTempDir() {
    try {
        if (!fs.existsSync(DOWNLOAD_DIR)) {
            fs.mkdirSync(DOWNLOAD_DIR, { recursive: true });
        }
    } catch (error) {
        throw error;
    }
}

function deleteFileImmediately(filePath, reason = 'Manual cleanup') {
    try {
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
            return true;
        }
        return false;
    } catch (error) {
        return false;
    }
}

function scheduleFileDelete(filePath, fileId, quickDelete = true) {
    if (deleteTimeoutMap.has(fileId)) {
        const oldTimeouts = deleteTimeoutMap.get(fileId);
        if (oldTimeouts.quick) clearTimeout(oldTimeouts.quick);
        if (oldTimeouts.backup) clearTimeout(oldTimeouts.backup);
    }
    
    const timeouts = {};
    
    if (quickDelete) {
        timeouts.quick = setTimeout(() => {
            if (fs.existsSync(filePath)) {
                deleteFileImmediately(filePath, `Quick cleanup after ${QUICK_DELETE_TIMEOUT / 1000}s`);
                deleteTimeoutMap.delete(fileId);
            }
        }, QUICK_DELETE_TIMEOUT);
    }
    
    timeouts.backup = setTimeout(() => {
        if (fs.existsSync(filePath)) {
            deleteFileImmediately(filePath, `Backup cleanup after ${AUTO_DELETE_TIMEOUT / 1000 / 60} minutes`);
            deleteTimeoutMap.delete(fileId);
        }
    }, AUTO_DELETE_TIMEOUT);
    
    deleteTimeoutMap.set(fileId, timeouts);
}

function cleanupOldTempFiles() {
    try {
        if (!fs.existsSync(DOWNLOAD_DIR)) return;
        
        const files = fs.readdirSync(DOWNLOAD_DIR);
        const now = Date.now();
        
        files.forEach(file => {
            const filePath = path.join(DOWNLOAD_DIR, file);
            try {
                const stats = fs.statSync(filePath);
                const fileAge = now - stats.mtimeMs;
                
                if (fileAge > 60 * 60 * 1000) {
                    fs.unlinkSync(filePath);
                }
            } catch (err) {
                // Silent error handling
            }
        });
    } catch (error) {
        // Silent error handling
    }
}

function generateUsageHelp(prefix, cmd) {
    return `*🎬 BOXLINK DOWNLOADER*

📥 *DOWNLOAD VIDEO*
${prefix}${cmd} <URL atau ID Boxlink>

• URL format: ${prefix}${cmd} https://www.boxlinkwfe.com/e/ID
• ID saja: ${prefix}${cmd} ID

🐛 *DEBUG MODE*
${prefix}${cmd} <URL/ID> --debug
${prefix}${cmd} ID -d

💡 *Fitur:*
• Support boxlinkwfe.com
• Support vidcloudoxo.com
• Support openvideoink.com
• Support linkvideoink.com
• Auto-decrypt encrypted URLs
• Smart fallback URL system
• Direct download dari CDN

⏰ *Auto-cleanup:*
• Quick: 30 detik
• Backup: 5 menit

🔧 *Teknologi:*
• POST API ke /v2/s/home/resources
• Base64 decryption untuk file ID
• Dual URL fallback mechanism

📌 *Supported domains:*
• www.boxlinkwfe.com
• www.vidcloudoxo.com
• www.openvideoink.com
• www.linkvideoink.com`;
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    let prefix = usedPrefix;
    if (!prefix && m.text) {
        const match = m.text.match(/^([.!#/])/);
        prefix = match ? match[1] : '.';
    }
    prefix = prefix || '.';
    
    const cmd = command || 'boxlink';
    
    let inputText = '';
    if (text) {
        inputText = text.trim();
    } else if (args && args.length > 0) {
        inputText = args.join(' ').trim();
    }
    
    // Check for debug mode
    const debugMode = inputText.includes('--debug') || inputText.includes('-d');
    if (debugMode) {
        inputText = inputText.replace(/--debug|-d/g, '').trim();
    }
    
    if (!inputText || inputText.toLowerCase() === 'help' || inputText === '?') {
        return m.reply(generateUsageHelp(prefix, cmd));
    }
    
    let boxlinkId = null;
    let detectedDomain = 'boxlinkwfe.com';
    
    // Try to extract ID from URL
    if (inputText.match(/(?:boxlinkwfe|vidcloudoxo|openvideoink|linkvideoink)\.com/)) {
        boxlinkId = extractBoxlinkId(inputText);
        
        // Detect which domain was used
        for (const domain of BOXLINK_DOMAINS) {
            if (inputText.includes(domain)) {
                detectedDomain = domain;
                break;
            }
        }
    } else {
        // Assume it's a direct ID
        boxlinkId = inputText;
    }
    
    if (!boxlinkId || !validateBoxlinkId(boxlinkId)) {
        return m.reply(`❌ Format tidak valid!\n\n💡 Gunakan format:\n\n1. URL: ${prefix}${cmd} https://www.boxlinkwfe.com/e/ID\n2. ID: ${prefix}${cmd} ID\n\n📌 Ketik ${prefix}${cmd} help untuk panduan lengkap`);
    }
    
    let filePath = null;
    let fileId = null;
    
    try {
        await conn.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });
        
        if (debugMode) {
            await m.reply('🐛 DEBUG MODE AKTIF\nMencoba mengakses API...');
        }
        
        // Fetch video
        const videoData = await fetchBoxlinkVideo(boxlinkId, detectedDomain, debugMode);
        
        if (debugMode) {
            const debugInfo = `🐛 *DEBUG INFO*

📋 *Video ID:* ${boxlinkId}
📄 *File Name:* ${videoData.fileName}
🌐 *Domain:* ${detectedDomain}
📁 *Folder ID:* ${videoData.folderId}
🖥️ *CDN Host:* ${videoData.cdnHost}
📊 *Size:* ${(videoData.buffer.length / 1024 / 1024).toFixed(2)} MB
🔗 *Used URL:* ${videoData.url.substring(0, 80)}...

✅ Download completed!`;
            await m.reply(debugInfo);
        }
        
        ensureTempDir();
        
        const timestamp = Date.now();
        const fileName = `boxlink_${boxlinkId}_${timestamp}.mp4`;
        filePath = path.join(DOWNLOAD_DIR, fileName);
        fileId = `${boxlinkId}_${timestamp}`;
        
        fs.writeFileSync(filePath, videoData.buffer);
        
        scheduleFileDelete(filePath, fileId, true);
        
        await conn.sendMessage(m.chat, { react: { text: '📤', key: m.key } });
        
        const sizeText = videoData.size ? 
            (parseInt(videoData.size) / (1024 * 1024)).toFixed(2) + ' MB' : 
            (videoData.buffer.length / (1024 * 1024)).toFixed(2) + ' MB';
        
        await conn.sendMessage(m.chat, {
            video: { url: filePath },
            mimetype: 'video/mp4',
            caption: `✅ *Video dari Boxlink*\n\n📄 File: ${videoData.fileName}\n🆔 ID: ${boxlinkId}\n🌐 Domain: ${detectedDomain}\n📁 Folder: ${videoData.folderId}\n🖥️ CDN: ${videoData.cdnHost}\n📊 Size: ${sizeText}\n\n💡 Downloaded from streaming CDN`,
            fileName: videoData.fileName || `${boxlinkId}.mp4`
        }, { quoted: m });
        
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (error) {
        if (filePath && fs.existsSync(filePath)) {
            deleteFileImmediately(filePath, 'Error cleanup');
            if (fileId && deleteTimeoutMap.has(fileId)) {
                const timeouts = deleteTimeoutMap.get(fileId);
                if (timeouts.quick) clearTimeout(timeouts.quick);
                if (timeouts.backup) clearTimeout(timeouts.backup);
                deleteTimeoutMap.delete(fileId);
            }
        }
        
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        
        let errorMsg = '❌ Terjadi kesalahan saat mengunduh video.\n\n';
        
        if (error.message.includes('Timeout')) {
            errorMsg += `⚠️ Timeout: Server tidak merespons dalam ${TIMEOUT_MS / 1000} detik\n💡 Coba lagi dalam beberapa saat`;
        } else if (error.message.includes('404') || error.message.includes('HTTP Error')) {
            errorMsg += '⚠️ Video tidak ditemukan atau URL tidak valid\n💡 Pastikan ID Boxlink benar dan video masih tersedia';
        } else if (error.message.includes('Could not extract folder ID')) {
            errorMsg += '⚠️ Gagal mendapatkan folder ID dari thumbnail\n💡 Video mungkin menggunakan format baru atau sudah dihapus';
        } else {
            errorMsg += `⚠️ Error: ${error.message}\n💡 Coba lagi atau ketik ${prefix}${cmd} help`;
        }
        
        if (debugMode) {
            errorMsg += `\n\n🐛 Full error: ${error.stack || error.message}`;
        } else {
            errorMsg += `\n\n💡 Gunakan ${prefix}${cmd} ${boxlinkId} --debug untuk info detail`;
        }
        
        return m.reply(errorMsg);
    }
};

handler.help = ["boxlink <url|id>"];
handler.tags = ["downloader"];
handler.command = ["boxlink", "boxlinkdl", "vidcloud", "openvideo", "linkvideo"];
handler.limit = true;

// Cleanup old files on startup
cleanupOldTempFiles();

export default handler;