const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

console.log('[Google Drive Handler] Loading enhanced handler...');

// ========== SHORT URL CONFIG ==========
const SHORTURL_CONFIG = {
    api: 'https://zeinklab.com/api/create',
    baseUrl: 'http://zeink.cc',
    timeout: 10000
};

// ========== SHORT URL FUNCTION ==========
async function createShortUrl(longUrl) {
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), SHORTURL_CONFIG.timeout);

        const response = await fetch(SHORTURL_CONFIG.api, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'User-Agent': 'Mozilla/5.0',
                'Origin': 'https://zeinklab.com',
                'Referer': 'https://zeinklab.com/create'
            },
            body: JSON.stringify({ url: longUrl }),
            signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        let responseText = await response.text();
        const jsonMatch = responseText.match(/(\{[\s\S]*\})/);
        if (jsonMatch) {
            responseText = jsonMatch[1];
        }
        
        const result = JSON.parse(responseText);

        if (result.success && result.short_url) {
            let url = result.short_url;
            if (url.startsWith('/')) {
                url = SHORTURL_CONFIG.baseUrl + url;
            } else if (!url.startsWith('http')) {
                url = SHORTURL_CONFIG.baseUrl + '/' + url;
            }
            return url;
        }
        
        return null;
    } catch (error) {
        console.log('[ShortURL] Error:', error.message);
        return null;
    }
}

// ========== MULTI API GOOGLE DRIVE (PRIORITY) ==========
async function getGoogleDriveDownload(url) {
    console.log('[Google Drive] Starting priority APIs (race condition)...');
    
    // API Prioritas (VBI1, VBI2, VBI3) - Race condition
    const priorityPromises = [
        getGDriveFromVBI1(url),
        getGDriveFromVBI2(url),
        getGDriveFromVBI3(url)
    ];
    
    try {
        const result = await Promise.race(priorityPromises);
        console.log('[Google Drive] Priority API won:', result.source);
        
        // Generate short URL
        if (result.downloadUrl) {
            const shortUrl = await createShortUrl(result.downloadUrl);
            if (shortUrl) {
                result.shortUrl = shortUrl;
            }
        }
        
        return result;
    } catch (priorityError) {
        console.log('[Google Drive] All priority APIs failed, trying backup APIs...');
        
        // Jika semua API prioritas gagal, coba API backup
        try {
            const backupResult = await getGDriveFromBackupAPIs(url);
            console.log('[Google Drive] Backup API success:', backupResult.source);
            
            // Generate short URL
            if (backupResult.downloadUrl) {
                const shortUrl = await createShortUrl(backupResult.downloadUrl);
                if (shortUrl) {
                    backupResult.shortUrl = shortUrl;
                }
            }
            
            return backupResult;
        } catch (backupError) {
            throw new Error(`Semua API gagal - Priority: ${priorityError.message}, Backup: ${backupError.message}`);
        }
    }
}

// ========== BACKUP APIs ==========
async function getGDriveFromBackupAPIs(url) {
    // Coba API Backup 1 (FathurDevs)
    try {
        return await getGDriveFromFathur(url);
    } catch (e1) {
        console.log('[Backup API 1] Failed:', e1.message);
        
        // Coba API Backup 2 (Deline)
        try {
            return await getGDriveFromDeline(url);
        } catch (e2) {
            throw new Error(`Backup API 1: ${e1.message}, Backup API 2: ${e2.message}`);
        }
    }
}

// ========== API BACKUP 1: FathurDevs ==========
async function getGDriveFromFathur(url) {
    try {
        const apiUrl = `https://fathurweb.qzz.io/api/download/gdrive?url=${encodeURIComponent(url)}`;
        
        const response = await fetch(apiUrl, {
            timeout: 15000
        });
        
        if (!response.ok) {
            throw new Error(`Fathur API Error: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (!data.status || !data.result || !data.result.download) {
            throw new Error('Fathur API tidak mengembalikan data yang valid');
        }
        
        return { 
            success: true, 
            source: 'FathurDevs API',
            filename: data.result.name || 'file',
            filesize: 'Unknown',
            thumbnail: null,
            downloadUrl: data.result.download,
            playUrl: null
        };
        
    } catch (error) {
        throw new Error(error.message);
    }
}

// ========== API BACKUP 2: Deline ==========
async function getGDriveFromDeline(url) {
    try {
        const apiUrl = `https://api.deline.web.id/downloader/gdrive?url=${encodeURIComponent(url)}`;
        
        const response = await fetch(apiUrl, {
            timeout: 15000
        });
        
        if (!response.ok) {
            throw new Error(`Deline API Error: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (!data.status || !data.result || !data.result.downloadUrl) {
            throw new Error('Deline API tidak mengembalikan data yang valid');
        }
        
        return { 
            success: true, 
            source: 'Deline API',
            filename: data.result.fileName || 'file',
            filesize: data.result.fileSize || 'Unknown',
            thumbnail: null,
            downloadUrl: data.result.downloadUrl,
            playUrl: null,
            mimetype: data.result.mimetype
        };
        
    } catch (error) {
        throw new Error(error.message);
    }
}

// ========== PRIORITY API 1: VBI1 Upload ==========
async function getGDriveFromVBI1(url) {
    try {
        const apiUrl = `https://upload.vbi1.my.id/gd-api.php?url=${encodeURIComponent(url)}`;
        
        const response = await fetch(apiUrl, {
            timeout: 15000
        });
        
        if (!response.ok) {
            throw new Error(`VBI1 API Error: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (!data.download || !data.judul) {
            throw new Error('VBI1 API tidak mengembalikan data yang valid');
        }
        
        return { 
            success: true, 
            source: 'VBI1 (upload)',
            filename: data.judul,
            filesize: data.size,
            thumbnail: data.thumbnail,
            downloadUrl: data.download,
            playUrl: data.play
        };
        
    } catch (error) {
        throw new Error(error.message);
    }
}

// ========== PRIORITY API 2: VBI1 API ==========
async function getGDriveFromVBI2(url) {
    try {
        const apiUrl = `https://api.vbi1.my.id/gd-api.php?url=${encodeURIComponent(url)}`;
        
        const response = await fetch(apiUrl, {
            timeout: 15000
        });
        
        if (!response.ok) {
            throw new Error(`VBI2 API Error: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (!data.download || !data.judul) {
            throw new Error('VBI2 API tidak mengembalikan data yang valid');
        }
        
        return { 
            success: true, 
            source: 'VBI1 (api)',
            filename: data.judul,
            filesize: data.size,
            thumbnail: data.thumbnail,
            downloadUrl: data.download,
            playUrl: data.play
        };
        
    } catch (error) {
        throw new Error(error.message);
    }
}

// ========== PRIORITY API 3: VBI1 Movie ==========
async function getGDriveFromVBI3(url) {
    try {
        const apiUrl = `https://vbi1.my.id/movie/gd-api.php?url=${encodeURIComponent(url)}`;
        
        const response = await fetch(apiUrl, {
            timeout: 15000
        });
        
        if (!response.ok) {
            throw new Error(`VBI3 API Error: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (!data.download || !data.judul) {
            throw new Error('VBI3 API tidak mengembalikan data yang valid');
        }
        
        return { 
            success: true, 
            source: 'VBI1 (movie)',
            filename: data.judul,
            filesize: data.size,
            thumbnail: data.thumbnail,
            downloadUrl: data.download,
            playUrl: data.play
        };
        
    } catch (error) {
        throw new Error(error.message);
    }
}

// ========== UTILITIES ==========
function parseFileSize(sizeStr) {
    if (!sizeStr || sizeStr === 'Unknown') return 0;
    
    const match = sizeStr.match(/(\d+\.?\d*)\s*(B|KB|MB|GB)/i);
    if (!match) return 0;
    
    const value = parseFloat(match[1]);
    const unit = match[2].toUpperCase();
    
    const multipliers = {
        'B': 1,
        'KB': 1024,
        'MB': 1024 * 1024,
        'GB': 1024 * 1024 * 1024
    };
    
    return value * (multipliers[unit] || 0);
}

function formatDownloadMessage(data) {
    const { filename, filesize, downloadUrl, shortUrl, source } = data;
    
    let message = `*📥 GOOGLE DRIVE DOWNLOADER*\n`;
    message += `*🔄 Source: ${source}*\n\n`;
    message += `┌─「 📁 *File Info* 」\n`;
    message += `├ 📄 Nama: ${filename}\n`;
    message += `├ 📊 Ukuran: ${filesize}\n`;
    message += `└ 🔗 Status: Ready!\n\n`;
    
    if (shortUrl) {
        message += `*🔗 Download Link:*\n${shortUrl}`;
    } else {
        message += `*📎 Download Link:*\n${downloadUrl}`;
    }
    
    return message;
}

function generateUsageHelp(prefix, cmd) {
    return `*📥 GOOGLE DRIVE DOWNLOADER*

📌 *Cara Penggunaan:*
${prefix}${cmd} [link google drive]

✨ *Fitur:*
• Download file dari Google Drive
• Generate direct download link + Short URL
• Support semua tipe file
• Auto-send file (jika < 50MB)
• Multi API dengan backup otomatis
  - 3 API Prioritas (simultan)
  - 2 API Backup (jika prioritas gagal)

📋 *Contoh:*
${prefix}${cmd} https://drive.google.com/file/d/xxxxx/view

⚠️ *Catatan:*
• File > 50MB akan dikirim link download
• File < 50MB akan dikirim langsung + link
• Short URL otomatis dibuat untuk kemudahan`;
}

function isValidGoogleDriveUrl(url) {
    const gdrivePattern = /^https?:\/\/(drive|docs)\.google\.com\/(file\/d\/|open\?id=|uc\?id=)/i;
    return gdrivePattern.test(url);
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    // Deteksi prefix
    let prefix = usedPrefix;
    if (!prefix && m.text) {
        const match = m.text.match(/^([.!#/])/);
        prefix = match ? match[1] : '.';
    }
    prefix = prefix || '.';
    
    const cmd = command || 'gdrive';
    
    // Ambil URL dari text atau args
    let url = '';
    if (text) {
        url = text.trim();
    } else if (args && args.length > 0) {
        url = args[0].trim();
    }
    
    console.log(`[Google Drive Handler] Command triggered - prefix: ${prefix}, cmd: ${cmd}, text: ${text}`);
    
    // Cek apakah user minta help atau tidak ada input
    if (!url || url.toLowerCase() === 'help' || url === '?') {
        console.log('[Google Drive Handler] Help requested');
        return m.reply(generateUsageHelp(prefix, cmd));
    }
    
    // Validasi URL Google Drive
    if (!isValidGoogleDriveUrl(url)) {
        console.log('[Google Drive Handler] Invalid URL:', url);
        return m.reply(`❌ Link tidak valid!\n\n💡 Format yang benar:\n${prefix}${cmd} https://drive.google.com/file/d/xxxxx/view\n\n📌 Pastikan link dari Google Drive!`);
    }
    
    console.log('[Google Drive Handler] Valid URL, starting download...');
    
    try {
        // React dengan emoji untuk menunjukkan proses
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        const result = await getGoogleDriveDownload(url);
        console.log('[Google Drive Handler] Download result:', result.source);
        
        if (!result.success) {
            console.log('[Google Drive Handler] Download failed');
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply('❌ Gagal mendapatkan link download dari Google Drive.\n\n💡 Pastikan link valid dan file masih tersedia.');
        }
        
        // Parse ukuran file
        const fileSizeBytes = parseFileSize(result.filesize);
        const maxSize = 50 * 1024 * 1024; // 50 MB
        
        console.log('[Google Drive Handler] File size:', result.filesize, '(', fileSizeBytes, 'bytes)');
        
        // Jika file terlalu besar, kirim link saja
        if (fileSizeBytes > maxSize || fileSizeBytes === 0) {
            console.log('[Google Drive Handler] File too large or unknown size, sending link only');
            const message = formatDownloadMessage(result);
            
            await conn.sendMessage(m.chat, {
                text: message
            }, { quoted: m });
            
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            return;
        }
        
        // File kecil, kirim langsung + link
        console.log('[Google Drive Handler] Downloading file...');
        
        try {
            // Download file
            const fileResponse = await fetch(result.downloadUrl, {
                timeout: 60000,
                headers: {
                    'User-Agent': 'Mozilla/5.0'
                }
            });
            
            if (!fileResponse.ok) {
                throw new Error(`Download failed: ${fileResponse.status}`);
            }
            
            const arrayBuffer = await fileResponse.arrayBuffer();
            const buffer = Buffer.from(arrayBuffer);
            console.log('[Google Drive Handler] File downloaded, size:', buffer.length, 'bytes');
            
            // Tentukan tipe dokumen berdasarkan ekstensi
            const extension = result.filename.split('.').pop().toLowerCase();
            const documentTypes = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'zip', 'rar', '7z', 'apk'];
            const videoTypes = ['mp4', 'avi', 'mkv', 'mov', 'webm', '3gp', 'flv'];
            const imageTypes = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
            
            // Caption untuk semua file
            const caption = `*📥 Google Drive Download*\n\n📄 *File:* ${result.filename}\n📊 *Size:* ${result.filesize}\n🔄 *Source:* ${result.source}${result.shortUrl ? '\n🔗 *Short:* ' + result.shortUrl : ''}`;
            
            // Kirim sesuai tipe file
            if (videoTypes.includes(extension)) {
                console.log('[Google Drive Handler] Sending as video...');
                await conn.sendMessage(m.chat, {
                    video: buffer,
                    caption: caption,
                    mimetype: result.mimetype || 'video/mp4'
                }, { quoted: m });
            } else if (imageTypes.includes(extension)) {
                console.log('[Google Drive Handler] Sending as image...');
                await conn.sendMessage(m.chat, {
                    image: buffer,
                    caption: caption
                }, { quoted: m });
            } else {
                console.log('[Google Drive Handler] Sending as document...');
                await conn.sendMessage(m.chat, {
                    document: buffer,
                    fileName: result.filename,
                    mimetype: result.mimetype || 'application/octet-stream',
                    caption: caption
                }, { quoted: m });
            }
            
            console.log('[Google Drive Handler] File sent successfully');
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            
        } catch (downloadError) {
            console.error('[Google Drive Handler] Download error:', downloadError.message);
            // Jika gagal download, kirim link saja
            const message = formatDownloadMessage(result);
            await conn.sendMessage(m.chat, {
                text: message + `\n\n⚠️ _Auto-download gagal, gunakan link di atas_`
            }, { quoted: m });
            
            await conn.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } });
        }
        
    } catch (error) {
        console.error('[Google Drive Handler] ERROR:', error);
        console.error('[Google Drive Handler] Stack:', error.stack);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        
        return m.reply('❌ Terjadi kesalahan saat memproses link Google Drive.\n\n💡 Pastikan link valid dan file masih tersedia.\n\n' + error.message);
    }
};

handler.help = ["gdrive [link]", "googledrive [link]"];
handler.tags = ["downloader"];
handler.command = ["gdrive", "gd", "googledrive", "drive"];
handler.limit = true;

console.log('[Google Drive Handler] Enhanced handler loaded successfully with 5 APIs + ShortURL');

export default handler;