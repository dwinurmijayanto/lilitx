import fetch from 'node-fetch';

const cache = new Map();
const CACHE_TTL = 5 * 60 * 1000;
const MAX_DOWNLOAD_TIMEOUT = 600000; // 10 minutes untuk file besar

function getCachedData(key) {
    const cached = cache.get(key);
    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
        return cached.data;
    }
    if (cached) cache.delete(key);
    return null;
}

function setCachedData(key, data) {
    cache.set(key, { data, timestamp: Date.now() });
    if (cache.size > 50) {
        const firstKey = cache.keys().next().value;
        cache.delete(firstKey);
    }
}

function extractShortUrl(input) {
    // Jika input sudah berupa surl langsung (hanya alfanumerik, dash, underscore)
    if (/^[a-zA-Z0-9_-]+$/.test(input)) {
        return input;
    }
    
    // Extract dari URL lengkap
    // Pattern 1: ?surl=xxx atau &surl=xxx
    let match = input.match(/[?&]surl=([a-zA-Z0-9_-]+)/);
    if (match) return match[1];
    
    // Pattern 2: /s/xxx
    match = input.match(/\/s\/([a-zA-Z0-9_-]+)/);
    if (match) return match[1];
    
    // Pattern 3: /sharing/link?surl=xxx
    match = input.match(/\/sharing\/link\?surl=([a-zA-Z0-9_-]+)/);
    if (match) return match[1];
    
    return null;
}

async function teraboxDownload(input) {
    try {
        const surl = extractShortUrl(input);
        
        if (!surl) {
            throw new Error('Invalid URL format. Gunakan format: https://www.terabox.com/sharing/link?surl=xxx atau langsung ID surl');
        }
        
        console.log('[Terabox] SURL:', surl);
        
        const cached = getCachedData(`tera_${surl}`);
        if (cached) {
            console.log('[Terabox] Cache hit!');
            return cached;
        }
        
        // Call Sylyt93 API
        const apiUrl = `https://tera2.sylyt93.workers.dev/download?s=${surl}`;
        console.log('[Terabox] API URL:', apiUrl);
        
        const response = await fetch(apiUrl, {
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            }
        });
        
        console.log('[Terabox] Response status:', response.status);
        
        if (!response.ok) {
            const errorText = await response.text().catch(() => '');
            console.log('[Terabox] Error body:', errorText.substring(0, 500));
            throw new Error(`HTTP ${response.status}: ${errorText || 'Request failed'}`);
        }
        
        const data = await response.json();
        console.log('[Terabox] Response data:', JSON.stringify(data).substring(0, 200));
        
        // Check response format
        if (!data || typeof data !== 'object') {
            throw new Error('Invalid response format');
        }
        
        // Parse response structure
        let files = [];
        let skippedFolders = [];
        
        // If response has direct download link (single file)
        if (data.downloadLink) {
            files.push({
                filename: data.filename || data.name || 'file',
                size: data.size || 0,
                category: data.category || 0,
                downloadLink: data.downloadLink
            });
        }
        // If response has files array
        else if (data.files && Array.isArray(data.files)) {
            data.files.forEach(item => {
                if (item.is_dir == 1 || item.is_dir == "1" || item.isDirectory) {
                    skippedFolders.push(item.filename || item.name);
                } else if (item.downloadLink) {
                    files.push({
                        filename: item.filename || item.name,
                        size: item.size || 0,
                        category: item.category || 0,
                        downloadLink: item.downloadLink
                    });
                }
            });
        }
        // If response has list array
        else if (data.list && Array.isArray(data.list)) {
            data.list.forEach(item => {
                if (item.is_dir == 1 || item.is_dir == "1" || item.isDirectory) {
                    skippedFolders.push(item.filename || item.name);
                } else if (item.downloadLink || item.dlink) {
                    files.push({
                        filename: item.filename || item.name,
                        size: item.size || 0,
                        category: item.category || 0,
                        downloadLink: item.downloadLink || item.dlink
                    });
                }
            });
        }
        // If response is array directly
        else if (Array.isArray(data)) {
            data.forEach(item => {
                if (item.is_dir == 1 || item.is_dir == "1" || item.isDirectory) {
                    skippedFolders.push(item.filename || item.name);
                } else if (item.downloadLink || item.dlink) {
                    files.push({
                        filename: item.filename || item.name,
                        size: item.size || 0,
                        category: item.category || 0,
                        downloadLink: item.downloadLink || item.dlink
                    });
                }
            });
        }
        else {
            throw new Error('No files found in response');
        }
        
        console.log('[Terabox] Found', files.length, 'file(s)');
        
        const result = { status: 'success', files, skippedFolders };
        setCachedData(`tera_${surl}`, result);
        
        return result;
        
    } catch (error) {
        console.error('[Terabox] Error:', error.message);
        return { status: 'error', msg: error.message };
    }
}

function formatFileSize(bytes) {
    if (!bytes || bytes === 0) return '0 B';
    if (bytes >= 1024 * 1024 * 1024) {
        return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
    } else if (bytes >= 1024 * 1024) {
        return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
    } else if (bytes >= 1024) {
        return (bytes / 1024).toFixed(2) + ' KB';
    }
    return bytes + ' B';
}

function getMediaType(filename, category) {
    const ext = filename.split('.').pop().toLowerCase();
    
    // Category: 1=video, 2=audio, 3=image, 4=document
    if (category == 3 || ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'].includes(ext)) {
        return 'image';
    } else if (category == 1 || ['mp4', 'mkv', 'avi', 'mov', 'webm', 'flv', 'm4v'].includes(ext)) {
        return 'video';
    } else if (category == 2 || ['mp3', 'wav', 'ogg', 'm4a', 'flac', 'aac'].includes(ext)) {
        return 'audio';
    } else {
        return 'document';
    }
}

async function downloadFileFromUrl(url, fileSize = 0) {
    console.log('[Terabox] Downloading from:', url.substring(0, 100) + '...');
    console.log('[Terabox] Expected size:', formatFileSize(fileSize));
    
    // Calculate timeout based on file size (minimum 3 minutes, add 1 minute per 100MB)
    const timeoutDuration = Math.max(180000, Math.min(MAX_DOWNLOAD_TIMEOUT, 180000 + (fileSize / (100 * 1024 * 1024)) * 60000));
    console.log('[Terabox] Timeout set to:', Math.round(timeoutDuration / 1000), 'seconds');
    
    const controller = new AbortController();
    const timeout = setTimeout(() => {
        controller.abort();
        console.log('[Terabox] Download timeout after', Math.round(timeoutDuration / 1000), 'seconds');
    }, timeoutDuration);
    
    try {
        const response = await fetch(url, {
            signal: controller.signal,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': '*/*'
            }
        });
        
        clearTimeout(timeout);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        
        const buffer = await response.buffer();
        console.log('[Terabox] Downloaded:', formatFileSize(buffer.length));
        
        return buffer;
        
    } catch (error) {
        clearTimeout(timeout);
        throw error;
    }
}

let processingUsers = new Set();

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    const userId = m.sender;
    let prefix = usedPrefix || '.';
    const cmd = command || 'tera3';
    
    if (processingUsers.has(userId)) {
        return m.reply('⏳ Tunggu proses sebelumnya...');
    }
    
    let input = '';
    
    if (text) {
        input = text.trim();
    } else if (args && args.length > 0) {
        input = args.join(' ').trim();
    }
    
    if (!input) {
        return m.reply(`*Terabox Downloader (Sylyt93 API)*

📝 *Cara Penggunaan:*

1️⃣ Dengan URL lengkap:
${prefix}${cmd} https://www.terabox.com/sharing/link?surl=xxx
${prefix}${cmd} https://terabox.com/s/xxx
${prefix}${cmd} https://1024terabox.com/s/xxx

2️⃣ Dengan ID surl langsung:
${prefix}${cmd} 1NGQurfv5s-La-EecZQ-NVA

📋 *Contoh:*
${prefix}${cmd} https://1024terabox.com/s/1NGQurfv5s-La-EecZQ-NVA
${prefix}${cmd} 1NGQurfv5s-La-EecZQ-NVA

📋 *Cara mendapatkan surl:*
• Buka link Terabox di browser
• Cari parameter "surl=" di URL atau "/s/" di path
• Copy kode setelahnya
• Contoh: dari https://1024terabox.com/s/1NGQurfv5s-La-EecZQ-NVA
  ambil: 1NGQurfv5s-La-EecZQ-NVA

✨ *Fitur:*
📤 Auto upload semua file ke WhatsApp
🔗 Link download jika upload gagal
📁 Support berbagai tipe file
⚡ Powered by tera2.sylyt93.workers.dev`);
    }
    
    processingUsers.add(userId);
    
    try {
        await conn.sendMessage(m.chat, {
            react: { text: '🔍', key: m.key }
        });
        
        const result = await teraboxDownload(input);
        
        if (result.status === 'error') {
            await conn.sendMessage(m.chat, {
                react: { text: '❌', key: m.key }
            });
            return m.reply(`❌ Download gagal: ${result.msg}`);
        }
        
        const files = result.files.filter(f => f.downloadLink);
        const skippedFolders = result.skippedFolders || [];
        
        // Handle folder only
        if (files.length === 0 && skippedFolders.length > 0) {
            let msg = '📁 *Link ini berisi folder:*\n\n';
            skippedFolders.forEach((folder, idx) => {
                msg += `${idx + 1}. ${folder}\n`;
            });
            msg += '\n⚠️ Saat ini hanya support file individual.\n';
            msg += '💡 Silakan share file dari dalam folder.';
            
            await conn.sendMessage(m.chat, {
                react: { text: '📁', key: m.key }
            });
            return m.reply(msg);
        }
        
        if (files.length === 0) {
            throw new Error('Tidak ada file yang berhasil diambil');
        }
        
        await conn.sendMessage(m.chat, {
            react: { text: '⬇️', key: m.key }
        });
        
        // Process each file
        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            
            try {
                const mediaType = getMediaType(file.filename, file.category);
                const sizeFormatted = formatFileSize(file.size);
                
                console.log(`[Terabox] Processing ${i+1}/${files.length}: ${file.filename} (${sizeFormatted}, ${mediaType})`);
                
                // Always try to download and upload
                await m.reply(`⬇️ *Downloading...*\n📄 ${file.filename}\n📦 ${sizeFormatted}\n\n⏳ Mohon tunggu...`);
                
                let buffer;
                let downloadSuccess = false;
                
                try {
                    buffer = await downloadFileFromUrl(file.downloadLink, file.size);
                    downloadSuccess = true;
                    console.log(`[Terabox] Download successful`);
                } catch (downloadError) {
                    console.error(`[Terabox] Download failed:`, downloadError.message);
                    
                    // Langsung kirim link jika download gagal
                    let failMsg = `❌ *Download Gagal*\n\n`;
                    failMsg += `📄 ${file.filename}\n`;
                    failMsg += `📦 ${sizeFormatted}\n`;
                    failMsg += `⚠️ Error: ${downloadError.message}\n\n`;
                    failMsg += `🔗 *Download Link:*\n${file.downloadLink}\n\n`;
                    failMsg += `💡 Silakan download manual dari link di atas`;
                    
                    await m.reply(failMsg);
                    continue;
                }
                
                if (!downloadSuccess || !buffer) {
                    continue;
                }
                
                // Try to upload to WhatsApp
                console.log(`[Terabox] Uploading to WhatsApp...`);
                await m.reply(`⬆️ *Uploading to WhatsApp...*\n📦 ${formatFileSize(buffer.length)}`);
                
                let caption = `✅ *${file.filename}*\n📦 ${sizeFormatted}`;
                let uploadSuccess = false;
                
                try {
                    // Send based on media type
                    if (mediaType === 'image') {
                        await conn.sendMessage(m.chat, {
                            image: buffer,
                            caption: caption
                        }, { quoted: m });
                        console.log(`[Terabox] ✓ Sent as image`);
                        uploadSuccess = true;
                        
                    } else if (mediaType === 'video') {
                        await conn.sendMessage(m.chat, {
                            video: buffer,
                            caption: caption,
                            mimetype: 'video/mp4'
                        }, { quoted: m });
                        console.log(`[Terabox] ✓ Sent as video`);
                        uploadSuccess = true;
                        
                    } else if (mediaType === 'audio') {
                        await conn.sendMessage(m.chat, {
                            audio: buffer,
                            mimetype: 'audio/mp4',
                            fileName: file.filename
                        }, { quoted: m });
                        console.log(`[Terabox] ✓ Sent as audio`);
                        uploadSuccess = true;
                        
                    } else {
                        await conn.sendMessage(m.chat, {
                            document: buffer,
                            fileName: file.filename,
                            mimetype: 'application/octet-stream',
                            caption: caption
                        }, { quoted: m });
                        console.log(`[Terabox] ✓ Sent as document`);
                        uploadSuccess = true;
                    }
                } catch (uploadError) {
                    console.error(`[Terabox] Upload failed:`, uploadError.message);
                    uploadSuccess = false;
                }
                
                // Jika upload gagal, kirim link sebagai fallback
                if (!uploadSuccess) {
                    console.log(`[Terabox] Upload failed, sending link as fallback`);
                    
                    let fallbackMsg = `⚠️ *Upload ke WhatsApp Gagal*\n\n`;
                    fallbackMsg += `📄 ${file.filename}\n`;
                    fallbackMsg += `📦 ${sizeFormatted}\n`;
                    fallbackMsg += `✅ File berhasil di-download\n`;
                    fallbackMsg += `❌ Gagal upload (mungkin file terlalu besar untuk WA)\n\n`;
                    fallbackMsg += `🔗 *Download Link:*\n${file.downloadLink}\n\n`;
                    fallbackMsg += `💡 Silakan download manual dari link di atas`;
                    
                    await m.reply(fallbackMsg);
                }
                
                // Delay between files
                if (i < files.length - 1) {
                    console.log('[Terabox] Waiting 3s before next file...');
                    await new Promise(resolve => setTimeout(resolve, 3000));
                }
                
            } catch (fileError) {
                console.error(`[Terabox] Error processing file:`, fileError.message);
                
                // Send link as fallback
                let errorMsg = `❌ *Error Memproses File*\n\n`;
                errorMsg += `📄 ${file.filename}\n`;
                errorMsg += `📦 ${formatFileSize(file.size)}\n`;
                errorMsg += `⚠️ Error: ${fileError.message}\n\n`;
                errorMsg += `🔗 *Download Link:*\n${file.downloadLink}\n\n`;
                errorMsg += `💡 Silakan download manual dari link di atas`;
                
                await m.reply(errorMsg);
            }
        }
        
        // Info about skipped folders
        if (skippedFolders.length > 0) {
            let folderMsg = `\n📁 *Folder yang dilewati (${skippedFolders.length}):*\n`;
            skippedFolders.forEach((folder) => {
                folderMsg += `• ${folder}\n`;
            });
            await m.reply(folderMsg);
        }
        
        await conn.sendMessage(m.chat, {
            react: { text: '✅', key: m.key }
        });
        
    } catch (error) {
        console.error('[Terabox]:', error);
        
        await conn.sendMessage(m.chat, {
            react: { text: '❌', key: m.key }
        });
        
        m.reply(`❌ Error: ${error.message}`);
    } finally {
        processingUsers.delete(userId);
    }
};

handler.help = ["tera3"];
handler.tags = ["downloader"];
handler.command = ["tera3", "terabox"];
handler.limit = true;
handler.register = false;

export default handler;