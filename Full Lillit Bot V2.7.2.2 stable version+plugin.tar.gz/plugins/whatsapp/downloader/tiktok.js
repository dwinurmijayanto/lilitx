const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

// ─── Validators ───────────────────────────────────────────────────────────────

function isValidTikTokUrl(url) {
    return [
        /^(https?:\/\/)?(www\.)?(vt\.)?tiktok\.com\/.*/,
        /^(https?:\/\/)?(www\.)?vm\.tiktok\.com\/.*/,
        /^(https?:\/\/)?(www\.)?tiktok\.com\/@[\w.-]+\/video\/\d+/
    ].some(p => p.test(url));
}

function extractTikTokUrls(text) {
    const matches = text.match(/(https?:\/\/)?(www\.)?(vt\.|vm\.)?tiktok\.com\/[^\s]+/gi) || [];
    return [...new Set(matches)];
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function randomDelay(min = 1000, max = 3000) {
    return new Promise(r => setTimeout(r, Math.floor(Math.random() * (max - min)) + min));
}

function formatNumber(n) {
    n = Number(n) || 0;
    if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + 'M';
    if (n >= 1_000)     return (n / 1_000).toFixed(1) + 'K';
    return String(n);
}

function formatDuration(s) {
    s = Number(s) || 0;
    return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

// ─── Rate-limit-aware fetch wrapper ──────────────────────────────────────────
// Retries up to `maxRetry` times when the API returns a rate-limit error.

async function fetchWithRetry(fn, maxRetry = 2) {
    let lastErr;
    for (let attempt = 0; attempt <= maxRetry; attempt++) {
        try {
            return await fn();
        } catch (e) {
            lastErr = e;
            const isRateLimit = /free api limit|1 request\/second/i.test(e.message);
            if (isRateLimit && attempt < maxRetry) {
                const delay = Math.floor(Math.random() * 2000) + 1000; // 1-3 s
                console.warn(`⚠️  Rate limit hit, retry ${attempt + 1}/${maxRetry} in ${delay}ms…`);
                await new Promise(r => setTimeout(r, delay));
                continue;
            }
            throw e; // non-rate-limit error or max retries reached
        }
    }
    throw lastErr;
}

async function detectContentType(url) {
    try {
        const res = await fetch(url, { method: 'HEAD', timeout: 5000 });
        const ct  = res.headers.get('content-type') || '';
        if (ct.includes('video')) return 'video';
        if (ct.includes('image')) return 'image';
        if (/\.(mp4|mov|avi|webm)(\?|$)/i.test(url)) return 'video';
        if (/\.(jpg|jpeg|png|webp)(\?|$)/i.test(url)) return 'image';
    } catch { /* fallthrough */ }
    return 'video';
}

async function downloadBuffer(url, type = 'file') {
    try {
        const res = await fetch(url, { timeout: 30000 });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return Buffer.from(await res.arrayBuffer());
    } catch (e) {
        console.error(`⚠️  Failed to download ${type}:`, e.message);
        return null;
    }
}

// ─── API: tikwm.com — Single Video ───────────────────────────────────────────

async function getTikTokData(url) {
    return fetchWithRetry(async () => {
        const apiUrl = `https://tikwm.com/api/?url=${encodeURIComponent(url)}`;
        console.log(`🎯 Fetching: ${apiUrl}`);

        const res  = await fetch(apiUrl, { timeout: 15000 });
        if (!res.ok) throw new Error(`API HTTP ${res.status}`);

        const json = await res.json();

        // Surface rate-limit message so fetchWithRetry can detect it
        if (!json || json.code !== 0 || !json.data)
            throw new Error(json?.msg || 'Invalid API response');

        const d = json.data;

        // ── Photo / Slideshow support ────────────────────────────────────────
        // TikTok slideshows expose d.images (array of URLs) and no d.play URL,
        // or sometimes both. We normalise everything here.
        const images = Array.isArray(d.images) && d.images.length
            ? d.images          // raw string array  e.g. ["https://…", …]
            : null;

        return {
            title:        d.title                || 'TikTok Video',
            author:       d.author?.unique_id     || '-',
            nickname:     d.author?.nickname      || '',
            avatar:       d.author?.avatar        || null,
            cover:        d.cover                 || null,
            duration:     formatDuration(d.duration),
            play_count:   formatNumber(d.play_count),
            like_count:   formatNumber(d.digg_count),
            comment_count: formatNumber(d.comment_count),
            share_count:  formatNumber(d.share_count),
            videoUrl:     d.play                  || null,
            wmVideoUrl:   d.wmplay                || null,
            audioUrl:     d.music                 || null,
            musicTitle:   d.music_info?.title     || '-',
            musicAuthor:  d.music_info?.author    || '-',
            size_mb:      d.size ? (d.size / 1_048_576).toFixed(2) : '-',
            region:       d.region                || '-',
            create_time:  d.create_time ? new Date(d.create_time * 1000).toLocaleDateString('id-ID') : '-',
            // new fields
            isPhoto:      !!images,
            images,           // string[] | null
        };
    });
}

// ─── API: tikwm.com — Search ──────────────────────────────────────────────────

async function searchTikTok(query, count = 10) {
    return fetchWithRetry(async () => {
        const res = await fetch('https://www.tikwm.com/api/feed/search', {
            method:  'POST',
            headers: { 'Content-Type': 'application/json' },
            body:    JSON.stringify({ keywords: query, count, cursor: 0, web: 1, hd: 1 }),
            timeout: 15000
        });

        if (!res.ok) throw new Error(`API HTTP ${res.status}`);

        const json = await res.json();
        if (!json || json.code !== 0 || !json.data?.videos?.length)
            throw new Error(json?.msg || 'Tidak ada video ditemukan');

        return json.data.videos.map((v, i) => ({
            index:    i + 1,
            id:       v.video_id,
            title:    v.title || 'TikTok Video',
            url:      `https://www.tiktok.com/@${v.author?.unique_id}/video/${v.video_id}`,
            cover:    v.cover || null,
            duration: v.duration ? `${v.duration}s` : '-',
            author: {
                username: v.author?.unique_id || '-',
                nickname: v.author?.nickname  || '',
            },
            stats: {
                play:    formatNumber(v.play_count),
                like:    formatNumber(v.digg_count),
                comment: formatNumber(v.comment_count),
                share:   formatNumber(v.share_count),
            },
            music:  v.music_info?.title || v.music || '-',
            region: v.region || '-',
        }));
    });
}

// ─── Formatters ───────────────────────────────────────────────────────────────

function buildSearchMessage(videos, query) {
    let msg  = `🔍 *Hasil Pencarian TikTok*\n`;
        msg += `📌 Keyword : *${query}*\n`;
        msg += `📊 Ditemukan : *${videos.length} video*\n`;
        msg += `─────────────────────────\n\n`;

    for (const v of videos) {
        msg += `*${v.index}. ${v.title}*\n`;
        msg += `👤 @${v.author.username}`;
        if (v.author.nickname) msg += ` _(${v.author.nickname})_`;
        msg += `\n`;
        msg += `⏱ ${v.duration}  |  👁 ${v.stats.play}  |  ❤️ ${v.stats.like}\n`;
        if (v.music !== '-') msg += `🎵 ${v.music}\n`;
        msg += `🔗 ${v.url}\n\n`;
    }

    msg += `💡 *Tips:* Kirim URL video di atas ke *.tiktok <url>* untuk download!`;
    return msg;
}

function buildCaption(meta, index = null, total = null) {
    let cap = '';
    if (index && total) cap += `🖼️ *Foto ${index}/${total}*\n\n`;
    if (meta.title !== 'TikTok Video') cap += `📝 ${meta.title}\n`;
    cap += `👤 @${meta.author}`;
    if (meta.nickname) cap += ` _(${meta.nickname})_`;
    cap += `\n`;
    if (!meta.isPhoto) cap += `⏱ ${meta.duration}  |  📦 ${meta.size_mb} MB\n`;
    cap += `👁 ${meta.play_count}  ❤️ ${meta.like_count}  💬 ${meta.comment_count}\n`;
    cap += `🎵 ${meta.musicTitle} — ${meta.musicAuthor}\n`;
    cap += `📅 ${meta.create_time}  |  🌏 ${meta.region}`;
    return cap;
}

// ─── Photo slideshow sender ───────────────────────────────────────────────────

async function sendPhotoSlideshow(conn, chatId, meta, quotedMsg) {
    const { images } = meta;
    console.log(`🖼️  Sending slideshow: ${images.length} photos`);

    for (let i = 0; i < images.length; i++) {
        const imgUrl = images[i];
        const buf    = await downloadBuffer(imgUrl, `photo ${i + 1}`);

        if (!buf) {
            console.warn(`⚠️  Skipping photo ${i + 1} — download failed`);
            continue;
        }

        const caption = i === 0 ? buildCaption(meta, i + 1, images.length) : `🖼️ *Foto ${i + 1}/${images.length}*`;

        await conn.sendMessage(chatId, { image: buf, caption }, { quoted: quotedMsg });
        console.log(`✅ Photo ${i + 1}/${images.length} sent`);

        // Delay between photos (skip after last one)
        if (i < images.length - 1) await randomDelay(1000, 3000);
    }
}

// ─── Core download + send logic ───────────────────────────────────────────────

async function processUrl(conn, m, url, index = null, total = null) {
    const isBulk = total !== null;

    // 1. Fetch metadata (rate-limit retry built-in)
    const meta = await getTikTokData(url);

    // ── PHOTO / SLIDESHOW ────────────────────────────────────────────────────
    if (meta.isPhoto) {
        if (!meta.images?.length) throw new Error('Data foto tidak tersedia dari API');

        await sendPhotoSlideshow(conn, m.chat, meta, m);

        // Send audio after photos
        await randomDelay();
        if (meta.audioUrl) {
            const audioBuf = await downloadBuffer(meta.audioUrl, 'audio');
            if (audioBuf) {
                await conn.sendMessage(m.chat, {
                    audio: audioBuf,
                    mimetype: 'audio/mpeg',
                    ptt: false,
                    fileName: `tiktok_${Date.now()}.mp3`,
                }, { quoted: m });
                console.log('✅ Audio sent');
            }
        }
        return;
    }

    // ── VIDEO ────────────────────────────────────────────────────────────────
    if (!meta.videoUrl) throw new Error('URL video tidak tersedia dari API');

    const contentType = await detectContentType(meta.videoUrl);
    console.log(`📋 Content type: ${contentType}`);

    const [mediaBuf, thumbBuf] = await Promise.all([
        downloadBuffer(meta.videoUrl, contentType),
        meta.cover ? downloadBuffer(meta.cover, 'thumbnail') : Promise.resolve(null),
    ]);

    if (!mediaBuf) throw new Error(`Gagal mendownload ${contentType}`);

    const caption = buildCaption(meta, isBulk ? index : null, isBulk ? total : null);

    if (contentType === 'image') {
        await conn.sendMessage(m.chat, { image: mediaBuf, caption }, { quoted: m });
    } else {
        await conn.sendMessage(m.chat, {
            video: mediaBuf,
            jpegThumbnail: thumbBuf ?? undefined,
            mimetype: 'video/mp4',
            caption,
        }, { quoted: m });
    }
    console.log(`✅ ${contentType} sent`);

    await randomDelay();

    if (meta.audioUrl) {
        const audioBuf = await downloadBuffer(meta.audioUrl, 'audio');
        if (audioBuf) {
            await conn.sendMessage(m.chat, {
                audio: audioBuf,
                mimetype: 'audio/mpeg',
                ptt: false,
                fileName: `tiktok_${Date.now()}.mp3`,
            }, { quoted: m });
            console.log('✅ Audio sent');
        }
    } else {
        console.log('⚠️  No audio URL from API');
    }
}

// ─── Help strings ─────────────────────────────────────────────────────────────

const HELP_DOWNLOAD = (p, c) => `
*📥 TikTok Downloader*
_Powered by tikwm.com_

*Single Download:*
${p}${c} <url>

*Bulk Download:*
${p}${c} <url1> <url2> ...

*Contoh:*
${p}${c} https://www.tiktok.com/@user/video/123
${p}${c} https://vt.tiktok.com/ZS2p8vGJg

✅ Mendukung: tiktok.com | vt.tiktok.com | vm.tiktok.com
🎯 No watermark + audio terpisah + slideshow foto
`.trim();

const HELP_SEARCH = (p, c) => `
*🔍 TikTok Search*
_Powered by tikwm.com_

*Penggunaan:*
${p}${c} <kata kunci>

*Contoh:*
${p}${c} kucing lucu
${p}${c} tutorial makeup viral
${p}${c} dance trending 2024

📊 Menampilkan 10 video teratas
`.trim();

// ─── Handler ──────────────────────────────────────────────────────────────────

let handler = async (m, { conn, args, usedPrefix, command }) => {
    const input  = args?.join(' ').trim() || '';
    const prefix = usedPrefix || m.text?.match(/^([.!#/])/)?.[1] || '.';
    const cmd    = command || 'tiktok';
    const isSearch = ['ttsearch', 'tiktoksearch'].includes(cmd);

    // ── SEARCH mode ──────────────────────────────────────────────────────────
    if (isSearch) {
        if (!input) return m.reply(HELP_SEARCH(prefix, cmd));
        await conn.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });
        try {
            const videos = await searchTikTok(input, 10);
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            return m.reply(buildSearchMessage(videos, input));
        } catch (e) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ Pencarian gagal.\n*Error:* ${e.message}\n\n💡 Coba kata kunci lain.`);
        }
    }

    // ── DOWNLOAD mode ─────────────────────────────────────────────────────────
    if (!input) return m.reply(HELP_DOWNLOAD(prefix, cmd));

    const urls = extractTikTokUrls(input).filter(isValidTikTokUrl);

    // No URL → keyword search then auto-download top result
    if (!urls.length) {
        await conn.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });
        let videos;
        try {
            videos = await searchTikTok(input, 10);
        } catch (e) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ Pencarian gagal.\n*Error:* ${e.message}\n\n💡 Coba kata kunci lain.`);
        }

        const top = videos[0];
        await m.reply(`🔍 Ditemukan *${videos.length} video* untuk: _"${input}"_\n\n🎯 Mengunduh video teratas:\n👤 @${top.author.username}\n📝 ${top.title}\n\n⏳ Mohon tunggu...`);

        try {
            await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
            await processUrl(conn, m, top.url);
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } catch (e) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ Gagal mendownload video.\n*Error:* ${e.message}`);
        }
        return;
    }

    const isBulk = urls.length > 1;
    if (isBulk) await m.reply(`📥 *Bulk Download*\n🎬 Memproses *${urls.length} item*...\n⏳ Mohon tunggu.`);

    let ok = 0, fail = 0;

    for (let i = 0; i < urls.length; i++) {
        const url = urls[i];
        try {
            if (!isBulk) await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
            await processUrl(conn, m, url, i + 1, isBulk ? urls.length : null);
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            ok++;
        } catch (e) {
            console.error(`❌ Error item ${i + 1}:`, e.message);
            fail++;
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            if (!isBulk) return m.reply(`❌ Gagal mendownload.\n*Error:* ${e.message}`);
        }

        if (isBulk && i < urls.length - 1) await randomDelay(2000, 4000);
    }

    if (isBulk)
        await m.reply(`📊 *Download Selesai*\n✅ Berhasil : ${ok}/${urls.length}\n❌ Gagal : ${fail}/${urls.length}`);
};

handler.help    = ['tiktok', 'tt', 'tiktokdl', 'ttsearch', 'tiktoksearch'];
handler.tags    = ['downloader'];
handler.command = ['tiktok', 'tt', 'tiktokdl', 'ttdl', 'ttsearch', 'tiktoksearch'];

export default handler;