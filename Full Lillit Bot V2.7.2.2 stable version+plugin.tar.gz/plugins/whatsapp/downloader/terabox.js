const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

// ========== SHORTURL CONFIG ==========
const SHORTURL_CONFIG = {
    api: 'https://zeinklab.com/api/create',
    baseUrl: 'http://zeink.cc',
    timeout: 15000
};

// ========== SHORTURL FUNCTIONS ==========
async function createShortUrl(longUrl) {
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), SHORTURL_CONFIG.timeout);

        const response = await fetch(SHORTURL_CONFIG.api, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'User-Agent': 'Mozilla/5.0',
                'Origin': 'https://zeinklab.com',
                'Referer': 'https://zeinklab.com/create'
            },
            body: JSON.stringify({ url: longUrl }),
            signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        let responseText = await response.text();
        
        const jsonMatch = responseText.match(/(\{[\s\S]*\})/);
        if (jsonMatch) {
            responseText = jsonMatch[1];
        }
        
        const result = JSON.parse(responseText);

        if (result.success && result.short_url) {
            let url = result.short_url;
            if (url.startsWith('/')) {
                url = SHORTURL_CONFIG.baseUrl + url;
            } else if (!url.startsWith('http')) {
                url = SHORTURL_CONFIG.baseUrl + '/' + url;
            }
            
            return url;
        }
        
        return null;

    } catch (error) {
        console.log(`[ShortURL] Error: ${error.message}`);
        return null;
    }
}

// ========== TERABOX FUNCTIONS ==========
function isValidTeraboxUrl(url) {
    return /(1024tera\.com|terabox\.com|teraboxapp\.com|teraboxlink\.com|terasharelink\.com|terafileshare\.com|terabox\.app)/i.test(url);
}

function normalizeUrl(url) {
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
        url = 'https://' + url;
    }
    
    const surlMatch = url.match(/[?&]surl=([^&]+)/);
    if (surlMatch) {
        const surl = surlMatch[1];
        url = `https://1024terabox.com/s/1${surl}`;
    }
    
    return url;
}

function formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function getRandomDelay() {
    return Math.floor(Math.random() * (120000 - 60000 + 1)) + 60000; // 1-2 menit
}

function formatDate(timestamp) {
    if (!timestamp) return 'N/A';
    try {
        const date = new Date(timestamp * 1000);
        return date.toLocaleDateString('id-ID', { 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    } catch {
        return 'N/A';
    }
}

function getFileType(filename) {
    const ext = filename.toLowerCase().split('.').pop();
    const types = {
        'jpg': '🖼️ Gambar', 'jpeg': '🖼️ Gambar', 'png': '🖼️ Gambar', 'gif': '🖼️ Gambar', 'webp': '🖼️ Gambar',
        'mp4': '🎥 Video', 'mkv': '🎥 Video', 'avi': '🎥 Video', 'mov': '🎥 Video', 'webm': '🎥 Video',
        'mp3': '🎵 Audio', 'wav': '🎵 Audio', 'flac': '🎵 Audio', 'm4a': '🎵 Audio',
        'pdf': '📄 Dokumen', 'doc': '📄 Dokumen', 'docx': '📄 Dokumen', 'txt': '📄 Dokumen',
        'zip': '📦 Archive', 'rar': '📦 Archive', '7z': '📦 Archive',
        'apk': '📱 Aplikasi', 'exe': '💻 Program'
    };
    return types[ext] || '📁 File';
}

function parseSize(sizeStr) {
    if (!sizeStr) return 0;
    
    if (typeof sizeStr === 'number') return sizeStr;
    
    const match = sizeStr.match(/^([\d.]+)\s*([A-Z]+)$/i);
    if (match) {
        const value = parseFloat(match[1]);
        const unit = match[2].toUpperCase();
        const multipliers = { 'B': 1, 'KB': 1024, 'MB': 1024*1024, 'GB': 1024*1024*1024 };
        return Math.floor(value * (multipliers[unit] || 1));
    }
    
    return parseInt(sizeStr) || 0;
}

// ========== TERA-CORE API ==========
async function getTeraboxFromTeraCore(teraboxUrl, retryCount = 0, maxRetries = 3) {
    const debugInfo = {
        api: 'Tera-Core API',
        startTime: Date.now(),
        requestUrl: '',
        responseStatus: null,
        responseTime: null,
        dataStructure: {},
        linksFound: {},
        errors: [],
        retries: retryCount
    };
    
    try {
        const encodedUrl = encodeURIComponent(teraboxUrl);
        const apiUrl = `https://upload.vbi1.my.id/terabox/tera-core.php?url=${encodedUrl}`;
        debugInfo.requestUrl = apiUrl;
        
        console.log(`\n╔════════════════════════════════════════════════════════════╗`);
        console.log(`║  [Tera-Core] 🔍 DEBUG: tera-core.php                     ║`);
        if (retryCount > 0) {
            console.log(`║  🔄 RETRY ATTEMPT: ${retryCount}/${maxRetries}                            ║`);
        }
        console.log(`╚════════════════════════════════════════════════════════════╝`);
        console.log(`📤 Request URL: ${apiUrl}`);
        console.log(`⏱️  Request started at: ${new Date(debugInfo.startTime).toISOString()}`);
        
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 30000);
        
        const response = await fetch(apiUrl, {
            signal: controller.signal,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': 'application/json'
            }
        });
        
        clearTimeout(timeout);
        
        debugInfo.responseTime = Date.now() - debugInfo.startTime;
        debugInfo.responseStatus = response.status;
        
        console.log(`📥 Response Status: ${response.status} ${response.statusText}`);
        console.log(`⏱️  Response Time: ${debugInfo.responseTime}ms`);
        
        if (!response.ok) {
            debugInfo.errors.push(`HTTP ${response.status}`);
            console.log(`❌ HTTP Error: ${response.status}`);
            
            if (retryCount < maxRetries) {
                const retryDelay = 2000 + (retryCount * 1000);
                console.log(`⏳ Retrying in ${retryDelay/1000} seconds...`);
                await delay(retryDelay);
                return getTeraboxFromTeraCore(teraboxUrl, retryCount + 1, maxRetries);
            }
            
            return { result: null, debug: debugInfo };
        }
        
        const data = await response.json();
        
        debugInfo.dataStructure = {
            success: data.success,
            status: data.status,
            filesLength: data.files ? data.files.length : 0,
            total_files: data.total_files
        };
        
        console.log(`\n📊 Response Data Structure:`);
        console.log(`   - success: ${data.success}`);
        console.log(`   - status: ${data.status}`);
        console.log(`   - files.length: ${data.files ? data.files.length : 0}`);
        console.log(`   - total_files: ${data.total_files}`);
        
        if (!data.success || data.status !== 'success' || !data.files || data.files.length === 0) {
            debugInfo.errors.push('Invalid data response or empty files');
            console.log(`❌ Invalid Response: success=${data.success}, status=${data.status}`);
            
            if (retryCount < maxRetries) {
                const retryDelay = 2000 + (retryCount * 1000);
                console.log(`⏳ Retrying in ${retryDelay/1000} seconds...`);
                await delay(retryDelay);
                return getTeraboxFromTeraCore(teraboxUrl, retryCount + 1, maxRetries);
            }
            
            return { result: null, debug: debugInfo };
        }
        
        console.log(`\n🔗 Links Analysis for ${data.files.length} file(s):`);
        
        const files = data.files.map((fileInfo, idx) => {
            console.log(`\n   📁 File ${idx + 1}: ${fileInfo.filename}`);
            console.log(`   ├─ Size: ${fileInfo.size || fileInfo.size_bytes}`);
            console.log(`   ├─ Is Directory: ${fileInfo.is_directory}`);
            
            const linksAvailable = {
                download_link: !!fileInfo.download_link,
                thumbnails: !!fileInfo.thumbnails
            };
            
            console.log(`   ├─ Links Available:`);
            console.log(`   │  ├─ download_link: ${linksAvailable.download_link ? '✓' : '✗'}`);
            console.log(`   │  └─ thumbnails: ${linksAvailable.thumbnails ? '✓' : '✗'}`);
            
            debugInfo.linksFound[`file_${idx + 1}`] = linksAvailable;
            
            let sizeBytes = 0;
            if (fileInfo.size_bytes) {
                sizeBytes = parseInt(fileInfo.size_bytes) || 0;
            } else if (fileInfo.size) {
                sizeBytes = parseSize(fileInfo.size);
            }
            
            return {
                downloadUrl: fileInfo.download_link,
                downloadUrl2: null,
                directLink: fileInfo.download_link,
                title: fileInfo.filename || 'file',
                size: fileInfo.size || formatBytes(sizeBytes),
                sizeBytes: sizeBytes,
                thumbnail: fileInfo.thumbnails?.large || fileInfo.thumbnails?.medium || fileInfo.thumbnails?.small || null,
                md5: null,
                category: null,
                mediaType: fileInfo.is_directory ? 'folder' : 'file',
                path: fileInfo.path || null,
                isdir: fileInfo.is_directory ? 1 : 0,
                server_ctime: null,
                server_mtime: null,
                fs_id: fileInfo.fs_id || null
            };
        });
        
        console.log(`\n✅ Tera-Core API Success: ${files.length} file(s) processed in ${debugInfo.responseTime}ms`);
        if (retryCount > 0) {
            console.log(`   (Success after ${retryCount} retry attempt(s))`);
        }
        console.log(`═══════════════════════════════════════════════════════════════\n`);
        
        return { 
            result: { api: 'Tera-Core API', files, duration: debugInfo.responseTime, retries: retryCount },
            debug: debugInfo 
        };
        
    } catch (error) {
        debugInfo.errors.push(error.message);
        console.log(`❌ Tera-Core API Error: ${error.message}`);
        
        if (retryCount < maxRetries) {
            const retryDelay = 2000 + (retryCount * 1000);
            console.log(`⏳ Retrying in ${retryDelay/1000} seconds due to: ${error.message}`);
            await delay(retryDelay);
            return getTeraboxFromTeraCore(teraboxUrl, retryCount + 1, maxRetries);
        }
        
        console.log(`═══════════════════════════════════════════════════════════════\n`);
        return { result: null, debug: debugInfo };
    }
}

// ========== TERABOXHNN API (Original) ==========
async function getTeraboxFromVBI(teraboxUrl, retryCount = 0, maxRetries = 3) {
    const debugInfo = {
        api: 'VBI API',
        startTime: Date.now(),
        requestUrl: '',
        responseStatus: null,
        responseTime: null,
        dataStructure: {},
        linksFound: {},
        errors: [],
        retries: retryCount
    };
    
    try {
        const encodedUrl = encodeURIComponent(teraboxUrl);
        const apiUrl = `https://upload.vbi1.my.id/terabox/teraboxhnn.php?url=${encodedUrl}`;
        debugInfo.requestUrl = apiUrl;
        
        console.log(`\n╔════════════════════════════════════════════════════════════╗`);
        console.log(`║  [VBI API] 🔍 DEBUG: teraboxhnn.php                      ║`);
        if (retryCount > 0) {
            console.log(`║  🔄 RETRY ATTEMPT: ${retryCount}/${maxRetries}                            ║`);
        }
        console.log(`╚════════════════════════════════════════════════════════════╝`);
        console.log(`📤 Request URL: ${apiUrl}`);
        console.log(`⏱️  Request started at: ${new Date(debugInfo.startTime).toISOString()}`);
        
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 30000);
        
        const response = await fetch(apiUrl, {
            signal: controller.signal,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': 'application/json'
            }
        });
        
        clearTimeout(timeout);
        
        debugInfo.responseTime = Date.now() - debugInfo.startTime;
        debugInfo.responseStatus = response.status;
        
        console.log(`📥 Response Status: ${response.status} ${response.statusText}`);
        console.log(`⏱️  Response Time: ${debugInfo.responseTime}ms`);
        
        if (!response.ok) {
            debugInfo.errors.push(`HTTP ${response.status}`);
            console.log(`❌ HTTP Error: ${response.status}`);
            
            if (retryCount < maxRetries) {
                const retryDelay = 2000 + (retryCount * 1000);
                console.log(`⏳ Retrying in ${retryDelay/1000} seconds...`);
                await delay(retryDelay);
                return getTeraboxFromVBI(teraboxUrl, retryCount + 1, maxRetries);
            }
            
            return { result: null, debug: debugInfo };
        }
        
        const data = await response.json();
        
        debugInfo.dataStructure = {
            status: data.status,
            filesLength: data.files ? data.files.length : 0,
            totalFiles: data.totalFiles,
            successFiles: data.successFiles,
            skippedFolders: data.skippedFolders?.length || 0
        };
        
        console.log(`\n📊 Response Data Structure:`);
        console.log(`   - status: ${data.status}`);
        console.log(`   - files.length: ${data.files ? data.files.length : 0}`);
        console.log(`   - totalFiles: ${data.totalFiles}`);
        console.log(`   - successFiles: ${data.successFiles}`);
        
        if (data.status !== 'success' || !data.files || data.files.length === 0) {
            debugInfo.errors.push('Invalid data response or empty files');
            console.log(`❌ Invalid Response: status=${data.status}`);
            
            if (retryCount < maxRetries) {
                const retryDelay = 2000 + (retryCount * 1000);
                console.log(`⏳ Retrying in ${retryDelay/1000} seconds...`);
                await delay(retryDelay);
                return getTeraboxFromVBI(teraboxUrl, retryCount + 1, maxRetries);
            }
            
            return { result: null, debug: debugInfo };
        }
        
        console.log(`\n🔗 Links Analysis for ${data.files.length} file(s):`);
        
        const files = data.files.map((fileInfo, idx) => {
            console.log(`\n   📁 File ${idx + 1}: ${fileInfo.filename}`);
            console.log(`   ├─ Size: ${fileInfo.sizeFormatted || fileInfo.size}`);
            console.log(`   ├─ Category: ${fileInfo.category}`);
            console.log(`   ├─ Media Type: ${fileInfo.mediaType}`);
            
            const linksAvailable = {
                download: !!fileInfo.download,
                download2: !!fileInfo.download2
            };
            
            console.log(`   ├─ Links Available:`);
            console.log(`   │  ├─ download: ${linksAvailable.download ? '✓' : '✗'}`);
            console.log(`   │  └─ download2: ${linksAvailable.download2 ? '✓' : '✗'}`);
            
            debugInfo.linksFound[`file_${idx + 1}`] = linksAvailable;
            
            let sizeBytes = 0;
            if (typeof fileInfo.size === 'number') {
                sizeBytes = fileInfo.size;
            } else if (fileInfo.sizeFormatted) {
                sizeBytes = parseSize(fileInfo.sizeFormatted);
            } else if (fileInfo.size) {
                sizeBytes = parseSize(fileInfo.size);
            }
            
            return {
                downloadUrl: fileInfo.download,
                downloadUrl2: fileInfo.download2,
                directLink: fileInfo.download,
                title: fileInfo.filename || 'file',
                size: fileInfo.sizeFormatted || formatBytes(sizeBytes),
                sizeBytes: sizeBytes,
                thumbnail: null,
                md5: null,
                category: fileInfo.category,
                mediaType: fileInfo.mediaType,
                path: fileInfo.path || null,
                isdir: 0,
                server_ctime: null,
                server_mtime: null,
                fs_id: fileInfo.fs_id || null
            };
        });
        
        console.log(`\n✅ VBI API Success: ${files.length} file(s) processed in ${debugInfo.responseTime}ms`);
        if (retryCount > 0) {
            console.log(`   (Success after ${retryCount} retry attempt(s))`);
        }
        console.log(`═══════════════════════════════════════════════════════════════\n`);
        
        return { 
            result: { api: 'VBI API', files, duration: debugInfo.responseTime, retries: retryCount },
            debug: debugInfo 
        };
        
    } catch (error) {
        debugInfo.errors.push(error.message);
        console.log(`❌ VBI API Error: ${error.message}`);
        
        if (retryCount < maxRetries) {
            const retryDelay = 2000 + (retryCount * 1000);
            console.log(`⏳ Retrying in ${retryDelay/1000} seconds due to: ${error.message}`);
            await delay(retryDelay);
            return getTeraboxFromVBI(teraboxUrl, retryCount + 1, maxRetries);
        }
        
        console.log(`═══════════════════════════════════════════════════════════════\n`);
        return { result: null, debug: debugInfo };
    }
}

// ========== DUAL API HANDLER (Race Both APIs) ==========
async function getTeraboxDualAPI(teraboxUrl) {
    console.log(`\n╔═══════════════════════════════════════════════════════════════╗`);
    console.log(`║  🚀 DUAL API MODE - Racing Both APIs Simultaneously          ║`);
    console.log(`╚═══════════════════════════════════════════════════════════════╝`);
    
    const startTime = Date.now();
    
    // Race both APIs simultaneously
    const raceResult = await Promise.race([
        getTeraboxFromVBI(teraboxUrl).then(res => ({ ...res, source: 'VBI' })),
        getTeraboxFromTeraCore(teraboxUrl).then(res => ({ ...res, source: 'Tera-Core' }))
    ]);
    
    const totalTime = Date.now() - startTime;
    
    console.log(`\n╔═══════════════════════════════════════════════════════════════╗`);
    console.log(`║  🏁 RACE RESULT                                               ║`);
    console.log(`╚═══════════════════════════════════════════════════════════════╝`);
    console.log(`🏆 Winner: ${raceResult.source}`);
    console.log(`⏱️  Total Time: ${totalTime}ms`);
    console.log(`📊 Valid Result: ${raceResult.result ? 'YES' : 'NO'}`);
    
    if (raceResult.result) {
        console.log(`✅ Using result from ${raceResult.result.api}`);
        console.log(`📁 Files Found: ${raceResult.result.files.length}`);
        return raceResult;
    }
    
    // If the winner failed, wait for the other API
    console.log(`\n⚠️  Winner failed, waiting for backup API...`);
    
    const backupPromise = raceResult.source === 'VBI' 
        ? getTeraboxFromTeraCore(teraboxUrl).then(res => ({ ...res, source: 'Tera-Core' }))
        : getTeraboxFromVBI(teraboxUrl).then(res => ({ ...res, source: 'VBI' }));
    
    const backupResult = await backupPromise;
    const backupTime = Date.now() - startTime;
    
    console.log(`\n╔═══════════════════════════════════════════════════════════════╗`);
    console.log(`║  🔄 BACKUP API RESULT                                         ║`);
    console.log(`╚═══════════════════════════════════════════════════════════════╝`);
    console.log(`📡 Backup: ${backupResult.source}`);
    console.log(`⏱️  Total Time: ${backupTime}ms`);
    console.log(`📊 Valid Result: ${backupResult.result ? 'YES' : 'NO'}`);
    
    if (backupResult.result) {
        console.log(`✅ Using backup result from ${backupResult.result.api}`);
        console.log(`📁 Files Found: ${backupResult.result.files.length}`);
        return backupResult;
    }
    
    // Both failed
    console.log(`\n❌ Both APIs failed`);
    return {
        result: null,
        debug: {
            vbi: raceResult.source === 'VBI' ? raceResult.debug : backupResult.debug,
            teraCore: raceResult.source === 'Tera-Core' ? raceResult.debug : backupResult.debug
        }
    };
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    const teraboxUrl = args && args.length > 0 ? args.join(' ').trim() : '';
    
    if (!teraboxUrl) {
        let prefix = usedPrefix;
        if (!prefix && m.text) {
            const match = m.text.match(/^([.!#/])/);
            prefix = match ? match[1] : '.';
        }
        prefix = prefix || '.';
        
        const cmd = command || 'terabox';
        
        return m.reply(`*📥 Format Terabox Downloader*

🔹 Download: ${prefix}${cmd} url_terabox

*Contoh:*
${prefix}${cmd} https://1024terabox.com/s/1-gTxOph13HZ2gUEV4H_Aeg
${prefix}${cmd} https://terabox.app/sharing/link?surl=xxx
${prefix}${cmd} https://terabox.com/s/1xxxxxx

*Supported Domains:*
• 1024tera.com
• terabox.com
• terabox.app
• teraboxapp.com
• teraboxlink.com
• terasharelink.com
• terafileshare.com

*✨ Fitur Enhanced:*
✓ Dual API System (VBI + Tera-Core)
✓ Simultaneous API Racing
✓ Auto Fallback if One Fails
✓ Multiple Download Links
✓ Folder Support (Auto Extract)
✓ ShortURL Support
✓ Enhanced File Details
✓ Auto Retry Mechanism
✓ 1-2 Menit Delay antar File`);
    }
    
    if (!isValidTeraboxUrl(teraboxUrl)) {
        return m.reply('❌ URL bukan dari Terabox/1024Tera. Pastikan URL mengandung domain yang didukung.');
    }
    
    try {
        await conn.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });
    } catch (e) {
        console.log('Gagal menambahkan reaksi:', e);
    }
    
    try {
        const normalizedUrl = normalizeUrl(teraboxUrl);
        
        console.log(`\n╔═══════════════════════════════════════════════════════════════╗`);
        console.log(`║  🔄 STARTING DUAL API PROCESSING                             ║`);
        console.log(`╚═══════════════════════════════════════════════════════════════╝`);
        console.log(`📍 Original URL: ${teraboxUrl}`);
        console.log(`📍 Normalized URL: ${normalizedUrl}`);
        console.log(`⏰ Started at: ${new Date().toISOString()}`);
        
        const { result, debug, source } = await getTeraboxDualAPI(normalizedUrl);
        
        if (!result || !result.files || result.files.length === 0) {
            console.log('❌ Gagal mendapatkan file dari kedua API:', teraboxUrl);
            
            let debugMsg = '*❌ Gagal mendapatkan file dari kedua API*\n\n';
            debugMsg += '*📊 Debug Information:*\n\n';
            
            if (debug.vbi) {
                debugMsg += `*VBI API (teraboxhnn)*\n`;
                debugMsg += `├─ Status: ${debug.vbi.responseStatus || 'No response'}\n`;
                debugMsg += `├─ Time: ${debug.vbi.responseTime || 'N/A'}ms\n`;
                debugMsg += `├─ Retries: ${debug.vbi.retries || 0}/3\n`;
                debugMsg += `└─ Errors: ${debug.vbi.errors.join(', ') || 'None'}\n\n`;
            }
            
            if (debug.teraCore) {
                debugMsg += `*Tera-Core API*\n`;
                debugMsg += `├─ Status: ${debug.teraCore.responseStatus || 'No response'}\n`;
                debugMsg += `├─ Time: ${debug.teraCore.responseTime || 'N/A'}ms\n`;
                debugMsg += `├─ Retries: ${debug.teraCore.retries || 0}/3\n`;
                debugMsg += `└─ Errors: ${debug.teraCore.errors.join(', ') || 'None'}\n\n`;
            }
            
            debugMsg += `💡 *Saran:*\n`;
            debugMsg += `• Cek koneksi internet\n`;
            debugMsg += `• Pastikan URL valid\n`;
            debugMsg += `• Coba lagi beberapa saat`;
            
            await conn.sendMessage(m.chat, { text: debugMsg });
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return;
        }
        
        const files = result.files;
        
        console.log(`\n✅ Total ${files.length} file(s) ditemukan via ${result.api}`);
        if (result.retries && result.retries > 0) {
            console.log(`   (Retrieved after ${result.retries} retry attempt(s))`);
        }
        
        try {
            await conn.sendMessage(m.chat, { react: { text: '📥', key: m.key } });
        } catch (e) {
            console.log('Gagal menambahkan reaksi download:', e);
        }
        
        // Info awal jika lebih dari 1 file
        if (files.length > 1) {
            const infoMsg = `*📦 Folder Terdeteksi*\n\n` +
                `Total ${files.length} file akan diproses\n` +
                `🔧 API: ${result.api}\n` +
                `⏱️ Delay antar file: 1-2 menit\n` +
                `⏳ Estimasi waktu: ${Math.ceil(files.length * 1.5)} menit\n\n` +
                `Mohon tunggu...`;
            await conn.sendMessage(m.chat, { text: infoMsg });
        }
        
        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            
            if (!file.downloadUrl && !file.downloadUrl2) {
                console.log(`File ${i + 1}: No download URL available`);
                continue;
            }
            
            // Delay antar file (kecuali file pertama)
            if (i > 0) {
                const delayMs = getRandomDelay();
                console.log(`⏳ Waiting ${Math.round(delayMs/1000)}s before processing next file...`);
                await conn.sendMessage(m.chat, { 
                    text: `⏳ Menunggu ${Math.round(delayMs/1000)} detik sebelum file berikutnya...` 
                });
                await delay(delayMs);
            }
            
            try {
                console.log(`\n📁 Processing File ${i + 1}/${files.length}: ${file.title}`);
                console.log(`   Size: ${file.size} (${file.sizeBytes} bytes)`);
                
                try {
                    await conn.sendMessage(m.chat, { react: { text: '⬇️', key: m.key } });
                } catch (e) {
                    console.log('Gagal menambahkan reaksi download:', e);
                }
                
                // Prioritas URL download
                const urlsToTry = [];
                
                // Coba download terlebih dahulu, lalu download2
                if (file.downloadUrl) urlsToTry.push({ url: file.downloadUrl, name: 'download' });
                if (file.downloadUrl2) urlsToTry.push({ url: file.downloadUrl2, name: 'download2' });
                
                let downloadSuccess = false;
                let buffer = null;
                let successUrl = null;
                
                for (const urlItem of urlsToTry) {
                    if (downloadSuccess) break;
                    
                    console.log(`   Trying ${urlItem.name}...`);
                    
                    // Timeout dinamis berdasarkan ukuran file (minimal 90s, maksimal 5 menit)
                    const timeoutDuration = Math.min(300000, Math.max(90000, file.sizeBytes / 1024 / 10));
                    const controller = new AbortController();
                    const downloadTimeout = setTimeout(() => {
                        controller.abort();
                        console.log(`   Download timeout after ${timeoutDuration}ms`);
                    }, timeoutDuration);
                    
                    try {
                        const response = await fetch(urlItem.url, {
                            signal: controller.signal,
                            headers: {
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                                'Referer': 'https://1024terabox.com/',
                                'Accept': '*/*'
                            }
                        });
                        
                        clearTimeout(downloadTimeout);
                        
                        if (!response.ok) {
                            console.log(`   Failed with ${urlItem.name} - HTTP ${response.status}`);
                            continue;
                        }
                        
                        const arrayBuffer = await response.arrayBuffer();
                        buffer = Buffer.from(arrayBuffer);
                        
                        if (!buffer || buffer.length === 0) {
                            console.log(`   Downloaded buffer is empty`);
                            buffer = null;
                            continue;
                        }
                        
                        downloadSuccess = true;
                        successUrl = urlItem.name;
                        console.log(`   ✅ Downloaded successfully via ${urlItem.name} (${buffer.length} bytes)`);
                        
                    } catch (downloadError) {
                        clearTimeout(downloadTimeout);
                        if (downloadError.name === 'AbortError') {
                            console.log(`   ${urlItem.name} timeout`);
                            continue;
                        }
                        console.log(`   ${urlItem.name} failed: ${downloadError.message}`);
                        continue;
                    }
                }
                
                if (!downloadSuccess || !buffer) {
                    console.log(`   ⚠️ All download attempts failed, sending links...`);
                    
                    const shortDownloadUrl = await createShortUrl(file.downloadUrl || file.downloadUrl2);
                    
                    let fallbackMsg = `*⚠️ Download Gagal - Gunakan Link*\n\n`;
                    fallbackMsg += `${getFileType(file.title)} *${file.title}*\n\n`;
                    fallbackMsg += `┌─ 📊 *Informasi File*\n`;
                    fallbackMsg += `├ 📏 Ukuran: *${file.size}*\n`;
                    fallbackMsg += `├ 🏷️ Tipe Media: *${file.mediaType || 'Unknown'}*\n`;
                    fallbackMsg += `├ 🔧 API: *${result.api}*\n`;
                    fallbackMsg += `└ 💡 Gunakan link download di bawah\n\n`;
                    fallbackMsg += `🔗 *DOWNLOAD LINK:*\n`;
                    fallbackMsg += `${shortDownloadUrl || file.downloadUrl || file.downloadUrl2}`;
                    
                    if (files.length > 1) {
                        fallbackMsg += `\n\n📊 File ${i + 1} dari ${files.length}`;
                    }
                    
                    await conn.sendMessage(m.chat, { text: fallbackMsg });
                    continue;
                }
                
                console.log(`   📤 Sending file...`);
                
                try {
                    await conn.sendMessage(m.chat, { react: { text: '⬆️', key: m.key } });
                } catch (e) {
                    console.log('Gagal menambahkan reaksi upload:', e);
                }
                
                let caption = `*📥 Terabox Download*\n\n`;
                caption += `${getFileType(file.title)} *${file.title}*\n\n`;
                caption += `┌─ 📊 *Detail File*\n`;
                caption += `├ 📏 Ukuran: *${file.size}*\n`;
                caption += `├ 🏷️ Tipe Media: *${file.mediaType || 'Unknown'}*\n`;
                caption += `├ 🔧 API: *${result.api}*\n`;
                caption += `├ 🔗 Via: *${successUrl}*\n`;
                caption += `└ ✅ Status: *Downloaded*`;
                
                if (files.length > 1) {
                    caption += `\n\n📊 File ${i + 1} dari ${files.length}`;
                }
                
                const fileName = file.title.toLowerCase();
                const isImage = /\.(jpg|jpeg|png|gif|bmp|webp)$/i.test(fileName);
                const isVideo = /\.(mp4|mkv|avi|mov|wmv|flv|webm|m4v)$/i.test(fileName);
                
                let sendSuccess = false;
                
                try {
                    if (isImage) {
                        await conn.sendMessage(m.chat, {
                            image: buffer,
                            caption: caption
                        });
                        console.log(`   ✅ Sent as image`);
                        sendSuccess = true;
                    } else if (isVideo) {
                        await conn.sendMessage(m.chat, {
                            video: buffer,
                            mimetype: 'video/mp4',
                            caption: caption
                        });
                        console.log(`   ✅ Sent as video`);
                        sendSuccess = true;
                    } else {
                        await conn.sendMessage(m.chat, {
                            document: buffer,
                            mimetype: 'application/octet-stream',
                            fileName: file.title,
                            caption: caption
                        });
                        console.log(`   ✅ Sent as document`);
                        sendSuccess = true;
                    }
                } catch (sendError) {
                    console.log(`   ❌ Failed to send file: ${sendError.message}`);
                    sendSuccess = false;
                }
                
                if (!sendSuccess) {
                    console.log(`   📎 Sending download link as fallback...`);
                    
                    const shortDownloadUrl = await createShortUrl(file.downloadUrl || file.downloadUrl2);
                    
                    let linkCaption = `*📥 Terabox Download*\n\n`;
                    linkCaption += `${getFileType(file.title)} *${file.title}*\n\n`;
                    linkCaption += `┌─ 📊 *Detail File*\n`;
                    linkCaption += `├ 📏 Ukuran: *${file.size}*\n`;
                    linkCaption += `├ 🏷️ Tipe Media: *${file.mediaType || 'Unknown'}*\n`;
                    linkCaption += `├ 🔧 API: *${result.api}*\n`;
                    linkCaption += `└ ⚠️ Gagal upload, gunakan link di bawah\n\n`;
                    linkCaption += `🔗 *DOWNLOAD LINK:*\n`;
                    linkCaption += `${shortDownloadUrl || file.downloadUrl || file.downloadUrl2}`;
                    
                    if (files.length > 1) {
                        linkCaption += `\n\n📊 File ${i + 1} dari ${files.length}`;
                    }
                    
                    await conn.sendMessage(m.chat, { text: linkCaption });
                }
                
                if (sendSuccess) {
                    try {
                        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                    } catch (e) {
                        console.log('Gagal menambahkan reaksi sukses:', e);
                    }
                }
                
            } catch (fileError) {
                console.error(`❌ Error processing file ${i + 1}:`, fileError.message);
                
                try {
                    const shortDownloadUrl = await createShortUrl(file.downloadUrl || file.downloadUrl2);
                    
                    let errorMsg = `*❌ Error pada File ${i + 1}*\n\n`;
                    errorMsg += `${getFileType(file.title)} *${file.title}*\n\n`;
                    errorMsg += `┌─ 📊 *Informasi*\n`;
                    errorMsg += `├ 📏 Ukuran: *${file.size}*\n`;
                    errorMsg += `├ 🔧 API: *${result.api}*\n`;
                    errorMsg += `└ ⚠️ Error: ${fileError.message}\n\n`;
                    errorMsg += `🔗 *DOWNLOAD LINK:*\n`;
                    errorMsg += `${shortDownloadUrl || file.downloadUrl || file.downloadUrl2}`;
                    
                    if (files.length > 1) {
                        errorMsg += `\n\n📊 File ${i + 1} dari ${files.length}`;
                    }
                    
                    await conn.sendMessage(m.chat, { text: errorMsg });
                } catch (e) {
                    console.error(`Failed to send error message for file ${i + 1}:`, e);
                }
                
                continue;
            }
        }
        
        // Pesan selesai jika folder
        if (files.length > 1) {
            await conn.sendMessage(m.chat, { 
                text: `✅ *Selesai!*\n\nSemua ${files.length} file telah diproses.\n🔧 API: ${result.api}` 
            });
        }
        
    } catch (error) {
        console.error('Error downloading Terabox:', error);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
};

handler.help = ["tera"];
handler.tags = ["downloader"];
handler.command = ["tera"];

export default handler;