import fetch from 'node-fetch';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

console.log('[QR Generator Handler] Loading handler...');

// ========== CONFIGURATION ==========
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const TEMP_DIR = path.join(__dirname, '../tmp');
const MAX_TEXT_LENGTH = 2000; // Max karakter untuk QR code
const QR_API_URL = 'https://api.qrserver.com/v1/create-qr-code/';

// Pastikan temp directory ada
if (!fs.existsSync(TEMP_DIR)) {
    fs.mkdirSync(TEMP_DIR, { recursive: true });
}

// ========== QR GENERATION FUNCTIONS ==========
/**
 * Generate QR Code dari text
 * @param {string} text - Text untuk di-encode ke QR
 * @param {Object} options - Options untuk customization
 * @returns {Object} - Result object dengan buffer atau error
 */
async function generateQRCode(text, options = {}) {
    try {
        const {
            size = 500,
            color = '000000',
            bgcolor = 'ffffff',
            format = 'png'
        } = options;

        // Validasi text
        if (!text || text.trim().length === 0) {
            throw new Error('Text tidak boleh kosong!');
        }

        if (text.length > MAX_TEXT_LENGTH) {
            throw new Error(`Text terlalu panjang! Max ${MAX_TEXT_LENGTH} karakter`);
        }

        console.log('[QR Generator Handler] Generating QR code...');

        // Encode text untuk URL
        const encodedText = encodeURIComponent(text);
        
        // Build API URL
        const apiUrl = `${QR_API_URL}?data=${encodedText}&size=${size}x${size}&color=${color}&bgcolor=${bgcolor}&format=${format}`;

        // Fetch QR code dari API
        const response = await fetch(apiUrl);
        
        if (!response.ok) {
            throw new Error(`API Error: ${response.status} ${response.statusText}`);
        }

        const buffer = await response.buffer();
        
        console.log(`[QR Generator Handler] QR code generated, size: ${buffer.length} bytes`);

        return {
            success: true,
            buffer: buffer,
            size: buffer.length,
            format: format
        };

    } catch (error) {
        console.error('[QR Generator Handler] Generation failed:', error.message);
        return {
            success: false,
            message: error.message
        };
    }
}

// ========== FORMAT FUNCTIONS ==========
/**
 * Generate help message
 * @param {string} prefix - Command prefix
 * @param {string} cmd - Command name
 * @returns {string} - Help message
 */
function generateUsageHelp(prefix, cmd) {
    return `*📱 QR CODE GENERATOR*

📌 *Cara Penggunaan:*

*1. Generate QR Code:*
${prefix}${cmd} <text>

*Contoh:*
${prefix}${cmd} https://github.com
${prefix}${cmd} Halo, ini QR code saya!
${prefix}${cmd} +628123456789

📋 *Supported Content:*
- URL / Link
- Text biasa
- Nomor telepon
- Email
- WiFi credentials
- vCard contact
- Dan lainnya

⚙️ *Fitur:*
- High quality QR code (500x500px)
- Support semua jenis text
- Instant generation
- Mudah di-scan

⚠️ *Batasan:*
- Max text length: ${MAX_TEXT_LENGTH} karakter
- Format output: PNG

💡 *Tips:*
- Untuk WiFi: WIFI:S:<ssid>;T:<WPA/WEP>;P:<password>;;
- Untuk vCard: BEGIN:VCARD\\nVERSION:3.0\\nFN:Name...
- Untuk URL: Langsung paste link-nya

*Contoh Lainnya:*
${prefix}${cmd} WIFI:S:MyWiFi;T:WPA;P:password123;;
${prefix}${cmd} mailto:email@example.com
${prefix}${cmd} tel:+628123456789
`;
}

/**
 * Format ukuran file
 * @param {number} bytes - Ukuran dalam bytes
 * @returns {string} - Formatted size
 */
function formatSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

/**
 * Deteksi tipe content dari text
 * @param {string} text - Text input
 * @returns {string} - Tipe content
 */
function detectContentType(text) {
    if (/^https?:\/\//i.test(text)) return '🔗 URL/Link';
    if (/^tel:/i.test(text) || /^\+?\d{10,15}$/.test(text)) return '📞 Nomor Telepon';
    if (/^mailto:/i.test(text) || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(text)) return '📧 Email';
    if (/^WIFI:/i.test(text)) return '📶 WiFi Credentials';
    if (/^BEGIN:VCARD/i.test(text)) return '👤 vCard Contact';
    if (/^geo:/i.test(text)) return '📍 Lokasi/Koordinat';
    return '📝 Text';
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    // Deteksi prefix dan command
    let prefix = usedPrefix || '.';
    const cmd = command || 'qrcode';
    
    try {
        // Ambil input text
        let inputText = '';
        if (text) {
            inputText = text.trim();
        } else if (args && args.length > 0) {
            inputText = args.join(' ').trim();
        }
        
        // Cek apakah user minta help
        if (!inputText || inputText.toLowerCase() === 'help' || inputText === '?') {
            return m.reply(generateUsageHelp(prefix, cmd));
        }
        
        // React dengan emoji untuk menunjukkan proses dimulai
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        // ========== GENERATE QR CODE ==========
        console.log('[QR Generator Handler] Input text:', inputText.substring(0, 50) + '...');
        
        const result = await generateQRCode(inputText, {
            size: 500,
            color: '000000',
            bgcolor: 'ffffff',
            format: 'png'
        });
        
        if (!result.success) {
            console.error('[QR Generator Handler] Generation failed:', result.message);
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            
            let errorMsg = '❌ Gagal membuat QR code!\n\n';
            
            if (result.message.includes('kosong')) {
                errorMsg += '⚠️ Text tidak boleh kosong!\n💡 Contoh: ' + prefix + cmd + ' https://example.com';
            } else if (result.message.includes('terlalu panjang')) {
                errorMsg += `⚠️ Text terlalu panjang!\n💡 Max: ${MAX_TEXT_LENGTH} karakter`;
            } else {
                errorMsg += `⚠️ Error: ${result.message}`;
            }
            
            return m.reply(errorMsg);
        }
        
        // ========== SEND QR CODE IMAGE ==========
        console.log('[QR Generator Handler] Sending QR code...');
        
        try {
            // Deteksi tipe content
            const contentType = detectContentType(inputText);
            
            // Potong text jika terlalu panjang untuk caption
            let displayText = inputText;
            if (displayText.length > 100) {
                displayText = displayText.substring(0, 97) + '...';
            }
            
            // Buat caption
            const caption = `✅ *QR Code Generated!*\n\n` +
                          `📊 *Info:*\n` +
                          `├ 📋 Type: ${contentType}\n` +
                          `├ 📏 Size: ${formatSize(result.size)}\n` +
                          `├ 🔢 Length: ${inputText.length} karakter\n` +
                          `└ 📐 Resolution: 500x500px\n\n` +
                          `💬 *Content:*\n${displayText}\n\n` +
                          `💡 Scan QR code ini dengan kamera HP untuk akses langsung!`;
            
            // Kirim QR code sebagai gambar
            await conn.sendMessage(m.chat, {
                image: result.buffer,
                caption: caption
            }, { quoted: m });
            
            // React success
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            
            console.log('[QR Generator Handler] Success!');
            
        } catch (sendError) {
            console.error('[QR Generator Handler] Failed to send:', sendError);
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply('❌ Gagal mengirim QR code!\n💡 Coba lagi.');
        }
        
    } catch (error) {
        // Error handling
        console.error('[QR Generator Handler] CRITICAL ERROR:', error.message);
        console.error('[QR Generator Handler] Stack:', error.stack);
        
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        
        // Kirim pesan error singkat ke user
        return m.reply(`❌ Terjadi kesalahan!\n💡 Coba lagi atau ketik ${prefix}${cmd} help`);
    }
};

// ========== HANDLER PROPERTIES ==========
handler.help = ["qrcode <text>"];
handler.tags = ["tools"];
handler.command = ["qrcode", "qr", "makeqr", "generateqr"];
handler.limit = true;

console.log('[QR Generator Handler] Handler loaded successfully');

export default handler;