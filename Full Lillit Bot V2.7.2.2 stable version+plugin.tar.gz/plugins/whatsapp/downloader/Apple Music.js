import axios from 'axios';
import { createWriteStream, unlinkSync, existsSync } from 'fs';
import { pipeline } from 'stream/promises';
import path from 'path';
import os from 'os';

const AM_SEARCH = 'https://itunes.apple.com/search';
const AM_LOOKUP = 'https://itunes.apple.com/lookup';

async function searchAppleMusic(term, entity = 'song', limit = 5) {
  const { data } = await axios.get(AM_SEARCH, {
    params: { term, entity, limit, media: 'music' }
  });
  return data.results || [];
}

async function lookupById(id) {
  const { data } = await axios.get(AM_LOOKUP, { params: { id } });
  return data.results?.[0] || null;
}

async function downloadPreview(previewUrl, outputPath) {
  const response = await axios.get(previewUrl, { responseType: 'stream' });
  await pipeline(response.data, createWriteStream(outputPath));
}

function formatDuration(ms) {
  const mins = Math.floor(ms / 60000);
  const secs = Math.floor((ms % 60000) / 1000);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

function formatResults(results, type = 'song') {
  return results.map((r, i) => {
    if (type === 'song') {
      return `${i + 1}. 🎵 *${r.trackName}*\n    👤 ${r.artistName}\n    💿 ${r.collectionName}\n    ⏱ ${formatDuration(r.trackTimeMillis || 0)}\n    🆔 \`${r.trackId}\``;
    }
    if (type === 'album') {
      return `${i + 1}. 💿 *${r.collectionName}*\n    👤 ${r.artistName}\n    📅 ${r.releaseDate?.slice(0, 4) || '-'}\n    🎵 ${r.trackCount} tracks\n    🆔 \`${r.collectionId}\``;
    }
    return `${i + 1}. ${r.trackName || r.collectionName || 'Unknown'}`;
  }).join('\n\n');
}

const USAGE = `╭━━━『 🍎 *Apple Music* 』━━━╮
│
│  🎵 *Auto Search & Download:*
│  /am <judul lagu>
│
│  🔍 *Cari (tampilkan daftar):*
│  /am search <judul>
│
│  📥 *Download by ID:*
│  /am song <ID>
│
│  💿 *Cari Album:*
│  /am album <nama>
│
│  ⚠️ Preview 30 detik (Apple DRM)
│
╰━━━━━━━━━━━━━━━━━━━━╯`;

async function searchAndDownload(m, conn, query) {
  const results = await searchAppleMusic(query, 'song', 5);
  if (!results.length) return m.reply('❌ Lagu tidak ditemukan.');

  const track = results[0];

  if (!track.previewUrl) {
    return m.reply(
      `⚠️ Preview tidak tersedia.\n\n` +
      `🎵 *${track.trackName}*\n` +
      `👤 ${track.artistName}\n` +
      `💿 ${track.collectionName}`
    );
  }

  const caption =
    `🍎 *Apple Music Preview*\n\n` +
    `🎵 *${track.trackName}*\n` +
    `👤 ${track.artistName}\n` +
    `💿 ${track.collectionName}\n` +
    `📅 ${track.releaseDate?.slice(0, 4) || '-'}\n` +
    `⏱ ${formatDuration(track.trackTimeMillis || 0)}\n` +
    `🎼 ${track.primaryGenreName || '-'}\n\n` +
    `⚠️ _Preview 30 detik (Apple DRM)_`;

  const tmpFile = path.join(os.tmpdir(), `am_${Date.now()}.m4a`);
  await downloadPreview(track.previewUrl, tmpFile);

  await conn.sendMessage(m.chat, {
    audio: { url: tmpFile },
    mimetype: 'audio/mp4',
    fileName: `${track.trackName} - ${track.artistName}.m4a`,
    ptt: false,
    caption
  }, { quoted: m });

  if (existsSync(tmpFile)) unlinkSync(tmpFile);
}

let handler = async (m, { conn, command }) => {
  try {
    // Ambil query dari m.body, strip prefix + command di depan
    const rawBody = (m.body || m.text || '').trim();
    const input = rawBody.replace(/^[./!~]\S+\s*/, '').trim();

    if (!input) return m.reply(USAGE);

    const spaceIdx = input.indexOf(' ');
    const sub = spaceIdx === -1 ? input.toLowerCase() : input.slice(0, spaceIdx).toLowerCase();
    const query = spaceIdx === -1 ? '' : input.slice(spaceIdx + 1).trim();

    if (sub === 'search' || sub === 'cari') {
      if (!query) return m.reply('❌ Masukkan judul lagu.\nContoh: `.am search Blinding Lights`');
      await conn.sendMessage(m.chat, { text: `🔍 Mencari: _${query}_...` }, { quoted: m });
      const results = await searchAppleMusic(query, 'song', 5);
      if (!results.length) return m.reply('❌ Lagu tidak ditemukan.');
      await conn.sendMessage(m.chat, {
        text:
          `╭━━━『 🔍 Hasil Pencarian 』━━━╮\n\n` +
          formatResults(results, 'song') +
          `\n\n╰━━━━━━━━━━━━━━━━━━━━╯\n\n` +
          `💡 Download: \`.am song <ID>\``
      }, { quoted: m });
    }

    else if (sub === 'song' || sub === 'lagu') {
      if (!query || isNaN(query)) return m.reply('❌ ID tidak valid.\nContoh: `.am song 1440818499`');
      await m.reply('⏳ Mengambil info lagu...');
      const track = await lookupById(query);
      if (!track || track.kind !== 'song') return m.reply('❌ Lagu tidak ditemukan.');
      if (!track.previewUrl) return m.reply('❌ Preview tidak tersedia untuk lagu ini.');
      const caption =
        `🍎 *Apple Music Preview*\n\n` +
        `🎵 *${track.trackName}*\n` +
        `👤 ${track.artistName}\n` +
        `💿 ${track.collectionName}\n` +
        `📅 ${track.releaseDate?.slice(0, 4) || '-'}\n` +
        `⏱ ${formatDuration(track.trackTimeMillis || 0)}\n` +
        `🎼 ${track.primaryGenreName || '-'}\n\n` +
        `⚠️ _Preview 30 detik (Apple DRM)_`;
      const tmpFile = path.join(os.tmpdir(), `am_${Date.now()}.m4a`);
      await downloadPreview(track.previewUrl, tmpFile);
      await conn.sendMessage(m.chat, {
        audio: { url: tmpFile },
        mimetype: 'audio/mp4',
        fileName: `${track.trackName} - ${track.artistName}.m4a`,
        ptt: false,
        caption
      }, { quoted: m });
      if (existsSync(tmpFile)) unlinkSync(tmpFile);
    }

    else if (sub === 'album') {
      if (!query) return m.reply('❌ Masukkan nama album.\nContoh: `.am album After Hours`');
      await conn.sendMessage(m.chat, { text: `🔍 Mencari album: _${query}_...` }, { quoted: m });
      const results = await searchAppleMusic(query, 'album', 5);
      if (!results.length) return m.reply('❌ Album tidak ditemukan.');
      await conn.sendMessage(m.chat, {
        text:
          `╭━━━『 💿 Hasil Album 』━━━╮\n\n` +
          formatResults(results, 'album') +
          `\n\n╰━━━━━━━━━━━━━━━━━━━━╯`
      }, { quoted: m });
    }

    else {
      // Default: seluruh input = query, langsung search & download
      await searchAndDownload(m, conn, input);
    }

  } catch (e) {
    console.error('[applemusic]', e);
    m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ['applemusic <judul>', 'am <judul>'];
handler.tags = ['downloader'];
handler.command = ['applemusic', 'amusic', 'am'];

export default handler;