const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

// ─── Validators ───────────────────────────────────────────────────────────────

function isValidFacebookUrl(url) {
    return /facebook\.com|fb\.watch/i.test(url);
}

function extractFacebookUrls(text) {
    const matches = text.match(/(https?:\/\/)?(www\.)?(m\.)?(facebook\.com|fb\.watch)\/[^\s]+/gi) || [];
    return [...new Set(matches)];
}

function normalizeUrl(url) {
    return url.startsWith('http') ? url : 'https://' + url;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function randomDelay(min = 1000, max = 3000) {
    return new Promise(r => setTimeout(r, Math.floor(Math.random() * (max - min)) + min));
}

function formatDuration(s) {
    s = Number(s) || 0;
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
    if (h > 0) return `${h}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`;
    return `${m}:${String(sec).padStart(2,'0')}`;
}

function decodeHtml(str) {
    if (!str) return str;
    return str
        .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"').replace(/&#039;/g, "'").replace(/&apos;/g, "'");
}

async function downloadBuffer(url, type = 'file') {
    try {
        const res = await fetch(url, {
            timeout: 60000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
                'Accept': '*/*',
                // Required for fbcdn.net video/thumbnail URLs — without Referer they return 403
                'Referer': 'https://www.facebook.com/',
            }
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return Buffer.from(await res.arrayBuffer());
    } catch (e) {
        console.error(`⚠️  Failed to download ${type}:`, e.message);
        return null;
    }
}

// ─── Build URL variants to try ───────────────────────────────────────────────

/**
 * For share URLs like /share/v/SHORTCODE, Facebook requires a browser session
 * to redirect. Instead, we generate all plausible URL variants to try directly.
 * The short code itself is a base64-like token — we cannot decode it without FB,
 * so we expand the variant list to maximize scrape success.
 */
function buildUrlVariants(url) {
    const variants = new Set();

    // Always include original + www normalized
    variants.add(url);
    variants.add(url.replace(/^https?:\/\/(m\.|www\.)?facebook\.com/, 'https://www.facebook.com'));

    // For share/v/ — try with different query params that sometimes bypass gating
    if (/\/share\/v\//i.test(url)) {
        const base = url.replace(/^https?:\/\/(m\.|www\.)?facebook\.com/, 'https://www.facebook.com').replace(/\/$/, '');
        variants.add(`${base}/?_rdr=p`);
        variants.add(`${base}/?ref=sharing`);
        // mbasic tends to return simpler HTML with more data exposed
        variants.add(url.replace(/^https?:\/\/(m\.|www\.)?facebook\.com/, 'https://mbasic.facebook.com'));
    }

    // fb.watch short URL — mbasic variant
    if (/fb\.watch/i.test(url)) {
        variants.add(url.replace(/^https?:\/\/fb\.watch/, 'https://www.facebook.com/watch'));
    }

    return [...variants];
}

// ─── Core: oEmbed + Meta scraping ────────────────────────────────────────────

async function getFacebookVideo(url) {
    // Step 1: Facebook oEmbed
    let oembedData = {};
    try {
        const oembedUrl = `https://www.facebook.com/plugins/video/oembed.json/?url=${encodeURIComponent(url)}`;
        const res = await fetch(oembedUrl, {
            timeout: 15000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'application/json',
            }
        });
        if (res.ok) {
            const json = await res.json();
            oembedData = {
                title:     json.title      || null,
                author:    json.author_name || null,
                thumbnail: json.thumbnail_url || null,
                html:      json.html        || null,
            };
            console.log('✅ oEmbed OK:', oembedData.title);
        }
    } catch (e) {
        console.log('⚠️  oEmbed failed:', e.message);
    }

    // Step 2: Scrape video URL from page HTML
    let videoUrl = null, sdUrl = null, hdUrl = null;
    let metaTitle = null, metaThumb = null, metaDuration = null;
    let metaViews = null, metaReactions = null, metaAuthor = null, metaDescription = null;

    // UA list — ordered by most likely to succeed
    const uaList = [
        // mbasic-friendly desktop
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        // older Chrome — sometimes bypasses newer bot checks
        'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.71 Safari/537.36',
        // Mobile Android
        'Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
        // Safari macOS
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15',
    ];

    const urlVariants = buildUrlVariants(url);
    console.log(`🔗 Trying ${urlVariants.length} URL variants:`, urlVariants);

    outer:
    for (const ua of uaList) {
        for (const u of urlVariants) {
            try {
                const res = await fetch(u, {
                    timeout: 20000,
                    redirect: 'follow',
                    follow: 10,
                    headers: {
                        'User-Agent': ua,
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                        'Accept-Language': 'en-US,en;q=0.9',
                        'Accept-Encoding': 'gzip, deflate, br',
                        'Connection': 'keep-alive',
                        'Upgrade-Insecure-Requests': '1',
                        'Sec-Fetch-Dest': 'document',
                        'Sec-Fetch-Mode': 'navigate',
                        'Sec-Fetch-Site': 'none',
                        'Sec-Fetch-User': '?1',
                        // Fake referer — makes request look organic
                        'Referer': 'https://www.facebook.com/',
                    }
                });

                if (!res.ok) {
                    console.log(`⚠️  HTTP ${res.status} for ${u.slice(0,60)}`);
                    continue;
                }

                // If redirected to a proper reel/video/watch URL, log it
                if (res.url !== u) console.log(`🔀 Redirected: ${u.slice(0,50)} → ${res.url.slice(0,60)}`);

                const html = await res.text();

                // Skip error pages
                if (/<title>\s*(Error|Something went wrong)/i.test(html)) {
                    console.log(`⚠️  Error page for ${u.slice(0,60)}`);
                    continue;
                }

                const clean = s => {
                    if (!s) return null;
                    let r = decodeHtml(s)
                        .replace(/\\\//g, '/')
                        .replace(/\\u([0-9a-fA-F]{4})/g, (_, c) => String.fromCharCode(parseInt(c, 16)));
                    if (r.includes('lookaside.fbsbx.com/lookaside/crawler')) return null;
                    if (!r.includes('fbcdn.net') && !r.includes('facebook.com/video')) return null;
                    return r;
                };

                const allPlayable   = [...html.matchAll(/"playable_url"\s*:\s*"([^"]+)"/g)].map(m => clean(m[1])).filter(Boolean);
                const allPlayableHD = [...html.matchAll(/"playable_url_quality_hd"\s*:\s*"([^"]+)"/g)].map(m => clean(m[1])).filter(Boolean);
                const allSdSrc      = [...html.matchAll(/sd_src(?:_no_ratelimit)?\s*:\s*"([^"]+)"/g)].map(m => clean(m[1])).filter(Boolean);
                const allHdSrc      = [...html.matchAll(/hd_src(?:_no_ratelimit)?\s*:\s*"([^"]+)"/g)].map(m => clean(m[1])).filter(Boolean);
                const allNativeSd   = [...html.matchAll(/"browser_native_sd_url"\s*:\s*"([^"]+)"/g)].map(m => clean(m[1])).filter(Boolean);
                const allNativeHd   = [...html.matchAll(/"browser_native_hd_url"\s*:\s*"([^"]+)"/g)].map(m => clean(m[1])).filter(Boolean);

                sdUrl = allSdSrc[0] || allNativeSd[0] || allPlayable[0] || null;
                hdUrl = allHdSrc[0] || allNativeHd[0] || allPlayableHD[0] || null;
                videoUrl = sdUrl || hdUrl;

                metaTitle       = decodeHtml(html.match(/<meta property="og:title" content="([^"]+)"/)?.[1] || '') || null;
                metaThumb       = html.match(/<meta property="og:image" content="([^"]+)"/)?.[1] || null;
                metaDescription = decodeHtml(html.match(/<meta property="og:description" content="([^"]+)"/)?.[1] || '') || null;

                const durRaw = html.match(/<meta property="video:duration" content="(\d+)"/)?.[1] ||
                               html.match(/"playable_duration_in_ms"\s*:\s*(\d+)/)?.[1] ||
                               html.match(/"duration"\s*:\s*(\d+)/)?.[1];
                if (durRaw) metaDuration = durRaw.length > 5 ? Math.floor(+durRaw / 1000) : +durRaw;

                if (metaTitle) {
                    const tm = metaTitle.match(/^(.+?)\s*\|\s*(.+?)(?:\s*\|\s*([^|]+))?$/s);
                    if (tm) {
                        const stats = tm[1];
                        metaTitle  = tm[2].trim();
                        metaAuthor = tm[3]?.trim() || null;
                        metaViews     = stats.match(/([\d.]+[KMB]?)\s*views?/i)?.[1]?.concat(' views') || null;
                        metaReactions = stats.match(/([\d.]+[KMB]?)\s*reactions?/i)?.[1]?.concat(' reactions') || null;
                    }
                }

                if (videoUrl) {
                    console.log(`✅ Video URL found [${u.slice(0,50)}] UA: ${ua.slice(0,30)}`);
                    console.log(`📺 SD: ${sdUrl?.slice(0, 100)}`);
                    console.log(`📺 HD: ${hdUrl?.slice(0, 100)}`);
                    break outer;
                } else {
                    console.log(`⚠️  No video URL in HTML for ${u.slice(0,60)}`);
                }

            } catch (e) {
                console.log(`⚠️  Scrape failed [${u.slice(0,40)}]: ${e.message}`);
            }
        }
    }

    if (!videoUrl) throw new Error('URL video tidak ditemukan. Video mungkin private atau memerlukan login.');

    return {
        sd_url:    sdUrl,
        hd_url:    hdUrl,
        video_url: videoUrl,
        source:    'oEmbed+Meta',
        extra: {
            title:       oembedData.title || metaTitle || 'Facebook Video',
            author:      oembedData.author || metaAuthor || null,
            thumbnail:   oembedData.thumbnail || metaThumb || null,
            duration:    metaDuration,
            views:       metaViews,
            reactions:   metaReactions,
            description: metaDescription,
        }
    };
}

// ─── Caption Builder ──────────────────────────────────────────────────────────

function buildCaption(data, index = null, total = null) {
    const d = data.extra;
    let cap = '';
    if (index && total) cap += `🎬 *Video ${index}/${total}*\n\n`;
    if (d.title && d.title !== 'Facebook Video') cap += `📝 *${d.title}*\n`;
    if (d.author)       cap += `👤 ${d.author}\n`;
    if (d.duration)     cap += `⏱ ${formatDuration(d.duration)}\n`;
    if (d.views)        cap += `👁 ${d.views}`;
    if (d.reactions)    cap += `  ❤️ ${d.reactions}`;
    if (d.views || d.reactions) cap += '\n';
    if (d.description && d.description !== d.title) {
        const desc = d.description.length > 120 ? d.description.slice(0, 120) + '...' : d.description;
        cap += `\n💬 ${desc}\n`;
    }
    cap += `\n📺 ${data.hd_url ? 'HD' : 'SD'}`;
    return cap.trim();
}

// ─── Handler ──────────────────────────────────────────────────────────────────

const HELP_MSG = (p, c) => `
*📥 Facebook Downloader*
_oEmbed + Meta — No 3rd party API_

*Penggunaan:*
${p}${c} <url>

*Bulk:*
${p}${c} <url1> <url2> ...

*Contoh:*
${p}${c} https://www.facebook.com/reel/123456
${p}${c} https://www.facebook.com/watch?v=123456
${p}${c} https://fb.watch/abcXYZ
${p}${c} https://www.facebook.com/share/v/abcXYZ

✅ Videos, Reels, Watch, fb.watch, Share links
📺 Auto SD/HD | Bulk download
`.trim();

let handler = async (m, { conn, args, usedPrefix, command }) => {
    const input  = args?.join(' ').trim() || '';
    const prefix = usedPrefix || m.text?.match(/^([.!#/])/)?.[1] || '.';
    const cmd    = command || 'fb';

    if (!input) return m.reply(HELP_MSG(prefix, cmd));

    const urls = extractFacebookUrls(input).filter(isValidFacebookUrl);
    if (!urls.length)
        return m.reply('❌ URL Facebook tidak valid.\n\nContoh:\n• https://www.facebook.com/reel/123456\n• https://fb.watch/abcXYZ\n• https://www.facebook.com/share/v/abcXYZ');

    const isBulk = urls.length > 1;
    if (isBulk) await m.reply(`📥 *Bulk Download Facebook*\n🎬 Memproses *${urls.length} video*...\n⏳ Mohon tunggu.`);

    let ok = 0, fail = 0;

    for (let i = 0; i < urls.length; i++) {
        const url = normalizeUrl(urls[i]);

        // React ⏳ BEFORE starting async work — not inside try/catch
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        try {
            const data = await getFacebookVideo(url);
            const bestVideoUrl = data.sd_url || data.hd_url || data.video_url;
            console.log(`⬇️  Downloading: ${bestVideoUrl?.slice(0, 100)}`);

            const [videoBuf, thumbBuf] = await Promise.all([
                downloadBuffer(bestVideoUrl, 'video'),
                data.extra.thumbnail ? downloadBuffer(data.extra.thumbnail, 'thumbnail') : Promise.resolve(null),
            ]);

            if (!videoBuf) throw new Error('Gagal mendownload buffer video');
            console.log(`📦 Buffer size: ${(videoBuf.length / 1024).toFixed(1)} KB`);

            const caption = buildCaption(data, isBulk ? i + 1 : null, isBulk ? urls.length : null);

            await conn.sendMessage(m.chat, {
                video: videoBuf,
                jpegThumbnail: thumbBuf ?? undefined,
                mimetype: 'video/mp4',
                caption,
            }, { quoted: m });

            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            ok++;

        } catch (e) {
            console.error(`❌ FB Error [${i + 1}]:`, e.message);
            fail++;
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            if (!isBulk)
                return m.reply(`❌ Gagal download video Facebook.\n*Error:* ${e.message}\n\n💡 Pastikan video bersifat publik.`);
        }

        if (isBulk && i < urls.length - 1) await randomDelay(2000, 4000);
    }

    if (isBulk)
        await m.reply(`📊 *Selesai*\n✅ Berhasil : ${ok}/${urls.length}\n❌ Gagal    : ${fail}/${urls.length}`);
};

handler.help    = ['fb', 'facebook', 'fbdl'];
handler.tags    = ['downloader'];
handler.command = ['fb', 'facebook', 'fbdl'];

export default handler;