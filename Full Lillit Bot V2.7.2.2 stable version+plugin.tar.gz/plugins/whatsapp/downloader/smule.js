const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));
import * as cheerio from 'cheerio';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

console.log('[Smule Handler] Loading handler...');

// ========== SMULE DOWNLOAD HANDLER ==========
const SMULE_BASE_URL = 'https://sownloader.com/index.php?url=';
const SMULE_DOWNLOADER_URL = 'https://sownloader.com';

const TIMEOUT_MS = 30000; // 30 detik timeout untuk download
const CONVERSION_TIMEOUT_MS = 90000; // 90 detik untuk download MP3
const AUTO_DELETE_TIMEOUT = 60 * 60 * 1000; // 1 jam (3600000 ms)

const DOWNLOAD_DIR = './downloads/smule/';

// Map untuk menyimpan reference timeout setiap file
const deleteTimeoutMap = new Map();

function validateSmuleUrl(url) {
    // Format: https://www.smule.com/recording/...
    return url.includes('smule.com/recording/') || url.includes('smule.com/sing-recording/');
}

async function fetchSmuleData(smuleUrl) {
    console.log(`[Smule Handler] Attempting to fetch data for URL: ${smuleUrl}`);
    
    try {
        const targetUrl = `${SMULE_BASE_URL}${encodeURIComponent(smuleUrl)}`;
        console.log(`[Smule Handler] Scraping: ${targetUrl}`);
        
        const fetchPromise = fetch(targetUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': 'text/html',
            }
        });
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error(`Timeout setelah ${TIMEOUT_MS}ms`)), TIMEOUT_MS)
        );
        
        const response = await Promise.race([fetchPromise, timeoutPromise]);
        
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status}`);
        }
        
        const html = await response.text();
        const $ = cheerio.load(html);
        
        // Extract metadata
        const title = $("h4 a").first().text().trim();
        const smule_link = $("h4 a").attr("href");
        const thumbnail = $(".sownloader-web-thumbnail").attr("src");
        const description = $(".sownloader-web-thumbnail")
            .closest(".row")
            .find("p")
            .first()
            .text()
            .trim();
        
        // Extract audio M4A link
        let audio_m4a = $("a.btn[href*='.m4a']").attr("href");
        if (audio_m4a && audio_m4a.startsWith("/")) {
            audio_m4a = SMULE_DOWNLOADER_URL + audio_m4a;
        }
        
        // Extract MP3 conversion link
        let audio_mp3 = $("button.btn:contains('Download as MP3')").attr("onclick");
        if (audio_mp3) {
            const match = audio_mp3.match(/'(https?:\/\/[^']+\.m4a)'/);
            if (match) {
                audio_mp3 = `${SMULE_DOWNLOADER_URL}/system/modules/downloader.php?url=` +
                    encodeURIComponent(match[1]) +
                    `&name=${encodeURIComponent(title)}&ext=mp3`;
            }
        }
        
        // Extract video MP4 link
        let video_mp4 = $("a.btn[href*='.mp4']").attr("href");
        if (video_mp4 && video_mp4.startsWith("/")) {
            video_mp4 = SMULE_DOWNLOADER_URL + video_mp4;
        }
        
        if (!title || !audio_m4a) {
            throw new Error('Data tidak lengkap, mungkin URL tidak valid');
        }
        
        console.log(`[Smule Handler] ✅ Data found: ${title}`);
        
        return {
            status: true,
            metadata: {
                title,
                smule_link,
                thumbnail,
                description
            },
            audio: {
                m4a: audio_m4a,
                mp3: audio_mp3
            },
            video: {
                mp4: video_mp4
            }
        };
        
    } catch (error) {
        console.error(`[Smule Handler] ❌ Scraping failed:`, error.message);
        throw new Error(`Gagal mengambil data Smule. Error: ${error.message}`);
    }
}

async function downloadFile(url, format = 'm4a', retries = 5) {
    console.log(`[Smule Handler] Downloading ${format} from: ${url}`);
    
    for (let attempt = 1; attempt <= retries; attempt++) {
        try {
            // Untuk MP3, tunggu dengan increasing delay
            if (format === 'mp3') {
                let waitTime;
                if (attempt === 1) {
                    waitTime = 30000; // 30 detik pertama
                } else if (attempt === 2) {
                    waitTime = 40000; // 40 detik kedua
                } else {
                    waitTime = 30000; // 30 detik berikutnya
                }
                
                console.log(`[Smule Handler] Waiting for MP3 conversion... (${waitTime / 1000} seconds) - Attempt ${attempt}/${retries}`);
                await new Promise(resolve => setTimeout(resolve, waitTime));
            }
            
            const timeout = format === 'mp3' ? CONVERSION_TIMEOUT_MS : TIMEOUT_MS;
            
            const fetchPromise = fetch(url);
            const timeoutPromise = new Promise((_, reject) => 
                setTimeout(() => reject(new Error(`Timeout download ${format}`)), timeout)
            );
            
            const response = await Promise.race([fetchPromise, timeoutPromise]);
            
            if (!response.ok) {
                throw new Error(`HTTP Error: ${response.status}`);
            }
            
            const contentLength = response.headers.get('content-length');
            const arrayBuffer = await response.arrayBuffer();
            const buffer = Buffer.from(arrayBuffer);
            
            // Check if file is empty or too small (likely failed conversion)
            if (buffer.length < 1000) {
                console.log(`[Smule Handler] ⚠️ File too small (${buffer.length} bytes), attempt ${attempt}/${retries}`);
                
                if (attempt < retries) {
                    console.log(`[Smule Handler] Will retry after waiting...`);
                    continue;
                }
                
                throw new Error('File konversi gagal atau kosong setelah beberapa kali percobaan');
            }
            
            const sizeInfo = contentLength ? `${contentLength} bytes` : `${buffer.length} bytes`;
            console.log(`[Smule Handler] ✅ File found, size: ${sizeInfo}`);
            
            return { buffer, size: contentLength || buffer.length };
            
        } catch (error) {
            console.error(`[Smule Handler] ❌ Download attempt ${attempt} failed:`, error.message);
            
            if (attempt === retries) {
                throw new Error(`Gagal mengunduh file ${format} setelah ${retries} percobaan. Error: ${error.message}`);
            }
            
            if (!error.message.includes('too small')) {
                console.log(`[Smule Handler] Error occurred, will retry...`);
            }
        }
    }
}

function ensureDownloadDir() {
    try {
        if (!fs.existsSync(DOWNLOAD_DIR)) {
            fs.mkdirSync(DOWNLOAD_DIR, { recursive: true });
            console.log(`[Smule Handler] Download directory created: ${DOWNLOAD_DIR}`);
        }
    } catch (error) {
        console.error(`[Smule Handler] Failed to create download directory:`, error.message);
    }
}

function scheduleFileDelete(filePath, fileId) {
    // Clear timeout lama jika ada
    if (deleteTimeoutMap.has(fileId)) {
        clearTimeout(deleteTimeoutMap.get(fileId));
    }
    
    // Set timeout baru untuk delete file
    const timeoutId = setTimeout(() => {
        try {
            if (fs.existsSync(filePath)) {
                fs.unlinkSync(filePath);
                console.log(`[Smule Handler] ✅ Auto-deleted: ${filePath} (setelah ${AUTO_DELETE_TIMEOUT / 1000 / 60} menit)`);
                deleteTimeoutMap.delete(fileId);
            }
        } catch (error) {
            console.error(`[Smule Handler] ❌ Failed to delete file ${filePath}:`, error.message);
        }
    }, AUTO_DELETE_TIMEOUT);
    
    // Simpan reference timeout
    deleteTimeoutMap.set(fileId, timeoutId);
    
    console.log(`[Smule Handler] ⏰ File akan dihapus otomatis dalam ${AUTO_DELETE_TIMEOUT / 1000 / 60} menit`);
}

function sanitizeFilename(filename) {
    // Remove invalid characters for filenames and decode HTML entities
    return filename
        .replace(/&amp;/g, '&')
        .replace(/&quot;/g, '"')
        .replace(/&#039;/g, "'")
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/[<>:"/\\|?*]/g, '_')
        .substring(0, 100);
}

function generateUsageHelp(prefix, cmd) {
    return `*🎤 SMULE DOWNLOADER*

📌 *Cara Penggunaan:*
${prefix}${cmd} <URL Smule> [format]

📋 *Format yang Tersedia:*
• M4A (default): ${prefix}${cmd} <url>
• MP3: ${prefix}${cmd} <url> mp3
• Video MP4: ${prefix}${cmd} <url> video

📝 *Contoh:*
${prefix}${cmd} https://www.smule.com/recording/...
${prefix}${cmd} https://www.smule.com/recording/... mp3
${prefix}${cmd} https://www.smule.com/recording/... video

⏰ *Info:* File akan dihapus otomatis setelah 1 jam`;
}

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    let prefix = usedPrefix;
    if (!prefix && m.text) {
        const match = m.text.match(/^([.!#/])/);
        prefix = match ? match[1] : '.';
    }
    prefix = prefix || '.';
    
    const cmd = command || 'smule';
    
    // Parse text dan args
    let fullText = '';
    if (text) {
        fullText = text.trim();
    } else if (args && args.length > 0) {
        fullText = args.join(' ').trim();
    }
    
    console.log(`[Smule Handler] Command triggered - prefix: ${prefix}, cmd: ${cmd}, text: ${fullText}`);
    console.log(`[Smule Handler] Raw args:`, args);
    
    // Help command
    if (!fullText || fullText.toLowerCase() === 'help' || fullText === '?') {
        console.log('[Smule Handler] Help requested');
        return m.reply(generateUsageHelp(prefix, cmd));
    }
    
    // Parse input: URL dan format
    // Split by whitespace to get URL and format
    const parts = fullText.split(/\s+/).filter(p => p.length > 0);
    const smuleUrl = parts[0];
    const formatArg = parts.length > 1 ? parts[1].toLowerCase() : 'm4a';
    
    console.log(`[Smule Handler] Parsed URL: ${smuleUrl}`);
    console.log(`[Smule Handler] Parsed format arg: ${formatArg}`);
    
    // Normalize format argument
    let format;
    if (formatArg === 'mp3' || formatArg === 'audio' || formatArg === 'a') {
        format = 'mp3';
    } else if (formatArg === 'video' || formatArg === 'v' || formatArg === 'mp4') {
        format = 'video';
    } else {
        format = 'm4a'; // default
    }
    
    console.log(`[Smule Handler] Final format: ${format}`);
    
    // Validate URL
    if (!validateSmuleUrl(smuleUrl)) {
        return m.reply(`❌ URL Smule tidak valid!\n\n💡 Contoh URL yang benar:\nhttps://www.smule.com/recording/...\n\n📌 Ketik ${prefix}${cmd} help untuk panduan lengkap`);
    }
    
    console.log('[Smule Handler] Valid Smule URL:', smuleUrl);
    
    try {
        // Send initial reaction
        await conn.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });
        
        // Fetch Smule data
        console.log('[Smule Handler] Fetching Smule data...');
        const smuleData = await fetchSmuleData(smuleUrl);
        
        if (!smuleData.status) {
            throw new Error(smuleData.msg || 'Gagal mengambil data Smule');
        }
        
        // Send info with format
        let infoMsg = `*🎤 SMULE DOWNLOADER*\n\n`;
        infoMsg += `📌 *Judul:* ${smuleData.metadata.title}\n`;
        if (smuleData.metadata.description) {
            infoMsg += `📝 *Deskripsi:* ${smuleData.metadata.description}\n`;
        }
        infoMsg += `📦 *Format:* ${format.toUpperCase()}\n`;
        
        if (format === 'mp3') {
            infoMsg += `\n⏳ Mengkonversi ke MP3... (mohon tunggu 2-4 menit)\n💡 Proses konversi memakan waktu, harap bersabar`;
        } else {
            infoMsg += `\n⏳ Mengunduh file...`;
        }
        
        await m.reply(infoMsg);
        
        // Determine download URL and file extension
        let downloadUrl, fileExt, mimetype;
        
        if (format === 'mp3' && smuleData.audio.mp3) {
            downloadUrl = smuleData.audio.mp3;
            fileExt = 'mp3';
            mimetype = 'audio/mpeg';
        } else if (format === 'video' && smuleData.video.mp4) {
            downloadUrl = smuleData.video.mp4;
            fileExt = 'mp4';
            mimetype = 'video/mp4';
        } else if (smuleData.audio.m4a) {
            downloadUrl = smuleData.audio.m4a;
            fileExt = 'm4a';
            mimetype = 'audio/mp4';
        } else {
            throw new Error('Format yang diminta tidak tersedia');
        }
        
        console.log(`[Smule Handler] Downloading ${fileExt} file...`);
        
        // Download file
        const fileData = await downloadFile(downloadUrl, fileExt);
        
        // Ensure download directory exists
        ensureDownloadDir();
        
        // Save to file
        const sanitizedTitle = sanitizeFilename(smuleData.metadata.title);
        const fileName = `${sanitizedTitle}_${Date.now()}.${fileExt}`;
        const filePath = path.join(DOWNLOAD_DIR, fileName);
        
        fs.writeFileSync(filePath, fileData.buffer);
        console.log(`[Smule Handler] File saved to: ${filePath}`);
        
        // Schedule auto delete
        scheduleFileDelete(filePath, fileName);
        
        // Send file
        console.log('[Smule Handler] Sending file to chat...');
        
        if (fileExt === 'mp4') {
            // Send as video
            await conn.sendMessage(m.chat, {
                video: { url: filePath },
                mimetype: mimetype,
                caption: `🎤 *${smuleData.metadata.title}*\n\n📥 Downloaded from Smule`,
                fileName: fileName
            }, { quoted: m });
        } else {
            // Send as audio
            await conn.sendMessage(m.chat, {
                audio: { url: filePath },
                mimetype: mimetype,
                ptt: false,
                fileName: fileName
            }, { quoted: m });
        }
        
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
        console.log('[Smule Handler] Download completed successfully');
        
    } catch (error) {
        console.error('[Smule Handler] ERROR:', error);
        console.error('[Smule Handler] Stack:', error.stack);
        
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        
        let errorMsg = '❌ Terjadi kesalahan saat mengunduh dari Smule.\n\n';
        
        if (error.message.includes('Timeout')) {
            const timeoutSec = error.message.includes('mp3') ? 60 : 30;
            errorMsg += `⚠️ Timeout: Server tidak merespons dalam ${timeoutSec} detik\n💡 Coba lagi dalam beberapa saat`;
        } else if (error.message.includes('404') || error.message.includes('tidak valid')) {
            errorMsg += '⚠️ URL tidak ditemukan atau tidak valid\n💡 Pastikan URL Smule benar';
        } else if (error.message.includes('kosong') || error.message.includes('percobaan')) {
            errorMsg += '⚠️ Konversi MP3 gagal atau timeout\n💡 Coba gunakan format M4A atau coba lagi nanti';
        } else if (error.message.includes('tidak tersedia')) {
            errorMsg += '⚠️ Format yang diminta tidak tersedia\n💡 Coba format lain (audio/mp3/video)';
        } else if (error.message.includes('Data tidak lengkap')) {
            errorMsg += '⚠️ Data tidak dapat diambil dari URL ini\n💡 URL mungkin tidak valid atau recording sudah dihapus';
        } else {
            errorMsg += `⚠️ Error: ${error.message}\n💡 Coba lagi atau ketik ${prefix}${cmd} help`;
        }
        
        return m.reply(errorMsg);
    }
};

handler.help = ["smule <url> [format]"];
handler.tags = ["downloader", "tools"];
handler.command = ["smule", "smuledl"];
handler.limit = true;

console.log('[Smule Handler] Handler loaded successfully');

export default handler;