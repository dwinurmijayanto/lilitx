const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

// ─── Validators ───────────────────────────────────────────────────────────────

function isValidMediafireUrl(url) {
    return /mediafire\.com\/(file|download)\/[a-zA-Z0-9]+/i.test(url);
}

function extractMediafireUrls(text) {
    const matches = text.match(/(https?:\/\/)?(www\.)?mediafire\.com\/(file|download)\/[a-zA-Z0-9/?.=&%_-]+/gi) || [];
    return [...new Set(matches)];
}

function normalizeUrl(url) {
    if (!url.startsWith('http')) url = 'https://' + url;
    return url;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function randomDelay(min = 1000, max = 3000) {
    return new Promise(r => setTimeout(r, Math.floor(Math.random() * (max - min)) + min));
}

function formatSize(bytes) {
    bytes = Number(bytes) || 0;
    if (bytes >= 1_073_741_824) return (bytes / 1_073_741_824).toFixed(2) + ' GB';
    if (bytes >= 1_048_576)     return (bytes / 1_048_576).toFixed(2) + ' MB';
    if (bytes >= 1_024)         return (bytes / 1_024).toFixed(1) + ' KB';
    return bytes + ' B';
}

function decodeHtml(str) {
    if (!str) return str;
    return str
        .replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>')
        .replace(/&quot;/g,'"').replace(/&#039;/g,"'").replace(/&apos;/g,"'");
}

function getFileExtension(filename) {
    return filename?.split('.').pop()?.toLowerCase() || '';
}

function getMimeType(ext) {
    const map = {
        mp4: 'video/mp4', mkv: 'video/x-matroska', avi: 'video/x-msvideo',
        mp3: 'audio/mpeg', m4a: 'audio/mp4', flac: 'audio/flac', ogg: 'audio/ogg',
        jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif', webp: 'image/webp',
        pdf: 'application/pdf',
        zip: 'application/zip', rar: 'application/x-rar-compressed',
        '7z': 'application/x-7z-compressed',
        apk: 'application/vnd.android.package-archive',
        exe: 'application/x-msdownload',
    };
    return map[ext] || 'application/octet-stream';
}

// ─── Core: Scrape MediaFire page ─────────────────────────────────────────────

async function getMediafireData(url) {
    const headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
    };

    const res = await fetch(url, { headers, timeout: 20000, follow: 5 });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const html = await res.text();

    // Cek apakah file tersedia
    if (html.includes('File Not Found') || html.includes('file-not-found') || html.includes('This file is no longer available')) {
        throw new Error('File tidak ditemukan atau sudah dihapus.');
    }

    // Cek password protected
    if (html.includes('password_form') || html.includes('requiresPassword')) {
        throw new Error('File dilindungi password, tidak bisa didownload.');
    }

    // ── Extract download URL ─────────────────────────────────────────────────

    let downloadUrl = null;

    // Method 1: aria-label="Download file" href
    downloadUrl = html.match(/href="(https:\/\/download\d*\.mediafire\.com\/[^"]+)"/)?.[1] || null;

    // Method 2: id="downloadButton" href
    if (!downloadUrl)
        downloadUrl = html.match(/id="downloadButton"[^>]*href="([^"]+)"/)?.[1] ||
                      html.match(/href="([^"]+)"[^>]*id="downloadButton"/)?.[1] || null;

    // Method 3: class="input popsok" value (direct download input)
    if (!downloadUrl)
        downloadUrl = html.match(/class="input popsok"[^>]*value="([^"]+)"/)?.[1] || null;

    // Method 4: window.location assign ke download URL
    if (!downloadUrl)
        downloadUrl = html.match(/window\.location\.href\s*=\s*['"]?(https:\/\/download[^'";\s]+)/)?.[1] || null;

    // Method 5: og:url atau canonical kalau sudah redirect ke download
    if (!downloadUrl) {
        const canonical = html.match(/<link rel="canonical" href="([^"]+)"/)?.[1];
        if (canonical?.includes('download')) downloadUrl = canonical;
    }

    if (!downloadUrl) throw new Error('Link download tidak ditemukan. File mungkin tidak tersedia.');

    downloadUrl = decodeHtml(downloadUrl);

    // ── Extract Metadata ─────────────────────────────────────────────────────

    // Filename
    const filename = decodeHtml(
        html.match(/<div class="filename"[^>]*>([^<]+)<\/div>/i)?.[1] ||
        html.match(/<div class="dl-btn-label"[^>]*>([^<]+)<\/div>/i)?.[1] ||
        html.match(/<meta property="og:title" content="([^"]+)"/i)?.[1] ||
        html.match(/id="downloadButton"[^>]*title="([^"]+)"/i)?.[1] ||
        html.match(/class="filename-label"[^>]*>([^<]+)<\/span>/i)?.[1] ||
        'unknown'
    )?.trim();

    // File size
    const rawSize = html.match(/class="file-size"[^>]*>\s*([^<]+)/i)?.[1]?.trim() ||
                    html.match(/\((\d[\d.,]+ ?(?:KB|MB|GB|TB))\)/i)?.[1] ||
                    html.match(/>\s*(\d[\d.,]+ ?(?:KB|MB|GB))\s*</i)?.[1] || null;

    // File type / extension
    const ext = getFileExtension(filename);

    // Upload date
    const uploadDate = html.match(/class="upload-date"[^>]*>([^<]+)/i)?.[1]?.trim() ||
                       html.match(/Uploaded:\s*<[^>]+>([^<]+)/i)?.[1]?.trim() || null;

    // Uploader
    const uploader = decodeHtml(
        html.match(/class="owner-name"[^>]*>([^<]+)<\/a>/i)?.[1] ||
        html.match(/href="\/[^"]*" class="owner-name[^"]*">([^<]+)/i)?.[1] || null
    );

    // Description / og:description
    const description = decodeHtml(
        html.match(/<meta property="og:description" content="([^"]+)"/i)?.[1] || ''
    ) || null;

    // Thumbnail / preview image
    const thumbnail = html.match(/<meta property="og:image" content="([^"]+)"/i)?.[1] || null;

    console.log(`✅ MediaFire data scraped: ${filename} | ${rawSize || '?'}`);
    console.log(`⬇️  Download URL: ${downloadUrl.slice(0, 80)}...`);

    return {
        filename,
        ext,
        size_raw:    rawSize,
        mime:        getMimeType(ext),
        upload_date: uploadDate,
        uploader,
        description,
        thumbnail,
        download_url: downloadUrl,
    };
}

// ─── Download File ────────────────────────────────────────────────────────────

async function downloadBuffer(url, filename = 'file') {
    const headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
        'Accept': '*/*',
        'Referer': 'https://www.mediafire.com/',
    };
    const res = await fetch(url, { headers, timeout: 120000, follow: 10 });
    if (!res.ok) throw new Error(`Download gagal: HTTP ${res.status}`);

    // Cek Content-Length untuk validasi ukuran
    const contentLength = res.headers.get('content-length');
    if (contentLength) console.log(`📦 Content-Length: ${formatSize(parseInt(contentLength))}`);

    const buf = Buffer.from(await res.arrayBuffer());
    console.log(`📦 Downloaded: ${formatSize(buf.length)} | File: ${filename}`);
    return buf;
}

// ─── Caption Builder ──────────────────────────────────────────────────────────

function buildCaption(data, index = null, total = null) {
    let cap = '';
    if (index && total) cap += `📁 *File ${index}/${total}*\n\n`;
    cap += `📄 *${data.filename}*\n`;
    if (data.size_raw)   cap += `📦 ${data.size_raw}\n`;
    if (data.uploader)   cap += `👤 ${data.uploader}\n`;
    if (data.upload_date) cap += `📅 ${data.upload_date}\n`;
    if (data.description && data.description !== data.filename) {
        const desc = data.description.length > 100 ? data.description.slice(0, 100) + '...' : data.description;
        cap += `\n💬 ${desc}\n`;
    }
    cap += `\n☁️ MediaFire`;
    return cap.trim();
}

// ─── Send by file type ────────────────────────────────────────────────────────

async function sendFile(conn, m, buf, data, caption) {
    const { ext, mime, filename } = data;
    const videoExts  = ['mp4', 'mkv', 'avi', 'mov', 'webm', 'flv'];
    const audioExts  = ['mp3', 'm4a', 'flac', 'ogg', 'wav', 'aac', 'opus'];
    const imageExts  = ['jpg', 'jpeg', 'png', 'webp', 'gif'];

    if (videoExts.includes(ext)) {
        await conn.sendMessage(m.chat, {
            video: buf, mimetype: 'video/mp4', caption, fileName: filename,
        }, { quoted: m });

    } else if (audioExts.includes(ext)) {
        await conn.sendMessage(m.chat, {
            audio: buf, mimetype: 'audio/mpeg', ptt: false,
            fileName: filename, caption,
        }, { quoted: m });

    } else if (imageExts.includes(ext)) {
        await conn.sendMessage(m.chat, {
            image: buf, caption,
        }, { quoted: m });

    } else {
        // Semua file lain (zip, apk, pdf, exe, dll) kirim sebagai dokumen
        await conn.sendMessage(m.chat, {
            document: buf, mimetype: mime,
            fileName: filename, caption,
        }, { quoted: m });
    }
}

// ─── Handler ──────────────────────────────────────────────────────────────────

const HELP_MSG = (p, c) => `
*📥 MediaFire Downloader*
_Direct scraping — No API Key_

*Penggunaan:*
${p}${c} <url>

*Bulk:*
${p}${c} <url1> <url2> ...

*Contoh:*
${p}${c} https://www.mediafire.com/file/abc123/namafile.zip/file
${p}${c} https://www.mediafire.com/download/abc123

*Supported:*
✅ Semua jenis file (video, audio, zip, apk, pdf, dll)
✅ Bulk download
⚠️ File password-protected tidak didukung
`.trim();

let handler = async (m, { conn, args, usedPrefix, command }) => {
    const input  = args?.join(' ').trim() || '';
    const prefix = usedPrefix || m.text?.match(/^([.!#/])/)?.[1] || '.';
    const cmd    = command || 'mf';

    if (!input) return m.reply(HELP_MSG(prefix, cmd));

    const urls = extractMediafireUrls(input).filter(isValidMediafireUrl).map(normalizeUrl);
    if (!urls.length)
        return m.reply('❌ URL MediaFire tidak valid.\n\nContoh:\n• https://www.mediafire.com/file/abc123/namafile.zip/file');

    const isBulk = urls.length > 1;
    if (isBulk) await m.reply(`📥 *Bulk Download MediaFire*\n📁 Memproses *${urls.length} file*...\n⏳ Mohon tunggu.`);

    let ok = 0, fail = 0;

    for (let i = 0; i < urls.length; i++) {
        const url = urls[i];
        try {
            if (!isBulk) await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

            // 1. Scrape halaman untuk dapat metadata + download URL
            const data = await getMediafireData(url);

            // 2. Download file
            const buf = await downloadBuffer(data.download_url, data.filename);

            const caption = buildCaption(data, isBulk ? i + 1 : null, isBulk ? urls.length : null);

            // 3. Kirim sesuai tipe file
            await sendFile(conn, m, buf, data, caption);

            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            ok++;

        } catch (e) {
            console.error(`❌ MF Error [${i+1}]:`, e.message);
            fail++;
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            if (!isBulk)
                return m.reply(`❌ Gagal download dari MediaFire.\n*Error:* ${e.message}`);
        }

        if (isBulk && i < urls.length - 1) await randomDelay(2000, 4000);
    }

    if (isBulk)
        await m.reply(`📊 *Selesai*\n✅ Berhasil : ${ok}/${urls.length}\n❌ Gagal    : ${fail}/${urls.length}`);
};

handler.help    = ['mf', 'mediafire', 'mfdl'];
handler.tags    = ['downloader'];
handler.command = ['mf', 'mediafire', 'mfdl'];

export default handler;