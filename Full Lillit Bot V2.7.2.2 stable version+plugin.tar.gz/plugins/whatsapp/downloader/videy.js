const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import FormData from 'form-data';
import { v4 as uuidv4 } from 'uuid';
import { downloadContentFromMessage } from 'baileys';
import os from 'os';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ========== VIDEY HANDLER (DOWNLOAD & UPLOAD) ==========
const VIDEY_CDN_URL = 'https://cdn.videy.co/';
const VIDEY_UPLOAD_URL = 'https://videy.co/api/upload';
const VIDEY_AD_API_URL = 'https://ads-api.videy.co/api/ad_type';

const TIMEOUT_MS = 30000;
const UPLOAD_TIMEOUT_MS = 120000;
const AUTO_DELETE_TIMEOUT = 5 * 60 * 1000;
const QUICK_DELETE_TIMEOUT = 30000;

const TEMP_DIR = path.join(os.tmpdir(), 'videy-downloads');
const DOWNLOAD_DIR = process.env.TEMP_DIR || TEMP_DIR || './temp/videy/';

const deleteTimeoutMap = new Map();

function extractVideyId(url) {
    const match = url.match(/videy\.co\/v\/\?id=([a-zA-Z0-9_-]+)/i);
    if (!match || !match[1]) {
        return null;
    }
    return match[1];
}

function validateVideyId(id) {
    const idRegex = /^[a-zA-Z0-9_-]+$/;
    return idRegex.test(id) && id.length > 3;
}

function generateVisitorId() {
    return uuidv4();
}

async function downloadMedia(message) {
    try {
        const mimeMap = {
            imageMessage: 'image',
            videoMessage: 'video',
            stickerMessage: 'sticker',
            documentMessage: 'document',
            audioMessage: 'audio'
        };

        const msgKeys = Object.keys(message || {});
        if (msgKeys.length === 0) return null;

        const type = msgKeys[0];
        if (!type) return null;

        const m = message[type];
        if (!m) return null;

        const mediaType = mimeMap[type];
        if (!mediaType) return null;

        const stream = await downloadContentFromMessage(m, mediaType);
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        
        return Buffer.concat(chunks);
    } catch (error) {
        return null;
    }
}

async function getAdType() {
    try {
        const url = `${VIDEY_AD_API_URL}?uploader=true&width=1536&ad_group=90`;
        const response = await fetch(url);
        
        if (!response.ok) {
            return null;
        }
        
        const data = await response.json();
        return data;
    } catch (error) {
        return null;
    }
}

async function uploadToVidey(mediaBuffer, filename) {
    try {
        const maxSize = 100 * 1024 * 1024;
        if (mediaBuffer.length > maxSize) {
            const sizeMB = (mediaBuffer.length / 1024 / 1024).toFixed(2);
            throw new Error(`Video terlalu besar (${sizeMB} MB). Maksimal 100MB`);
        }
        
        const visitorId = generateVisitorId();
        await getAdType();
        
        const form = new FormData();
        form.append('file', mediaBuffer, {
            filename: filename,
            contentType: 'video/mp4'
        });
        
        const uploadUrl = `${VIDEY_UPLOAD_URL}?visitorId=${visitorId}`;
        
        const fetchPromise = fetch(uploadUrl, {
            method: 'POST',
            body: form,
            headers: {
                ...form.getHeaders(),
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error(`Upload timeout setelah ${UPLOAD_TIMEOUT_MS}ms`)), UPLOAD_TIMEOUT_MS)
        );
        
        const response = await Promise.race([fetchPromise, timeoutPromise]);
        
        if (!response.ok) {
            const errorText = await response.text().catch(() => 'Unknown error');
            throw new Error(`HTTP Error ${response.status}: ${errorText.substring(0, 200)}`);
        }
        
        const result = await response.json();
        
        if (result && result.id) {
            return {
                success: true,
                id: result.id,
                url: `https://videy.co/v/?id=${result.id}`,
                cdnUrl: `${VIDEY_CDN_URL}${result.id}.mp4`,
                visitorId: visitorId
            };
        } else {
            throw new Error('Invalid response from Videy API');
        }
        
    } catch (error) {
        throw error;
    }
}

async function fetchVideyVideo(videyId) {
    try {
        const videoUrl = `${VIDEY_CDN_URL}${videyId}.mp4`;
        
        const fetchPromise = fetch(videoUrl);
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error(`Timeout setelah ${TIMEOUT_MS}ms`)), TIMEOUT_MS)
        );
        
        const response = await Promise.race([fetchPromise, timeoutPromise]);
        
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status}`);
        }
        
        const contentLength = response.headers.get('content-length');
        const arrayBuffer = await response.arrayBuffer();
        const buffer = Buffer.from(arrayBuffer);
        
        return { buffer, size: contentLength, url: videoUrl };
        
    } catch (error) {
        throw new Error(`Gagal mengunduh video. Error: ${error.message}`);
    }
}

function ensureTempDir() {
    try {
        if (!fs.existsSync(DOWNLOAD_DIR)) {
            fs.mkdirSync(DOWNLOAD_DIR, { recursive: true });
        }
    } catch (error) {
        throw error;
    }
}

function deleteFileImmediately(filePath, reason = 'Manual cleanup') {
    try {
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
            return true;
        }
        return false;
    } catch (error) {
        return false;
    }
}

function scheduleFileDelete(filePath, fileId, quickDelete = true) {
    if (deleteTimeoutMap.has(fileId)) {
        const oldTimeouts = deleteTimeoutMap.get(fileId);
        if (oldTimeouts.quick) clearTimeout(oldTimeouts.quick);
        if (oldTimeouts.backup) clearTimeout(oldTimeouts.backup);
    }
    
    const timeouts = {};
    
    if (quickDelete) {
        timeouts.quick = setTimeout(() => {
            if (fs.existsSync(filePath)) {
                deleteFileImmediately(filePath, `Quick cleanup after ${QUICK_DELETE_TIMEOUT / 1000}s`);
                deleteTimeoutMap.delete(fileId);
            }
        }, QUICK_DELETE_TIMEOUT);
    }
    
    timeouts.backup = setTimeout(() => {
        if (fs.existsSync(filePath)) {
            deleteFileImmediately(filePath, `Backup cleanup after ${AUTO_DELETE_TIMEOUT / 1000 / 60} minutes`);
            deleteTimeoutMap.delete(fileId);
        }
    }, AUTO_DELETE_TIMEOUT);
    
    deleteTimeoutMap.set(fileId, timeouts);
}

function cleanupOldTempFiles() {
    try {
        if (!fs.existsSync(DOWNLOAD_DIR)) return;
        
        const files = fs.readdirSync(DOWNLOAD_DIR);
        const now = Date.now();
        
        files.forEach(file => {
            const filePath = path.join(DOWNLOAD_DIR, file);
            try {
                const stats = fs.statSync(filePath);
                const fileAge = now - stats.mtimeMs;
                
                if (fileAge > 60 * 60 * 1000) {
                    fs.unlinkSync(filePath);
                }
            } catch (err) {
                // Silent error handling
            }
        });
    } catch (error) {
        // Silent error handling
    }
}

function generateUsageHelp(prefix, cmd) {
    return `*🎬 VIDEY HANDLER*

📥 *DOWNLOAD VIDEO*
${prefix}${cmd} <URL atau ID Videy>

• URL: ${prefix}${cmd} https://videy.co/v/?id=TqwYldGQ1
• ID: ${prefix}${cmd} TqwYldGQ1

📤 *UPLOAD VIDEO*
1️⃣ *Dari WhatsApp:*
   ${prefix}${cmd}up <reply ke video>
   ${prefix}${cmd}up <kirim video dengan caption>

2️⃣ *Dari URL:*
   ${prefix}${cmd}up https://example.com/video.mp4
   ${prefix}${cmd}up <URL video apa saja>

💡 *Fitur:*
• Upload dari WA atau URL
• Max: 100MB
• Support semua format video

⏰ *Auto-cleanup:*
• Quick: 30 detik
• Backup: 5 menit`;
}

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    let prefix = usedPrefix;
    if (!prefix && m.text) {
        const match = m.text.match(/^([.!#/])/);
        prefix = match ? match[1] : '.';
    }
    prefix = prefix || '.';
    
    const cmd = command || 'videy';
    
    // ========== UPLOAD MODE ==========
    if (command === 'videyup' || command === 'videoup') {
        try {
            let mediaBuffer = null;
            let mime = '';
            
            let inputText = '';
            if (text) {
                inputText = text.trim();
            } else if (args && args.length > 0) {
                inputText = args.join(' ').trim();
            }
            
            const urlRegex = /^https?:\/\/.+/i;
            if (inputText && urlRegex.test(inputText)) {
                await conn.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });
                
                try {
                    const fetchPromise = fetch(inputText);
                    const timeoutPromise = new Promise((_, reject) => 
                        setTimeout(() => reject(new Error(`Timeout fetching URL`)), TIMEOUT_MS)
                    );
                    
                    const response = await Promise.race([fetchPromise, timeoutPromise]);
                    
                    if (!response.ok) {
                        throw new Error(`HTTP ${response.status}: Gagal mengunduh video dari URL`);
                    }
                    
                    const contentType = response.headers.get('content-type') || '';
                    if (!contentType.startsWith('video/')) {
                        throw new Error('URL bukan video yang valid');
                    }
                    
                    mime = contentType;
                    const arrayBuffer = await response.arrayBuffer();
                    mediaBuffer = Buffer.from(arrayBuffer);
                } catch (error) {
                    throw new Error(`Gagal download dari URL: ${error.message}`);
                }
            } else {
                let rawMessage = m.message;
                let contextInfo = null;
                let quotedMessage = null;
                
                if (rawMessage) {
                    if (rawMessage.extendedTextMessage) {
                        contextInfo = rawMessage.extendedTextMessage.contextInfo;
                    } else if (rawMessage.imageMessage) {
                        contextInfo = rawMessage.imageMessage.contextInfo;
                    } else if (rawMessage.videoMessage) {
                        contextInfo = rawMessage.videoMessage.contextInfo;
                    } else if (rawMessage.documentMessage) {
                        contextInfo = rawMessage.documentMessage.contextInfo;
                    }
                    
                    if (contextInfo) {
                        quotedMessage = contextInfo.quotedMessage;
                    }
                }
                
                if (rawMessage?.videoMessage) {
                    mime = rawMessage.videoMessage.mimetype || 'video/mp4';
                    mediaBuffer = await downloadMedia(rawMessage);
                }
                else if (quotedMessage?.videoMessage) {
                    mime = quotedMessage.videoMessage.mimetype || 'video/mp4';
                    mediaBuffer = await downloadMedia(quotedMessage);
                }
                else if (m.quoted?.message?.videoMessage) {
                    mime = m.quoted.message.videoMessage.mimetype || 'video/mp4';
                    mediaBuffer = await downloadMedia(m.quoted.message);
                }
            }
            
            if (!mediaBuffer || !mime.startsWith('video/')) {
                return m.reply('❌ Reply ke video atau berikan URL video!\n\n💡 Cara:\n1️⃣ Reply video: ' + prefix + command + '\n2️⃣ Kirim video dengan caption: ' + prefix + command + '\n3️⃣ Dari URL: ' + prefix + command + ' https://example.com/video.mp4\n\n📌 Max: 100MB');
            }
            
            await conn.sendMessage(m.chat, { react: { text: '📤', key: m.key } });
            
            const sizeMB = (mediaBuffer.length / (1024 * 1024)).toFixed(2);
            
            await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
            
            const filename = `video_${Date.now()}.mp4`;
            const uploadResult = await uploadToVidey(mediaBuffer, filename);
            
            const successMsg = `✅ *VIDEO BERHASIL DI-UPLOAD KE VIDEY*

🆔 *ID:* ${uploadResult.id}
🔗 *Link:* ${uploadResult.url}
📦 *CDN:* ${uploadResult.cdnUrl}
📊 *Size:* ${sizeMB} MB

💡 *Gunakan link untuk share video!*`;
            
            await m.reply(successMsg);
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            
        } catch (error) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
            
            let errorMsg = '❌ Terjadi kesalahan saat upload video.\n\n';
            
            if (error.message.includes('timeout')) {
                errorMsg += `⚠️ Upload timeout setelah ${UPLOAD_TIMEOUT_MS / 1000} detik\n💡 Video terlalu besar atau koneksi lambat`;
            } else if (error.message.includes('terlalu besar')) {
                errorMsg += `⚠️ ${error.message}\n💡 Kompres video terlebih dahulu`;
            } else {
                errorMsg += `⚠️ Error: ${error.message}\n💡 Coba lagi atau ketik ${prefix}${cmd} help`;
            }
            
            return m.reply(errorMsg);
        }
        
        return;
    }
    
    // ========== DOWNLOAD MODE ==========
    let inputText = '';
    if (text) {
        inputText = text.trim();
    } else if (args && args.length > 0) {
        inputText = args.join(' ').trim();
    }
    
    if (!inputText || inputText.toLowerCase() === 'help' || inputText === '?') {
        return m.reply(generateUsageHelp(prefix, cmd));
    }
    
    let videyId = null;
    
    if (inputText.includes('videy.co')) {
        videyId = extractVideyId(inputText);
    } else {
        videyId = inputText;
    }
    
    if (!videyId || !validateVideyId(videyId)) {
        return m.reply(`❌ Format tidak valid!\n\n💡 Gunakan salah satu format:\n\n1. URL: ${prefix}${cmd} https://videy.co/v/?id=TqwYldGQ1\n\n2. ID: ${prefix}${cmd} TqwYldGQ1\n\n📌 Ketik ${prefix}${cmd} help untuk panduan lengkap`);
    }
    
    let filePath = null;
    let fileId = null;
    
    try {
        await conn.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });
        
        const videoData = await fetchVideyVideo(videyId);
        
        ensureTempDir();
        
        const timestamp = Date.now();
        const fileName = `videy_${videyId}_${timestamp}.mp4`;
        filePath = path.join(DOWNLOAD_DIR, fileName);
        fileId = `${videyId}_${timestamp}`;
        
        fs.writeFileSync(filePath, videoData.buffer);
        
        scheduleFileDelete(filePath, fileId, true);
        
        await conn.sendMessage(m.chat, { react: { text: '📤', key: m.key } });
        
        await conn.sendMessage(m.chat, {
            video: { url: filePath },
            mimetype: 'video/mp4',
            caption: `✅ *Video dari Videy*\n\n🆔 ID: ${videyId}\n📊 Size: ${videoData.size ? (parseInt(videoData.size) / (1024 * 1024)).toFixed(2) + ' MB' : 'unknown'}`,
            fileName: `${videyId}.mp4`
        }, { quoted: m });
        
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (error) {
        if (filePath && fs.existsSync(filePath)) {
            deleteFileImmediately(filePath, 'Error cleanup');
            if (fileId && deleteTimeoutMap.has(fileId)) {
                const timeouts = deleteTimeoutMap.get(fileId);
                if (timeouts.quick) clearTimeout(timeouts.quick);
                if (timeouts.backup) clearTimeout(timeouts.backup);
                deleteTimeoutMap.delete(fileId);
            }
        }
        
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        
        let errorMsg = '❌ Terjadi kesalahan saat mengunduh video.\n\n';
        
        if (error.message.includes('Timeout')) {
            errorMsg += `⚠️ Timeout: CDN tidak merespons dalam ${TIMEOUT_MS / 1000} detik\n💡 Coba lagi dalam beberapa saat`;
        } else if (error.message.includes('404')) {
            errorMsg += '⚠️ Video tidak ditemukan\n💡 Pastikan ID Videy benar';
        } else if (error.message.includes('gagal mengunduh')) {
            errorMsg += '⚠️ CDN tidak dapat diakses\n💡 Coba lagi nanti';
        } else {
            errorMsg += `⚠️ Error: ${error.message}\n💡 Coba lagi atau ketik ${prefix}${cmd} help`;
        }
        
        return m.reply(errorMsg);
    }
};

handler.help = ["videy <url|id>", "videyup <reply video>"];
handler.tags = ["downloader"];
handler.command = ["videy", "videydl", "videyup", "videoup"];
handler.limit = true;

cleanupOldTempFiles();

export default handler;