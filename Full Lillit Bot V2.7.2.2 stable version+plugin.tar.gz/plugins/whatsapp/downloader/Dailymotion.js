import axios from 'axios';

// Fungsi untuk download dari Dailymotion
async function daily(url) {
    const res = await axios.post(
        "https://vidomon.com/wp-json/aio-dl/video-data/",
        { url },
        {
            headers: {
                "content-type": "application/json",
                "origin": "https://vidomon.com",
                "referer": "https://vidomon.com/"
            }
        }
    );
    return res.data;
}

// Fungsi untuk shorten URL dengan Monojson
async function shortenUrl(longUrl) {
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 15000);

        const response = await axios.post(
            'https://monojson.com/api/short-link',
            { url: longUrl },
            {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'User-Agent': 'Mozilla/5.0'
                },
                signal: controller.signal
            }
        );

        clearTimeout(timeoutId);

        if (response.data && response.data.shortUrl) {
            return response.data.shortUrl;
        }
        
        return longUrl; // Fallback ke URL asli jika gagal
    } catch (error) {
        return longUrl; // Fallback ke URL asli jika error
    }
}

const handler = async (m, { conn, text, args, usedPrefix, command }) => {
    const url = text || args[0];
    
    if (!url) return m.reply(`❌ Kirim link Dailymotion yang ingin di-download!\n\nContoh:\n${usedPrefix + command} https://www.dailymotion.com/video/xxxxx`);
    
    if (!url.includes('dailymotion.com')) {
        return m.reply('❌ Link harus dari Dailymotion!');
    }
    
    // React dengan emoji loading
    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
        // Download dari Dailymotion
        const result = await daily(url);
        
        // React dengan emoji success
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
        if (!result || !result.medias || result.medias.length === 0) {
            throw new Error('Tidak ada media yang ditemukan');
        }
        
        const title = result.title || 'Dailymotion Video';
        const thumbnail = result.thumbnail || '';
        const duration = result.duration || 'Unknown';
        
        // Filter media yang valid
        const validMedias = result.medias.filter(media => {
            return media.videoAvailable && media.audioAvailable;
        });
        
        if (validMedias.length === 0) {
            throw new Error('Tidak ada kualitas video yang valid ditemukan');
        }
        
        // Urutkan berdasarkan kualitas (1080p > 720p > 480p > 380p)
        const qualityOrder = { '1080p': 4, '720p': 3, '480p': 2, '380p': 1 };
        validMedias.sort((a, b) => {
            const orderA = qualityOrder[a.quality] || 0;
            const orderB = qualityOrder[b.quality] || 0;
            return orderB - orderA;
        });
        
        // Pilih kualitas terbaik
        const bestQuality = validMedias[0];
        
        // Shorten URLs untuk semua kualitas
        const shortUrlPromises = validMedias.map(async (media) => {
            const shortUrl = await shortenUrl(media.url);
            return { ...media, shortUrl };
        });
        
        const mediasWithShortUrls = await Promise.all(shortUrlPromises);
        
        // Kirim pesan dengan semua link kualitas
        let message = `╭───═[ 📹 DAILYMOTION ]═───╮\n`;
        message += `│\n`;
        message += `│ 🎬 *${title}*\n`;
        message += `│\n`;
        message += `│ ⏱️  Durasi: ${duration}\n`;
        message += `│ ⭐ Terbaik: ${bestQuality.quality}\n`;
        message += `│\n`;
        message += `╰──────────────────────╯\n\n`;
        message += `📺 *Streaming Links:*\n\n`;
        
        mediasWithShortUrls.forEach((media, index) => {
            message += `${index + 1}. *${media.quality}*\n`;
            message += `${media.shortUrl}\n\n`;
        });
        
        message += `💡 *Cara pakai:*\n`;
        message += `• Salin link di atas\n`;
        message += `• Buka di browser (auto play)\n`;
        message += `• Atau pakai VLC Player untuk download\n\n`;
        message += `⚡ *Rekomendasi:* Gunakan link *${bestQuality.quality}*`;
        
        // Kirim pesan dengan thumbnail jika ada
        if (thumbnail) {
            await conn.sendMessage(m.chat, {
                image: { url: thumbnail },
                caption: message
            }, { quoted: m });
        } else {
            await conn.sendMessage(m.chat, {
                text: message
            }, { quoted: m });
        }
        
    } catch (err) {
        // React dengan emoji error
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        m.reply(`❌ Gagal mendapatkan link: ${err.message}\nCoba lagi nanti.`);
    }
};

handler.help = ["dailymotion <url>", "dm <url>"];
handler.command = ["dailymotion", "dm"];
handler.tags = ["downloader"];
handler.description = "Dapatkan link streaming Dailymotion (langsung kirim link, tanpa download)";
handler.limit = false;

export default handler;

// Untuk konversi streaming ke downloading gunakan ffmpeg:
// ffmpeg -i "URL_M3U8" -c copy -bsf:a aac_adtstoasc "output.mp4"