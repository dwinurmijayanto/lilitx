const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

// ─── Constants ────────────────────────────────────────────────────────────────

const SC_BASE     = 'https://soundcloud.com';
const SC_API      = 'https://api-v2.soundcloud.com';
const UA          = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

// ─── Validators ───────────────────────────────────────────────────────────────

function isValidUrl(url) {
    return /^(https?:\/\/)?(www\.|on\.)?soundcloud\.com\/[\w.@-]+/.test(url);
}

function extractUrls(text) {
    const m = text.match(/(https?:\/\/)?(www\.|on\.)?soundcloud\.com\/[^\s]+/gi) || [];
    return [...new Set(m)];
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

const delay = (ms) => new Promise(r => setTimeout(r, ms));

function formatDuration(ms) {
    const s = Math.floor((ms || 0) / 1000);
    return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

function formatNum(n) {
    n = Number(n) || 0;
    if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + 'M';
    if (n >= 1_000)     return (n / 1_000).toFixed(1) + 'K';
    return String(n);
}

function slugify(s = '') {
    return s.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '').slice(0, 60);
}

// ─── client_id resolver ───────────────────────────────────────────────────────

let _clientId = null;

async function getClientId() {
    if (_clientId) return _clientId;

    const html = await fetch(SC_BASE, { headers: { 'User-Agent': UA }, timeout: 15000 })
        .then(r => { if (!r.ok) throw new Error(`SC homepage ${r.status}`); return r.text(); });

    const scripts = [...html.matchAll(/src="(https:\/\/a-v2\.sndcdn\.com\/assets\/[^"]+\.js)"/g)]
        .map(m => m[1]).slice(-6);

    for (const url of scripts) {
        const js = await fetch(url, { headers: { 'User-Agent': UA }, timeout: 10000 })
            .then(r => r.text()).catch(() => '');
        const m  = js.match(/client_id\s*[=:]\s*"([A-Za-z0-9]{32})"/);
        if (m?.[1]) { _clientId = m[1]; return _clientId; }
    }

    throw new Error('Tidak dapat mengambil client_id dari SoundCloud');
}

// ─── API helpers ──────────────────────────────────────────────────────────────

async function scFetch(path, clientId) {
    const sep = path.includes('?') ? '&' : '?';
    const res = await fetch(`${SC_API}${path}${sep}client_id=${clientId}`, {
        headers: { 'User-Agent': UA },
        timeout: 15000,
    });
    if (!res.ok) throw new Error(`API ${res.status}: ${path}`);
    return res.json();
}

async function resolveUrl(url, clientId) {
    return scFetch(`/resolve?url=${encodeURIComponent(url)}`, clientId);
}

// ─── Search — relevansi + official priority ───────────────────────────────────
// Menggunakan /search/tracks dengan sorting relevance bawaan SC,
// lalu re-rank: verified / label account naik ke atas.

async function searchTracks(query, limit = 10) {
    const clientId = await getClientId();
    const data     = await scFetch(
        `/search/tracks?q=${encodeURIComponent(query)}&limit=${limit * 2}&offset=0&linked_partitioning=1`,
        clientId
    );

    if (!data?.collection?.length) throw new Error('Tidak ada hasil ditemukan');

    const tracks = data.collection
        .filter(t => t.streamable !== false)  // skip non-streamable
        .map(t => ({ ...t, _score: scoreTrack(t, query) }))
        .sort((a, b) => b._score - a._score)
        .slice(0, limit);

    return tracks;
}

// Scoring: prioritaskan akun verified/label + kedekatan judul dengan query
function scoreTrack(t, query) {
    let score = 0;
    const q   = query.toLowerCase();
    const title  = (t.title || '').toLowerCase();
    const artist = (t.user?.username || '').toLowerCase();

    // Exact / close title match
    if (title === q)                 score += 100;
    else if (title.includes(q))      score += 50;
    else if (q.split(' ').every(w => title.includes(w))) score += 30;

    // Official / verified signals
    if (t.user?.verified)            score += 40;
    if (t.label_name)                score += 20;
    if (t.publisher_metadata?.artist) score += 15;
    if (t.publisher_metadata?.isrc)  score += 10;  // has ISRC = official release

    // Popularity (log scale agar tidak mendominasi)
    score += Math.log10((t.playback_count || 1) + 1) * 5;

    // Penalti: remix / cover (kecuali query memang minta itu)
    if (!q.includes('remix') && /remix|cover|bootleg/i.test(title)) score -= 20;

    return score;
}

// ─── Stream resolver ──────────────────────────────────────────────────────────

async function getStreamUrl(track, clientId) {
    const tc = (track?.media?.transcodings || []);

    // Priority: progressive MP3 → HLS MP3 → progressive anything → first available
    const pick =
        tc.find(t => t.format?.protocol === 'progressive' && /mpeg/.test(t.format?.mime_type)) ||
        tc.find(t => t.format?.protocol === 'hls'         && /mpeg/.test(t.format?.mime_type)) ||
        tc.find(t => t.format?.protocol === 'progressive') ||
        tc[0];

    if (!pick) throw new Error('Tidak ada stream tersedia untuk track ini');

    const res = await fetch(`${pick.url}?client_id=${clientId}`, {
        headers: { 'User-Agent': UA }, timeout: 15000,
    });
    if (!res.ok) throw new Error(`Stream auth ${res.status}`);

    const { url } = await res.json();
    if (!url) throw new Error('Stream URL kosong');

    return { url, protocol: pick.format?.protocol };
}

// ─── Downloaders ──────────────────────────────────────────────────────────────

async function downloadHls(m3u8Url) {
    const base = m3u8Url.split('?')[0].replace(/\/[^/]+$/, '/');
    const pl   = await fetch(m3u8Url, { headers: { 'User-Agent': UA }, timeout: 15000 })
        .then(r => { if (!r.ok) throw new Error(`HLS playlist ${r.status}`); return r.text(); });

    const segs = pl.split('\n')
        .filter(l => l && !l.startsWith('#'))
        .map(l => l.startsWith('http') ? l : base + l);

    if (!segs.length) throw new Error('HLS playlist kosong');

    const chunks = await Promise.all(
        segs.map(seg =>
            fetch(seg, { headers: { 'User-Agent': UA }, timeout: 30000 })
                .then(r => r.ok ? r.arrayBuffer().then(Buffer.from) : null)
                .catch(() => null)
        )
    );

    return Buffer.concat(chunks.filter(Boolean));
}

async function downloadProgressive(url) {
    const res = await fetch(url, { headers: { 'User-Agent': UA }, timeout: 60000 });
    if (!res.ok) throw new Error(`Download ${res.status}`);
    return Buffer.from(await res.arrayBuffer());
}

async function downloadArtwork(url) {
    if (!url) return null;
    try {
        const hi  = url.replace(/-\w+\.jpg/, '-t500x500.jpg');
        const res = await fetch(hi, { headers: { 'User-Agent': UA }, timeout: 10000 });
        return res.ok ? Buffer.from(await res.arrayBuffer()) : null;
    } catch { return null; }
}

// ─── Normalise ────────────────────────────────────────────────────────────────

function normaliseTrack(t) {
    return {
        id:          t.id,
        title:       t.title        || 'Unknown Title',
        artist:      t.user?.username || '-',
        displayName: t.user?.full_name || '',
        verified:    !!t.user?.verified,
        genre:       t.genre         || '-',
        duration:    formatDuration(t.duration),
        plays:       formatNum(t.playback_count),
        likes:       formatNum(t.likes_count),
        artworkUrl:  t.artwork_url   || t.user?.avatar_url || null,
        permalink:   t.permalink_url || SC_BASE,
        label:       t.label_name    || t.publisher_metadata?.artist || null,
        isrc:        t.publisher_metadata?.isrc || null,
        created:     t.created_at ? new Date(t.created_at).toLocaleDateString('id-ID') : '-',
        transcodings: t.media?.transcodings || [],
    };
}

function normalisePlaylist(p) {
    return {
        title:      p.title         || 'Unknown Playlist',
        artist:     p.user?.username || '-',
        trackCount: p.track_count   || (p.tracks?.length ?? 0),
        duration:   formatDuration(p.duration),
        artworkUrl: p.artwork_url    || null,
        isAlbum:    !!p.is_album,
        tracks:     (p.tracks || []),
    };
}

// ─── Caption builder ──────────────────────────────────────────────────────────

function buildCaption(meta) {
    let cap = `🎵 *${meta.title}*\n`;
    cap += `👤 ${meta.artist}`;
    if (meta.displayName) cap += ` _(${meta.displayName})_`;
    if (meta.verified)    cap += ` ✅`;
    cap += '\n';
    if (meta.label)  cap += `🏷️ ${meta.label}\n`;
    if (meta.genre !== '-') cap += `🎸 ${meta.genre}  |  `;
    cap += `⏱ ${meta.duration}  |  ▶️ ${meta.plays}  |  ❤️ ${meta.likes}\n`;
    cap += `📅 ${meta.created}`;
    return cap;
}

function buildSearchMsg(tracks, query) {
    let msg  = `🔍 *Hasil Pencarian SoundCloud*\n`;
        msg += `📌 Keyword : *${query}*\n`;
        msg += `📊 Ditemukan : *${tracks.length} track*\n`;
        msg += `─────────────────────────\n\n`;

    for (let i = 0; i < tracks.length; i++) {
        const t = normaliseTrack(tracks[i]);
        msg += `*${i + 1}. ${t.title}*\n`;
        msg += `👤 @${t.artist}`;
        if (t.displayName) msg += ` _(${t.displayName})_`;
        if (t.verified)    msg += ` ✅`;
        msg += '\n';
        if (t.label) msg += `🏷️ ${t.label}\n`;
        msg += `⏱ ${t.duration}  |  ▶️ ${t.plays}  |  ❤️ ${t.likes}\n`;
        msg += `🔗 ${t.permalink}\n\n`;
    }

    msg += `💡 *Tips:* Kirim URL di atas ke *.sc <url>* untuk download!`;
    return msg;
}

// ─── Core: download & send 1 track (silent, no status spam) ──────────────────

async function sendTrack(conn, m, trackData, clientId) {
    const meta = normaliseTrack(trackData);

    const { url, protocol } = await getStreamUrl(trackData, clientId);

    const [audioBuf, artBuf] = await Promise.all([
        protocol === 'hls' ? downloadHls(url) : downloadProgressive(url),
        downloadArtwork(meta.artworkUrl),
    ]);

    if (!audioBuf?.length) throw new Error('Audio buffer kosong');

    const caption  = buildCaption(meta);
    const fileName = `${slugify(meta.artist)}_${slugify(meta.title)}.mp3`;

    if (artBuf) {
        await conn.sendMessage(m.chat, { image: artBuf, caption }, { quoted: m });
    }

    await conn.sendMessage(m.chat, {
        audio:    audioBuf,
        mimetype: 'audio/mpeg',
        ptt:      false,
        fileName,
        ...(artBuf ? {} : { caption }),
    }, { quoted: m });
}

// ─── Core: process URL (track or playlist) ───────────────────────────────────

async function processUrl(conn, m, url) {
    const clientId = await getClientId();
    const data     = await resolveUrl(url, clientId);

    // ── Single track ─────────────────────────────────────────────────────────
    if (data.kind === 'track') {
        await sendTrack(conn, m, data, clientId);
        return;
    }

    // ── Playlist / Album ─────────────────────────────────────────────────────
    if (data.kind === 'playlist' || data.kind === 'system-playlist') {
        const pl     = normalisePlaylist(data);
        const cap    = pl.isAlbum ? 'Album' : 'Playlist';
        const tracks = pl.tracks.slice(0, 20);

        await m.reply(
            `📂 *${cap}: ${pl.title}*\n` +
            `👤 @${pl.artist}\n` +
            `🎵 ${pl.trackCount} tracks  |  ⏱ ${pl.duration}\n` +
            `⏳ Mendownload ${tracks.length} track…`
        );

        let ok = 0, fail = 0;
        for (let i = 0; i < tracks.length; i++) {
            try {
                // Stub tracks (no transcodings) perlu di-resolve ulang
                const t = tracks[i].media?.transcodings?.length
                    ? tracks[i]
                    : await resolveUrl(tracks[i].permalink_url, clientId);

                await sendTrack(conn, m, t, clientId);
                ok++;
            } catch (e) {
                console.error(`Track ${i + 1} gagal: ${e.message}`);
                fail++;
            }
            if (i < tracks.length - 1) await delay(1500);
        }

        await m.reply(
            `📊 *Selesai*\n✅ ${ok}  ❌ ${fail}  dari ${tracks.length} track`
        );
        return;
    }

    throw new Error(`Tipe tidak didukung: ${data.kind}`);
}

// ─── Help ─────────────────────────────────────────────────────────────────────

const HELP_DL = (p, c) => `
*🎵 SoundCloud Downloader*

*Download track:*
${p}${c} <url>

*Download playlist / album:*
${p}${c} <url playlist>

*Cari & download otomatis:*
${p}${c} <kata kunci>

✅ Prioritas hasil official & verified
`.trim();

const HELP_SEARCH = (p, c) => `
*🔍 SoundCloud Search*

${p}${c} <kata kunci>

✅ Prioritas hasil official & verified
`.trim();

// ─── Handler ──────────────────────────────────────────────────────────────────

let handler = async (m, { conn, args, usedPrefix, command }) => {
    const input  = args?.join(' ').trim() || '';
    const prefix = usedPrefix || '.';
    const cmd    = command || 'sc';
    const isSearch = ['scsearch', 'soundcloudsearch'].includes(cmd);

    // ── SEARCH only ──────────────────────────────────────────────────────────
    if (isSearch) {
        if (!input) return m.reply(HELP_SEARCH(prefix, cmd));
        try {
            const tracks = await searchTracks(input, 10);
            return m.reply(buildSearchMsg(tracks, input));
        } catch (e) {
            return m.reply(`❌ ${e.message}`);
        }
    }

    // ── DOWNLOAD ──────────────────────────────────────────────────────────────
    if (!input) return m.reply(HELP_DL(prefix, cmd));

    const urls = extractUrls(input).filter(isValidUrl);

    // Keyword → cari, ambil #1, download
    if (!urls.length) {
        let tracks;
        try {
            tracks = await searchTracks(input, 10);
        } catch (e) {
            return m.reply(`❌ ${e.message}`);
        }

        const top = normaliseTrack(tracks[0]);
        await m.reply(
            `🎯 *${top.title}*\n` +
            `👤 @${top.artist}${top.verified ? ' ✅' : ''}\n` +
            `⏳ Mendownload…`
        );

        try {
            await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
            await processUrl(conn, m, top.permalink);
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } catch (e) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ ${e.message}`);
        }
        return;
    }

    // URL langsung
    const isBulk = urls.length > 1;
    if (isBulk) await m.reply(`📥 Memproses *${urls.length} URL*…`);

    let ok = 0, fail = 0;
    for (let i = 0; i < urls.length; i++) {
        try {
            await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
            await processUrl(conn, m, urls[i]);
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            ok++;
        } catch (e) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            if (!isBulk) return m.reply(`❌ ${e.message}`);
            fail++;
        }
        if (isBulk && i < urls.length - 1) await delay(1500);
    }

    if (isBulk)
        await m.reply(`📊 *Selesai*\n✅ ${ok}  ❌ ${fail}  dari ${urls.length}`);
};

handler.help    = ['sc', 'soundcloud', 'scdl', 'scsearch', 'soundcloudsearch'];
handler.tags    = ['downloader'];
handler.command = ['sc', 'soundcloud', 'scdl', 'scsearch', 'soundcloudsearch'];

export default handler;