import fetch from 'node-fetch';

function isValidDouyinUrl(url) {
    return /douyin\.com/i.test(url);
}

function normalizeUrl(url) {
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
        url = 'https://' + url;
    }
    return url;
}

// Generate session ID tanpa crypto (ESM pure)
function generateSessionId(videoUrl) {
    const raw = videoUrl + Date.now() + Math.random();
    let hash = 0;
    for (let i = 0; i < raw.length; i++) {
        hash = (Math.imul(31, hash) + raw.charCodeAt(i)) | 0;
    }
    return Math.abs(hash).toString(16).padStart(8, '0') + Date.now().toString(16);
}

// Step 1: Fetch data dari snapdouyin API
async function getSnapDouyinData(videoUrl) {
    const sessionId = generateSessionId(videoUrl);

    const response = await fetch('https://snapdouyin.app/wp-json/mx-downloader/video-data/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Referer': 'https://snapdouyin.app/',
            'Origin': 'https://snapdouyin.app',
            'Cache-Control': 'no-cache',
            'X-Requested-With': 'XMLHttpRequest',
            'X-Session-ID': sessionId
        },
        body: JSON.stringify({ url: videoUrl })
    });

    if (!response.ok) throw new Error(`SnapDouyin API error: ${response.status}`);

    const setCookie = response.headers.get('set-cookie') || '';
    const cookieHeader = setCookie.split(',').map(c => c.split(';')[0].trim()).filter(Boolean).join('; ');

    const data = await response.json();
    return { data, cookieHeader, sessionId };
}

// Step 2: Resolve URL snapdouyin.app → CDN via redirect chain
async function resolveSnapUrl(snapUrl, cookieHeader, sessionId) {
    const cdnDomains = ['zjcdn.com', 'douyinpic.com', 'douyinvod.com', 'bytecdn.cn', 'bytedance.com', 'douyinstatic.com'];

    const separator = snapUrl.includes('?') ? '&' : '?';
    const urlToFetch = `${snapUrl}${separator}bandwidth_saving=1&_t=${Date.now()}${Math.floor(Math.random() * 9000 + 1000)}`;

    let currentUrl = urlToFetch;

    for (let i = 0; i < 10; i++) {
        try {
            const res = await fetch(currentUrl, {
                method: 'HEAD',
                redirect: 'manual',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Referer': 'https://snapdouyin.app/down/',
                    'Accept': '*/*',
                    'Accept-Language': 'en-US,en;q=0.9',
                    'Cache-Control': 'no-cache',
                    'X-Session-ID': sessionId,
                    ...(cookieHeader ? { 'Cookie': cookieHeader } : {})
                }
            });

            const status = res.status;
            const location = res.headers.get('location');

            if (cdnDomains.some(d => currentUrl.includes(d))) return currentUrl;

            if (status >= 300 && status < 400 && location) {
                let nextUrl = location;
                if (!nextUrl.startsWith('http')) {
                    nextUrl = 'https://snapdouyin.app' + location;
                }
                if (cdnDomains.some(d => nextUrl.includes(d))) return nextUrl;
                currentUrl = nextUrl;
            } else {
                break;
            }
        } catch (e) {
            break;
        }
    }

    return currentUrl;
}

// Main function
async function getDouyinDownloadUrl(douyinUrl) {
    const normalizedUrl = normalizeUrl(douyinUrl);

    try {
        console.log(`[Douyin] Fetching SnapDouyin API...`);
        const startTime = Date.now();

        const { data, cookieHeader, sessionId } = await getSnapDouyinData(normalizedUrl);

        if (!data?.medias || !Array.isArray(data.medias) || data.medias.length === 0) {
            console.log(`[Douyin] No medias in response`);
            return null;
        }

        // Resolve CDN URL untuk media yang masih di snapdouyin.app
        for (const media of data.medias) {
            if (media.url?.includes('snapdouyin.app')) {
                const resolved = await resolveSnapUrl(media.url, cookieHeader, sessionId);
                if (resolved) media.url = resolved;
            }
        }

        // Pilih quality: hd > sd > watermark (skip original karena terlalu besar)
        const qualityOrder = ['hd', 'sd', 'watermark'];
        let selected = null;

        for (const quality of qualityOrder) {
            selected = data.medias.find(m =>
                m.quality === quality &&
                m.videoAvailable === true &&
                m.extension === 'mp4' &&
                m.url?.startsWith('http')
            );
            if (selected) break;
        }

        // Fallback: video mp4 valid pertama (bukan original)
        if (!selected) {
            selected = data.medias.find(m =>
                m.quality !== 'original' &&
                m.videoAvailable === true &&
                m.extension === 'mp4' &&
                m.url?.startsWith('http')
            );
        }

        if (!selected) {
            console.log(`[Douyin] No valid video URL found`);
            return null;
        }

        const duration = Date.now() - startTime;
        console.log(`[Douyin] ✓ Quality: ${selected.quality} | Size: ${selected.formattedSize} | ${duration}ms`);

        return {
            downloadUrl: selected.url,
            quality: selected.quality,
            size: selected.formattedSize,
            judul: data.title || 'Douyin Video',
            thumbnail: data.thumbnail || null
        };

    } catch (error) {
        console.log(`[Douyin] Error: ${error.message}`);
        return null;
    }
}

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    const douyinUrl = args && args.length > 0 ? args.join(' ').trim() : '';

    if (!douyinUrl) {
        let prefix = usedPrefix;
        if (!prefix && m.text) {
            const match = m.text.match(/^([.!#/])/);
            prefix = match ? match[1] : '.';
        }
        prefix = prefix || '.';
        const cmd = command || 'douyin';

        return m.reply(`*📥 Format Douyin Downloader:*

🔹 Download: ${prefix}${cmd} url_douyin

*Contoh:*
${prefix}${cmd} https://v.douyin.com/iPHW24DE/
${prefix}${cmd} https://www.douyin.com/video/1234567890
${prefix}${cmd} v.douyin.com/iPHW24DE/

*Supported Douyin URLs:*
- v.douyin.com/*
- www.douyin.com/*
- m.douyin.com/*
- **Semua URL yang mengandung douyin.com**

*URL bisa dengan atau tanpa https://*`);
    }

    if (!isValidDouyinUrl(douyinUrl)) {
        return m.reply('❌ URL bukan dari Douyin. Pastikan URL mengandung douyin.com');
    }

    try {
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    } catch (e) {
        console.log('Gagal menambahkan reaksi:', e);
    }

    try {
        const result = await getDouyinDownloadUrl(douyinUrl);

        if (!result || !result.downloadUrl) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply('❌ Gagal mengambil video. Coba lagi nanti.');
        }

        const response = await fetch(result.downloadUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Referer': 'https://www.douyin.com/'
            }
        });

        if (!response.ok) throw new Error(`Download gagal: ${response.status}`);

        const arrayBuffer = await response.arrayBuffer();
        const buffer = Buffer.from(arrayBuffer);

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

        await conn.sendMessage(m.chat, {
            video: buffer,
            mimetype: 'video/mp4',
            caption: `📥 *${result.judul}*\n🎬 Quality: ${result.quality?.toUpperCase()} | 📦 Size: ${result.size}`
        });

    } catch (error) {
        console.error('Error downloading Douyin video:', error);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        return m.reply('❌ Terjadi kesalahan saat mendownload video.');
    }
};

handler.help = ["douyin", "dy", "douyindl"];
handler.tags = ["downloader"];
handler.command = ["douyin", "dy", "douyindl", "douyindown"];

export default handler;