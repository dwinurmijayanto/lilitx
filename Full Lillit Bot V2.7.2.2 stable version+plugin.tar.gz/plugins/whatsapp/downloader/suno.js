const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

console.log('[Suno Handler] Loading handler...');

// ========== SUNO DOWNLOAD HANDLER ==========
const SUNO_CDN_URL = 'https://cdn1.suno.ai/';

const TIMEOUT_MS = 15000; // 15 detik timeout untuk download audio
const AUTO_DELETE_TIMEOUT = 60 * 60 * 1000; // 1 jam (3600000 ms)

const DOWNLOAD_DIR = './downloads/suno/';

// Map untuk menyimpan reference timeout setiap file
const deleteTimeoutMap = new Map();

function extractSunoId(url) {
    // Format: https://suno.com/song/8b468d39-8c5a-41ca-b3ba-f6e92919aab9
    const match = url.match(/suno\.com\/song\/([a-f0-9\-]+)/i);
    
    if (!match || !match[1]) {
        return null;
    }
    
    return match[1];
}

function validateSunoId(id) {
    // UUID v4 format: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
    const uuidRegex = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
    return uuidRegex.test(id);
}

async function fetchSunoAudio(sunoId) {
    console.log(`[Suno Handler] Attempting to fetch audio for ID: ${sunoId}`);
    
    try {
        const audioUrl = `${SUNO_CDN_URL}${sunoId}.mp3`;
        console.log(`[Suno Handler] Trying CDN: ${audioUrl}`);
        
        const fetchPromise = fetch(audioUrl);
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error(`Timeout setelah ${TIMEOUT_MS}ms`)), TIMEOUT_MS)
        );
        
        const response = await Promise.race([fetchPromise, timeoutPromise]);
        
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status}`);
        }
        
        // Check content length
        const contentLength = response.headers.get('content-length');
        console.log(`[Suno Handler] ✅ Audio found, size: ${contentLength} bytes`);
        
        const buffer = await response.buffer();
        return { buffer, size: contentLength, url: audioUrl };
        
    } catch (error) {
        console.error(`[Suno Handler] ❌ CDN failed:`, error.message);
        throw new Error(`Gagal mengunduh audio. Error: ${error.message}`);
    }
}

function ensureDownloadDir() {
    try {
        if (!fs.existsSync(DOWNLOAD_DIR)) {
            fs.mkdirSync(DOWNLOAD_DIR, { recursive: true });
            console.log(`[Suno Handler] Download directory created: ${DOWNLOAD_DIR}`);
        }
    } catch (error) {
        console.error(`[Suno Handler] Failed to create download directory:`, error.message);
    }
}

function scheduleFileDelete(filePath, sunoId) {
    // Clear timeout lama jika ada
    if (deleteTimeoutMap.has(sunoId)) {
        clearTimeout(deleteTimeoutMap.get(sunoId));
    }
    
    // Set timeout baru untuk delete file
    const timeoutId = setTimeout(() => {
        try {
            if (fs.existsSync(filePath)) {
                fs.unlinkSync(filePath);
                console.log(`[Suno Handler] ✅ Auto-deleted: ${filePath} (setelah ${AUTO_DELETE_TIMEOUT / 1000 / 60} menit)`);
                deleteTimeoutMap.delete(sunoId);
            }
        } catch (error) {
            console.error(`[Suno Handler] ❌ Failed to delete file ${filePath}:`, error.message);
        }
    }, AUTO_DELETE_TIMEOUT);
    
    // Simpan reference timeout
    deleteTimeoutMap.set(sunoId, timeoutId);
    
    console.log(`[Suno Handler] ⏰ File akan dihapus otomatis dalam ${AUTO_DELETE_TIMEOUT / 1000 / 60} menit`);
}

function generateUsageHelp(prefix, cmd) {
    return `*🎵 SUNO DOWNLOADER*

📌 *Cara Penggunaan:*
${prefix}${cmd} <URL atau ID Suno>

📋 *Format yang Diterima:*
• URL lengkap: ${prefix}${cmd} https://suno.com/song/8b468d39-8c5a-41ca-b3ba-f6e92919aab9
• ID Suno: ${prefix}${cmd} 8b468d39-8c5a-41ca-b3ba-f6e92919aab9

⏰ *Info:* File akan dihapus otomatis setelah 1 jam`;
}

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    let prefix = usedPrefix;
    if (!prefix && m.text) {
        const match = m.text.match(/^([.!#/])/);
        prefix = match ? match[1] : '.';
    }
    prefix = prefix || '.';
    
    const cmd = command || 'suno';
    
    let inputText = '';
    if (text) {
        inputText = text.trim();
    } else if (args && args.length > 0) {
        inputText = args.join(' ').trim();
    }
    
    console.log(`[Suno Handler] Command triggered - prefix: ${prefix}, cmd: ${cmd}, text: ${inputText}`);
    
    // Help command
    if (!inputText || inputText.toLowerCase() === 'help' || inputText === '?') {
        console.log('[Suno Handler] Help requested');
        return m.reply(generateUsageHelp(prefix, cmd));
    }
    
    // Extract Suno ID dari URL atau langsung ID
    let sunoId = null;
    
    if (inputText.includes('suno.com')) {
        sunoId = extractSunoId(inputText);
    } else {
        sunoId = inputText;
    }
    
    // Validate Suno ID format
    if (!sunoId || !validateSunoId(sunoId)) {
        return m.reply(`❌ Format tidak valid!\n\n💡 Gunakan salah satu format:\n\n1. URL: ${prefix}${cmd} https://suno.com/song/8b468d39-8c5a-41ca-b3ba-f6e92919aab9\n\n2. ID: ${prefix}${cmd} 8b468d39-8c5a-41ca-b3ba-f6e92919aab9\n\n📌 Ketik ${prefix}${cmd} help untuk panduan lengkap`);
    }
    
    console.log('[Suno Handler] Valid Suno ID:', sunoId);
    
    try {
        // Send initial reaction
        await conn.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });
        
        // Download audio
        console.log('[Suno Handler] Starting audio download...');
        
        const audioData = await fetchSunoAudio(sunoId);
        
        // Ensure download directory exists
        ensureDownloadDir();
        
        // Save to file
        const fileName = `${sunoId}.mp3`;
        const filePath = path.join(DOWNLOAD_DIR, fileName);
        
        fs.writeFileSync(filePath, audioData.buffer);
        console.log(`[Suno Handler] Audio saved to: ${filePath}`);
        
        // Schedule auto delete
        scheduleFileDelete(filePath, sunoId);
        
        // Send audio file
        console.log('[Suno Handler] Sending audio file to chat...');
        
        await conn.sendMessage(m.chat, {
            audio: { url: filePath },
            mimetype: 'audio/mpeg',
            ptt: false,
            waveform: [100, 0, 100, 0, 100],
            fileName: `${sunoId}.mp3`
        }, { quoted: m });
        
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
        console.log('[Suno Handler] Download completed successfully');
        
    } catch (error) {
        console.error('[Suno Handler] ERROR:', error);
        console.error('[Suno Handler] Stack:', error.stack);
        
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        
        let errorMsg = '❌ Terjadi kesalahan saat mengunduh lagu.\n\n';
        
        if (error.message.includes('Timeout')) {
            errorMsg += `⚠️ Timeout: CDN tidak merespons dalam ${TIMEOUT_MS}ms\n💡 Coba lagi dalam beberapa saat`;
        } else if (error.message.includes('404')) {
            errorMsg += '⚠️ Lagu tidak ditemukan\n💡 Pastikan ID Suno benar';
        } else if (error.message.includes('gagal mengunduh')) {
            errorMsg += '⚠️ CDN tidak dapat diakses\n💡 Coba lagi nanti';
        } else {
            errorMsg += `⚠️ Error: ${error.message}\n💡 Coba lagi atau ketik ${prefix}${cmd} help`;
        }
        
        return m.reply(errorMsg);
    }
};

handler.help = ["suno <url|id>"];
handler.tags = ["downloader", "tools"];
handler.command = ["suno", "sunoai"];
handler.limit = true;

console.log('[Suno Handler] Handler loaded successfully');

export default handler;