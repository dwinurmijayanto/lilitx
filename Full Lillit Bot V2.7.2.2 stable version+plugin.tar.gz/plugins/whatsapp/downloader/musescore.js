import axios from 'axios';
import { zencf } from 'zencf';

const cache = new Map();
const CACHE_TTL = 5 * 60 * 1000;

function getCachedData(key) {
    const cached = cache.get(key);
    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
        return cached.data;
    }
    if (cached) cache.delete(key);
    return null;
}

function setCachedData(key, data) {
    cache.set(key, { data, timestamp: Date.now() });
    if (cache.size > 100) {
        const firstKey = cache.keys().next().value;
        cache.delete(firstKey);
    }
}

function isValidMuseScoreUrl(url) {
    return /musescore\.com\/.*\/scores\/\d+/.test(url);
}

function extractScoreId(url) {
    const match = url.match(/scores\/(\d+)/);
    return match ? match[1] : null;
}

class NanomidiScraper {
    constructor() {
        this.baseURL = 'https://api.nanomidi.net';
        this.cfToken = null;
    }

    async generateCFToken() {
        const { token } = await zencf.turnstileMax('https://nanomidi.net/musescore-downloader');
        this.cfToken = token;
        return this.cfToken;
    }

    getHeaders() {
        return {
            'accept': '*/*',
            'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'origin': 'https://nanomidi.net',
            'referer': 'https://nanomidi.net/',
            'sec-ch-ua': '"Not(A:Brand";v="8", "Chromium";v="144", "Google Chrome";v="144"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'user-agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Mobile Safari/537.36'
        };
    }

    async downloadMuseScore(url, type = 'midi', refetch = false) {
        const scoreId = extractScoreId(url);
        if (scoreId && !refetch) {
            const cached = getCachedData(`musescore_${scoreId}_${type}`);
            if (cached) return cached;
        }

        await this.generateCFToken();

        const params = {
            url: url,
            type: type,
            token: this.cfToken,
            refetch: refetch
        };

        try {
            const response = await axios.get(`${this.baseURL}/api/musescore-downloader`, {
                headers: this.getHeaders(),
                params: params,
                timeout: 30000
            });

            const result = response.data;
            
            if (scoreId) {
                setCachedData(`musescore_${scoreId}_${type}`, result);
            }

            return result;
        } catch (error) {
            return { error: error.message };
        }
    }
}

let processingUsers = new Set();

let handler = async (m, { conn, args, usedPrefix, command }) => {
    const userId = m.sender;
    
    if (processingUsers.has(userId)) {
        return m.reply('⏳ Tunggu proses sebelumnya...');
    }
    
    const input = args && args.length > 0 ? args.join(' ').trim() : '';
    
    if (!input) {
        return m.reply(`*MuseScore Downloader*

Gunakan: ${usedPrefix}${command} <url>

Contoh:
${usedPrefix}${command} https://musescore.com/user/39593079/scores/6977564

Format: midi (default) atau mp3`);
    }
    
    const parts = input.split(' ');
    const url = parts[0];
    const type = parts[1] || 'midi';
    
    if (!isValidMuseScoreUrl(url)) {
        return m.reply('❌ URL MuseScore tidak valid');
    }
    
    if (!['midi', 'mp3'].includes(type.toLowerCase())) {
        return m.reply('❌ Format harus midi atau mp3');
    }
    
    processingUsers.add(userId);
    
    try {
        await conn.sendMessage(m.chat, {
            react: { text: '⏳', key: m.key }
        });
        
        const scraper = new NanomidiScraper();
        const result = await scraper.downloadMuseScore(url, type.toLowerCase(), false);
        
        if (result.error) {
            await conn.sendMessage(m.chat, {
                react: { text: '❌', key: m.key }
            });
            return m.reply(`❌ Download gagal: ${result.error}`);
        }
        
        if (!result.url) {
            throw new Error('URL download tidak ditemukan');
        }
        
        const caption = `*MuseScore Download*\n\n` +
                       `📝 Title: ${result.title || 'N/A'}\n` +
                       `👤 Author: ${result.author || 'N/A'}\n` +
                       `🎵 Format: ${type.toUpperCase()}`;
        
        if (type.toLowerCase() === 'mp3') {
            const response = await axios.get(result.url, { 
                responseType: 'arraybuffer',
                timeout: 60000
            });
            
            await conn.sendMessage(m.chat, {
                audio: Buffer.from(response.data),
                mimetype: 'audio/mpeg',
                fileName: `${result.title || 'musescore'}.mp3`,
                caption: caption
            }, { quoted: m });
        } else {
            const response = await axios.get(result.url, { 
                responseType: 'arraybuffer',
                timeout: 60000
            });
            
            await conn.sendMessage(m.chat, {
                document: Buffer.from(response.data),
                mimetype: 'audio/midi',
                fileName: `${result.title || 'musescore'}.mid`,
                caption: caption
            }, { quoted: m });
        }
        
        await conn.sendMessage(m.chat, {
            react: { text: '✅', key: m.key }
        });
        
    } catch (error) {
        console.error('Error:', error);
        await conn.sendMessage(m.chat, {
            react: { text: '❌', key: m.key }
        });
        m.reply(`❌ Error: ${error.message}`);
    } finally {
        processingUsers.delete(userId);
    }
};

handler.help = ["musescore"];
handler.tags = ["downloader"];
handler.command = ["musescore", "midi"];
handler.limit = true;
handler.register = false;

export default handler;