const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));
import axios from "axios";
import { sizeFormatter } from "human-readable";

console.log('[Streamable Handler] Loading optimized handler...');

// ========== FORMAT SIZE ==========
const formatSize = sizeFormatter({
  std: "JEDEC",
  decimalPlaces: 2,
  keepTrailingZeroes: false,
  render: (literal, symbol) => `${literal} ${symbol}B`,
});

// ========== EXTRACT STREAMABLE ID ==========
function extractStreamableId(url) {
    try {
        const patterns = [
            /streamable\.com\/([a-zA-Z0-9]+)/i,
            /streamabledl\.com\/([a-zA-Z0-9]+)/i
        ];
        
        for (const pattern of patterns) {
            const match = url.match(pattern);
            if (match && match[1]) {
                return match[1];
            }
        }
        
        if (/^[a-zA-Z0-9]+$/.test(url)) {
            return url;
        }
        
        return null;
    } catch (error) {
        console.error('[Error] Extract ID:', error.message);
        return null;
    }
}

// ========== FAST DISCOVERY: Direct Streamable API Only ==========
async function getStreamableInfo(videoId) {
    try {
        console.log('[Fast Discovery] Getting info for:', videoId);
        const url = `https://api.streamable.com/videos/${videoId}`;
        
        const response = await fetch(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0',
                'Accept': 'application/json'
            },
            timeout: 10000
        });
        
        const data = await response.json();
        console.log('[Fast Discovery] Response received');
        
        if (!data.files || !data.files.mp4 || !data.files.mp4.url) {
            throw new Error('Video URL not found in API response');
        }
        
        // Fix thumbnail URL if it starts with //
        let thumbnailUrl = data.thumbnail_url;
        if (thumbnailUrl && thumbnailUrl.startsWith('//')) {
            thumbnailUrl = 'https:' + thumbnailUrl;
        }
        
        return {
            success: true,
            videoUrl: data.files.mp4.url,
            title: data.title || `Video ${videoId}`,
            thumbnail: thumbnailUrl,
            width: data.files.mp4.width || 0,
            height: data.files.mp4.height || 0,
            videoId: videoId
        };
        
    } catch (error) {
        console.error('[Fast Discovery] Error:', error.message);
        throw new Error('Tidak dapat mengakses informasi video dari Streamable API');
    }
}

// ========== DOWNLOAD VIDEO (Optimized) ==========
async function downloadVideo(videoUrl, videoId) {
    try {
        console.log('[Download] Starting download...');
        
        if (!videoUrl || videoUrl.trim() === '') {
            throw new Error('Video URL kosong');
        }
        
        const response = await axios.get(videoUrl, {
            responseType: "arraybuffer",
            timeout: 120000, // 2 minutes max
            maxContentLength: 500 * 1024 * 1024,
            maxBodyLength: 500 * 1024 * 1024,
            headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Accept": "*/*",
                "Referer": "https://streamable.com/"
            }
        });
        
        const buffer = Buffer.from(response.data);
        const mimeType = response.headers["content-type"] || "video/mp4";
        const actualSize = formatSize(buffer.length);
        const filename = `streamable_${videoId}.mp4`;
        
        console.log('[Download] Complete! Size:', actualSize);
        
        return {
            success: true,
            buffer: buffer,
            mimeType: mimeType,
            actualSize: actualSize,
            filename: filename
        };
        
    } catch (error) {
        console.error('[Download] Error:', error.message);
        throw new Error('Gagal mendownload video: ' + error.message);
    }
}

// ========== DOWNLOAD THUMBNAIL (Optimized) ==========
async function downloadThumbnail(thumbnailUrl) {
    if (!thumbnailUrl || thumbnailUrl.trim() === '') {
        return null;
    }
    
    try {
        console.log('[Thumbnail] Downloading...');
        
        const response = await axios.get(thumbnailUrl, {
            responseType: "arraybuffer",
            timeout: 15000,
            headers: {
                "User-Agent": "Mozilla/5.0",
                "Accept": "image/*",
                "Referer": "https://streamable.com/"
            }
        });
        
        return Buffer.from(response.data);
    } catch (error) {
        console.log('[Thumbnail] Skip (error)');
        return null;
    }
}

// ========== FORMAT VIDEO CAPTION ==========
function formatVideoCaption(data, actualSize, mimeType, filename) {
    const { title, width, height, videoId } = data;
    const resolution = `${width}x${height}`;
    
    return `┌─「 📹 *Video Info* 」
├ 🎥 Judul: ${title}
├ 📊 Ukuran: ${actualSize}
├ 📐 Resolusi: ${resolution}
├ 📝 Type: ${mimeType}
├ 🆔 Video ID: ${videoId}
└ 📎 File: ${filename}`;
}

// ========== GENERATE USAGE HELP ==========
function generateUsageHelp(prefix, cmd) {
    return `*🎬 STREAMABLE DOWNLOADER*

📌 *Cara Penggunaan:*
${prefix}${cmd} [link streamable]

✨ *Fitur:*
- Download video dari Streamable
- Fast processing dengan Direct API
- Kualitas HD (jika tersedia)
- Include thumbnail preview

📋 *Contoh:*
${prefix}${cmd} https://streamable.com/wild20
${prefix}${cmd} wild20
${prefix}${cmd} https://streamabledl.com/wild20

⚠️ *Catatan:*
- Support video hingga 500MB
- Proses cepat dan efisien
- Thumbnail otomatis jika tersedia

💡 *Tips:*
- Gunakan koneksi internet yang stabil
- Video besar membutuhkan waktu lebih lama`;
}

// ========== VALIDATE STREAMABLE URL ==========
function isValidStreamableUrl(url) {
    const streamablePattern = /^(https?:\/\/)?(www\.)?(streamable\.com|streamabledl\.com)\/[a-zA-Z0-9]+/i;
    const idPattern = /^[a-zA-Z0-9]{4,12}$/;
    return streamablePattern.test(url) || idPattern.test(url);
}

// ========== MAIN HANDLER (Optimized) ==========
let handler = async function(m, options) {
    const { conn, text, args, usedPrefix, command } = options;
    
    let prefix = usedPrefix;
    if (!prefix && m.text) {
        const match = m.text.match(/^([.!#/])/);
        prefix = match ? match[1] : '.';
    }
    prefix = prefix || '.';
    
    const cmd = command || 'streamable';
    
    let url = '';
    if (text) {
        url = text.trim();
    } else if (args && args.length > 0) {
        url = args[0].trim();
    }
    
    console.log(`[Handler] Command: ${cmd}, URL: ${url}`);
    
    if (!url || url.toLowerCase() === 'help' || url === '?') {
        return m.reply(generateUsageHelp(prefix, cmd));
    }
    
    if (!isValidStreamableUrl(url)) {
        return m.reply(`❌ Link tidak valid!\n\n💡 Format yang benar:\n• ${prefix}${cmd} https://streamable.com/wild20\n• ${prefix}${cmd} wild20\n\n📌 Pastikan link dari Streamable!`);
    }
    
    try {
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        // Step 1: Get video info (Fast)
        const videoId = extractStreamableId(url);
        if (!videoId) {
            throw new Error('Tidak dapat mengekstrak video ID');
        }
        
        console.log('[Handler] Getting info...');
        const videoInfo = await getStreamableInfo(videoId);
        
        if (!videoInfo.success) {
            throw new Error('Gagal mendapatkan informasi video');
        }
        
        // Step 2: Download video
        console.log('[Handler] Downloading video...');
        await conn.sendMessage(m.chat, { react: { text: '📥', key: m.key } });
        
        const downloadResult = await downloadVideo(videoInfo.videoUrl, videoId);
        
        if (!downloadResult.success) {
            throw new Error('Gagal mendownload video');
        }
        
        // Step 3: Download thumbnail (parallel, non-blocking)
        console.log('[Handler] Getting thumbnail...');
        const thumbnailPromise = videoInfo.thumbnail 
            ? downloadThumbnail(videoInfo.thumbnail) 
            : Promise.resolve(null);
        
        // Step 4: Send video
        console.log('[Handler] Sending video...');
        await conn.sendMessage(m.chat, { react: { text: '📤', key: m.key } });
        
        const caption = formatVideoCaption(
            videoInfo,
            downloadResult.actualSize,
            downloadResult.mimeType,
            downloadResult.filename
        );
        
        const thumbnailBuffer = await thumbnailPromise;
        
        const messageOptions = {
            video: downloadResult.buffer,
            mimetype: downloadResult.mimeType,
            fileName: downloadResult.filename,
            caption: caption
        };
        
        if (thumbnailBuffer) {
            messageOptions.jpegThumbnail = thumbnailBuffer;
        }
        
        await conn.sendMessage(m.chat, messageOptions, { quoted: m });
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
        console.log('[Handler] ✅ Complete!');
        
    } catch (error) {
        console.error('[Handler] Error:', error.message);
        
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        
        let errorMsg = '❌ *Terjadi kesalahan*\n\n';
        
        if (error.message.includes('API')) {
            errorMsg += '⚠️ Tidak dapat mengakses Streamable API\n';
            errorMsg += '└ Video mungkin private atau dihapus\n\n';
            errorMsg += '💡 Pastikan video masih tersedia';
        } else if (error.message.includes('timeout')) {
            errorMsg += '⚠️ Timeout\n';
            errorMsg += '└ Koneksi terlalu lambat\n\n';
            errorMsg += '💡 Coba lagi dengan koneksi lebih baik';
        } else if (error.message.includes('download')) {
            errorMsg += '⚠️ Gagal mendownload\n';
            errorMsg += '└ ' + error.message + '\n\n';
            errorMsg += '💡 Coba beberapa saat lagi';
        } else {
            errorMsg += `⚠️ ${error.message}\n\n`;
            errorMsg += '💡 Coba lagi atau hubungi admin';
        }
        
        return m.reply(errorMsg);
    }
};

handler.help = ["streamable [link]"];
handler.tags = ["downloader"];
handler.command = ["streamable", "stream", "streamdl", "stdl"];
handler.limit = true;

console.log('[Handler] Loaded (Optimized Fast Mode)');
console.log('[Handler] Commands:', handler.command.join(', '));

export default handler;