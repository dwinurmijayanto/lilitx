import fetch from 'node-fetch';
import { downloadContentFromMessage } from 'baileys';
import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const execPromise = promisify(exec);

console.log('[Video to Voice Handler] Loading handler...');

// ========== CONFIGURATION ==========
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const TEMP_DIR = path.join(__dirname, '../tmp');
const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB
const TIMEOUT_MS = 60000; // 60 detik timeout untuk konversi

// Pastikan temp directory ada
if (!fs.existsSync(TEMP_DIR)) {
    fs.mkdirSync(TEMP_DIR, { recursive: true });
}

// ========== DOWNLOAD MEDIA FUNCTION ==========
/**
 * Download video dari Baileys message
 * @param {Object} message - Raw Baileys message object
 * @returns {Buffer|null} - Media buffer atau null jika gagal
 */
async function downloadVideo(message) {
    try {
        const mimeMap = {
            videoMessage: 'video'
        };

        const msgKeys = Object.keys(message || {});
        if (msgKeys.length === 0) return null;

        const type = msgKeys[0];
        if (!type) return null;

        const m = message[type];
        if (!m) return null;

        const mediaType = mimeMap[type];
        if (!mediaType) return null;

        console.log('[Video to Voice Handler] Downloading video...');
        
        // Download media menggunakan Baileys
        const stream = await downloadContentFromMessage(m, mediaType);
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        
        const buffer = Buffer.concat(chunks);
        console.log(`[Video to Voice Handler] Video downloaded, size: ${buffer.length} bytes`);
        
        return buffer;
    } catch (error) {
        console.error('[Video to Voice Handler] Error downloading video:', error);
        return null;
    }
}

// ========== CONVERSION FUNCTIONS ==========
/**
 * Konversi video ke audio menggunakan FFmpeg
 * @param {Buffer} videoBuffer - Buffer video
 * @param {string} outputFormat - Format output (opus/mp3)
 * @returns {Object} - Result object dengan audio buffer atau error
 */
async function convertVideoToAudio(videoBuffer, outputFormat = 'opus') {
    const tempVideoPath = path.join(TEMP_DIR, `video_${Date.now()}.mp4`);
    const tempAudioPath = path.join(TEMP_DIR, `audio_${Date.now()}.${outputFormat}`);
    
    try {
        // Validasi ukuran file
        if (videoBuffer.length > MAX_FILE_SIZE) {
            throw new Error(`File terlalu besar! Max ${MAX_FILE_SIZE / 1024 / 1024}MB`);
        }
        
        console.log('[Video to Voice Handler] Writing temp video file...');
        fs.writeFileSync(tempVideoPath, videoBuffer);
        
        console.log('[Video to Voice Handler] Converting video to audio...');
        
        // FFmpeg command untuk ekstrak audio
        // Untuk voice note WhatsApp, gunakan format Opus dengan codec libopus
        let ffmpegCmd;
        if (outputFormat === 'opus') {
            ffmpegCmd = `ffmpeg -i "${tempVideoPath}" -vn -c:a libopus -b:a 64k -ar 48000 -ac 1 "${tempAudioPath}"`;
        } else {
            ffmpegCmd = `ffmpeg -i "${tempVideoPath}" -vn -c:a libmp3lame -b:a 128k -ar 44100 "${tempAudioPath}"`;
        }
        
        // Jalankan FFmpeg dengan timeout
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error(`Timeout setelah ${TIMEOUT_MS}ms`)), TIMEOUT_MS)
        );
        
        const conversionPromise = execPromise(ffmpegCmd);
        
        await Promise.race([conversionPromise, timeoutPromise]);
        
        console.log('[Video to Voice Handler] Conversion complete, reading output...');
        
        // Baca hasil konversi
        if (!fs.existsSync(tempAudioPath)) {
            throw new Error('File audio tidak ditemukan setelah konversi');
        }
        
        const audioBuffer = fs.readFileSync(tempAudioPath);
        const audioSize = audioBuffer.length;
        
        console.log(`[Video to Voice Handler] Audio created, size: ${audioSize} bytes`);
        
        // Cleanup temp files
        try {
            fs.unlinkSync(tempVideoPath);
            fs.unlinkSync(tempAudioPath);
        } catch (e) {
            console.error('[Video to Voice Handler] Cleanup error:', e.message);
        }
        
        return {
            success: true,
            buffer: audioBuffer,
            size: audioSize,
            format: outputFormat
        };
        
    } catch (error) {
        console.error('[Video to Voice Handler] Conversion failed:', error.message);
        
        // Cleanup temp files on error
        try {
            if (fs.existsSync(tempVideoPath)) fs.unlinkSync(tempVideoPath);
            if (fs.existsSync(tempAudioPath)) fs.unlinkSync(tempAudioPath);
        } catch (e) {
            console.error('[Video to Voice Handler] Cleanup error:', e.message);
        }
        
        return {
            success: false,
            message: error.message
        };
    }
}

// ========== FORMAT FUNCTIONS ==========
/**
 * Generate help message
 * @param {string} prefix - Command prefix
 * @param {string} cmd - Command name
 * @returns {string} - Help message
 */
function generateUsageHelp(prefix, cmd) {
    return `*🎙️ VIDEO TO VOICE NOTE*

📌 *Cara Penggunaan:*

*1. Reply Video:*
Reply video, lalu ketik: ${prefix}${cmd}

*2. Kirim Langsung:*
Kirim video dengan caption: ${prefix}${cmd}

📋 *Supported Formats:*
- MP4
- AVI
- MKV
- MOV
- WEBM
- Dan format video lainnya

⚙️ *Fitur:*
- Auto extract audio dari video
- Konversi ke format voice note WhatsApp
- Kompatibel dengan semua device
- Kualitas audio optimal

⚠️ *Batasan:*
- Max file size: ${MAX_FILE_SIZE / 1024 / 1024}MB
- Requires FFmpeg di server

*Contoh:*
Reply video → ${prefix}${cmd}
`;
}

/**
 * Format ukuran file
 * @param {number} bytes - Ukuran dalam bytes
 * @returns {string} - Formatted size
 */
function formatSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    // Deteksi prefix dan command
    let prefix = usedPrefix || '.';
    const cmd = command || 'tovn';
    
    try {
        // Ambil input text
        let inputText = '';
        if (text) {
            inputText = text.trim();
        } else if (args && args.length > 0) {
            inputText = args.join(' ').trim();
        }
        
        // Cek apakah user minta help
        if (inputText.toLowerCase() === 'help' || inputText === '?') {
            return m.reply(generateUsageHelp(prefix, cmd));
        }
        
        // React dengan emoji untuk menunjukkan proses dimulai
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        let videoBuffer = null;
        let mime = '';
        
        // ========== EXTRACT RAW MESSAGE & CONTEXT INFO ==========
        let rawMessage = m.message;
        let contextInfo = null;
        let quotedMessage = null;
        
        // Extract contextInfo berdasarkan tipe message
        if (rawMessage) {
            if (rawMessage.extendedTextMessage) {
                contextInfo = rawMessage.extendedTextMessage.contextInfo;
            } else if (rawMessage.videoMessage) {
                contextInfo = rawMessage.videoMessage.contextInfo;
            }
            
            // Extract quoted message dari contextInfo
            if (contextInfo) {
                quotedMessage = contextInfo.quotedMessage;
            }
        }
        
        // ========== GET VIDEO ==========
        // Check 1: Direct video message (video dikirim dengan caption)
        if (rawMessage?.videoMessage) {
            console.log('[Video to Voice Handler] Processing direct video');
            mime = rawMessage.videoMessage.mimetype || 'video/mp4';
            videoBuffer = await downloadVideo(rawMessage);
        }
        // Check 2: Quoted video (reply video)
        else if (quotedMessage?.videoMessage) {
            console.log('[Video to Voice Handler] Processing quoted video');
            mime = quotedMessage.videoMessage.mimetype || 'video/mp4';
            videoBuffer = await downloadVideo(quotedMessage);
        }
        // Check 3: Fallback ke m.quoted (jika ada di store)
        else if (m.quoted?.message?.videoMessage) {
            console.log('[Video to Voice Handler] Processing from m.quoted');
            mime = m.quoted.message.videoMessage.mimetype || 'video/mp4';
            videoBuffer = await downloadVideo(m.quoted.message);
        }
        else {
            console.log('[Video to Voice Handler] No video found');
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            
            return m.reply(`❌ Tidak ada video yang ditemukan!\n\n💡 Cara penggunaan:\n\n*Reply Video:*\nReply video, lalu ketik: ${prefix}${cmd}\n\n*Kirim Langsung:*\nKirim video dengan caption: ${prefix}${cmd}\n\n📌 Ketik ${prefix}${cmd} help untuk panduan lengkap`);
        }
        
        // Validasi video buffer
        if (!videoBuffer) {
            console.error('[Video to Voice Handler] Failed to download video');
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply('❌ Gagal mendownload video!\n💡 Coba lagi atau pastikan file adalah video yang valid.');
        }
        
        // Validasi format video
        if (!/video\/(mp4|avi|mkv|mov|webm|3gp|flv)/.test(mime)) {
            console.error('[Video to Voice Handler] Unsupported format:', mime);
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply('⚠️ Format tidak didukung!\n💡 Hanya video format: mp4, avi, mkv, mov, webm, 3gp, flv.');
        }
        
        // ========== CONVERT VIDEO TO AUDIO ==========
        const result = await convertVideoToAudio(videoBuffer, 'opus');
        
        if (!result.success) {
            console.error('[Video to Voice Handler] Conversion failed:', result.message);
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            
            let errorMsg = '❌ Gagal mengkonversi video!\n\n';
            
            if (result.message.includes('FFmpeg')) {
                errorMsg += '⚠️ FFmpeg tidak tersedia di server.\n💡 Hubungi admin untuk install FFmpeg.';
            } else if (result.message.includes('terlalu besar')) {
                errorMsg += `⚠️ File terlalu besar!\n💡 Max size: ${MAX_FILE_SIZE / 1024 / 1024}MB`;
            } else {
                errorMsg += `⚠️ Error: ${result.message}`;
            }
            
            return m.reply(errorMsg);
        }
        
        // ========== SEND VOICE NOTE ==========
        console.log('[Video to Voice Handler] Sending voice note...');
        
        try {
            // Kirim voice note dengan caption info sekaligus
            const infoMsg = `✅ *Konversi Berhasil!*\n\n` +
                           `📊 *Info:*\n` +
                           `├ 📹 Video: ${formatSize(videoBuffer.length)}\n` +
                           `├ 🎙️ Audio: ${formatSize(result.size)}\n` +
                           `└ 🔊 Format: Voice Note (Opus)`;
            
            await conn.sendMessage(m.chat, {
                audio: result.buffer,
                mimetype: 'audio/ogg; codecs=opus',
                ptt: true,
                waveform: [0,10,20,30,40,50,40,30,20,10,0]
            }, { quoted: m });
            
            // Kirim info sebagai reply ke voice note
            await m.reply(infoMsg);
            
            // React success
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            
            console.log('[Video to Voice Handler] Success!');
            
        } catch (sendError) {
            console.error('[Video to Voice Handler] Failed to send:', sendError);
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply('❌ Gagal mengirim voice note!\n💡 Coba lagi atau file terlalu besar.');
        }
        
    } catch (error) {
        // Error handling
        console.error('[Video to Voice Handler] CRITICAL ERROR:', error.message);
        console.error('[Video to Voice Handler] Stack:', error.stack);
        
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        
        // Kirim pesan error singkat ke user
        return m.reply(`❌ Terjadi kesalahan!\n💡 Coba lagi atau ketik ${usedPrefix || '.'}${command || 'tovn'} help`);
    }
};

// ========== HANDLER PROPERTIES ==========
handler.help = ["tovn (reply/kirim video)"];
handler.tags = ["tools"];
handler.command = ["tovn", "tovideo", "videotonote", "vn", "toaudio"];
handler.limit = true;

console.log('[Video to Voice Handler] Handler loaded successfully');

export default handler;