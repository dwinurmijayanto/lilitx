const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

const cache = new Map();
const CACHE_TTL = 5 * 60 * 1000;

function isValidInstagramUrl(url) {
    return /instagram\.com\/(p|reel|reels|tv)\/[\w-]+/.test(url);
}

function getCachedData(key) {
    const cached = cache.get(key);
    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
        return cached.data;
    }
    if (cached) cache.delete(key);
    return null;
}

function setCachedData(key, data) {
    cache.set(key, { data, timestamp: Date.now() });
    if (cache.size > 100) {
        const firstKey = cache.keys().next().value;
        cache.delete(firstKey);
    }
}

function extractPostId(url) {
    const match = url.match(/\/(p|reel|reels|tv)\/([A-Za-z0-9_-]+)/);
    return match ? match[2] : null;
}

async function igramFetch(url) {
    try {
        const endpoint = 'https://igram.website/content.php?url=' + encodeURIComponent(url);
        
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 20000);
        
        const response = await fetch(endpoint, {
            method: 'POST',
            signal: controller.signal,
            headers: {
                'authority': 'igram.website',
                'accept': '*/*',
                'accept-language': 'id-ID,id;q=0.9',
                'content-type': 'application/x-www-form-urlencoded',
                'referer': 'https://igram.website/',
                'sec-ch-ua': '"Chromium";v="139", "Not;A=Brand";v="99"',
                'sec-ch-ua-mobile': '?1',
                'sec-ch-ua-platform': '"Android"',
                'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36'
            },
            body: ''
        });
        
        clearTimeout(timeout);
        
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        
        const data = await response.json();
        return data;
        
    } catch (error) {
        return { error: error.message };
    }
}

function parseHTML(html) {
    const clean = html.replace(/\n|\t/g, '');
    
    const videoMatch = [...clean.matchAll(/<source src="([^"]+)/g)].map(x => x[1]);
    let imageMatch = [...clean.matchAll(/<img src="([^"]+)/g)].map(x => x[1]);
    
    if (imageMatch.length > 0) imageMatch = imageMatch.slice(1);
    
    const captionRaw = clean.match(/<p class="text-sm"[^>]*>(.*?)<\/p>/);
    const caption = captionRaw ? captionRaw[1].replace(/<br ?\/?>/g, '\n') : '';
    
    return {
        is_video: videoMatch.length > 0,
        videos: videoMatch,
        images: imageMatch,
        caption
    };
}

async function instagramDownload(url) {
    const postId = extractPostId(url);
    if (postId) {
        const cached = getCachedData(`igram_${postId}`);
        if (cached) return cached;
    }
    
    const raw = await igramFetch(url);
    if (!raw || !raw.html) return { error: 'scrape_failed' };
    
    const parsed = parseHTML(raw.html);
    
    const result = {
        status: raw.status,
        username: raw.username,
        type: parsed.is_video ? 'video' : 'image',
        video_url: parsed.is_video && parsed.videos.length > 0 ? parsed.videos[0] : null,
        images: parsed.is_video ? [] : parsed.images,
        caption: parsed.caption
    };
    
    if (postId) setCachedData(`igram_${postId}`, result);
    
    return result;
}

async function downloadMedia(url) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30000);
    
    const response = await fetch(url, { 
        signal: controller.signal,
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
    });
    
    clearTimeout(timeout);
    
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    
    const arrayBuffer = await response.arrayBuffer();
    return Buffer.from(arrayBuffer);
}

let processingUsers = new Set();

let handler = async (m, { conn, args, usedPrefix, command }) => {
    const userId = m.sender;
    
    if (processingUsers.has(userId)) {
        return m.reply('⏳ Tunggu proses sebelumnya...');
    }
    
    const url = args && args.length > 0 ? args.join(' ').trim() : '';
    
    if (!url) {
        return m.reply(`*Instagram Downloader*

Gunakan: ${usedPrefix}${command} <url>

Contoh:
${usedPrefix}${command} instagram.com/p/ABC123`);
    }
    
    if (!isValidInstagramUrl(url)) {
        return m.reply('❌ URL Instagram tidak valid');
    }
    
    processingUsers.add(userId);
    
    try {
        await conn.sendMessage(m.chat, {
            react: { text: '⏳', key: m.key }
        });
        
        const result = await instagramDownload(url);
        
        if (result.error) {
            await conn.sendMessage(m.chat, {
                react: { text: '❌', key: m.key }
            });
            return m.reply(`❌ Download gagal: ${result.error}`);
        }
        
        const caption = result.caption ? `${result.caption.substring(0, 200)}${result.caption.length > 200 ? '...' : ''}` : '';
        
        if (result.type === 'video' && result.video_url) {
            const videoBuffer = await downloadMedia(result.video_url);
            
            await conn.sendMessage(m.chat, {
                video: videoBuffer,
                mimetype: 'video/mp4',
                caption: caption || undefined
            }, { quoted: m });
            
        } else if (result.type === 'image' && result.images.length > 0) {
            for (let i = 0; i < result.images.length; i++) {
                const imageBuffer = await downloadMedia(result.images[i]);
                
                await conn.sendMessage(m.chat, {
                    image: imageBuffer,
                    mimetype: 'image/jpeg',
                    caption: i === 0 ? caption || undefined : undefined
                }, { quoted: m });
                
                if (i < result.images.length - 1) {
                    await new Promise(resolve => setTimeout(resolve, 1500));
                }
            }
        } else {
            throw new Error('Tidak ada media ditemukan');
        }
        
        await conn.sendMessage(m.chat, {
            react: { text: '✅', key: m.key }
        });
        
    } catch (error) {
        console.error('Error:', error);
        await conn.sendMessage(m.chat, {
            react: { text: '❌', key: m.key }
        });
        m.reply(`❌ Error: ${error.message}`);
    } finally {
        processingUsers.delete(userId);
    }
};

handler.help = ["igram"];
handler.tags = ["downloader"];
handler.command = ["igram"];
handler.limit = true;
handler.register = false;

export default handler;