const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

// ─── CONFIG (opsional, tapi sangat disarankan) ────────────────────────────────
// Isi cookie IG untuk hasil lebih stabil
// Ambil dari browser: F12 → Application → Cookies → instagram.com
const IG_CONFIG = {
    sessionid:  process.env.IG_SESSIONID  || '',
    csrftoken:  process.env.IG_CSRFTOKEN  || '',
    ds_user_id: process.env.IG_DS_USER_ID || '',
    ig_did:     process.env.IG_DID        || '',
    mid:        process.env.IG_MID        || '',
    app_id:     '936619743392459',
};

function buildCookie() {
    const parts = [];
    if (IG_CONFIG.sessionid)  parts.push(`sessionid=${IG_CONFIG.sessionid}`);
    if (IG_CONFIG.csrftoken)  parts.push(`csrftoken=${IG_CONFIG.csrftoken}`);
    if (IG_CONFIG.ds_user_id) parts.push(`ds_user_id=${IG_CONFIG.ds_user_id}`);
    if (IG_CONFIG.ig_did)     parts.push(`ig_did=${IG_CONFIG.ig_did}`);
    if (IG_CONFIG.mid)        parts.push(`mid=${IG_CONFIG.mid}`);
    // Kalau tidak ada session, pakai minimal agar tidak diblokir
    if (!parts.length)        parts.push('ig_did=0; csrftoken=0');
    return parts.join('; ');
}

const COOKIE      = buildCookie();
const IS_LOGGED_IN = !!IG_CONFIG.sessionid;

// ─── Validators ───────────────────────────────────────────────────────────────

function isValidInstagramUrl(url) {
    return /instagram\.com\/(p|reel|reels|tv|stories)\/[a-zA-Z0-9_-]+/i.test(url);
}

function extractInstagramUrls(text) {
    const matches = text.match(/(https?:\/\/)?(www\.)?instagram\.com\/(p|reel|reels|tv|stories)\/[a-zA-Z0-9_\-/?=&%]+/gi) || [];
    return [...new Set(matches)];
}

function normalizeUrl(url) {
    if (!url.startsWith('http')) url = 'https://' + url;
    try {
        const u = new URL(url);
        return `${u.origin}${u.pathname}`;
    } catch { return url; }
}

function isVideoUrl(url) {
    return /\/(reel|reels|tv)\//i.test(url);
}

function extractShortcode(url) {
    const m = url.match(/instagram\.com\/(?:p|reel|reels|tv|stories)\/([a-zA-Z0-9_-]+)/i);
    return m ? m[1] : null;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function randomDelay(min = 1000, max = 3000) {
    return new Promise(r => setTimeout(r, Math.floor(Math.random() * (max - min)) + min));
}

function decodeHtml(str) {
    if (!str) return str;
    return str
        .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"').replace(/&#039;/g, "'").replace(/&apos;/g, "'");
}

/**
 * Bersihkan URL dari berbagai encoding:
 * - HTML entities (&amp; dll)
 * - JSON unicode escape (\u0026 dll)
 * - JSON slash escape (\/)
 * Hasil: URL bersih yang bisa di-fetch
 */
function cleanUrl(s) {
    if (!s || typeof s !== 'string') return null;
    try {
        // Tahap 1: decode HTML entities
        let r = decodeHtml(s);
        // Tahap 2: decode JSON unicode escape \uXXXX
        r = r.replace(/\\u([0-9a-fA-F]{4})/g, (_, c) => String.fromCharCode(parseInt(c, 16)));
        // Tahap 3: decode escaped slash
        r = r.replace(/\\\//g, '/');
        // Tahap 4: decode %XX percent encoding (kecuali yang sudah decode)
        try { r = decodeURIComponent(r.replace(/\+/g, ' ')); } catch { /* skip */ }
        // Tahap 5: trim whitespace
        r = r.trim();
        if (!r.startsWith('http')) return null;
        // Validasi URL
        new URL(r);
        return r;
    } catch {
        return null;
    }
}

/** Pilih video_versions kualitas terbaik */
function bestVideoUrl(versions) {
    if (!Array.isArray(versions) || !versions.length) return null;
    return [...versions].sort((a, b) => (b.width || 0) - (a.width || 0))[0]?.url || null;
}

async function downloadBuffer(url, type = 'file') {
    try {
        const res = await fetch(url, {
            timeout: 60000, follow: 5,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
                'Accept': '*/*',
                'Referer': 'https://www.instagram.com/',
                'Cookie': COOKIE,
            }
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const buf = Buffer.from(await res.arrayBuffer());
        // Sanity check: video harus > 50 KB
        if (type === 'video' && buf.length < 50 * 1024) throw new Error(`File terlalu kecil (${(buf.length/1024).toFixed(1)}KB), bukan video`);
        return buf;
    } catch (e) {
        console.error(`⚠️  Failed to download ${type}:`, e.message);
        return null;
    }
}

// ─── Extractor: scan semua JSON di HTML ───────────────────────────────────────

/**
 * Strategi utama: cari semua kemunculan "video_url" dan "video_versions"
 * di seluruh HTML (termasuk script tag JSON yang di-embed Instagram).
 * Ini yang berhasil untuk case Cellini.
 */
function extractVideoFromHtml(html) {
    let videoUrl = null;

    // Pattern 1: "video_url":"https://..."
    // Paling umum di JSON embed Instagram
    for (const m of html.matchAll(/"video_url"\s*:\s*"(https?:[^"]+)"/g)) {
        const u = cleanUrl(m[1]);
        if (u && (u.includes('cdninstagram') || u.includes('fbcdn') || u.includes('scontent'))) {
            videoUrl = u;
            console.log('✅ [Pattern 1] video_url found');
            break;
        }
    }

    // Pattern 2: video_versions array — ambil url dari elemen pertama
    if (!videoUrl) {
        for (const m of html.matchAll(/"video_versions"\s*:\s*\[[\s\S]{0,50}?"url"\s*:\s*"(https?:[^"]+)"/g)) {
            const u = cleanUrl(m[1]);
            if (u) { videoUrl = u; console.log('✅ [Pattern 2] video_versions found'); break; }
        }
    }

    // Pattern 3: "playable_url":"https://..."
    if (!videoUrl) {
        for (const m of html.matchAll(/"playable_url"\s*:\s*"(https?:[^"]+)"/g)) {
            const u = cleanUrl(m[1]);
            if (u) { videoUrl = u; console.log('✅ [Pattern 3] playable_url found'); break; }
        }
    }

    // Pattern 4: JSON-LD contentUrl
    if (!videoUrl) {
        const ldMatch = html.match(/<script type="application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/i);
        if (ldMatch) {
            try {
                const ld = JSON.parse(ldMatch[1]);
                const nodes = Array.isArray(ld['@graph']) ? ld['@graph'] : [ld];
                for (const n of nodes) {
                    if (n.contentUrl) {
                        const u = cleanUrl(n.contentUrl);
                        if (u) { videoUrl = u; console.log('✅ [Pattern 4] JSON-LD contentUrl found'); break; }
                    }
                }
            } catch { /* skip */ }
        }
    }

    // Pattern 5: og:video meta tag
    if (!videoUrl) {
        const ogVideo = html.match(/<meta\s+property="og:video(?::secure_url)?"\s+content="([^"]+)"/i)?.[1]
                     || html.match(/<meta\s+content="([^"]+)"\s+property="og:video(?::secure_url)?"/i)?.[1];
        if (ogVideo) {
            const u = cleanUrl(ogVideo);
            if (u) { videoUrl = u; console.log('✅ [Pattern 5] og:video found'); }
        }
    }

    return videoUrl;
}

function extractMetaFromHtml(html) {
    let author = null, caption = null, thumbUrl = null;

    // thumbnail dari og:image
    const ogImage = html.match(/<meta\s+property="og:image"\s+content="([^"]+)"/i)?.[1]
                 || html.match(/<meta\s+content="([^"]+)"\s+property="og:image"/i)?.[1];
    if (ogImage) thumbUrl = cleanUrl(ogImage);

    // Author dari og:title
    const ogTitle = decodeHtml(html.match(/<meta\s+property="og:title"\s+content="([^"]+)"/i)?.[1] || '');
    const am = ogTitle.match(/^(.+?)\s+on\s+Instagram/i);
    if (am) author = am[1].trim();

    // Caption dari og:description
    const ogDesc = decodeHtml(html.match(/<meta\s+property="og:description"\s+content="([^"]+)"/i)?.[1] || '');
    caption = ogDesc.replace(/[\d,]+\s*likes?.*?-\s*/i, '').trim() || null;

    // Coba dari JSON embed untuk author lebih akurat
    const authorMatch = html.match(/"username"\s*:\s*"([^"]+)"/);
    if (authorMatch && !author) author = authorMatch[1];

    return { author, caption, thumbUrl };
}

// ─── Method 1: API v1 dengan session ─────────────────────────────────────────

async function tryApiV1(shortcode) {
    if (!IS_LOGGED_IN) return null;
    try {
        const res = await fetch(`https://www.instagram.com/api/v1/media/shortcode/${shortcode}/info/`, {
            timeout: 15000,
            headers: {
                'User-Agent': 'Instagram 275.0.0.27.98 Android (33/13; 420dpi; 1080x2400; samsung; SM-G998B; o1s; exynos2100; en_US; 458229258)',
                'Accept': '*/*',
                'X-IG-App-ID': IG_CONFIG.app_id,
                'Cookie': COOKIE,
            }
        });
        if (!res.ok) { console.log(`⚠️  API v1 HTTP ${res.status}`); return null; }
        const json = await res.json();
        const item = json?.items?.[0];
        if (!item) return null;

        const videoUrl = bestVideoUrl(item.video_versions) || null;
        const thumbUrl = item.image_versions2?.candidates?.[0]?.url || null;
        const author   = item.user?.username || null;
        const caption  = item.caption?.text || null;

        console.log('✅ Got data via API v1');
        return { videoUrl, imageUrl: thumbUrl, thumbUrl, author, caption, mediaType: videoUrl ? 'video' : 'image' };
    } catch (e) {
        console.log('⚠️  API v1 failed:', e.message);
        return null;
    }
}

// ─── Method 2: HTML scrape ────────────────────────────────────────────────────

async function tryHtmlScrape(url, ua) {
    try {
        const res = await fetch(url, {
            timeout: 20000, follow: 5,
            headers: {
                'User-Agent': ua,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.9',
                'Cookie': COOKIE,
                'Referer': 'https://www.instagram.com/',
            }
        });
        if (!res.ok) return null;
        const html = await res.text();

        const videoUrl = extractVideoFromHtml(html);
        const { author, caption, thumbUrl } = extractMetaFromHtml(html);

        if (videoUrl || thumbUrl) {
            console.log(`✅ HTML scrape OK [${ua.slice(0,30)}...]`);
            return { videoUrl, imageUrl: thumbUrl, thumbUrl, author, caption };
        }
    } catch (e) {
        console.log(`⚠️  HTML scrape failed: ${e.message}`);
    }
    return null;
}

// ─── Core ─────────────────────────────────────────────────────────────────────

async function getInstagramData(url) {
    const forceVideo = isVideoUrl(url);
    const shortcode  = extractShortcode(url);

    // oEmbed untuk metadata dasar
    let oembedData = {};
    try {
        const res = await fetch(`https://www.instagram.com/api/v1/oembed/?url=${encodeURIComponent(url)}`, {
            timeout: 15000,
            headers: {
                'User-Agent': 'Mozilla/5.0',
                'Accept': 'application/json',
                'Cookie': COOKIE,
            }
        });
        if (res.ok) {
            const j = await res.json();
            oembedData = { title: j.title, author: j.author_name, thumbnail: j.thumbnail_url };
            console.log('✅ oEmbed OK:', oembedData.author);
        }
    } catch { /* skip */ }

    let result = null;

    // Method 1: API v1 (butuh session)
    if (shortcode) result = await tryApiV1(shortcode);

    // Method 2: HTML scrape — coba beberapa UA
    // Mobile UA lebih sering dapat JSON video embed dari Instagram
    const uaList = [
        // Mobile Safari — paling sering dapat embedded JSON
        'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
        // Android Chrome
        'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
        // Desktop Chrome
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        // Desktop Safari
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15',
    ];

    for (const ua of uaList) {
        if (result?.videoUrl) break; // sudah dapat video, stop
        const scraped = await tryHtmlScrape(url, ua);
        if (!scraped) continue;
        if (!result) {
            result = scraped;
        } else {
            // Merge: prioritaskan videoUrl
            result.videoUrl  = result.videoUrl  || scraped.videoUrl;
            result.thumbUrl  = result.thumbUrl  || scraped.thumbUrl;
            result.author    = result.author    || scraped.author;
            result.caption   = result.caption   || scraped.caption;
        }
    }

    if (!result) throw new Error('Tidak dapat mengambil data. Pastikan post publik.');

    // Jika URL reel/tv tapi video tidak ketemu
    if (forceVideo && !result.videoUrl) {
        const hint = !IS_LOGGED_IN ? '\n\n💡 Set IG_SESSIONID di .env untuk hasil lebih stabil.' : '';
        throw new Error(`Video tidak ditemukan. Instagram memblokir akses untuk post ini.${hint}`);
    }

    const mediaType = result.videoUrl ? 'video' : 'image';
    const mediaUrl  = result.videoUrl || result.imageUrl;
    if (!mediaUrl) throw new Error('URL media tidak ditemukan.');

    console.log(`📺 Final: ${mediaType} | ${mediaUrl.slice(0, 90)}`);

    // Parse likes
    let caption = result.caption || '';
    let likes = null, likeCount = 0;
    const lm = caption.match(/([\d,]+)\s*likes?/i);
    if (lm) {
        likes     = lm[1] + ' likes';
        likeCount = parseInt(lm[1].replace(/,/g, ''));
        caption   = caption.replace(/[\d,]+\s*likes?.*?-\s*/i, '').trim();
    }

    return {
        media_url: mediaUrl, video_url: result.videoUrl || null,
        image_url: result.imageUrl || null, media_type: mediaType,
        extra: {
            title:     oembedData.title     || 'Instagram Post',
            author:    oembedData.author    || result.author  || null,
            thumbnail: oembedData.thumbnail || result.thumbUrl || null,
            caption:   caption || null, likes, like_count: likeCount,
        }
    };
}

// ─── Caption Builder ──────────────────────────────────────────────────────────

function buildCaption(data, index = null, total = null) {
    const d = data.extra;
    let cap = '';
    if (index && total) cap += `📸 *Media ${index}/${total}*\n\n`;
    if (d.author)  cap += `👤 @${d.author}\n`;
    if (d.likes)   cap += `❤️ ${d.likes}\n`;
    if (d.caption?.length) {
        const txt = d.caption.length > 150 ? d.caption.slice(0, 150) + '...' : d.caption;
        cap += `\n💬 ${txt}\n`;
    }
    cap += `\n📱 ${data.media_type === 'video' ? '🎬 Video' : '📸 Photo'} · Instagram`;
    return cap.trim();
}

// ─── Handler ──────────────────────────────────────────────────────────────────

const HELP_MSG = (p, c) => `
*📥 Instagram Downloader*

*Penggunaan:*
${p}${c} <url>

*Bulk:*
${p}${c} <url1> <url2> ...

*Contoh:*
${p}${c} https://www.instagram.com/reel/ABC123/
${p}${c} https://www.instagram.com/p/ABC123/

✅ Post, Reels, IGTV | 📺 Video & Photo
`.trim();

let handler = async (m, { conn, args, usedPrefix, command }) => {
    const input  = args?.join(' ').trim() || '';
    const prefix = usedPrefix || m.text?.match(/^([.!#/])/)?.[1] || '.';
    const cmd    = command || 'ig';

    if (!input) return m.reply(HELP_MSG(prefix, cmd));

    const urls = extractInstagramUrls(input).filter(isValidInstagramUrl).map(normalizeUrl);
    if (!urls.length)
        return m.reply('❌ URL Instagram tidak valid.\n\nContoh: https://www.instagram.com/reel/ABC123');

    const isBulk = urls.length > 1;
    if (isBulk) await m.reply(`📥 *Bulk Download*\nMemproses *${urls.length} post*... ⏳`);

    let ok = 0, fail = 0;

    for (let i = 0; i < urls.length; i++) {
        const url = urls[i];
        try {
            if (!isBulk) await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

            const data    = await getInstagramData(url);
            const caption = buildCaption(data, isBulk ? i + 1 : null, isBulk ? urls.length : null);

            const [mediaBuf, thumbBuf] = await Promise.all([
                downloadBuffer(data.media_url, data.media_type),
                data.extra.thumbnail && data.media_type === 'video'
                    ? downloadBuffer(data.extra.thumbnail, 'thumbnail')
                    : Promise.resolve(null),
            ]);

            if (!mediaBuf) throw new Error('Gagal mendownload media');
            console.log(`📦 ${(mediaBuf.length / 1024).toFixed(1)} KB | ${data.media_type}`);

            if (data.media_type === 'video') {
                await conn.sendMessage(m.chat, {
                    video: mediaBuf, jpegThumbnail: thumbBuf ?? undefined,
                    mimetype: 'video/mp4', caption,
                }, { quoted: m });
            } else {
                await conn.sendMessage(m.chat, { image: mediaBuf, caption }, { quoted: m });
            }

            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            ok++;

        } catch (e) {
            console.error(`❌ IG Error [${i + 1}]:`, e.message);
            fail++;
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            if (!isBulk) return m.reply(`❌ Gagal download.\n*Error:* ${e.message}`);
        }

        if (isBulk && i < urls.length - 1) await randomDelay(2000, 4000);
    }

    if (isBulk) await m.reply(`📊 *Selesai*\n✅ Berhasil: ${ok}/${urls.length}\n❌ Gagal: ${fail}/${urls.length}`);
};

handler.help    = ['ig', 'instagram', 'igdl'];
handler.tags    = ['downloader'];
handler.command = ['ig', 'instagram', 'igdl'];

export default handler;