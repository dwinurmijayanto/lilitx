/*
Silakan share link grup ini ke teman-teman yang ingin ikut menikmati video viral.

Kamu juga boleh invite bot atau layanan pendukung yang bisa membantu mempercepat download atau mempermudah share video.

Tetap saling menghargai, dan gunakan bot dengan bijak agar grup tetap nyaman.

Jika ada fitur baru atau bot rekomendasi, silakan share untuk memudahkan semua member.

🔗 Link Grup untuk Invite Member Baru:
https://chat.whatsapp.com/HkMTzyXJgmi22DHqW6oTIr

Ayo ramein grup kesayangan ini! 🎉
*/


const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));
import axios from "axios";
import { sizeFormatter } from "human-readable";
import { execSync } from "child_process";
import { writeFileSync, unlinkSync, existsSync } from "fs";
import { tmpdir } from "os";
import { join } from "path";
import * as cheerio from "cheerio";

console.log('[kbtv Handler] Loading handler...');

// ========== FORMAT SIZE ==========
const formatSize = sizeFormatter({
  std: "JEDEC",
  decimalPlaces: 2,
  keepTrailingZeroes: false,
  render: (literal, symbol) => `${literal} ${symbol}B`,
});

// ========== SHORTURL CONFIG ==========
const SHORTURL_CONFIG = {
    zeink: {
        api: 'https://zeinklab.com/api/create',
        baseUrl: 'http://zeink.cc',
        timeout: 15000
    },
    mono: {
        api: 'https://monojson.com/api/short-link',
        timeout: 15000
    }
};

// ========== CREATE SHORT URL - MONOJSON ==========
async function createMonoShortUrl(longUrl) {
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), SHORTURL_CONFIG.mono.timeout);

        const response = await fetch(SHORTURL_CONFIG.mono.api, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'User-Agent': 'Mozilla/5.0'
            },
            body: JSON.stringify({ url: longUrl }),
            signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        const result = await response.json();

        if (result.shortUrl) {
            return { 
                success: true, 
                url: result.shortUrl,
                slug: result.slug,
                service: 'monojson'
            };
        }
        
        throw new Error('Gagal membuat short URL');

    } catch (error) {
        if (error.name === 'AbortError') {
            return { success: false, message: 'Timeout' };
        }
        return { success: false, message: error.message };
    }
}

// ========== CREATE SHORT URL - ZEINKLAB ==========
async function createZeinkShortUrl(longUrl, options = {}) {
    try {
        const payload = { url: longUrl, ...options };
        delete payload.service;
        
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), SHORTURL_CONFIG.zeink.timeout);

        const response = await fetch(SHORTURL_CONFIG.zeink.api, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'User-Agent': 'Mozilla/5.0',
                'Origin': 'https://zeinklab.com',
                'Referer': 'https://zeinklab.com/create'
            },
            body: JSON.stringify(payload),
            signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        let responseText = await response.text();
        
        const jsonMatch = responseText.match(/(\{[\s\S]*\})/);
        if (jsonMatch) {
            responseText = jsonMatch[1];
        }
        
        const result = JSON.parse(responseText);

        if (result.success && result.short_url) {
            let url = result.short_url;
            if (url.startsWith('/')) {
                url = SHORTURL_CONFIG.zeink.baseUrl + url;
            } else if (!url.startsWith('http')) {
                url = SHORTURL_CONFIG.zeink.baseUrl + '/' + url;
            }
            
            return { 
                success: true, 
                url,
                service: 'zeinklab'
            };
        }
        
        throw new Error(result.message || 'Gagal membuat short URL');

    } catch (error) {
        if (error.name === 'AbortError') {
            return { success: false, message: 'Timeout' };
        }
        return { success: false, message: error.message };
    }
}

// ========== CREATE SHORT URLS ==========
async function createShortUrls(streamUrl) {
    try {
        console.log('[kbtv] Creating short URLs for stream...');
        
        const zeinkPromise = createZeinkShortUrl(streamUrl);
        const monoPromise = createMonoShortUrl(streamUrl);
        
        const [zeinkResult, monoResult] = await Promise.allSettled([zeinkPromise, monoPromise]);
        
        let urls = [];
        
        if (zeinkResult.status === 'fulfilled' && zeinkResult.value.success) {
            urls.push(zeinkResult.value.url);
        }
        
        if (monoResult.status === 'fulfilled' && monoResult.value.success) {
            urls.push(monoResult.value.url);
        }
        
        return urls;
    } catch (error) {
        console.error('[kbtv] Short URL creation error:', error.message);
        return [];
    }
}

// ========== GENERATE THUMBNAIL URL ==========
function generateThumbnailUrl(videoUrl) {
    try {
        // Extract video ID from URL
        // Pattern: https://kingbokep.tv/view/VIDEO-ID/
        const urlMatch = videoUrl.match(/kingbokep\.tv\/view\/([^\/]+)/i);
        
        if (urlMatch && urlMatch[1]) {
            const videoId = urlMatch[1];
            // Generate thumbnail URL: https://cdn.kingbokep.video/thumbs/VIDEO-ID.webp
            const thumbnailUrl = `https://cdn.kingbokep.video/thumbs/${videoId}.webp`;
            console.log('[kbtv] Generated thumbnail URL:', thumbnailUrl);
            return thumbnailUrl;
        }
        
        console.log('[kbtv] Could not extract video ID from URL');
        return '';
    } catch (error) {
        console.error('[kbtv] Thumbnail generation error:', error.message);
        return '';
    }
}

// ========== SCRAPE kbtv URL ==========
async function scrapeKbtvUrl(url) {
    try {
        console.log('[kbtv] Scraping URL:', url);
        
        const response = await axios.get(url, {
            headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.5",
                "Referer": "https://kingbokep.tv/"
            },
            timeout: 15000
        });
        
        const $ = cheerio.load(response.data);
        
        // Extract video title
        const title = $('h1.title').text().trim() || 
                     $('meta[property="og:title"]').attr('content') || 
                     'Video';
        
        // Extract stream URL from various possible locations
        let streamUrl = '';
        
        // Method 1: Look for m3u8 in script tags
        const scripts = $('script').toArray();
        for (const script of scripts) {
            const scriptContent = $(script).html() || '';
            const m3u8Match = scriptContent.match(/https?:\/\/[^\s"']+\.m3u8/i);
            if (m3u8Match) {
                streamUrl = m3u8Match[0];
                break;
            }
        }
        
        // Method 2: Look for stream.kingbokep.video pattern
        if (!streamUrl) {
            const pageContent = response.data;
            const streamMatch = pageContent.match(/https?:\/\/stream\.kingbokep\.video\/[^"'\s]+\/playlist\.m3u8/i);
            if (streamMatch) {
                streamUrl = streamMatch[0];
            }
        }
        
        // Method 3: Generate from URL pattern
        if (!streamUrl) {
            const urlMatch = url.match(/kingbokep\.tv\/view\/([^\/]+)/);
            if (urlMatch) {
                const videoId = urlMatch[1];
                streamUrl = `https://stream.kingbokep.video/${videoId}/playlist.m3u8`;
            }
        }
        
        if (!streamUrl) {
            throw new Error('Stream URL tidak ditemukan di halaman');
        }
        
        console.log('[kbtv] Stream URL found:', streamUrl);
        
        // Generate thumbnail URL from video URL
        const thumbnail = generateThumbnailUrl(url);
        
        // Extract duration if available
        const duration = $('meta[property="video:duration"]').attr('content') || 'Unknown';
        
        return {
            success: true,
            title: title,
            streamUrl: streamUrl,
            thumbnail: thumbnail,
            duration: duration,
            originalUrl: url
        };
        
    } catch (error) {
        console.error('[kbtv] Scraping error:', error.message);
        throw new Error(`Gagal scraping: ${error.message}`);
    }
}

// ========== DOWNLOAD AND CONVERT M3U8 TO MP4 ==========
async function downloadAndConvertM3U8(streamUrl, title) {
    const tempDir = tmpdir();
    const timestamp = Date.now();
    const safeTitle = title.replace(/[^a-zA-Z0-9]/g, '_').substring(0, 50);
    const outputFile = join(tempDir, `kbtv_${timestamp}_${safeTitle}.mp4`);
    
    try {
        console.log('[kbtv] Starting download and conversion...');
        console.log('[kbtv] Output file:', outputFile);
        
        // FFmpeg command untuk download dan convert m3u8 ke mp4
        const ffmpegCommand = [
            'ffmpeg',
            '-protocol_whitelist', 'file,http,https,tcp,tls,crypto',
            '-i', `"${streamUrl}"`,
            '-c', 'copy',
            '-bsf:a', 'aac_adtstoasc',
            '-movflags', '+faststart',
            '-y',
            `"${outputFile}"`
        ].join(' ');
        
        console.log('[kbtv] Executing FFmpeg command...');
        
        // Execute FFmpeg dengan timeout 10 menit
        execSync(ffmpegCommand, {
            timeout: 600000, // 10 minutes
            stdio: 'pipe',
            maxBuffer: 500 * 1024 * 1024 // 500MB buffer
        });
        
        console.log('[kbtv] Conversion completed');
        
        // Check if file exists
        if (!existsSync(outputFile)) {
            throw new Error('File output tidak ditemukan setelah konversi');
        }
        
        // Read file stats
        const fs = await import('fs/promises');
        const stats = await fs.stat(outputFile);
        const fileSize = formatSize(stats.size);
        
        console.log('[kbtv] File size:', fileSize);
        
        // Read file buffer
        const fileBuffer = await fs.readFile(outputFile);
        
        return {
            success: true,
            buffer: fileBuffer,
            filename: `${safeTitle}.mp4`,
            fileSize: fileSize,
            filePath: outputFile,
            mimeType: 'video/mp4'
        };
        
    } catch (error) {
        console.error('[kbtv] Download/Convert error:', error.message);
        
        // Cleanup file if exists
        if (existsSync(outputFile)) {
            try {
                unlinkSync(outputFile);
            } catch (e) {
                console.error('[kbtv] Failed to cleanup temp file:', e.message);
            }
        }
        
        throw new Error(`Gagal download/convert: ${error.message}`);
    }
}

// ========== CLEANUP TEMP FILE ==========
function cleanupTempFile(filePath) {
    try {
        if (filePath && existsSync(filePath)) {
            unlinkSync(filePath);
            console.log('[kbtv] Temp file cleaned up:', filePath);
        }
    } catch (error) {
        console.error('[kbtv] Cleanup error:', error.message);
    }
}

function generateUsageHelp(prefix, cmd) {
    return `*✨ Fitur:*
• Download video dari kbtv
• Auto scrape stream URL
• Convert M3U8 ke MP4 (FFmpeg)
• High quality video output
• Auto generate short URLs
• Auto generate thumbnail`;
}

function isValidKbtvUrl(url) {
    const pattern = /^https?:\/\/(www\.)?kingbokep\.tv\/view\/[a-zA-Z0-9\-]+/i;
    return pattern.test(url);
}

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    // Deteksi prefix
    let prefix = usedPrefix;
    if (!prefix && m.text) {
        const match = m.text.match(/^([.!#/])/);
        prefix = match ? match[1] : '.';
    }
    prefix = prefix || '.';
    
    const cmd = command || 'kbtv';
    
    // Ambil URL dari text atau args
    let url = '';
    if (text) {
        url = text.trim();
    } else if (args && args.length > 0) {
        url = args[0].trim();
    }
    
    console.log(`[kbtv Handler] Command triggered - prefix: ${prefix}, cmd: ${cmd}, text: ${text}`);
    
    // Cek apakah user minta help atau tidak ada input
    if (!url || url.toLowerCase() === 'help' || url === '?') {
        console.log('[kbtv Handler] Help requested');
        return m.reply(generateUsageHelp(prefix, cmd));
    }
    
    // Validasi URL kbtv
    if (!isValidKbtvUrl(url)) {
        console.log('[kbtv Handler] Invalid URL:', url);
        return m.reply(`❌ Link tidak valid!\n\n💡 Format yang benar:\n${prefix}${cmd} https://kingbokep.tv/view/video-name/\n\n📌 Pastikan link dari kbtv!`);
    }
    
    console.log('[kbtv Handler] Valid URL, starting process...');
    
    let tempFilePath = null;
    
    try {
        // React dengan emoji untuk menunjukkan proses
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        // STEP 1: Scrape video info dan stream URL
        console.log('[kbtv Handler] Step 1: Scraping video info...');
        const videoInfo = await scrapeKbtvUrl(url);
        console.log('[kbtv Handler] Video info obtained');
        
        if (!videoInfo.success || !videoInfo.streamUrl) {
            console.log('[kbtv Handler] Failed to get stream URL');
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply('❌ Gagal mendapatkan stream URL dari video.\n\n💡 Pastikan link valid dan video masih tersedia.');
        }
        
        // STEP 1.5: Create short URLs for stream
        console.log('[kbtv Handler] Step 1.5: Creating short URLs...');
        const shortUrls = await createShortUrls(videoInfo.streamUrl);
        console.log('[kbtv Handler] Short URLs created:', shortUrls.length);
        
        // STEP 2: Download dan convert M3U8 ke MP4
        console.log('[kbtv Handler] Step 2: Downloading and converting video...');
        await conn.sendMessage(m.chat, { react: { text: '📥', key: m.key } });
        
        // Kirim pesan processing dengan thumbnail image
        try {
            // Download thumbnail sebagai buffer
            let thumbnailBuffer = null;
            if (videoInfo.thumbnail) {
                try {
                    const thumbResponse = await axios.get(videoInfo.thumbnail, {
                        responseType: 'arraybuffer',
                        timeout: 10000
                    });
                    thumbnailBuffer = Buffer.from(thumbResponse.data);
                } catch (thumbError) {
                    console.log('[kbtv] Failed to download thumbnail:', thumbError.message);
                }
            }
            
            const processingMsg = await conn.sendMessage(m.chat, {
                image: thumbnailBuffer || Buffer.from(''),
                caption: `*⏳ PROCESSING VIDEO*\n\n` +
                        `*📹 Judul:* ${videoInfo.title}\n` +
                        `*🔄 Status:* Converting M3U8 to MP4...\n\n` +
                        `⚠️ Mohon tunggu, proses memakan waktu tergantung ukuran video.`
            });
        } catch (msgError) {
            console.error('[kbtv] Failed to send processing message:', msgError.message);
            // Fallback: kirim text saja tanpa thumbnail
            await conn.sendMessage(m.chat, {
                text: `*⏳ PROCESSING VIDEO*\n\n` +
                      `*📹 Judul:* ${videoInfo.title}\n` +
                      `*🔄 Status:* Converting M3U8 to MP4...\n\n` +
                      `⚠️ Mohon tunggu, proses memakan waktu tergantung ukuran video.`
            });
        }
        
        const downloadResult = await downloadAndConvertM3U8(videoInfo.streamUrl, videoInfo.title);
        tempFilePath = downloadResult.filePath;
        
        if (!downloadResult.success) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply('❌ Gagal mendownload dan convert video.\n\n💡 Video mungkin tidak tersedia atau terlalu besar.');
        }
        
        console.log('[kbtv Handler] Video downloaded and converted successfully');
        
        // STEP 3: Kirim video ke user
        console.log('[kbtv Handler] Step 3: Sending video to user...');
        await conn.sendMessage(m.chat, { react: { text: '📤', key: m.key } });
        
        // Build caption with one short URL
        let caption = `*🎬 KBTV VIDEO*\n\n` +
                     `*📹 Judul:* ${videoInfo.title}\n` +
                     `*📊 Ukuran:* ${downloadResult.fileSize}\n` +
                     `*⏱️ Durasi:* ${videoInfo.duration}\n`;
        
        if (shortUrls.length > 0) {
            caption += `*🔗 Stream:* ${shortUrls[0]}\n`;
        } else {
            caption += `*🔗 Stream:* ${videoInfo.streamUrl}\n`;
        }
        
        caption += `\n*👥 Join Grup:* https://chat.whatsapp.com/HkMTzyXJgmi22DHqW6oTIr`;
        
        // Kirim sebagai video
        await conn.sendMessage(m.chat, {
            video: downloadResult.buffer,
            mimetype: 'video/mp4',
            fileName: downloadResult.filename,
            caption: caption.trim(),
            contextInfo: videoInfo.thumbnail ? {
                externalAdReply: {
                    title: videoInfo.title,
                    body: 'kbtv Video',
                    thumbnailUrl: videoInfo.thumbnail,
                    mediaType: 1,
                    mediaUrl: url,
                    sourceUrl: url
                }
            } : undefined
        }, { quoted: m });
        
        console.log('[kbtv Handler] Video sent successfully');
        
        // React dengan checkmark
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
        // Cleanup temp file
        cleanupTempFile(tempFilePath);
        
    } catch (error) {
        console.error('[kbtv Handler] ERROR:', error);
        console.error('[kbtv Handler] Stack:', error.stack);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        
        // Cleanup temp file on error
        if (tempFilePath) {
            cleanupTempFile(tempFilePath);
        }
        
        let errorMsg = '❌ Terjadi kesalahan saat memproses video kbtv.\n\n';
        
        if (error.message.includes('timeout')) {
            errorMsg += '⚠️ Timeout: Video terlalu besar atau koneksi lambat\n💡 Coba video dengan ukuran lebih kecil';
        } else if (error.message.includes('404') || error.message.includes('Stream URL tidak ditemukan')) {
            errorMsg += '⚠️ Video tidak ditemukan\n💡 Pastikan link masih aktif dan valid';
        } else if (error.message.includes('FFmpeg') || error.message.includes('ffmpeg')) {
            errorMsg += '⚠️ FFmpeg Error: Gagal convert video\n💡 Format video mungkin tidak didukung';
        } else if (error.message.includes('scraping')) {
            errorMsg += '⚠️ Gagal mengambil informasi video\n💡 Website mungkin berubah atau link tidak valid';
        } else {
            errorMsg += `⚠️ Error: ${error.message}\n💡 Pastikan link valid dan coba lagi`;
        }
        
        return m.reply(errorMsg);
    }
};

handler.help = ["kbtv [link]"];
handler.tags = ["downloader"];
handler.command = ["kbtv"];
handler.limit = true;

console.log('[kbtv Handler] Handler loaded successfully');

export default handler;