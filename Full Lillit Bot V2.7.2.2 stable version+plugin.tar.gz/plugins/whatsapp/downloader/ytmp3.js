const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));
import FormData from 'form-data';
import fs from 'fs';
import { promisify } from 'util';
import { tmpdir } from 'os';
import { join } from 'path';
import { v4 as uuidv4 } from 'uuid';

const writeFile = promisify(fs.writeFile);
const unlink    = promisify(fs.unlink);

// ========== CONFIG ==========
const RAPIDAPI_KEY  = '3a7e9844ffmsh5d0520e908fa6e7p1da7d9jsn9d8f1e787e46';
const RAPIDAPI_HOST = 'youtube-mp36.p.rapidapi.com';
const RAPIDAPI_URL  = `https://${RAPIDAPI_HOST}/dl`;

const SEARCH_API    = 'https://api.deline.web.id/search/youtube';

// Upload hosts
const PANZLYNC_URL = 'https://panzlync.biz.id/upload';
const HF_URL       = 'https://ikyy-upload-file.hf.space/upload';
const TMPFILES_URL = 'https://tmpfiles.org/api/v1/upload';
const UGUU_URL     = 'https://uguu.se/upload.php';

const MAX_RETRIES    = 10;
const RETRY_DELAY    = 2000;
const MAX_WAIT_MS    = 60000;
const REQ_TIMEOUT    = 30000;
const UP_RETRY       = 3;
const UP_TIMEOUT     = 120000;
const DIRECT_TIMEOUT = 30000;

// ========== HELPERS ==========
const delay = ms => new Promise(r => setTimeout(r, ms));

function isValidYoutubeUrl(url) {
    return [
        /^(https?:\/\/)?(www\.)?youtube\.com\/watch\?v=/,
        /^(https?:\/\/)?(www\.)?youtube\.com\/shorts\//,
        /^(https?:\/\/)?(youtu\.be)\//,
        /^(https?:\/\/)?(www\.)?youtube\.com\/live\//,
        /^(https?:\/\/)?(m\.)?youtube\.com\//
    ].some(p => p.test(url));
}

function extractVideoId(url) {
    for (const p of [
        /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/shorts\/|youtube\.com\/live\/)([a-zA-Z0-9_-]{11})/,
        /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/
    ]) {
        const m = url.match(p);
        if (m?.[1]) return m[1];
    }
    return null;
}

function normalizeUrl(url) {
    return /^https?:\/\//.test(url) ? url : 'https://' + url;
}

function formatDuration(seconds) {
    if (!seconds || isNaN(seconds)) return 'Unknown';
    seconds = Math.round(seconds);
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return h > 0
        ? `${h}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`
        : `${m}:${String(s).padStart(2,'0')}`;
}

// ========== THUMBNAIL ==========
async function getYoutubeThumbnail(videoId) {
    if (!videoId) return null;
    for (const url of [
        `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`,
        `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
        `https://img.youtube.com/vi/${videoId}/mqdefault.jpg`,
        `https://img.youtube.com/vi/${videoId}/default.jpg`
    ]) {
        try {
            const res = await fetch(url);
            if (!res.ok) continue;
            const buf = Buffer.from(await res.arrayBuffer());
            if (buf.length > 5000) return buf;
        } catch { continue; }
    }
    return null;
}

// ========== CONVERT MP3 → OGG/OPUS ==========
async function convertToOpus(mp3Buffer) {
    const ffmpeg     = (await import('fluent-ffmpeg')).default;
    const ffmpegPath = (await import('ffmpeg-static')).default;
    const { Readable, PassThrough } = await import('stream');
    ffmpeg.setFfmpegPath(ffmpegPath);
    return new Promise((resolve, reject) => {
        const input  = new Readable();
        const output = new PassThrough();
        const chunks = [];
        input.push(mp3Buffer);
        input.push(null);
        output.on('data', c => chunks.push(c));
        output.on('end',  () => resolve(Buffer.concat(chunks)));
        output.on('error', reject);
        ffmpeg(input)
            .inputFormat('mp3')
            .audioCodec('libopus')
            .audioChannels(2)
            .audioFrequency(48000)
            .audioBitrate('128k')
            .outputOptions(['-avoid_negative_ts make_zero', '-map_metadata -1', '-vn'])
            .outputFormat('ogg')
            .on('error', reject)
            .pipe(output);
    });
}

// ========== SEARCH ==========
async function searchYoutubeViaDeline(query) {
    for (let i = 1; i <= 3; i++) {
        try {
            console.log(`[Search] Attempt ${i}: "${query}"`);
            const ctrl = new AbortController();
            const tid  = setTimeout(() => ctrl.abort(), REQ_TIMEOUT);
            const res  = await fetch(`${SEARCH_API}?q=${encodeURIComponent(query)}`, {
                headers: { 'User-Agent': 'Mozilla/5.0', Accept: 'application/json' },
                signal: ctrl.signal
            });
            clearTimeout(tid);
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const data = JSON.parse(await res.text());
            if ((data.status !== true && data.status !== 'true') ||
                !Array.isArray(data.result) || !data.result.length)
                throw new Error('No results');
            const top = data.result[0];
            if (!top.link) throw new Error('No link');
            console.log(`[Search] ✓ ${top.title}`);
            return {
                url:         top.link,
                videoId:     extractVideoId(top.link),
                title:       top.title    || 'YouTube Audio',
                channelName: top.channel  || 'Unknown',
                lengthText:  top.duration || 'Unknown'
            };
        } catch (e) {
            console.error(`[Search] Attempt ${i} failed:`, e.message);
            if (i < 3) await delay(RETRY_DELAY * i);
        }
    }
    return null;
}

// ========== RAPIDAPI POLLING ==========
async function rapidApiRequest(videoId) {
    const ctrl = new AbortController();
    const tid  = setTimeout(() => ctrl.abort(), REQ_TIMEOUT);
    try {
        const res = await fetch(`${RAPIDAPI_URL}?id=${videoId}`, {
            headers: { 'x-rapidapi-key': RAPIDAPI_KEY, 'x-rapidapi-host': RAPIDAPI_HOST },
            signal: ctrl.signal
        });
        clearTimeout(tid);
        if (!res.ok) return { _err: `HTTP ${res.status}` };
        return JSON.parse(await res.text());
    } catch (e) {
        clearTimeout(tid);
        return { _err: e.message };
    }
}

async function getYoutubeMp3(input) {
    let videoId = /^[a-zA-Z0-9_-]{11}$/.test(input)
        ? input
        : extractVideoId(normalizeUrl(input));
    if (!videoId) return { success: false, error: 'Tidak dapat mengekstrak video ID' };

    console.log(`[RapidAPI] Polling video ID: ${videoId}`);
    const startTime = Date.now();
    let attempt = 0, title = '', duration = 0, lastStatus = '';

    while (attempt < MAX_RETRIES) {
        attempt++;
        const data = await rapidApiRequest(videoId);
        if (data._err) {
            if (Date.now() - startTime >= MAX_WAIT_MS) break;
            await delay(RETRY_DELAY);
            continue;
        }
        if (data.title    && !title)    title    = data.title;
        if (data.duration && !duration) duration = data.duration;

        const status = data.status || 'unknown';
        const link   = data.link   || '';
        lastStatus   = status;
        console.log(`[RapidAPI] status: ${status}, progress: ${data.progress || 0}`);

        if (status === 'ok' && link) {
            return {
                success:     true,
                videoId,
                title:       title || 'YouTube Audio',
                duration:    formatDuration(duration),
                downloadUrl: link.replace(/\\\//g, '/'),
                quality:     '128kbps',
                waitTime:    Math.round((Date.now() - startTime) / 1000),
                attempts:    attempt
            };
        }
        if (Date.now() - startTime >= MAX_WAIT_MS) break;
        await delay(RETRY_DELAY);
    }
    return { success: false, error: `Gagal setelah ${attempt} percobaan`, title, lastStatus, attempts: attempt };
}

// ========== STEP 1: DOWNLOAD BUFFER LANGSUNG ==========
async function downloadMp3Buffer(mp3Url) {
    console.log('[Buffer] Downloading MP3 buffer dari URL...');
    for (let i = 1; i <= UP_RETRY; i++) {
        try {
            const ctrl = new AbortController();
            const tid  = setTimeout(() => ctrl.abort(), UP_TIMEOUT);
            const res  = await fetch(mp3Url, {
                headers: { 'User-Agent': 'Mozilla/5.0', 'Referer': 'https://youtube-mp36.p.rapidapi.com/' },
                signal: ctrl.signal
            });
            clearTimeout(tid);
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const buf = Buffer.from(await res.arrayBuffer());
            if (buf.length < 1000) throw new Error(`Buffer terlalu kecil: ${buf.length} bytes`);
            console.log(`[Buffer] ✓ MP3 berhasil didownload: ${(buf.length / 1024 / 1024).toFixed(2)} MB`);
            return buf;
        } catch (e) {
            console.error(`[Buffer] Attempt ${i}/${UP_RETRY} gagal:`, e.message);
            if (i < UP_RETRY) await delay(500);
        }
    }
    return null;
}

// ========== STEP 2: UPLOAD KE SEMUA HOST ==========

// — Panzlync (via temp file, follow redirect untuk ambil file ID) —
async function uploadToPanzlync(buf, filename) {
    let tempPath = null;
    try {
        tempPath = join(tmpdir(), `panzlync_${Date.now()}_${filename}`);
        await writeFile(tempPath, buf);
        await delay(100);

        const form = new FormData();
        form.append('file', fs.createReadStream(tempPath), { filename, contentType: 'audio/mpeg' });
        form.append('expire_unit', 'unlimited');
        form.append('expire_value', '10');
        form.append('max_downloads_option', 'unlimited');
        form.append('max_downloads', '1');

        const res = await Promise.race([
            fetch(PANZLYNC_URL, {
                method: 'POST',
                body: form,
                headers: {
                    ...form.getHeaders(),
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                },
                redirect: 'follow'
            }),
            new Promise((_, r) => setTimeout(() => r(new Error('Timeout')), DIRECT_TIMEOUT))
        ]);

        // response.url = https://panzlync.biz.id/success?file=<id>
        const match = res.url.match(/[?&]file=([^&]+)/);
        if (!match) throw new Error('File ID tidak ditemukan di URL Panzlync: ' + res.url);
        const fileId = decodeURIComponent(match[1]);
        return { host: 'panzlync', url: `https://panzlync.biz.id/f/${fileId}` };
    } finally {
        if (tempPath) {
            await delay(200);
            try { if (fs.existsSync(tempPath)) await unlink(tempPath); } catch {}
        }
    }
}

// — Ikky HF —
async function uploadToHF(buf, filename) {
    const form = new FormData();
    form.append('file', buf, { filename, contentType: 'audio/mpeg' });
    const res = await Promise.race([
        fetch(HF_URL, { method: 'POST', body: form,
            headers: { ...form.getHeaders(), Accept: 'application/json', 'User-Agent': 'Mozilla/5.0' } }),
        new Promise((_, r) => setTimeout(() => r(new Error('Timeout')), DIRECT_TIMEOUT))
    ]);
    if (!res.ok) throw new Error(`HF HTTP ${res.status}`);
    const d = await res.json();
    if (!d.fileUrl) throw new Error(d.message || 'No fileUrl');
    return { host: 'hf', url: d.fileUrl };
}

// — TmpFiles —
async function uploadToTmpFiles(buf, filename) {
    const form = new FormData();
    form.append('file', buf, { filename, contentType: 'audio/mpeg' });
    const res = await Promise.race([
        fetch(TMPFILES_URL, { method: 'POST', body: form,
            headers: { ...form.getHeaders(), Accept: 'application/json', 'User-Agent': 'Mozilla/5.0' } }),
        new Promise((_, r) => setTimeout(() => r(new Error('Timeout')), DIRECT_TIMEOUT))
    ]);
    if (!res.ok) throw new Error(`TmpFiles HTTP ${res.status}`);
    const d = await res.json();
    if (d.status !== 'success' || !d.data?.url) throw new Error(d.message || 'No url');
    const parts = d.data.url.split('/');
    return { host: 'tmpfiles', url: `https://tmpfiles.org/dl/${parts[parts.length - 2]}/${parts[parts.length - 1]}` };
}

// — Uguu.se —
async function uploadToUguu(buf, filename) {
    let tempPath = null;
    try {
        tempPath = join(tmpdir(), `uguu_${Date.now()}_${filename}`);
        await writeFile(tempPath, buf);
        await delay(100);
        const form = new FormData();
        form.append('files[]', fs.createReadStream(tempPath), { filename, contentType: 'audio/mpeg' });
        const res = await Promise.race([
            fetch(UGUU_URL, { method: 'POST', body: form,
                headers: { ...form.getHeaders(), 'User-Agent': 'Mozilla/5.0' } }),
            new Promise((_, r) => setTimeout(() => r(new Error('Timeout')), DIRECT_TIMEOUT))
        ]);
        if (!res.ok) throw new Error(`Uguu HTTP ${res.status}`);
        const d = await res.json();
        if (!d.files?.[0]?.url) throw new Error('No url');
        return { host: 'uguu', url: d.files[0].url };
    } finally {
        if (tempPath) {
            await delay(200);
            try { if (fs.existsSync(tempPath)) await unlink(tempPath); } catch {}
        }
    }
}

// ========== RACE SEMUA HOST ==========
async function getAudioBuffer(mp3Url) {
    console.log('[Audio] Step 1: Download buffer MP3 dari URL asli...');
    const directBuf = await downloadMp3Buffer(mp3Url);

    if (directBuf) {
        console.log('[Audio] ✓ Buffer MP3 berhasil didapat, lanjut upload ke semua host (background)...');
        const fname = `audio_${Date.now()}.mp3`;
        Promise.allSettled([
            uploadToPanzlync(directBuf, fname).then(r => console.log(`[Upload-BG] ✓ ${r.host}: ${r.url}`)).catch(e => console.error('[Upload-BG] panzlync gagal:', e.message)),
            uploadToHF(directBuf, fname)       .then(r => console.log(`[Upload-BG] ✓ ${r.host}: ${r.url}`)).catch(e => console.error('[Upload-BG] hf gagal:', e.message)),
            uploadToTmpFiles(directBuf, fname) .then(r => console.log(`[Upload-BG] ✓ ${r.host}: ${r.url}`)).catch(e => console.error('[Upload-BG] tmpfiles gagal:', e.message)),
            uploadToUguu(directBuf, fname)     .then(r => console.log(`[Upload-BG] ✓ ${r.host}: ${r.url}`)).catch(e => console.error('[Upload-BG] uguu gagal:', e.message)),
        ]);
        return directBuf;
    }

    console.error('[Audio] ✗ Semua metode gagal mendapatkan buffer MP3');
    return null;
}

// ========== CONVERT OPUS WITH RETRY ==========
async function convertToOpusWithRetry(mp3Buffer) {
    for (let i = 1; i <= UP_RETRY; i++) {
        try {
            console.log(`[Convert] OGG/Opus attempt ${i}/${UP_RETRY}...`);
            const opus = await convertToOpus(mp3Buffer);
            console.log(`[Convert] ✓ OGG/Opus ${(opus.length / 1024).toFixed(2)} KB`);
            return opus;
        } catch (e) {
            console.error(`[Convert] Attempt ${i} gagal:`, e.message);
            if (i < UP_RETRY) await delay(RETRY_DELAY);
        }
    }
    return null;
}

// ========== HANDLER ==========
let handler = async (m, { conn, args, usedPrefix }) => {
    const input = args?.length ? args.join(' ').trim() : '';

    if (!input) {
        const prefix = usedPrefix || (m.text?.match(/^([.!#/])/)?.[1]) || '.';
        return m.reply(`*🎵 YouTube to Opus Audio Downloader*

*Cara 1: Download langsung dengan URL*
${prefix}ytmp3 <url_youtube>

*Cara 2: Cari dan download audio*
${prefix}ytmp3 <kata_kunci_pencarian>

*Contoh:*
${prefix}ytmp3 https://www.youtube.com/watch?v=dQw4w9WgXcQ
${prefix}ytmp3 https://www.youtube.com/shorts/ac4f-BpF4pY
${prefix}ytmp3 despacito official audio`);
    }

    const react = async emoji => {
        try { await conn.sendMessage(m.chat, { react: { text: emoji, key: m.key } }); } catch {}
    };

    await react('⏳');

    let youtubeUrl = input;
    let searchMode = false;

    if (!isValidYoutubeUrl(input)) {
        searchMode = true;
        await react('🔍');
        const sr = await searchYoutubeViaDeline(input);
        if (!sr?.url) {
            await react('❌');
            return m.reply(`❌ Tidak dapat menemukan video: "${input}"\n\nCoba kata kunci lain atau gunakan URL YouTube langsung.`);
        }
        youtubeUrl = sr.url;
        await react('⏳');
    }

    try {
        // 1. Dapatkan link MP3 dari RapidAPI
        const audioData = await getYoutubeMp3(youtubeUrl);
        if (!audioData.success || !audioData.downloadUrl) {
            await react('❌');
            return m.reply(`❌ Gagal mendapatkan link download.\nError: ${audioData.error || 'Unknown'}`);
        }
        console.log(`[Handler] ✓ ${audioData.title} (${audioData.duration})`);

        // 2. Download buffer MP3 SEGERA (URL expires cepat!)
        await react('⬇️');
        const mp3Buffer = await getAudioBuffer(audioData.downloadUrl);
        if (!mp3Buffer) {
            await react('❌');
            return m.reply('❌ Gagal mendapatkan audio. URL mungkin sudah expired, coba lagi.');
        }

        // 3. Convert MP3 → OGG/Opus
        console.log('[Handler] Converting MP3 → OGG/Opus...');
        const opusBuffer = await convertToOpusWithRetry(mp3Buffer);
        if (!opusBuffer) {
            await react('⚠️');
            console.log('[Handler] Convert gagal, fallback kirim MP3...');
        }

        // 4. Ambil thumbnail
        const thumbBuf = await getYoutubeThumbnail(audioData.videoId);

        const buildCtx = () => {
            const ctx = { mentionedJid: [m.sender] };
            if (thumbBuf) {
                ctx.externalAdReply = {
                    title:                 audioData.title,
                    body:                  `Durasi: ${audioData.duration}`,
                    mediaType:             1,
                    thumbnail:             thumbBuf,
                    sourceUrl:             youtubeUrl,
                    renderLargerThumbnail: true
                };
            }
            return ctx;
        };

        const infoText =
            `*🎵 YouTube Audio*${searchMode ? ' *(dari pencarian)*' : ''}\n` +
            `*Judul:* ${audioData.title}\n` +
            `*Durasi:* ${audioData.duration}\n` +
            `*Format:* ${opusBuffer ? 'OGG/Opus' : 'MP3 (fallback)'}`;

        // 5. Kirim audio
        await react('⬆️');

        if (opusBuffer) {
            await conn.sendMessage(m.chat, {
                audio:       opusBuffer,
                mimetype:    'audio/ogg; codecs=opus',
                ptt:         false,
                caption:     infoText,
                contextInfo: buildCtx()
            }, { quoted: m });
        } else {
            await conn.sendMessage(m.chat, {
                audio:       mp3Buffer,
                mimetype:    'audio/mpeg',
                fileName:    `${audioData.title}.mp3`,
                caption:     infoText,
                contextInfo: buildCtx()
            }, { quoted: m });
        }

        await react('✅');
        console.log(`[Handler] ✓ Audio sent (${opusBuffer ? 'ogg/opus' : 'mp3 fallback'})`);

    } catch (err) {
        console.error('[Handler] Fatal error:', err.message);
        await react('❌');
        m.reply('❌ Terjadi kesalahan saat memproses audio. Silakan coba lagi.');
    }
};

handler.help    = ['ytmp3', 'yta', 'play'];
handler.tags    = ['downloader'];
handler.command = ['ytmp3', 'yta', 'play', 'ytaudio'];

export default handler;