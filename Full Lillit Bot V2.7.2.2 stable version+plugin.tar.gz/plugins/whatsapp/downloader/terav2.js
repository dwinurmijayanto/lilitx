const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

// ========== SHORTURL CONFIG ==========
const SHORTURL_CONFIG = {
    api: 'https://zeinklab.com/api/create',
    baseUrl: 'http://zeink.cc',
    timeout: 15000
};

// ========== SHORTURL FUNCTIONS ==========
async function createShortUrl(longUrl) {
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), SHORTURL_CONFIG.timeout);

        const response = await fetch(SHORTURL_CONFIG.api, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'User-Agent': 'Mozilla/5.0',
                'Origin': 'https://zeinklab.com',
                'Referer': 'https://zeinklab.com/create'
            },
            body: JSON.stringify({ url: longUrl }),
            signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        let responseText = await response.text();
        
        const jsonMatch = responseText.match(/(\{[\s\S]*\})/);
        if (jsonMatch) {
            responseText = jsonMatch[1];
        }
        
        const result = JSON.parse(responseText);

        if (result.success && result.short_url) {
            let url = result.short_url;
            if (url.startsWith('/')) {
                url = SHORTURL_CONFIG.baseUrl + url;
            } else if (!url.startsWith('http')) {
                url = SHORTURL_CONFIG.baseUrl + '/' + url;
            }
            
            return url;
        }
        
        return null;

    } catch (error) {
        console.log(`[ShortURL] Error: ${error.message}`);
        return null;
    }
}

// ========== UTILITY FUNCTIONS ==========
function formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function getRandomDelay() {
    return Math.floor(Math.random() * (15000 - 10000 + 1)) + 10000;
}

// ========== TERABOX DOWNLOADER ==========
async function teradl(url) {
    try {
        // Pattern untuk format: ?surl=xxx atau &surl=xxx
        const surlPattern = /[?&]surl=([a-zA-Z0-9_-]+)/i;
        // Pattern untuk format: /s/1xxxxx
        const shortPattern = /\/s\/1([a-zA-Z0-9_-]+)/i;
        
        let surl = null;
        
        // Cek pattern ?surl= atau &surl=
        let match = url.match(surlPattern);
        if (match) {
            surl = match[1];
        }
        
        // Cek pattern /s/1xxxxx
        if (!surl) {
            match = url.match(shortPattern);
            if (match) {
                surl = match[1];
            }
        }
        
        if (!surl) {
            // Validate URL format
            if (!/^https?:\/\/(?:www\.|1024)?terabox(?:app)?\.com/i.test(url)) {
                throw new Error('Invalid TeraBox URL.');
            }
            
            // Follow redirects to get final URL
            const response = await fetch(url, {
                redirect: 'follow',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 15; SM-F958) AppleWebKit/537.36'
                }
            });
            
            const finalUrl = response.url;
            console.log(`🔄 Final URL after redirect: ${finalUrl}`);
            
            // Try both patterns on final URL
            match = finalUrl.match(surlPattern);
            if (match) {
                surl = match[1];
            } else {
                match = finalUrl.match(shortPattern);
                if (match) {
                    surl = match[1];
                }
            }
            
            if (!surl) throw new Error('SURL not found.');
        }
        
        console.log(`🔑 Extracted SURL: ${surl}`);
        console.log(`📤 API Request: https://tera2.sylyt93.workers.dev/info?s=${surl}`);
        
        const apiUrl = `https://tera2.sylyt93.workers.dev/info?s=${surl}`;
        const response = await fetch(apiUrl, {
            headers: {
                'origin': 'https://www.kauruka.com',
                'referer': 'https://www.kauruka.com/',
                'user-agent': 'Mozilla/5.0 (Linux; Android 15; SM-F958 Build/AP3A.240905.015) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.86 Mobile Safari/537.36'
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        
        const data = await response.json();
        return data;
        
    } catch (error) {
        throw new Error(error.message);
    }
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    const teraboxUrl = args && args.length > 0 ? args.join(' ').trim() : '';
    
    if (!teraboxUrl) {
        let prefix = usedPrefix;
        if (!prefix && m.text) {
            const match = m.text.match(/^([.!#/])/);
            prefix = match ? match[1] : '.';
        }
        prefix = prefix || '.';
        
        const cmd = command || 'teraboxv2';
        
        return m.reply(`*📥 TeraBox Downloader V2*

🔹 Download: ${prefix}${cmd} url_terabox

*Contoh:*
${prefix}${cmd} https://terabox.com/s/1ZdiYMWn2JsklSZxGdKJEBw
${prefix}${cmd} https://1024terabox.com/s/1GB4jebTyebNiKgwaHYzsxA
${prefix}${cmd} https://terabox.app/sharing/link?surl=xxx
${prefix}${cmd} https://www.terabox.com/wap/share/filelist?surl=xxx

*Supported URL Format:*
- https://terabox.com/s/1xxxxx
- https://1024terabox.com/s/1xxxxx
- https://terabox.app/sharing/link?surl=xxx
- https://www.terabox.com/wap/share/filelist?surl=xxx

*✨ Fitur V2:*
✓ API Terbaru & Lebih Cepat
✓ Support Fast Download Link
✓ Auto Follow Redirects
✓ Link Download Pendek (ShortURL)
✓ Auto detect file type (Image/Video/Document)`);
    }
    
    try {
        await conn.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });
    } catch (e) {
        console.log('Gagal menambahkan reaksi:', e);
    }
    
    try {
        console.log(`\n╔═══════════════════════════════════════════════════════════════╗`);
        console.log(`║  🔄 TERABOX V2 PROCESSING                                     ║`);
        console.log(`╚═══════════════════════════════════════════════════════════════╝`);
        console.log(`📍 URL: ${teraboxUrl}`);
        console.log(`⏰ Started at: ${new Date().toISOString()}`);
        
        const data = await teradl(teraboxUrl);
        
        console.log(`\n📊 Response Data:`);
        console.log(`   - status: ${data.status || 'N/A'}`);
        console.log(`   - shortUrl: ${data.shortUrl || 'N/A'}`);
        console.log(`   - files: ${data.list ? data.list.length : 0}`);
        console.log(`   - dlink: ${data.dlink ? '✓' : '✗'}`);
        
        // Check if response is valid
        const isValid = (data.status === 'ok' || data.ok) && data.list && data.list.length > 0;
        
        if (!isValid) {
            console.log(`❌ Error: ${data.msg || 'No files found'}`);
            await conn.sendMessage(m.chat, { 
                text: `*❌ Gagal mendapatkan file*\n\n${data.msg || 'File tidak ditemukan atau URL invalid'}` 
            });
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return;
        }
        
        try {
            await conn.sendMessage(m.chat, { react: { text: '📥', key: m.key } });
        } catch (e) {
            console.log('Gagal menambahkan reaksi download:', e);
        }
        
        const MAX_SIZE = 100 * 1024 * 1024; // 100MB
        const files = data.list;
        const folderTitle = data.title || null;
        const rootDlink = data.dlink || null; // Root level download link
        
        console.log(`\n✅ Found ${files.length} file(s)`);
        if (rootDlink) console.log(`🔗 Root dlink available`);
        
        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            
            console.log(`\n📁 File ${i + 1}: ${file.server_filename || file.name}`);
            console.log(`   ├─ Size: ${formatBytes(file.size)}`);
            console.log(`   ├─ Category: ${file.category || 'N/A'}`);
            console.log(`   ├─ MD5: ${file.md5 || 'N/A'}`);
            console.log(`   ├─ File dlink: ${file.dlink ? '✓' : '✗'}`);
            console.log(`   ├─ Root dlink: ${rootDlink ? '✓' : '✗'}`);
            console.log(`   ├─ Download: ${file.download ? '✓' : '✗'}`);
            console.log(`   ├─ Fast Download: ${file.fastDownload ? '✓' : '✗'}`);
            console.log(`   └─ Thumbnails: ${file.thumbs ? '✓' : '✗'}`);
            
            // Prioritize download links: fastDownload > download > root dlink > file dlink
            const fileDownloadUrl = file.fastDownload || file.download || rootDlink || file.dlink;
            const fileName = file.server_filename || file.name || 'file';
            
            // Get best quality thumbnail
            const thumbnail = file.thumbs?.url3 || file.thumbs?.url2 || file.thumbs?.url1 || file.thumbs?.icon || file.thumbnail || null;
            
            if (!fileDownloadUrl) {
                console.log(`   ⚠️ No download link available`);
                continue;
            }
            
            // Delay untuk file kedua dan seterusnya
            if (i > 0) {
                const delayMs = getRandomDelay();
                console.log(`⏳ Waiting ${delayMs}ms before processing next file...`);
                await delay(delayMs);
            }
            
            try {
                if (file.size > MAX_SIZE) {
                    console.log(`   ⚠️ File too large, sending links only`);
                    
                    const shortUrl = await createShortUrl(fileDownloadUrl);
                    const shortFastUrl = file.fastDownload ? await createShortUrl(file.fastDownload) : null;
                    
                    let caption = `*📥 TeraBox Download V2*\n\n`;
                    if (folderTitle) caption += `📦 *Folder:* ${folderTitle}\n`;
                    caption += `📂 *File:* ${fileName}\n`;
                    caption += `📏 *Size:* ${formatBytes(file.size)}\n`;
                    caption += `⚠️ *File terlalu besar untuk diupload*\n\n`;
                    
                    if (file.fastDownload) {
                        caption += `⚡ *FAST DOWNLOAD:*\n`;
                        caption += `${shortFastUrl || file.fastDownload}\n\n`;
                    }
                    
                    caption += `🔗 *DOWNLOAD:*\n`;
                    caption += `${shortUrl || fileDownloadUrl}`;
                    
                    if (files.length > 1) {
                        caption += `\n\n📊 File ${i + 1} dari ${files.length}`;
                    }
                    
                    if (thumbnail) {
                        await conn.sendMessage(m.chat, {
                            image: { url: thumbnail },
                            caption: caption
                        });
                    } else {
                        await conn.sendMessage(m.chat, { text: caption });
                    }
                    
                } else {
                    console.log(`   ⬇️ Downloading file...`);
                    
                    try {
                        await conn.sendMessage(m.chat, { react: { text: '⬇️', key: m.key } });
                    } catch (e) {}
                    
                    const controller = new AbortController();
                    const downloadTimeout = setTimeout(() => {
                        controller.abort();
                        console.log(`   ⏱️ Download timeout`);
                    }, 120000);
                    
                    try {
                        const response = await fetch(fileDownloadUrl, {
                            signal: controller.signal,
                            headers: {
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                                'Referer': 'https://www.kauruka.com/'
                            }
                        });
                        
                        clearTimeout(downloadTimeout);
                        
                        if (!response.ok) {
                            throw new Error(`HTTP ${response.status}`);
                        }
                        
                        const arrayBuffer = await response.arrayBuffer();
                        const buffer = Buffer.from(arrayBuffer);
                        
                        console.log(`   ✅ Downloaded, sending...`);
                        
                        try {
                            await conn.sendMessage(m.chat, { react: { text: '⬆️', key: m.key } });
                        } catch (e) {}
                        
                        let caption = `*📥 TeraBox Download V2*\n\n`;
                        if (folderTitle) caption += `📦 *Folder:* ${folderTitle}\n`;
                        caption += `📂 *File:* ${fileName}\n`;
                        caption += `📏 *Size:* ${formatBytes(file.size)}`;
                        
                        if (files.length > 1) {
                            caption += `\n\n📊 File ${i + 1} dari ${files.length}`;
                        }
                        
                        const fileNameLower = fileName.toLowerCase();
                        const isImage = /\.(jpg|jpeg|png|gif|bmp|webp)$/i.test(fileNameLower);
                        const isVideo = /\.(mp4|mkv|avi|mov|wmv|flv|webm|m4v)$/i.test(fileNameLower);
                        
                        if (isImage) {
                            await conn.sendMessage(m.chat, {
                                image: buffer,
                                caption: caption
                            });
                            console.log(`   📤 Sent as image`);
                        } else if (isVideo) {
                            await conn.sendMessage(m.chat, {
                                video: buffer,
                                mimetype: 'video/mp4',
                                caption: caption
                            });
                            console.log(`   📤 Sent as video`);
                        } else {
                            await conn.sendMessage(m.chat, {
                                document: buffer,
                                mimetype: 'application/octet-stream',
                                fileName: fileName,
                                caption: caption
                            });
                            console.log(`   📤 Sent as document`);
                        }
                        
                        try {
                            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                        } catch (e) {}
                        
                    } catch (downloadError) {
                        clearTimeout(downloadTimeout);
                        
                        if (downloadError.name === 'AbortError') {
                            console.log(`   ⚠️ Download timeout, sending links`);
                            
                            const shortUrl = await createShortUrl(fileDownloadUrl);
                            const shortFastUrl = file.fastDownload ? await createShortUrl(file.fastDownload) : null;
                            
                            let fallbackMsg = `*⚠️ Download Timeout*\n\n`;
                            if (folderTitle) fallbackMsg += `📦 *Folder:* ${folderTitle}\n`;
                            fallbackMsg += `📂 *File:* ${fileName}\n`;
                            fallbackMsg += `📏 *Size:* ${formatBytes(file.size)}\n`;
                            fallbackMsg += `💡 *Gunakan link ini:*\n\n`;
                            
                            if (file.fastDownload) {
                                fallbackMsg += `⚡ *FAST DOWNLOAD:*\n`;
                                fallbackMsg += `${shortFastUrl || file.fastDownload}\n\n`;
                            }
                            
                            fallbackMsg += `🔗 *DOWNLOAD:*\n`;
                            fallbackMsg += `${shortUrl || fileDownloadUrl}`;
                            
                            if (files.length > 1) {
                                fallbackMsg += `\n\n📊 File ${i + 1} dari ${files.length}`;
                            }
                            
                            if (thumbnail) {
                                await conn.sendMessage(m.chat, {
                                    image: { url: thumbnail },
                                    caption: fallbackMsg
                                });
                            } else {
                                await conn.sendMessage(m.chat, { text: fallbackMsg });
                            }
                            
                            continue;
                        }
                        throw downloadError;
                    }
                }
                
            } catch (fileError) {
                console.error(`   ❌ Error: ${fileError.message}`);
                
                try {
                    const shortUrl = await createShortUrl(fileDownloadUrl);
                    const shortFastUrl = file.fastDownload ? await createShortUrl(file.fastDownload) : null;
                    
                    let errorMsg = `*❌ Error pada File ${i + 1}*\n\n`;
                    if (folderTitle) errorMsg += `📦 *Folder:* ${folderTitle}\n`;
                    errorMsg += `📂 *File:* ${fileName}\n`;
                    errorMsg += `📏 *Size:* ${formatBytes(file.size)}\n`;
                    errorMsg += `⚠️ *Error:* ${fileError.message}\n\n`;
                    
                    if (file.fastDownload) {
                        errorMsg += `⚡ *FAST DOWNLOAD:*\n`;
                        errorMsg += `${shortFastUrl || file.fastDownload}\n\n`;
                    }
                    
                    errorMsg += `🔗 *DOWNLOAD:*\n`;
                    errorMsg += `${shortUrl || fileDownloadUrl}`;
                    
                    if (files.length > 1) {
                        errorMsg += `\n\n📊 File ${i + 1} dari ${files.length}`;
                    }
                    
                    if (thumbnail) {
                        await conn.sendMessage(m.chat, {
                            image: { url: thumbnail },
                            caption: errorMsg
                        });
                    } else {
                        await conn.sendMessage(m.chat, { text: errorMsg });
                    }
                } catch (e) {
                    console.error(`   ❌ Failed to send error message: ${e.message}`);
                }
                
                continue;
            }
        }
        
        console.log(`\n╔═══════════════════════════════════════════════════════════════╗`);
        console.log(`║  ✅ COMPLETED                                                 ║`);
        console.log(`╚═══════════════════════════════════════════════════════════════╝\n`);
        
    } catch (error) {
        console.error('❌ Main Error:', error.message);
        await conn.sendMessage(m.chat, { 
            text: `*❌ Error*\n\n${error.message}` 
        });
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
};

handler.help = ["teraboxv2", "terav2", "tbv2"];
handler.tags = ["downloader"];
handler.command = ["teraboxv2", "terav2", "tbv2", "teradownv2"];

export default handler;