const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

// Cache untuk menghindari API call berulang
const cache = new Map();
const CACHE_TTL = 5 * 60 * 1000; // 5 menit

function isValidFacebookUrl(url) {
    const facebookPatterns = [
        /^(https?:\/\/)?(www\.|m\.|web\.)?facebook\.com/,
        /^(https?:\/\/)?(www\.)?fb\.watch/,
        /^(https?:\/\/)?(www\.)?fb\.com/
    ];
    return facebookPatterns.some(pattern => pattern.test(url));
}

function normalizeUrl(url) {
    url = url.trim()
        .replace(/^(https?:\/\/)?(m\.|mobile\.|web\.)?/, 'https://www.')
        .replace(/\?.*$/, ''); // Remove query params untuk cache
    return url;
}

function getCachedData(key) {
    const cached = cache.get(key);
    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
        console.log('💾 Cache hit:', key);
        return cached.data;
    }
    if (cached) cache.delete(key);
    return null;
}

function setCachedData(key, data) {
    cache.set(key, { data, timestamp: Date.now() });
    // Auto cleanup cache jika terlalu besar
    if (cache.size > 100) {
        const firstKey = cache.keys().next().value;
        cache.delete(firstKey);
    }
}

function extractVideoId(url) {
    // Extract unique identifier from URL for caching
    const matches = url.match(/\/(\d+)\/?/);
    return matches ? matches[1] : url;
}

async function facebookDownload(url) {
    try {
        if (!isValidFacebookUrl(url)) {
            throw new Error('Invalid Facebook URL');
        }
        
        // Check cache first
        const videoId = extractVideoId(url);
        const cached = getCachedData(`fb_${videoId}`);
        if (cached) return cached;
        
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 20000);
        
        // Prepare form data
        const formData = new URLSearchParams();
        formData.append('id', url);
        formData.append('locale', 'en');
        
        const startTime = Date.now();
        
        const response = await fetch(
            'https://likeedownloader.com/process',
            {
                method: 'POST',
                signal: controller.signal,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10)',
                    'Accept': 'application/json,text/javascript,*/*',
                    'x-requested-with': 'XMLHttpRequest',
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'origin': 'https://likeedownloader.com',
                    'referer': 'https://likeedownloader.com/facebook-video-downloader'
                },
                body: formData.toString()
            }
        );
        
        clearTimeout(timeout);
        const responseTime = Date.now() - startTime;
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        
        const data = await response.json();
        
        if (!data?.template) {
            throw new Error('Invalid response: no template found');
        }
        
        // Parse HTML template to extract download links and thumbnail
        function pick(regex) {
            const match = data.template.match(regex);
            return match ? match[1] : null;
        }
        
        const downloadLinks = [];
        const linkRegex = /href="([^"]+)"[^>]*download/g;
        let match;
        
        while ((match = linkRegex.exec(data.template)) !== null) {
            downloadLinks.push(match[1]);
        }
        
        const thumb = pick(/<img[^>]+src="([^"]+)"/);
        const title = pick(/<p[^>]*class="[^"]*title[^"]*"[^>]*>([^<]+)<\/p>/);
        
        if (downloadLinks.length === 0) {
            throw new Error('No download links found');
        }
        
        const result = {
            thumb: thumb || null,
            sd: downloadLinks[0] || null,
            hd: downloadLinks[1] || null,
            title: title || null,
            responseTime: responseTime
        };
        
        console.log(`✅ Facebook fetch: ${responseTime}ms | SD: ${!!result.sd} | HD: ${!!result.hd}`);
        
        // Cache result
        setCachedData(`fb_${videoId}`, result);
        
        return result;
        
    } catch (error) {
        console.error('❌ Facebook download error:', error.message);
        return { status: 'error', msg: error.message };
    }
}

async function downloadMedia(url, retries = 3) {
    for (let attempt = 1; attempt <= retries; attempt++) {
        try {
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), 45000); // 45s for large videos
            
            const response = await fetch(url, { 
                signal: controller.signal,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            clearTimeout(timeout);
            
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            
            const arrayBuffer = await response.arrayBuffer();
            const buffer = Buffer.from(arrayBuffer);
            
            console.log(`✅ Downloaded: ${(buffer.length / 1024 / 1024).toFixed(2)} MB`);
            return buffer;
            
        } catch (error) {
            console.error(`❌ Download attempt ${attempt}/${retries}:`, error.message);
            if (attempt === retries) throw error;
            await new Promise(resolve => setTimeout(resolve, 2000 * attempt));
        }
    }
}

let processingUsers = new Set(); // Anti-spam per user

let handler = async (m, { conn, args, usedPrefix, command }) => {
    const userId = m.sender;
    
    // Anti-spam check
    if (processingUsers.has(userId)) {
        return m.reply('⏳ Mohon tunggu, request sebelumnya masih diproses...');
    }
    
    const facebookUrl = args && args.length > 0 ? args.join(' ').trim() : '';
    
    if (!facebookUrl) {
        let prefix = usedPrefix || '.';
        const cmd = command || 'fb';
        
        return m.reply(`╭─❒ *Facebook Downloader* ❒
│
│ 📥 *Command:*
│ ${prefix}${cmd} <url>
│
│ 📌 *Examples:*
│ ${prefix}${cmd} facebook.com/watch?v=123
│ ${prefix}${cmd} fb.watch/abc123
│ ${prefix}${cmd} facebook.com/reel/456
│
│ ✨ *Features:*
│ • 🎬 Video Download (SD/HD)
│ • 🖼️ Thumbnail Preview
│ • 💾 Smart Caching (5m)
│ • 🔄 Auto Retry (3x)
│ • ⚡ Fast Processing
│ • 🛡️ Anti-Spam Protection
│ • 📊 Quality Selection
│
│ 📱 *Supported:*
│ Watch Videos, Reels, Stories
│
╰─────────────────❒`);
    }
    
    if (!isValidFacebookUrl(facebookUrl)) {
        await conn.sendMessage(m.chat, {
            react: { text: '❌', key: m.key }
        });
        return m.reply('❌ *Invalid URL*\n\nGunakan URL Facebook yang valid:\n• facebook.com/watch?v=...\n• facebook.com/reel/...\n• fb.watch/...');
    }
    
    // Set processing flag
    processingUsers.add(userId);
    
    try {
        // React: Processing
        await conn.sendMessage(m.chat, {
            react: { text: '🔍', key: m.key }
        });
        
        const startTime = Date.now();
        const result = await facebookDownload(facebookUrl);
        
        if (result.status === 'error') {
            await conn.sendMessage(m.chat, {
                react: { text: '❌', key: m.key }
            });
            return m.reply(`❌ *Download Failed*\n\n*Error:* ${result.msg}\n\n💡 *Possible Causes:*\n• Video is private\n• Invalid URL format\n• Content deleted\n• Region restricted\n\nTry a different video or check URL.`);
        }
        
        const { thumb, sd, hd, title } = result;
        
        if (!sd && !hd) {
            await conn.sendMessage(m.chat, {
                react: { text: '❌', key: m.key }
            });
            return m.reply('❌ *No Download Links Found*\n\nVideo mungkin private atau tidak tersedia.');
        }
        
        // Send info message
        const qualityInfo = [];
        if (sd) qualityInfo.push('SD ✓');
        if (hd) qualityInfo.push('HD ✓');
        
        await m.reply(`╭─❒ *Processing Video* ❒
│
│ 📹 *Quality Available:*
│ ${qualityInfo.join(' | ')}
│
${title ? `│ 📝 *Title:* ${title}\n│\n` : ''}│ ⏳ Downloading...
╰─────────────────❒`);
        
        // React: Downloading
        await conn.sendMessage(m.chat, {
            react: { text: '📥', key: m.key }
        });
        
        // Download HD first, fallback to SD
        const downloadUrl = hd || sd;
        const quality = hd ? 'HD' : 'SD';
        
        try {
            const videoBuffer = await downloadMedia(downloadUrl);
            const totalTime = Date.now() - startTime;
            
            // Prepare caption
            const caption = `╭─❒ *Facebook Video* ❒
│
│ 📹 *Quality:* ${quality}
│ 📦 *Size:* ${(videoBuffer.length / 1024 / 1024).toFixed(2)} MB
${title ? `│ 📝 *Title:* ${title}\n` : ''}│ ⚡ *Time:* ${(totalTime / 1000).toFixed(1)}s
│
╰─────────────────❒`;
            
            // Send video
            await conn.sendMessage(m.chat, {
                video: videoBuffer,
                mimetype: 'video/mp4',
                caption: caption,
                ...(thumb && { jpegThumbnail: await downloadMedia(thumb).catch(() => null) })
            }, { quoted: m });
            
            // React: Success
            await conn.sendMessage(m.chat, {
                react: { text: '✅', key: m.key }
            });
            
        } catch (downloadError) {
            console.error('❌ Download error:', downloadError.message);
            
            // Try alternative quality
            if (hd && sd) {
                await m.reply('⚠️ HD download gagal, mencoba SD...');
                
                try {
                    const videoBuffer = await downloadMedia(sd);
                    
                    await conn.sendMessage(m.chat, {
                        video: videoBuffer,
                        mimetype: 'video/mp4',
                        caption: `📹 *Quality:* SD (Fallback)\n📦 *Size:* ${(videoBuffer.length / 1024 / 1024).toFixed(2)} MB`
                    }, { quoted: m });
                    
                    await conn.sendMessage(m.chat, {
                        react: { text: '⚠️', key: m.key }
                    });
                    
                } catch (sdError) {
                    throw sdError;
                }
            } else {
                throw downloadError;
            }
        }
        
    } catch (error) {
        console.error('Error in Facebook downloader:', error);
        await conn.sendMessage(m.chat, {
            react: { text: '💥', key: m.key }
        });
        m.reply(`❌ *Error Occurred*\n\n\`\`\`${error.message || 'Unknown error'}\`\`\`\n\n💡 Tips:\n• Check if video is public\n• Try again in a few moments\n• Contact support if persists`);
    } finally {
        // Remove processing flag
        processingUsers.delete(userId);
    }
};

handler.help = ["likee", "likeefb"];
handler.tags = ["downloader"];
handler.command = ["likee", "likeefb"];
handler.limit = true;
handler.register = false;

export default handler;