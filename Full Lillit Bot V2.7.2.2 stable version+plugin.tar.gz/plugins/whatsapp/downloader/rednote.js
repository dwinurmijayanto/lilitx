import fetch from 'node-fetch';
import * as cheerio from 'cheerio';

const cache = new Map();
const CACHE_TTL = 5 * 60 * 1000;

function getCachedData(key) {
    const cached = cache.get(key);
    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
        return cached.data;
    }
    if (cached) cache.delete(key);
    return null;
}

function setCachedData(key, data) {
    cache.set(key, { data, timestamp: Date.now() });
    if (cache.size > 100) {
        const firstKey = cache.keys().next().value;
        cache.delete(firstKey);
    }
}

function getRandomIp() {
    const ip = [];
    for (let i = 0; i < 4; i++) {
        ip.push(Math.floor(Math.random() * 256));
    }
    return ip.join('.');
}

function removeUnicode(jsonString) {
    return jsonString
        .replace(/\\u/g, '')
        .replace(/\\n/g, '\n')
        .replace(/002F/g, '/')
        .replace(/undefined/g, 'null')
        .replace(/\\r/g, '\r')
        .replace(/\\t/g, '\t')
        .replace(/\\f/g, '\f')
        .replace(/\\b/g, '\b')
        .replace(/\\\\/g, '\\')
        .replace(/\\'/g, "'")
        .replace(/\\"/g, '"');
}

function isValidRedNoteUrl(url) {
    return /xiaohongshu\.com|xhslink\.com/.test(url);
}

function extractPostId(url) {
    const match = url.match(/\/([a-zA-Z0-9]+)(?:\?|$)/);
    return match ? match[1] : null;
}

async function rednoteDownload(url) {
    try {
        const postId = extractPostId(url);
        console.log('[RedNote DEBUG] Post ID:', postId);
        
        if (postId) {
            const cached = getCachedData(`rednote_${postId}`);
            if (cached) {
                console.log('[RedNote DEBUG] Cache hit');
                return cached;
            }
        }
        
        // Follow redirects for short URLs (improved)
        if (url.includes('xhslink.com')) {
            console.log('[RedNote DEBUG] Short URL detected, following redirect...');
            try {
                const redirectController = new AbortController();
                const redirectTimeout = setTimeout(() => redirectController.abort(), 10000);
                
                const redirectResponse = await fetch(url, {
                    signal: redirectController.signal,
                    redirect: 'follow', // Changed from 'manual' to 'follow'
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15'
                    }
                });
                
                clearTimeout(redirectTimeout);
                
                // Get final URL after redirects
                url = redirectResponse.url;
                console.log('[RedNote DEBUG] Final URL after redirect:', url);
                
                // If still xhslink, try to extract from HTML
                if (url.includes('xhslink.com')) {
                    const html = await redirectResponse.text();
                    const $ = cheerio.load(html);
                    const metaUrl = $('meta[property="og:url"]').attr('content');
                    if (metaUrl) {
                        url = metaUrl;
                        console.log('[RedNote DEBUG] Extracted from meta tag:', url);
                    }
                }
            } catch (e) {
                console.log('[RedNote DEBUG] Redirect follow failed:', e.message);
                // If redirect fails, try to construct URL from post ID
                if (postId) {
                    url = `https://www.xiaohongshu.com/explore/${postId}`;
                    console.log('[RedNote DEBUG] Constructed URL from post ID:', url);
                }
            }
        }
        
        console.log('[RedNote DEBUG] Fetching URL:', url);
        
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 30000);
        
        const randomIp = getRandomIp();
        console.log('[RedNote DEBUG] Using random IP:', randomIp);
        
        const response = await fetch(url, {
            signal: controller.signal,
            headers: {
                'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
                'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
                'Accept-Encoding': 'gzip, deflate, br',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
                'Sec-Fetch-Dest': 'document',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-Site': 'none',
                'Sec-Fetch-User': '?1',
                'Cache-Control': 'max-age=0',
                'DNT': '1',
                'X-Forwarded-For': randomIp,
                'Referer': 'https://www.xiaohongshu.com/'
            }
        });
        
        clearTimeout(timeout);
        
        console.log('[RedNote DEBUG] Response status:', response.status);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        
        const html = await response.text();
        console.log('[RedNote DEBUG] HTML length:', html.length);
        
        const $ = cheerio.load(html);
        
        const scriptCount = $('script').length;
        console.log('[RedNote DEBUG] Script tags found:', scriptCount);
        
        let jsonString;
        try {
            const scriptText = $('script').last().text();
            console.log('[RedNote DEBUG] Last script length:', scriptText.length);
            console.log('[RedNote DEBUG] Script preview:', scriptText.substring(0, 200));
            
            if (!scriptText.includes('window.__INITIAL_STATE__=')) {
                console.log('[RedNote DEBUG] __INITIAL_STATE__ not found in last script');
                throw new Error('__INITIAL_STATE__ not found');
            }
            
            jsonString = scriptText
                .split('window.__INITIAL_STATE__=')[1]
                .replace(/\\\//g, '/');
            
            console.log('[RedNote DEBUG] Extracted JSON length:', jsonString.length);
            console.log('[RedNote DEBUG] JSON preview:', jsonString.substring(0, 200));
        } catch (error) {
            console.error('[RedNote DEBUG] Extract error:', error.message);
            throw new Error('Failed to extract JSON data');
        }
        
        if (!jsonString) {
            throw new Error('No JSON data found');
        }
        
        let data;
        try {
            const cleanJson = removeUnicode(jsonString);
            console.log('[RedNote DEBUG] Clean JSON length:', cleanJson.length);
            console.log('[RedNote DEBUG] Clean JSON preview:', cleanJson.substring(0, 300));
            
            // Find the end of the main JSON object
            let braceCount = 0;
            let jsonEnd = -1;
            for (let i = 0; i < cleanJson.length; i++) {
                if (cleanJson[i] === '{') braceCount++;
                if (cleanJson[i] === '}') {
                    braceCount--;
                    if (braceCount === 0) {
                        jsonEnd = i;
                        break;
                    }
                }
            }
            
            if (jsonEnd === -1) {
                throw new Error('Invalid JSON structure - could not find end');
            }
            
            const validJson = cleanJson.substring(0, jsonEnd + 1);
            console.log('[RedNote DEBUG] Valid JSON length:', validJson.length);
            
            data = JSON.parse(validJson);
            console.log('[RedNote DEBUG] JSON parsed successfully');
            console.log('[RedNote DEBUG] Data keys:', Object.keys(data));
        } catch (error) {
            console.error('[RedNote DEBUG] JSON parse error:', error.message);
            console.error('[RedNote DEBUG] Error at position:', error.message.match(/position (\d+)/)?.[1]);
            throw new Error('Failed to parse JSON data: ' + error.message);
        }
        
        console.log('[RedNote DEBUG] Looking for note data...');
        console.log('[RedNote DEBUG] data.note exists:', !!data.note);
        
        const id = data.note?.firstNoteId || data.note?.currentNoteId;
        console.log('[RedNote DEBUG] Note ID:', id);
        
        if (!id) {
            console.log('[RedNote DEBUG] Available note keys:', data.note ? Object.keys(data.note) : 'no note object');
            throw new Error('Note ID not found');
        }
        
        console.log('[RedNote DEBUG] noteDetailMap exists:', !!data.note?.noteDetailMap);
        console.log('[RedNote DEBUG] noteDetailMap keys:', data.note?.noteDetailMap ? Object.keys(data.note.noteDetailMap) : 'none');
        
        const meta = data.note?.noteDetailMap?.[id]?.note;
        console.log('[RedNote DEBUG] Meta exists:', !!meta);
        
        if (!meta) {
            throw new Error('Note metadata not found');
        }
        
        console.log('[RedNote DEBUG] Meta keys:', Object.keys(meta));
        console.log('[RedNote DEBUG] Has video:', !!meta.video);
        console.log('[RedNote DEBUG] Has imageList:', !!meta.imageList);
        
        const result = {
            metadata: {
                title: meta.title || 'No Title',
                category: meta.tagList?.map(a => a.name) || [],
                stats: meta.interactInfo || {},
                author: {
                    nickname: meta.user?.nickname || 'Unknown',
                    userId: meta.user?.userId || ''
                }
            },
            download: null,
            type: null
        };
        
        if (meta.video) {
            result.type = 'video';
            result.download = meta.video.media?.stream?.h264?.[0]?.masterUrl || null;
            console.log('[RedNote DEBUG] Video URL:', result.download);
        } else if (meta.imageList) {
            result.type = 'image';
            result.download = meta.imageList.map(a => a.urlDefault || a.url);
            console.log('[RedNote DEBUG] Image count:', result.download.length);
        }
        
        if (!result.download || (Array.isArray(result.download) && result.download.length === 0)) {
            throw new Error('No media found');
        }
        
        if (postId) setCachedData(`rednote_${postId}`, result);
        
        console.log('[RedNote DEBUG] Success:', result.type);
        return result;
        
    } catch (error) {
        console.error('[RedNote DEBUG] Final error:', error.message);
        console.error('[RedNote DEBUG] Stack:', error.stack);
        return { status: 'error', msg: error.message };
    }
}

async function downloadMedia(url) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30000);
    
    const response = await fetch(url, {
        signal: controller.signal,
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
    });
    
    clearTimeout(timeout);
    
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    
    const arrayBuffer = await response.arrayBuffer();
    return Buffer.from(arrayBuffer);
}

let processingUsers = new Set();

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    const userId = m.sender;
    let prefix = usedPrefix || '.';
    const cmd = command || 'rednote';
    
    if (processingUsers.has(userId)) {
        return m.reply('⏳ Tunggu download sebelumnya...');
    }
    
    let url = '';
    if (text) {
        url = text.trim();
    } else if (args && args.length > 0) {
        url = args.join(' ').trim();
    }
    
    if (!url) {
        return m.reply(`*RedNote Downloader*

Gunakan: ${prefix}${cmd} <url>

Contoh:
${prefix}${cmd} https://xiaohongshu.com/xxx
${prefix}${cmd} https://xhslink.com/xxx`);
    }
    
    if (!isValidRedNoteUrl(url)) {
        return m.reply('❌ URL RedNote tidak valid');
    }
    
    processingUsers.add(userId);
    
    try {
        await conn.sendMessage(m.chat, {
            react: { text: '⏳', key: m.key }
        });
        
        const result = await rednoteDownload(url);
        
        if (result.status === 'error') {
            await conn.sendMessage(m.chat, {
                react: { text: '❌', key: m.key }
            });
            return m.reply(`❌ Download gagal: ${result.msg}

🐛 Cek console untuk detail debug`);
        }
        
        const caption = `📌 *${result.metadata.title}*

👤 ${result.metadata.author.nickname}
${result.metadata.category.length > 0 ? `🏷️ ${result.metadata.category.join(', ')}` : ''}`;
        
        if (result.type === 'video' && result.download) {
            const videoBuffer = await downloadMedia(result.download);
            
            await conn.sendMessage(m.chat, {
                video: videoBuffer,
                mimetype: 'video/mp4',
                caption: caption
            }, { quoted: m });
            
        } else if (result.type === 'image' && Array.isArray(result.download)) {
            for (let i = 0; i < result.download.length; i++) {
                const imageBuffer = await downloadMedia(result.download[i]);
                
                await conn.sendMessage(m.chat, {
                    image: imageBuffer,
                    mimetype: 'image/jpeg',
                    caption: i === 0 ? caption : undefined
                }, { quoted: m });
                
                if (i < result.download.length - 1) {
                    await new Promise(resolve => setTimeout(resolve, 1500));
                }
            }
        } else {
            throw new Error('Tidak ada media ditemukan');
        }
        
        await conn.sendMessage(m.chat, {
            react: { text: '✅', key: m.key }
        });
        
    } catch (error) {
        console.error('[RedNote] Handler error:', error);
        
        await conn.sendMessage(m.chat, {
            react: { text: '❌', key: m.key }
        });
        
        m.reply(`❌ Error: ${error.message}

🐛 Cek console untuk detail debug`);
    } finally {
        processingUsers.delete(userId);
    }
};

handler.help = ["rednote"];
handler.tags = ["downloader"];
handler.command = ["rednote", "rednotedl", "xhs"];
handler.limit = true;
handler.register = false;

export default handler;