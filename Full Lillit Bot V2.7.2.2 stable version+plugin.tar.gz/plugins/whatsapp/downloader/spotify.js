import fetch from 'node-fetch';

console.log('[SPOTIFY] Handler loaded - Search + SpotMate downloader');

// ========== CONFIG ==========
const BASE = 'https://spotmate.online';
const POLL_INTERVAL = 5000;
const POLL_MAX = 40;
const SPOTIFY_SEARCH_API = 'https://api.spotify.com/v1/search';
const SPOTIFY_TOKEN_URL = 'https://accounts.spotify.com/api/token';

// Spotify App credentials (public client credentials flow - tidak butuh login user)
// Daftarkan di https://developer.spotify.com/dashboard dan isi di sini:
const SPOTIFY_CLIENT_ID = 'da714f860e7e40369c740c9f47749872';
const SPOTIFY_CLIENT_SECRET = '288a148dc54849328009f7048232abb4';

const UA_HEADERS = {
    'user-agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Mobile Safari/537.36',
    'referer': `${BASE}/`,
    'origin': BASE,
    'sec-ch-ua': '"Not:A-Brand";v="99", "Google Chrome";v="145", "Chromium";v="145"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'accept-language': 'en-US,en;q=0.9',
};

const sleep = ms => new Promise(r => setTimeout(r, ms));

// ========== SPOTIFY SEARCH ==========
let _spotifyToken = null;
let _tokenExpiry = 0;

async function getSpotifyToken() {
    if (_spotifyToken && Date.now() < _tokenExpiry) return _spotifyToken;

    const res = await fetch(SPOTIFY_TOKEN_URL, {
        method: 'POST',
        headers: {
            'Authorization': 'Basic ' + Buffer.from(`${SPOTIFY_CLIENT_ID}:${SPOTIFY_CLIENT_SECRET}`).toString('base64'),
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'grant_type=client_credentials',
    });

    if (!res.ok) throw new Error(`Spotify token HTTP ${res.status}`);
    const data = await res.json();
    _spotifyToken = data.access_token;
    _tokenExpiry = Date.now() + (data.expires_in - 60) * 1000;
    return _spotifyToken;
}

async function searchSpotify(query, limit = 5) {
    const token = await getSpotifyToken();
    const params = new URLSearchParams({ q: query, type: 'track', limit: String(limit) });
    const res = await fetch(`${SPOTIFY_SEARCH_API}?${params}`, {
        headers: { 'Authorization': `Bearer ${token}` }
    });
    if (!res.ok) throw new Error(`Spotify search HTTP ${res.status}`);
    const data = await res.json();
    return data.tracks?.items || [];
}

// ========== SPOTMATE ==========
async function getCsrf() {
    const res = await fetch(`${BASE}/en1`, {
        headers: { ...UA_HEADERS, 'accept': 'text/html,application/xhtml+xml' }
    });
    const html = await res.text();
    const csrfMatch = html.match(/<meta name="csrf-token" content="([^"]+)"/);
    if (!csrfMatch) throw new Error('CSRF token tidak ditemukan');
    const rawCookies = res.headers.raw()['set-cookie'] || [];
    const cookie = rawCookies.map(c => c.split(';')[0]).join('; ');
    return { csrf: csrfMatch[1], cookie };
}

async function getTrackData(spotifyUrl, csrf, cookie) {
    const res = await fetch(`${BASE}/getTrackData`, {
        method: 'POST',
        headers: {
            ...UA_HEADERS,
            'content-type': 'application/json',
            'accept': 'application/json',
            'x-csrf-token': csrf,
            'x-requested-with': 'XMLHttpRequest',
            'cookie': cookie,
        },
        body: JSON.stringify({ spotify_url: spotifyUrl }),
    });
    if (!res.ok) throw new Error(`getTrackData HTTP ${res.status}`);
    return res.json();
}

async function convert(trackUrl, csrf, cookie) {
    const res = await fetch(`${BASE}/convert`, {
        method: 'POST',
        headers: {
            ...UA_HEADERS,
            'content-type': 'application/json',
            'accept': 'application/json',
            'x-csrf-token': csrf,
            'x-requested-with': 'XMLHttpRequest',
            'cookie': cookie,
        },
        body: JSON.stringify({ urls: trackUrl }),
    });
    if (!res.ok) throw new Error(`convert HTTP ${res.status}`);
    return res.json();
}

async function pollTask(taskId, cookie) {
    for (let i = 0; i < POLL_MAX; i++) {
        await sleep(POLL_INTERVAL);
        try {
            const res = await fetch(`${BASE}/tasks/${encodeURIComponent(taskId)}`, {
                headers: { ...UA_HEADERS, 'accept': 'application/json', 'cookie': cookie }
            });
            if (!res.ok) continue;
            const payload = await res.json();
            const info = payload?.data || {};
            const status = String(info.status || info.state || '').toLowerCase();
            console.log(`[SPOTIFY] Poll #${i + 1} status: ${status}`);
            if (status === 'finished') {
                const url = info.url || info.download_url || info?.result?.url || info?.result?.download_url;
                if (url) return url;
                throw new Error('Task selesai tapi tidak ada URL download');
            }
            if (['failed', 'error', 'expired', 'cancelled'].includes(status)) {
                throw new Error(info.message || `Task status: ${status}`);
            }
        } catch (err) {
            if (err.message.includes('Task') || err.message.includes('status')) throw err;
            console.error(`[SPOTIFY] Poll error #${i + 1}:`, err.message);
        }
    }
    throw new Error('Timeout: konversi terlalu lama');
}

async function downloadBuffer(url) {
    const res = await fetch(url, { headers: UA_HEADERS });
    if (!res.ok) throw new Error(`Download file HTTP ${res.status}`);
    const buf = await res.buffer();
    if (buf.length < 5000) throw new Error('File terlalu kecil, kemungkinan error');
    return buf;
}

// ========== DOWNLOAD PROSES ==========
async function processDownload(m, conn, spotifyTrackUrl) {
    const { csrf, cookie } = await getCsrf();
    const trackData = await getTrackData(spotifyTrackUrl, csrf, cookie);

    if (!trackData || (!trackData.type && !trackData.tracks)) {
        throw new Error(trackData?.status || 'Data track tidak ditemukan');
    }

    let track;
    if (trackData.type === 'track') {
        track = trackData;
        spotifyTrackUrl = trackData.external_urls?.spotify || spotifyTrackUrl;
    } else if (trackData.type === 'album') {
        track = { ...trackData.tracks.items[0], album: { images: trackData.images, name: trackData.name } };
        spotifyTrackUrl = track.external_urls?.spotify;
    } else if (trackData.type === 'playlist') {
        const item = trackData.tracks.items[0]?.track;
        track = item;
        spotifyTrackUrl = item?.external_urls?.spotify;
    }

    if (!spotifyTrackUrl) throw new Error('URL track tidak ditemukan');

    const title = track?.name || 'Unknown';
    const artist = track?.artists?.map(a => a.name).join(', ') || 'Unknown';
    const album = track?.album?.name || '';
    const ms = track?.duration_ms;
    const duration = ms ? ` ⏱️ ${Math.floor(ms / 60000)}:${String(Math.floor((ms % 60000) / 1000)).padStart(2, '0')}` : '';

    await conn.sendMessage(m.chat, { react: { text: '⬇️', key: m.key } });

    const convertRes = await convert(spotifyTrackUrl, csrf, cookie);
    let downloadUrl;

    if (convertRes.error === false && convertRes.url) {
        downloadUrl = convertRes.url;
    } else if (convertRes.task_id || convertRes.taskId) {
        downloadUrl = await pollTask(convertRes.task_id || convertRes.taskId, cookie);
    } else {
        throw new Error(convertRes.status || convertRes.message || 'Convert gagal');
    }

    const audioBuffer = await downloadBuffer(downloadUrl);
    const caption = `🎵 *${title}*\n👤 ${artist}${album ? `\n💿 ${album}` : ''}${duration}`;

    await conn.sendMessage(m.chat, {
        audio: audioBuffer,
        mimetype: 'audio/mpeg',
        fileName: `${title} - ${artist}.mp3`,
        ptt: false,
        caption,
    }, { quoted: m });

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}

// ========== HELP ==========
function help(prefix, cmd) {
    return `🎵 *Spotify Downloader*

*Download via link:*
${prefix}${cmd} https://open.spotify.com/track/xxx

*Download via judul lagu:*
${prefix}${cmd} Kau Masih Kekasihku NaFF
${prefix}${cmd} shape of you ed sheeran`;
}

// ========== MAIN HANDLER ==========
const handler = async (m, { conn, text, args, usedPrefix, command }) => {
    const prefix = usedPrefix || '.';
    const cmd = command || 'spotify';
    const input = (text || args.join(' ')).trim();

    if (!input || ['help', '?'].includes(input.toLowerCase())) {
        return m.reply(help(prefix, cmd));
    }

    try {
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        let spotifyUrl;

        // ── Link langsung ──
        if (/https?:\/\/(open\.)?spotify\.com\/(track|album|playlist)\/[a-zA-Z0-9]+/.test(input)) {
            spotifyUrl = input;
        } else {
            // ── Cari di Spotify, ambil hasil paling relevan (#1) ──
            const results = await searchSpotify(input, 1);
            if (!results.length) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ Lagu *"${input}"* tidak ditemukan di Spotify.`);
            }
            spotifyUrl = results[0].external_urls.spotify;
            console.log('[SPOTIFY] Search result URL:', spotifyUrl);
        }

        await processDownload(m, conn, spotifyUrl);

    } catch (err) {
        console.error('[SPOTIFY] Error:', err.message, err.stack);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        m.reply(`❌ Gagal: ${err.message}`);
    }
};

handler.help = ['spotify <link/judul> - cari & download lagu Spotify'];
handler.tags = ['downloader', 'music'];
handler.command = ['spotify', 'spotdl', 'sp'];
handler.limit = true;

export default handler;