const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

// ═══════════════════════════════════════════════════════════════════
//  Vidoy / Vide63 Downloader — No 3rd Party API
//  Scraping langsung ke vide63.com
//  Support: Single video (/e/, /d/), Folder (/f/)
// ═══════════════════════════════════════════════════════════════════

// ─── Config ───────────────────────────────────────────────────────

const PROCESS_DOMAIN = 'vide63.com';
const BASE_URL       = `https://${PROCESS_DOMAIN}`;

// ─── Validators ───────────────────────────────────────────────────

function isValidVidoyUrl(url) {
    return /\/(e|d|f)\/[a-z0-9]+/i.test(url);
}

function extractVidoyUrls(text) {
    const matches = text.match(/https?:\/\/[^\s]+\/(?:e|d|f)\/[a-z0-9]+[^\s]*/gi) || [];
    return [...new Set(matches)];
}

function normalizeUrl(url) {
    if (!url.startsWith('http')) url = 'https://' + url;
    // Normalize semua domain ke vide63.com untuk processing
    return url.replace(/https?:\/\/[^\/]+/, BASE_URL);
}

function isFolder(url) { return /\/f\//i.test(url); }

function extractVideoId(url) {
    return url.match(/\/(?:e|d|v|watch)\/([a-z0-9]+)/i)?.[1] || null;
}

function extractFolderId(url) {
    return url.match(/\/f\/([a-z0-9]+)/i)?.[1] || null;
}

function videoIdToIframeId(videoId) {
    return Buffer.from(videoId).toString('hex');
}

// ─── Helpers ──────────────────────────────────────────────────────

function randomDelay(min = 1000, max = 3000) {
    return new Promise(r => setTimeout(r, Math.floor(Math.random() * (max - min)) + min));
}

function formatSize(bytes) {
    bytes = Number(bytes) || 0;
    if (bytes >= 1_048_576) return (bytes/1_048_576).toFixed(2) + ' MB';
    if (bytes >= 1_024)     return (bytes/1_024).toFixed(1) + ' KB';
    return bytes + ' B';
}

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

async function fetchHtml(url, referer = null) {
    const headers = {
        'User-Agent':      UA,
        'Accept':          'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        ...(referer ? { 'Referer': referer } : {}),
    };
    const res = await fetch(url, { headers, timeout: 30000, follow: 5 });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res.text();
}

async function downloadBuffer(url, referer = BASE_URL) {
    const res = await fetch(url, {
        timeout: 120000,
        follow: 10,
        headers: {
            'User-Agent': UA,
            'Accept':     '*/*',
            'Referer':    referer,
        }
    });
    if (!res.ok) throw new Error(`Download HTTP ${res.status}`);
    const buf = Buffer.from(await res.arrayBuffer());
    console.log(`📦 Downloaded: ${formatSize(buf.length)}`);
    return buf;
}

// ─── Extractors ───────────────────────────────────────────────────

function extractMp4Url(html) {
    const patterns = [
        /<source\s+src=["']([^"']+\.mp4[^"']*)['"]/i,
        /<source[^>]+src=["']([^"']+)["'][^>]+type=["']video\/mp4["']/i,
        /src:\s*["']([^"']+\.mp4[^"']*)['"]/i,
        /https?:\/\/[^"'<>\s]+\.mp4[^"'<>\s]*/i,
        /file:\s*["']([^"']+)['"]/i,
    ];
    for (const p of patterns) {
        const m = html.match(p);
        if (m) {
            const url = (m[1] || m[0]).replace(/&amp;/g, '&');
            if (url.startsWith('http')) return url;
        }
    }
    return null;
}

function extractPoster(html) {
    return html.match(/poster=["']([^"']+)['"]/i)?.[1] || null;
}

function extractEmbedUrl(html, videoId) {
    const patterns = [
        /playerPath\s*=\s*["']([^"']+)['"]/,
        /fullURL\s*=\s*["']([^"']+)['"]/,
        /src=["']([^"']*embed\.php[^"']*)['"]/,
        /https?:\/\/[^"']+\/embed\.php\?[^"']+/,
    ];
    for (const p of patterns) {
        const m = html.match(p);
        if (m) return m[1] || m[0];
    }
    return `${BASE_URL}/embed.php?bucket=temporary&id=${videoId}`;
}

// ─── Core: Single Video ───────────────────────────────────────────

async function getSingleVideo(url) {
    const videoId = extractVideoId(url);
    if (!videoId) throw new Error('Video ID tidak ditemukan dari URL');

    const normalized = normalizeUrl(url);
    console.log(`🎯 Video ID: ${videoId} | URL: ${normalized}`);

    // Method 1: Direct embed (paling cepat)
    try {
        const embedUrl  = `${BASE_URL}/embed.php?bucket=temporary&id=${videoId}`;
        console.log(`🔗 Trying direct embed: ${embedUrl}`);
        const embedHtml = await fetchHtml(embedUrl);
        const mp4Url    = extractMp4Url(embedHtml);
        if (mp4Url) {
            console.log(`✅ Method 1 (direct embed) success`);
            return {
                video_id:     videoId,
                download_url: mp4Url,
                thumbnail:    extractPoster(embedHtml),
                embed_url:    embedUrl,
                title:        `Video ${videoId}`,
                method:       'direct_embed',
            };
        }
    } catch (e) {
        console.log(`⚠️  Method 1 failed: ${e.message}`);
    }

    // Method 2: Via IP endpoint
    try {
        const iframeId = videoIdToIframeId(videoId);
        const ipUrl    = `${BASE_URL}/ip129jk?id=${iframeId}`;
        console.log(`🔗 Trying IP endpoint: ${ipUrl}`);
        const ipHtml   = await fetchHtml(ipUrl, normalized);
        const embedUrl = extractEmbedUrl(ipHtml, videoId);
        console.log(`🔗 Embed URL: ${embedUrl}`);

        const embedHtml = await fetchHtml(embedUrl, ipUrl);
        const mp4Url    = extractMp4Url(embedHtml);
        if (!mp4Url) throw new Error('MP4 URL tidak ditemukan di embed page');

        console.log(`✅ Method 2 (IP endpoint) success`);
        return {
            video_id:     videoId,
            download_url: mp4Url,
            thumbnail:    extractPoster(embedHtml),
            embed_url:    embedUrl,
            title:        `Video ${videoId}`,
            method:       'ip_endpoint',
        };
    } catch (e) {
        console.log(`⚠️  Method 2 failed: ${e.message}`);
        throw new Error(`Gagal mendapatkan URL video: ${e.message}`);
    }
}

// ─── Core: Folder ─────────────────────────────────────────────────

async function getFolderVideos(url) {
    const folderId = extractFolderId(url);
    if (!folderId) throw new Error('Folder ID tidak ditemukan dari URL');

    const normalized = normalizeUrl(url);
    console.log(`📁 Folder ID: ${folderId} | URL: ${normalized}`);

    const html = await fetchHtml(normalized);

    // Extract semua video link dari folder
    const patterns = [
        /href=["']\/(e|d|v)\/([a-z0-9]+)['"]/gi,
        /href=\/(e|d|v)\/([a-z0-9]+)/gi,
        /https?:\/\/[^/"']+\/(e|d|v)\/([a-z0-9]+)/gi,
    ];

    const seen   = new Set();
    const videos = [];

    for (const p of patterns) {
        let m;
        // Reset lastIndex
        p.lastIndex = 0;
        while ((m = p.exec(html)) !== null) {
            const path    = m[1].toLowerCase();
            const videoId = m[2];
            if (!seen.has(videoId)) {
                seen.add(videoId);
                videos.push({ path, videoId, url: `${BASE_URL}/${path}/${videoId}` });
            }
        }
        if (videos.length) break;
    }

    if (!videos.length) throw new Error('Tidak ada video ditemukan dalam folder ini');

    console.log(`📂 Found ${videos.length} videos in folder`);
    return { folderId, videos, folderHtml: html };
}

// ─── Caption Builder ──────────────────────────────────────────────

function buildCaption(data, index = null, total = null) {
    let cap = '';
    if (index && total) cap += `🎬 *Video ${index}/${total}*\n`;
    cap += `📁 ID: \`${data.video_id}\`\n`;
    if (data.title && data.title !== `Video ${data.video_id}`) cap += `📝 ${data.title}\n`;
    cap += `🔧 Method: ${data.method}\n`;
    cap += `☁️ vide63.com`;
    return cap.trim();
}

// ─── Handler ──────────────────────────────────────────────────────

const HELP_MSG = (p, c) => `
*📥 Vidoy / Vide63 Downloader*
_Direct scraping — No API Key_

*Single Video:*
${p}${c} https://vide63.com/e/VIDEO_ID
${p}${c} https://vide63.com/d/VIDEO_ID

*Folder (bulk semua video):*
${p}${c} https://vide63.com/f/FOLDER_ID

*Domain yang didukung:*
✅ vide63.com
✅ vid8.online
✅ vid9.online
✅ vidstream.online

📺 Support: /e/, /d/, /v/ (single) dan /f/ (folder)
`.trim();

let handler = async (m, { conn, args, usedPrefix, command }) => {
    const input  = args?.join(' ').trim() || '';
    const prefix = usedPrefix || m.text?.match(/^([.!#/])/)?.[1] || '.';
    const cmd    = command || 'vidoy';

    if (!input) return m.reply(HELP_MSG(prefix, cmd));

    const urls = extractVidoyUrls(input).filter(isValidVidoyUrl);
    if (!urls.length)
        return m.reply('❌ URL tidak valid.\n\nPastikan URL mengandung /e/, /d/, atau /f/\n\nContoh:\n• https://vide63.com/e/abc123\n• https://domain-lain.com/f/abc123');

    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    for (const rawUrl of urls) {
        const url = normalizeUrl(rawUrl.startsWith('http') ? rawUrl : 'https://' + rawUrl);

        // ── FOLDER mode ───────────────────────────────────────────
        if (isFolder(url)) {
            try {
                const { folderId, videos } = await getFolderVideos(url);
                await m.reply(`📁 *Folder Ditemukan!*\n🗂 ID: \`${folderId}\`\n🎬 Total: *${videos.length} video*\n⏳ Memproses satu per satu...`);

                let ok = 0, fail = 0;
                for (let i = 0; i < videos.length; i++) {
                    const v = videos[i];
                    try {
                        const data  = await getSingleVideo(v.url);
                        const buf   = await downloadBuffer(data.download_url, BASE_URL);
                        const thumbBuf = data.thumbnail
                            ? await downloadBuffer(data.thumbnail, BASE_URL).catch(() => null)
                            : null;

                        await conn.sendMessage(m.chat, {
                            video:         buf,
                            jpegThumbnail: thumbBuf ?? undefined,
                            mimetype:      'video/mp4',
                            caption:       buildCaption(data, i + 1, videos.length),
                        }, { quoted: m });

                        ok++;
                    } catch (e) {
                        console.error(`❌ Folder video ${i+1} error:`, e.message);
                        fail++;
                        await m.reply(`⚠️ Video ${i+1}/${videos.length} gagal: ${e.message}`);
                    }

                    if (i < videos.length - 1) await randomDelay(2000, 4000);
                }

                await conn.sendMessage(m.chat, { react: { text: ok > 0 ? '✅' : '❌', key: m.key } });
                await m.reply(`📊 *Selesai*\n✅ Berhasil : ${ok}/${videos.length}\n❌ Gagal    : ${fail}/${videos.length}`);

            } catch (e) {
                console.error(`❌ Folder error:`, e.message);
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                await m.reply(`❌ Gagal memproses folder.\n*Error:* ${e.message}`);
            }

        // ── SINGLE VIDEO mode ─────────────────────────────────────
        } else {
            try {
                const data     = await getSingleVideo(url);
                const buf      = await downloadBuffer(data.download_url, BASE_URL);
                const thumbBuf = data.thumbnail
                    ? await downloadBuffer(data.thumbnail, BASE_URL).catch(() => null)
                    : null;

                await conn.sendMessage(m.chat, {
                    video:         buf,
                    jpegThumbnail: thumbBuf ?? undefined,
                    mimetype:      'video/mp4',
                    caption:       buildCaption(data),
                }, { quoted: m });

                await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

            } catch (e) {
                console.error(`❌ Vidoy Error:`, e.message);
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                await m.reply(`❌ Gagal download video.\n*Error:* ${e.message}`);
            }
        }
    }
};

handler.help    = ['vidoy', 'vide63', 'vid63'];
handler.tags    = ['downloader'];
handler.command = ['vidoy', 'vide63', 'vid63'];

export default handler;