// ========================================
// HANDLER: Universal Download Command (dl)
// Auto-detect platform dari URL dan redirect ke command yang sesuai
// ========================================

const handler = async (m, { conn, text, usedPrefix = '.', command = 'dl' }) => {
  console.log("\n==============================================");
  console.log("[DL] Universal download handler dipanggil");
  console.log("[DL] Chat ID:", m.chat);
  console.log("[DL] Sender:", m.sender);
  console.log("[DL] Input text:", text);
  console.log("[DL] usedPrefix:", usedPrefix);
  console.log("[DL] command:", command);
  console.log("==============================================\n");

  try {
    // ========================================
    // STEP 1: Extract text input
    // ========================================
    
    // Jika text kosong, coba extract dari m.text atau m.body
    let inputText = text;
    
    if (!inputText) {
      if (m.text) {
        inputText = m.text;
        // Remove command dari text
        const cmdRegex = new RegExp(`^${usedPrefix}${command}\\s*`, 'i');
        inputText = inputText.replace(cmdRegex, '').trim();
      } else if (m.body) {
        inputText = m.body;
        const cmdRegex = new RegExp(`^${usedPrefix}${command}\\s*`, 'i');
        inputText = inputText.replace(cmdRegex, '').trim();
      }
    }
    
    console.log("[DL] Extracted input text:", inputText);
    
    // ========================================
    // STEP 2: Validasi input
    // ========================================
    if (!inputText || inputText.trim() === '') {
      return m.reply(
        `❌ *Cara penggunaan salah!*\n\n` +
        `Kirim URL yang ingin di-download.\n\n` +
        `*Format:*\n` +
        `${usedPrefix}${command} <url>\n\n` +
        `*Contoh:*\n` +
        `${usedPrefix}${command} https://youtube.com/watch?v=xxxxx\n` +
        `${usedPrefix}${command} https://tiktok.com/@user/video/123\n` +
        `${usedPrefix}${command} https://facebook.com/watch/xxxxx\n\n` +
        `✨ *Platform yang didukung:*\n` +
        `• YouTube (yt)\n` +
        `• TikTok (tt)\n` +
        `• Facebook (fb)\n` +
        `• Instagram (ig)\n` +
        `• Videy (videy)\n` +
        `• Streamable (streamable)\n` +
        `• TeraBox (terabox)\n` +
        `• Douyin (douyin)\n` +
        `• Snack Video (snack)\n` +
        `• Suno AI (suno)\n` +
        `• Spotify (spotify)\n` +
        `• SoundCloud (soundcloud)\n` +
        `• MediaFire (mediafire)\n` +
        `• Google Drive (gdrive)\n` +
        `• Dailymotion (dailymotion)\n` +
        `• Mega (mega)`
      );
    }

    // ========================================
    // STEP 3: Extract URL dari text
    // ========================================
    // Regex yang lebih robust untuk handle URL dengan # dan karakter spesial
    const urlRegex = /(https?:\/\/[^\s]+)/gi;
    const urls = inputText.match(urlRegex);

    if (!urls || urls.length === 0) {
      return m.reply(
        `❌ *URL tidak ditemukan!*\n\n` +
        `Text yang Anda kirim: "${inputText}"\n\n` +
        `Pastikan mengirim URL yang valid.\n` +
        `Contoh: ${usedPrefix}${command} https://youtube.com/watch?v=xxxxx`
      );
    }

    let url = urls[0]; // Ambil URL pertama
    
    // Special handling untuk URL yang mengandung # (seperti Mega, Google Drive anchor)
    // Pastikan hash/fragment tidak terpotong
    if (!url.includes('#') && inputText.includes('#')) {
      // Coba extract ulang dengan cara manual
      const manualMatch = inputText.match(/(https?:\/\/\S+)/i);
      if (manualMatch && manualMatch[0].includes('#')) {
        url = manualMatch[0];
      }
    }
    
    console.log("[DL] URL extracted:", url);

    // ========================================
    // STEP 4: Detect platform dari URL
    // ========================================
    
    /**
     * Mapping URL patterns ke command yang sesuai
     */
    const urlMappings = [
      // YouTube
      {
        patterns: [
          /youtube\.com\/watch/i,
          /youtu\.be\//i,
          /youtube\.com\/shorts/i,
          /youtube\.com\/live/i,
          /m\.youtube\.com/i,
          /music\.youtube\.com/i
        ],
        command: 'yt',
        name: 'YouTube',
        icon: '📺'
      },
      // Videy
      {
        patterns: [
          /videy\.co/i
        ],
        command: 'videy',
        name: 'Videy',
        icon: '🎥'
      },
      // TikTok
      {
        patterns: [
          /tiktok\.com/i,
          /vt\.tiktok\.com/i,
          /vm\.tiktok\.com/i
        ],
        command: 'tt',
        name: 'TikTok',
        icon: '🎵'
      },
      // Facebook
      {
        patterns: [
          /facebook\.com/i,
          /fb\.watch/i,
          /fb\.com/i,
          /m\.facebook\.com/i
        ],
        command: 'fb',
        name: 'Facebook',
        icon: '📘'
      },
      // Instagram
      {
        patterns: [
          /instagram\.com/i,
          /instagr\.am/i
        ],
        command: 'ig',
        name: 'Instagram',
        icon: '📸'
      },
      // Douyin (Chinese TikTok)
      {
        patterns: [
          /douyin\.com/i,
          /iesdouyin\.com/i,
          /v\.douyin\.com/i
        ],
        command: 'douyin',
        name: 'Douyin',
        icon: '🎭'
      },
      // Streamable
      {
        patterns: [
          /streamable\.com/i
        ],
        command: 'streamable',
        name: 'Streamable',
        icon: '🎬'
      },
      // TeraBox
      {
        patterns: [
          /terabox\.com/i,
          /1024terabox\.com/i,
          /teraboxapp\.com/i
        ],
        command: 'terabox',
        name: 'TeraBox',
        icon: '📦'
      },
      // Snack Video
      {
        patterns: [
          /snackvideo\.com/i,
          /sck\.io/i
        ],
        command: 'snack',
        name: 'Snack Video',
        icon: '🍿'
      },
      // Suno AI
      {
        patterns: [
          /suno\.ai/i,
          /suno\.com/i
        ],
        command: 'suno',
        name: 'Suno AI',
        icon: '🎼'
      },
      // Spotify
      {
        patterns: [
          /spotify\.com/i,
          /spotify\.link/i,
          /open\.spotify\.com/i
        ],
        command: 'spotify',
        name: 'Spotify',
        icon: '🎧'
      },
      // SoundCloud
      {
        patterns: [
          /soundcloud\.com/i
        ],
        command: 'soundcloud',
        name: 'SoundCloud',
        icon: '🎶'
      },
      // MediaFire
      {
        patterns: [
          /mediafire\.com/i
        ],
        command: 'mediafire',
        name: 'MediaFire',
        icon: '📁'
      },
      // Google Drive
      {
        patterns: [
          /drive\.google\.com/i
        ],
        command: 'gdrive',
        name: 'Google Drive',
        icon: '☁️'
      },
      // Dailymotion - FITUR BARU
      {
        patterns: [
          /dailymotion\.com/i,
          /dai\.ly/i
        ],
        command: 'dailymotion',
        name: 'Dailymotion',
        icon: '🎞️'
      },
              // vidoy - FITUR BARU
      {
        patterns: [
        /vidoy\.com\/view\/([a-zA-Z0-9]+)/i,
        /vide14\.com\/d\/([a-zA-Z0-9]+)/i,
        /vidpy\.cc\/d\/([a-zA-Z0-9]+)/i,
        /vide16\.com\/d\/([a-zA-Z0-9]+)/i
        ],
        command: 'vidoy',
        name: 'vidoy',
        icon: '🎞️'
      },
      // Mega - FITUR BARU
      {
        patterns: [
          /mega\.nz/i,
          /mega\.co\.nz/i
        ],
        command: 'mega',
        name: 'Mega',
        icon: '💾'
      }
    ];

    // Cari platform yang cocok
    let detectedPlatform = null;

    for (const mapping of urlMappings) {
      for (const pattern of mapping.patterns) {
        if (pattern.test(url)) {
          detectedPlatform = mapping;
          console.log(`[DL] ✅ Platform detected: ${mapping.name}`);
          break;
        }
      }
      if (detectedPlatform) break;
    }

    // Jika platform tidak dikenali
    if (!detectedPlatform) {
      console.log("[DL] ⚠️ Platform tidak dikenali");
      console.log("[DL] URL yang dicoba:", url);
      
      // Kirim reaksi error
      try {
        await conn.sendMessage(m.chat, {
          react: {
            text: '❌',
            key: m.key
          }
        });
        console.log("[DL] Sent reaction: ❌");
      } catch (e) {
        console.log("[DL] Failed to send error reaction:", e.message);
      }
      
      return m.reply(
        `❌ *Platform tidak dikenali!*\n\n` +
        `URL: ${url}\n\n` +
        `Saat ini bot hanya mendukung:\n` +
        `• YouTube\n` +
        `• TikTok\n` +
        `• Facebook\n` +
        `• Instagram\n` +
        `• Videy\n` +
        `• Douyin\n` +
        `• Streamable\n` +
        `• TeraBox\n` +
        `• Snack Video\n` +
        `• Suno AI\n` +
        `• Spotify\n` +
        `• SoundCloud\n` +
        `• MediaFire\n` +
        `• Google Drive\n` +
        `• Dailymotion\n` +
        `• Mega\n\n` +
        `💡 Pastikan URL Anda berasal dari platform yang didukung.`
      );
    }

    // ========================================
    // STEP 5: Redirect ke command yang sesuai
    // ========================================
    
    const targetCommand = detectedPlatform.command;
    const commandText = `${usedPrefix}${targetCommand} ${url}`;
    
    console.log("[DL] Redirecting to command:", targetCommand);
    console.log("[DL] Full command:", commandText);

    // Kirim reaksi sedang memproses
    try {
      await conn.sendMessage(m.chat, {
        react: {
          text: '⏳',
          key: m.key
        }
      });
      console.log("[DL] Sent reaction: ⏳");
    } catch (e) {
      console.log("[DL] Failed to send reaction:", e.message);
    }

    // Kirim notifikasi processing
    const processingMsg = await m.reply(
      `${detectedPlatform.icon} *Platform terdeteksi: ${detectedPlatform.name}*\n\n` +
      `🔀 Mengalihkan ke: *${usedPrefix}${targetCommand}*\n` +
      `🔗 URL: ${url}\n\n` +
      `⏳ Memproses...`
    );

    // Tunggu sebentar
    await new Promise(resolve => setTimeout(resolve, 800));

    // Construct fake message untuk trigger handler
    const fakeRawMessage = {
      key: {
        remoteJid: m.chat,
        fromMe: false,
        id: 'DL_' + Date.now(),
        participant: m.sender
      },
      message: {
        conversation: commandText
      },
      messageTimestamp: Math.floor(Date.now() / 1000),
      pushName: m.pushName || 'User'
    };

    console.log("[DL] Fake message object:", JSON.stringify(fakeRawMessage, null, 2));

    // Execute handler
    let handlerExecuted = false;

    // Method 1: conn.handler
    if (typeof conn.handler === 'function') {
      console.log("[DL] Trying Method 1: conn.handler");
      try {
        await conn.handler.call(conn, { 
          messages: [fakeRawMessage], 
          type: 'notify' 
        });
        handlerExecuted = true;
        console.log("[DL] ✅ Executed via conn.handler");
      } catch (e) {
        console.log("[DL] Method 1 failed:", e.message);
      }
    }

    // Method 2: conn.ev.emit
    if (!handlerExecuted && conn.ev && typeof conn.ev.emit === 'function') {
      console.log("[DL] Trying Method 2: conn.ev.emit");
      try {
        conn.ev.emit('messages.upsert', { 
          messages: [fakeRawMessage], 
          type: 'notify' 
        });
        handlerExecuted = true;
        console.log("[DL] ✅ Emitted via conn.ev");
      } catch (e) {
        console.log("[DL] Method 2 failed:", e.message);
      }
    }

    // Method 3: sendMessage (fallback)
    if (!handlerExecuted) {
      console.log("[DL] Trying Method 3: sendMessage (fallback)");
      try {
        await conn.sendMessage(m.chat, { 
          text: commandText 
        }, {
          quoted: m
        });
        handlerExecuted = true;
        console.log("[DL] ✅ Message sent via sendMessage");
      } catch (e) {
        console.log("[DL] Method 3 failed:", e.message);
      }
    }

    if (!handlerExecuted) {
      throw new Error("Tidak ada handler method yang tersedia");
    }

    // Wait for processing
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Delete processing message
    try {
      await conn.sendMessage(m.chat, { delete: processingMsg.key });
      console.log("[DL] Processing notification deleted");
    } catch (e) {
      console.log("[DL] Failed to delete notification:", e.message);
    }

    // Kirim reaksi sukses
    try {
      await conn.sendMessage(m.chat, {
        react: {
          text: '✅',
          key: m.key
        }
      });
      console.log("[DL] Sent reaction: ✅");
    } catch (e) {
      console.log("[DL] Failed to send success reaction:", e.message);
    }

    console.log("[DL] ✅ Command execution completed");

  } catch (e) {
    console.error("\n[DL ERROR] ==========================================");
    console.error("[DL ERROR] Unhandled error:", e.message);
    console.error("[DL ERROR] Stack:", e.stack);
    console.error("[DL ERROR] ==========================================\n");
    
    // Kirim reaksi error
    try {
      await conn.sendMessage(m.chat, {
        react: {
          text: '❌',
          key: m.key
        }
      });
      console.log("[DL] Sent error reaction: ❌");
    } catch (reactError) {
      console.log("[DL] Failed to send error reaction:", reactError.message);
    }
    
    m.reply(
      `❌ *Terjadi kesalahan!*\n\n` +
      `${e.message}\n\n` +
      `Silakan coba lagi atau gunakan command manual:\n` +
      `Contoh: ${usedPrefix}yt <url> atau ${usedPrefix}tt <url>`
    );
  }
};

// ========================================
// HANDLER METADATA
// ========================================
handler.help = ["dl <url>"];
handler.command = ["dl", "download"];
handler.tags = ["downloader"];
handler.description = "Universal downloader - otomatis deteksi platform dan download";
handler.limit = false;

export default handler;