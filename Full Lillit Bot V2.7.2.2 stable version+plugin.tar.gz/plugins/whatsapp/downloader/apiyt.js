const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

// ═══════════════════════════════════════════════════════════════════
// YouTube Downloader (Modif: savenow.to + fallback p.lbserver.xyz)
// Kualitas default diubah ke 480p
// Search tetap scraping ytInitialData
// ═══════════════════════════════════════════════════════════════════

// ─── Helpers ──────────────────────────────────────────────────────
function randomDelay(min = 1000, max = 3000) {
    return new Promise(r => setTimeout(r, Math.floor(Math.random() * (max - min)) + min));
}
function formatDuration(s) {
    s = Number(s) || 0;
    const h = Math.floor(s/3600), m = Math.floor((s%3600)/60), sec = s%60;
    if (h > 0) return `${h}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`;
    return `${m}:${String(sec).padStart(2,'0')}`;
}
function formatViews(n) {
    n = Number(n) || 0;
    if (n >= 1_000_000_000) return (n/1_000_000_000).toFixed(1) + 'B';
    if (n >= 1_000_000) return (n/1_000_000).toFixed(1) + 'M';
    if (n >= 1_000) return (n/1_000).toFixed(1) + 'K';
    return String(n);
}
function formatSize(bytes) {
    bytes = Number(bytes) || 0;
    if (bytes >= 1_073_741_824) return (bytes/1_073_741_824).toFixed(2) + ' GB';
    if (bytes >= 1_048_576) return (bytes/1_048_576).toFixed(2) + ' MB';
    if (bytes >= 1_024) return (bytes/1_024).toFixed(1) + ' KB';
    return bytes + ' B';
}
function isYouTubeUrl(url) {
    return /youtu\.be|youtube\.com/i.test(url);
}
function extractYouTubeUrls(text) {
    const matches = text.match(/(https?:\/\/)?(www\.)?(youtu\.be|youtube\.com)\/[^\s]+/gi) || [];
    return [...new Set(matches)];
}
function normalizeUrl(url) {
    return url.startsWith('http') ? url : 'https://' + url;
}

// ─── oEmbed — metadata ringan ──────────────────────────────────────
async function getYouTubeMeta(url) {
    try {
        const id = url.match(/(?:v=|youtu\.be\/|shorts\/|embed\/)([a-zA-Z0-9_-]{11})/)?.[1];
        if (!id) return {};
        const res = await fetch(`https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${id}&format=json`, { timeout: 10000 });
        if (!res.ok) return {};
        const j = await res.json();
        return {
            title: j.title || null,
            author: j.author_name || null,
            thumbnail: `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
        };
    } catch { return {}; }
}

// ─── API: savenow.to primary + lbserver.xyz fallback ───────────────
async function getDownloadUrl(videoUrl) {
    const servers = [
        { name: 'primary (savenow.to)', base: 'https://p.savenow.to' },
        { name: 'backup (lbserver.xyz)', base: 'https://p.lbserver.xyz' }
    ];

    let lastError = null;

    for (const server of servers) {
        const { name, base } = server;
        console.log(`🔄 Mencoba server: ${name}`);

        const format = '480';  // Diubah ke 480p sesuai permintaan
        const button = '1';

        const initParams = new URLSearchParams({
            button: button,
            start: '1',
            end: '1',
            format: format,
            iframe_source: 'direct-iframe',
            url: videoUrl
        });

        const initUrl = `${base}/ajax/download.php?${initParams.toString()}`;

        console.log(`🎯 Init URL: ${initUrl}`);

        let initRes;
        try {
            initRes = await fetch(initUrl, {
                timeout: 25000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
                    'Accept': 'application/json, text/javascript, */*; q=0.01',
                    'Referer': `${base}/`
                }
            });
        } catch (err) {
            lastError = `Fetch init gagal di ${name}: ${err.message}`;
            console.error(lastError);
            continue;
        }

        if (!initRes.ok) {
            lastError = `Init HTTP ${initRes.status} di ${name}`;
            console.error(lastError);
            continue;
        }

        let initData;
        try {
            initData = await initRes.json();
        } catch (err) {
            lastError = `Response init bukan JSON di ${name}: ${err.message}`;
            console.error(lastError);
            continue;
        }

        if (!initData.success || !initData.progress_url) {
            lastError = `Init gagal atau progress_url hilang di ${name}`;
            console.error(lastError);
            continue;
        }

        const progressUrl = initData.progress_url;
        console.log(`📡 Progress URL (${name}): ${progressUrl}`);

        // Polling progress
        const maxAttempts = 40;
        const delayMs = 3500;

        for (let attempt = 1; attempt <= maxAttempts; attempt++) {
            await new Promise(r => setTimeout(r, delayMs));

            let progRes;
            try {
                progRes = await fetch(progressUrl, {
                    timeout: 15000,
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
                        'Accept': 'application/json'
                    }
                });
            } catch (err) {
                lastError = `Progress fetch gagal attempt ${attempt} di ${name}: ${err.message}`;
                console.error(lastError);
                break;
            }

            if (!progRes.ok) {
                lastError = `Progress HTTP ${progRes.status} attempt ${attempt} di ${name}`;
                console.error(lastError);
                break;
            }

            let progData;
            try {
                progData = await progRes.json();
            } catch {
                lastError = `Progress bukan JSON di ${name}`;
                console.error(lastError);
                break;
            }

            if (progData.progress >= 1000) {
                if (!progData.download_url) {
                    lastError = `download_url hilang setelah selesai di ${name}`;
                    console.error(lastError);
                    break;
                }
                console.log(`✅ Sukses dari ${name}! Download URL: ${progData.download_url.slice(0, 80)}...`);
                return progData.download_url;
            }

            console.log(`⏳ Progress (${name}): ${progData.progress || 0}/1000`);
        }
    }

    throw new Error(`Semua server gagal: ${lastError || 'Unknown error'}. Coba lagi nanti atau ganti mirror.`);
}

// ─── Download buffer ───────────────────────────────────────────────
async function downloadBuffer(url, type = 'video') {
    const res = await fetch(url, {
        timeout: 180000,
        follow: 10,
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
            'Accept': '*/*',
        }
    });
    if (!res.ok) throw new Error(`Download gagal HTTP ${res.status} untuk ${type}`);
    const buf = Buffer.from(await res.arrayBuffer());
    console.log(`📦 ${type} downloaded: ${formatSize(buf.length)}`);
    return buf;
}

// ─── Search ───────────────────────────────────────────────────────
async function searchYouTube(query, limit = 8) {
    const res = await fetch(`https://www.youtube.com/results?search_query=${encodeURIComponent(query)}&hl=id`, {
        timeout: 15000,
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
            'Accept-Language': 'id-ID,id;q=0.9,en;q=0.8',
        }
    });
    if (!res.ok) throw new Error(`Search HTTP ${res.status}`);
    const html = await res.text();
    const raw = html.match(/var ytInitialData\s*=\s*({.+?});<\/script>/s)?.[1];
    if (!raw) throw new Error('ytInitialData tidak ditemukan');
    const yd = JSON.parse(raw);
    const contents = yd?.contents?.twoColumnSearchResultsRenderer
                      ?.primaryContents?.sectionListRenderer
                      ?.contents?.[0]?.itemSectionRenderer?.contents || [];
    const results = [];
    for (const item of contents) {
        if (results.length >= limit) break;
        const v = item?.videoRenderer;
        if (!v?.videoId) continue;
        results.push({
            id: v.videoId,
            title: v.title?.runs?.[0]?.text || '-',
            author: v.ownerText?.runs?.[0]?.text || '-',
            duration: v.lengthText?.simpleText || '-',
            views: v.shortViewCountText?.simpleText || '-',
            url: `https://www.youtube.com/watch?v=${v.videoId}`,
        });
    }
    if (!results.length) throw new Error('Tidak ada hasil ditemukan');
    return results;
}

// ─── Caption Builders ──────────────────────────────────────────────
function buildVideoCaption(meta) {
    let cap = `🎬 *${meta.title || 'YouTube Video'}*\n`;
    if (meta.author) cap += `👤 ${meta.author}\n`;
    cap += `Youtube Downloader`;
    return cap.trim();
}

function buildSearchCaption(results, query) {
    let msg = `🔍 *Hasil Pencarian YouTube*\n`;
    msg += `📌 Keyword: *${query}*\n`;
    msg += `📊 Ditemukan: *${results.length} video*\n`;
    msg += `─────────────────────────\n\n`;
    results.forEach((v, i) => {
        msg += `*${i+1}. ${v.title}*\n`;
        msg += `👤 ${v.author}\n`;
        msg += `⏱ ${v.duration} | 👁 ${v.views}\n`;
        msg += `🔗 ${v.url}\n\n`;
    });
    msg += `💡 Kirim URL di atas ke *.yt <url>* untuk download!`;
    return msg;
}

// ─── Core download flow ────────────────────────────────────────────
async function processDownload(conn, m, url) {
    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
        const [meta, downloadUrl] = await Promise.all([
            getYouTubeMeta(url),
            getDownloadUrl(url)
        ]);

        console.log(`✅ Final download link: ${downloadUrl.slice(0, 80)}...`);

        const [videoBuf, thumbBuf] = await Promise.all([
            downloadBuffer(downloadUrl, 'video'),
            meta.thumbnail ? downloadBuffer(meta.thumbnail, 'thumbnail').catch(() => null) : Promise.resolve(null)
        ]);

        await conn.sendMessage(m.chat, {
            video: videoBuf,
            jpegThumbnail: thumbBuf ?? undefined,
            mimetype: 'video/mp4',
            caption: buildVideoCaption(meta),
        }, { quoted: m });

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (e) {
        console.error(`❌ Download error: ${e.message}`);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await m.reply(`❌ Gagal download.\n*Error:* ${e.message || 'Cek console bot untuk detail'}`);
    }
}

// ─── Handler ──────────────────────────────────────────────────────
const HELP_MSG = (p) => `
*📥 YouTube Downloader MP4*
*Perintah:*
${p}yt <url atau keyword>
${p}ytsearch <keyword>

*Contoh:*
${p}yt https://youtu.be/dQw4w9WgXcQ
${p}yt lagu sheila on 7
${p}ytsearch kucing lucu

✅ Support: Video, Shorts, Keyword
Kualitas: ~480p (via savenow.to + fallback lbserver.xyz)
Proses bisa 15-90 detik
`.trim();

let handler = async (m, { conn, args, usedPrefix, command }) => {
    const input = args?.join(' ').trim() || '';
    const prefix = usedPrefix || m.text?.match(/^([.!#/])/)?.[1] || '.';
    const isSearch = ['ytsearch', 'yts'].includes(command);

    if (!input) return m.reply(HELP_MSG(prefix));

    if (isSearch) {
        await conn.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });
        try {
            const results = await searchYouTube(input, 8);
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            return m.reply(buildSearchCaption(results, input));
        } catch (e) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ Pencarian gagal.\n*Error:* ${e.message}`);
        }
    }

    const urls = extractYouTubeUrls(input).filter(isYouTubeUrl);
    let targetUrl = null;

    if (urls.length) {
        targetUrl = normalizeUrl(urls[0]);
    } else {
        await conn.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });
        try {
            const results = await searchYouTube(input, 5);
            targetUrl = results[0].url;
            await m.reply(`🔍 Ditemukan *${results.length} hasil* untuk "${input}"\n\n🎯 Mengunduh video teratas:\n*${results[0].title}*\n👤 ${results[0].author}\n⏳ Tunggu...`);
        } catch (e) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ Gagal mencari.\n*Error:* ${e.message}`);
        }
    }

    if (!targetUrl) return m.reply('❌ Tidak menemukan URL YouTube valid.');

    await processDownload(conn, m, targetUrl);
};

handler.help = ['yt', 'ytmp4', 'yts'];
handler.tags = ['downloader'];
handler.command = ['yt', 'ytmp4', 'yts'];

export default handler;