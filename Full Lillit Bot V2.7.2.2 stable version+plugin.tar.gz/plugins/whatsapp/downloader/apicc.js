import axios from 'axios';

const HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'en-US,en;q=0.9',
  'Referer': 'https://www.capcut.com/'
};

function isCapcutUrl(text) {
  return /capcut\.com/i.test(text);
}

function parseHtml(html) {
  const result = {};

  // Video URL dari <a href>
  const hrefMatch = html.match(/href="(https:\/\/v\d+-(?:capcut\.capcutcdn-us|vod\.capcutvod)\.com\/[^"]+)"/);
  if (hrefMatch) result.videoUrl = hrefMatch[1];

  // Fallback src/data-src
  if (!result.videoUrl) {
    const srcMatch = html.match(/(?:src|data-src)="(https:\/\/v\d+-(?:capcut\.capcutcdn-us|vod\.capcutvod)\.com\/[^"]+)"/);
    if (srcMatch) result.videoUrl = srcMatch[1];
  }

  // Fallback raw
  if (!result.videoUrl) {
    const raw = html.match(/https:\/\/v\d+-(?:capcut\.capcutcdn-us|vod\.capcutvod)\.com\/[^\s"'<>]+/);
    if (raw) result.videoUrl = raw[0];
  }

  // Title dari <h1>
  const h1 = html.match(/<h1[^>]*>\s*([^<]{1,100})\s*<\/h1>/);
  const titleTag = html.match(/<title>\s*([^<]{1,100}?)\s*(?:-\s*(?:contoh video|CapCut)[^<]*)?\s*<\/title>/);
  if (h1) result.title = h1[1].trim();
  else if (titleTag) result.title = titleTag[1].trim();

  // Stats
  const stats = html.match(/(\d+)\s+uses,\s*(\d+)\s+likes/);
  if (stats) {
    result.uses = parseInt(stats[1]);
    result.likes = parseInt(stats[2]);
  }

  return result;
}

async function fetchCapcutPage(url) {
  const { data: html } = await axios.get(url, {
    headers: HEADERS,
    timeout: 15000,
    maxRedirects: 5
  });

  const result = parseHtml(html);
  if (!result.videoUrl) throw new Error('Video tidak ditemukan. Pastikan link valid dan publik.');
  return result;
}

const USAGE = `╭━━━『 ✂️ *CapCut Downloader* 』━━━╮
│
│  🔗 *Download via Link:*
│  .cc <link capcut>
│
╰━━━━━━━━━━━━━━━━━━━━━━╯`;

let handler = async (m, { conn }) => {
  try {
    const rawBody = (m.body || m.text || '').trim();
    const input = rawBody.replace(/^[./!~]\S+\s*/, '').trim();

    if (!input || !isCapcutUrl(input)) return m.reply(USAGE);

    const result = await fetchCapcutPage(input);

    await conn.sendMessage(m.chat, {
      video: { url: result.videoUrl },
      mimetype: 'video/mp4',
      caption: `✂️ *${result.title || 'CapCut Template'}*` +
        (result.uses  ? `  🔁 ${result.uses}` : '') +
        (result.likes ? `  ❤️ ${result.likes}` : '')
    }, { quoted: m });

  } catch (e) {
    console.error('[capcut]', e.message);
    m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ['cc <link>'];
handler.tags = ['downloader'];
handler.command = ['capcut', 'cc'];

export default handler;