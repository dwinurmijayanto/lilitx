import fetch from 'node-fetch';
import { downloadContentFromMessage } from 'baileys';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

console.log('[QR Scanner Handler] Loading handler...');

// ========== CONFIGURATION ==========
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const TEMP_DIR = path.join(__dirname, '../tmp');
const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
const QR_SCAN_API = 'https://api.qrserver.com/v1/read-qr-code/';

// Pastikan temp directory ada
if (!fs.existsSync(TEMP_DIR)) {
    fs.mkdirSync(TEMP_DIR, { recursive: true });
}

// ========== DOWNLOAD MEDIA FUNCTION ==========
/**
 * Download image dari Baileys message
 * @param {Object} message - Raw Baileys message object
 * @returns {Buffer|null} - Media buffer atau null jika gagal
 */
async function downloadImage(message) {
    try {
        const mimeMap = {
            imageMessage: 'image'
        };

        const msgKeys = Object.keys(message || {});
        if (msgKeys.length === 0) return null;

        const type = msgKeys[0];
        if (!type) return null;

        const m = message[type];
        if (!m) return null;

        const mediaType = mimeMap[type];
        if (!mediaType) return null;

        console.log('[QR Scanner Handler] Downloading image...');
        
        // Download media menggunakan Baileys
        const stream = await downloadContentFromMessage(m, mediaType);
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        
        const buffer = Buffer.concat(chunks);
        console.log(`[QR Scanner Handler] Image downloaded, size: ${buffer.length} bytes`);
        
        return buffer;
    } catch (error) {
        console.error('[QR Scanner Handler] Error downloading image:', error);
        return null;
    }
}

// ========== QR SCANNING FUNCTIONS ==========
/**
 * Scan QR Code dari image buffer
 * @param {Buffer} imageBuffer - Buffer gambar
 * @returns {Object} - Result object dengan data QR atau error
 */
async function scanQRCode(imageBuffer) {
    try {
        // Validasi ukuran file
        if (imageBuffer.length > MAX_FILE_SIZE) {
            throw new Error(`File terlalu besar! Max ${MAX_FILE_SIZE / 1024 / 1024}MB`);
        }
        
        console.log('[QR Scanner Handler] Scanning QR code...');
        
        // Konversi buffer ke base64
        const base64Image = imageBuffer.toString('base64');
        
        // Buat form data untuk API
        const FormData = (await import('form-data')).default;
        const form = new FormData();
        form.append('file', imageBuffer, {
            filename: 'qrcode.png',
            contentType: 'image/png'
        });
        
        // Kirim ke QR Scanner API
        const response = await fetch(QR_SCAN_API, {
            method: 'POST',
            body: form,
            headers: form.getHeaders()
        });
        
        if (!response.ok) {
            throw new Error(`API Error: ${response.status} ${response.statusText}`);
        }
        
        const result = await response.json();
        
        console.log('[QR Scanner Handler] Scan result:', result);
        
        // Parse hasil scan
        if (!result || result.length === 0) {
            throw new Error('Tidak ada QR code yang terdeteksi!');
        }
        
        const qrData = result[0];
        
        if (!qrData.symbol || !qrData.symbol[0]) {
            throw new Error('QR code tidak dapat dibaca!');
        }
        
        const decodedData = qrData.symbol[0].data;
        
        if (!decodedData || decodedData.trim().length === 0) {
            throw new Error('QR code kosong atau corrupt!');
        }
        
        console.log('[QR Scanner Handler] Decoded data:', decodedData.substring(0, 100));
        
        return {
            success: true,
            data: decodedData,
            type: qrData.type || 'unknown'
        };
        
    } catch (error) {
        console.error('[QR Scanner Handler] Scan failed:', error.message);
        return {
            success: false,
            message: error.message
        };
    }
}

// ========== FORMAT FUNCTIONS ==========
/**
 * Generate help message
 * @param {string} prefix - Command prefix
 * @param {string} cmd - Command name
 * @returns {string} - Help message
 */
function generateUsageHelp(prefix, cmd) {
    return `*🔍 QR CODE SCANNER*

📌 *Cara Penggunaan:*

*1. Reply Gambar QR:*
Reply gambar QR code, lalu ketik: ${prefix}${cmd}

*2. Kirim Gambar Langsung:*
Kirim gambar QR dengan caption: ${prefix}${cmd}

📋 *Supported QR Types:*
- URL / Link
- Text biasa
- WiFi credentials
- vCard contact
- Email
- Phone number
- Dan semua jenis QR code

⚙️ *Fitur:*
- Auto detect QR code dari gambar
- Support berbagai format gambar (PNG, JPG, WEBP)
- Instant scanning
- Decode semua jenis QR

⚠️ *Batasan:*
- Max file size: ${MAX_FILE_SIZE / 1024 / 1024}MB
- Gambar harus jelas dan tidak blur
- QR code harus terlihat penuh

💡 *Tips:*
- Pastikan gambar QR code jelas
- Hindari gambar blur atau terpotong
- Lighting yang baik menghasilkan scan lebih akurat

*Contoh:*
Reply gambar QR → ${prefix}${cmd}
`;
}

/**
 * Format ukuran file
 * @param {number} bytes - Ukuran dalam bytes
 * @returns {string} - Formatted size
 */
function formatSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

/**
 * Deteksi tipe content dari QR data
 * @param {string} data - QR data
 * @returns {string} - Tipe content
 */
function detectContentType(data) {
    if (/^https?:\/\//i.test(data)) return '🔗 URL/Link';
    if (/^tel:/i.test(data) || /^\+?\d{10,15}$/.test(data)) return '📞 Nomor Telepon';
    if (/^mailto:/i.test(data) || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data)) return '📧 Email';
    if (/^WIFI:/i.test(data)) return '📶 WiFi Credentials';
    if (/^BEGIN:VCARD/i.test(data)) return '👤 vCard Contact';
    if (/^geo:/i.test(data)) return '📍 Lokasi/Koordinat';
    if (/^SMSTO:/i.test(data)) return '💬 SMS';
    if (/^BEGIN:VEVENT/i.test(data)) return '📅 Event/Calendar';
    return '📝 Text';
}

/**
 * Format WiFi credentials untuk display
 * @param {string} data - WiFi QR data
 * @returns {string} - Formatted WiFi info
 */
function formatWiFiData(data) {
    try {
        const matches = data.match(/WIFI:S:([^;]+);T:([^;]+);P:([^;]+);/i);
        if (matches) {
            return `📶 *WiFi Information:*\n` +
                   `├ SSID: ${matches[1]}\n` +
                   `├ Security: ${matches[2]}\n` +
                   `└ Password: ${matches[3]}`;
        }
    } catch (e) {
        // Fallback ke raw data
    }
    return data;
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    // Deteksi prefix dan command
    let prefix = usedPrefix || '.';
    const cmd = command || 'scanqr';
    
    try {
        // Ambil input text
        let inputText = '';
        if (text) {
            inputText = text.trim();
        } else if (args && args.length > 0) {
            inputText = args.join(' ').trim();
        }
        
        // Cek apakah user minta help
        if (inputText.toLowerCase() === 'help' || inputText === '?') {
            return m.reply(generateUsageHelp(prefix, cmd));
        }
        
        // React dengan emoji untuk menunjukkan proses dimulai
        await conn.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });
        
        let imageBuffer = null;
        let mime = '';
        
        // ========== EXTRACT RAW MESSAGE & CONTEXT INFO ==========
        let rawMessage = m.message;
        let contextInfo = null;
        let quotedMessage = null;
        
        // Extract contextInfo berdasarkan tipe message
        if (rawMessage) {
            if (rawMessage.extendedTextMessage) {
                contextInfo = rawMessage.extendedTextMessage.contextInfo;
            } else if (rawMessage.imageMessage) {
                contextInfo = rawMessage.imageMessage.contextInfo;
            }
            
            // Extract quoted message dari contextInfo
            if (contextInfo) {
                quotedMessage = contextInfo.quotedMessage;
            }
        }
        
        // ========== GET IMAGE ==========
        // Check 1: Direct image message (gambar dikirim dengan caption)
        if (rawMessage?.imageMessage) {
            console.log('[QR Scanner Handler] Processing direct image');
            mime = rawMessage.imageMessage.mimetype || 'image/png';
            imageBuffer = await downloadImage(rawMessage);
        }
        // Check 2: Quoted image (reply gambar)
        else if (quotedMessage?.imageMessage) {
            console.log('[QR Scanner Handler] Processing quoted image');
            mime = quotedMessage.imageMessage.mimetype || 'image/png';
            imageBuffer = await downloadImage(quotedMessage);
        }
        // Check 3: Fallback ke m.quoted (jika ada di store)
        else if (m.quoted?.message?.imageMessage) {
            console.log('[QR Scanner Handler] Processing from m.quoted');
            mime = m.quoted.message.imageMessage.mimetype || 'image/png';
            imageBuffer = await downloadImage(m.quoted.message);
        }
        else {
            console.log('[QR Scanner Handler] No image found');
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            
            return m.reply(`❌ Tidak ada gambar yang ditemukan!\n\n💡 Cara penggunaan:\n\n*Reply Gambar:*\nReply gambar QR code, lalu ketik: ${prefix}${cmd}\n\n*Kirim Langsung:*\nKirim gambar QR dengan caption: ${prefix}${cmd}\n\n📌 Ketik ${prefix}${cmd} help untuk panduan lengkap`);
        }
        
        // Validasi image buffer
        if (!imageBuffer) {
            console.error('[QR Scanner Handler] Failed to download image');
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply('❌ Gagal mendownload gambar!\n💡 Coba lagi atau pastikan file adalah gambar yang valid.');
        }
        
        // Validasi format gambar
        if (!/image\/(png|jpe?g|webp)/.test(mime)) {
            console.error('[QR Scanner Handler] Unsupported format:', mime);
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply('⚠️ Format tidak didukung!\n💡 Hanya gambar format: PNG, JPG, JPEG, WEBP.');
        }
        
        // ========== SCAN QR CODE ==========
        const result = await scanQRCode(imageBuffer);
        
        if (!result.success) {
            console.error('[QR Scanner Handler] Scan failed:', result.message);
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            
            let errorMsg = '❌ Gagal scan QR code!\n\n';
            
            if (result.message.includes('tidak terdeteksi')) {
                errorMsg += '⚠️ Tidak ada QR code dalam gambar!\n💡 Pastikan gambar mengandung QR code yang jelas.';
            } else if (result.message.includes('tidak dapat dibaca')) {
                errorMsg += '⚠️ QR code tidak dapat dibaca!\n💡 Gunakan gambar yang lebih jelas atau tidak blur.';
            } else if (result.message.includes('terlalu besar')) {
                errorMsg += `⚠️ File terlalu besar!\n💡 Max size: ${MAX_FILE_SIZE / 1024 / 1024}MB`;
            } else {
                errorMsg += `⚠️ Error: ${result.message}`;
            }
            
            return m.reply(errorMsg);
        }
        
        // ========== FORMAT & SEND RESULT ==========
        console.log('[QR Scanner Handler] Formatting result...');
        
        try {
            // Deteksi tipe content
            const contentType = detectContentType(result.data);
            
            // Format data berdasarkan tipe
            let formattedData = result.data;
            if (contentType === '📶 WiFi Credentials') {
                formattedData = formatWiFiData(result.data);
            } else if (result.data.length > 500) {
                // Potong data jika terlalu panjang
                formattedData = result.data.substring(0, 497) + '...';
            }
            
            // Buat response message
            const responseMsg = `✅ *QR Code Scanned!*\n\n` +
                              `📊 *Info:*\n` +
                              `├ 📋 Type: ${contentType}\n` +
                              `├ 📏 Size: ${formatSize(imageBuffer.length)}\n` +
                              `└ 🔢 Length: ${result.data.length} karakter\n\n` +
                              `💬 *Content:*\n${formattedData}\n\n` +
                              `💡 Data di atas berhasil di-decode dari QR code!`;
            
            // Kirim hasil
            await m.reply(responseMsg);
            
            // React success
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            
            console.log('[QR Scanner Handler] Success!');
            
        } catch (sendError) {
            console.error('[QR Scanner Handler] Failed to send result:', sendError);
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply('❌ Gagal mengirim hasil scan!\n💡 Coba lagi.');
        }
        
    } catch (error) {
        // Error handling
        console.error('[QR Scanner Handler] CRITICAL ERROR:', error.message);
        console.error('[QR Scanner Handler] Stack:', error.stack);
        
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        
        // Kirim pesan error singkat ke user
        return m.reply(`❌ Terjadi kesalahan!\n💡 Coba lagi atau ketik ${prefix}${cmd} help`);
    }
};

// ========== HANDLER PROPERTIES ==========
handler.help = ["scanqr (reply/kirim gambar QR)"];
handler.tags = ["tools"];
handler.command = ["scanqr", "readqr", "qrscan", "decodeqr"];
handler.limit = true;

console.log('[QR Scanner Handler] Handler loaded successfully');

export default handler;