import crypto from 'crypto';
import { lookup } from 'mime-types';

const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

// ========== SHORTURL CONFIG ==========
const SHORTURL_CONFIG = {
    api: 'https://zeinklab.com/api/create',
    baseUrl: 'http://zeink.cc',
    timeout: 15000
};

// ========== SHORTURL FUNCTIONS ==========
async function createShortUrl(longUrl) {
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), SHORTURL_CONFIG.timeout);

        const response = await fetch(SHORTURL_CONFIG.api, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'User-Agent': 'Mozilla/5.0',
                'Origin': 'https://zeinklab.com',
                'Referer': 'https://zeinklab.com/create'
            },
            body: JSON.stringify({ url: longUrl }),
            signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        let responseText = await response.text();
        
        const jsonMatch = responseText.match(/(\{[\s\S]*\})/);
        if (jsonMatch) {
            responseText = jsonMatch[1];
        }
        
        const result = JSON.parse(responseText);

        if (result.success && result.short_url) {
            let url = result.short_url;
            if (url.startsWith('/')) {
                url = SHORTURL_CONFIG.baseUrl + url;
            } else if (!url.startsWith('http')) {
                url = SHORTURL_CONFIG.baseUrl + '/' + url;
            }
            
            return url;
        }
        
        return null;

    } catch (error) {
        console.log(`[ShortURL] Error: ${error.message}`);
        return null;
    }
}

// ========== MEGA FUNCTIONS ==========
function isValidMegaUrl(url) {
    return /mega\.nz\/(#!|file\/|folder\/)/i.test(url);
}

function formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function getRandomDelay() {
    return Math.floor(Math.random() * (7000 - 3000 + 1)) + 3000;
}

// ========== MEGA DECRYPTION ==========
function decryptFileAttributes(encryptedAttr, keyBuffer) {
    try {
        console.log(`[Decrypt] Starting attribute decryption...`);
        
        const paddedKey = Buffer.concat([keyBuffer, Buffer.alloc((4 - (keyBuffer.length % 4)) % 4)]);
        let keyArray = Array.from({ length: paddedKey.length / 4 }, (_, i) => paddedKey.readUInt32BE(i * 4));
        
        if (keyArray.length === 8) {
            keyArray = [
                keyArray[0] ^ keyArray[4], 
                keyArray[1] ^ keyArray[5], 
                keyArray[2] ^ keyArray[6], 
                keyArray[3] ^ keyArray[7]
            ];
        }
        
        const keyBuf = Buffer.alloc(keyArray.length * 4);
        keyArray.forEach((val, i) => keyBuf.writeUInt32BE(val >>> 0, i * 4));
        
        const encAttr = Buffer.from(
            (encryptedAttr.replace(/-/g, '+').replace(/_/g, '/') + 
            '='.repeat((4 - (encryptedAttr.length % 4)) % 4)), 
            'base64'
        );
        
        const decipher = crypto.createDecipheriv('aes-128-cbc', keyBuf, Buffer.alloc(16, 0));
        decipher.setAutoPadding(false);
        const decrypted = Buffer.concat([decipher.update(encAttr), decipher.final()]);
        
        const trimmed = decrypted.toString('utf8').replace(/\0+$/, '');
        const attributes = trimmed.startsWith('MEGA{') ? JSON.parse(trimmed.substring(4)) : { n: 'Unknown' };
        
        console.log(`[Decrypt] Successfully decrypted: ${attributes.n}`);
        return attributes;
        
    } catch (error) {
        console.log(`[Decrypt] Error: ${error.message}`);
        return { n: 'Unknown' };
    }
}

function getMegaKeys(keyBuffer) {
    const paddedKey = Buffer.concat([keyBuffer, Buffer.alloc((4 - (keyBuffer.length % 4)) % 4)]);
    const keyArray = Array.from({ length: paddedKey.length / 4 }, (_, i) => paddedKey.readUInt32BE(i * 4));
    
    if (keyArray.length !== 8) {
        throw new Error('Invalid key length');
    }
    
    const encKey = Buffer.alloc(16);
    for (let i = 0; i < 4; i++) {
        encKey.writeUInt32BE((keyArray[i] ^ keyArray[i + 4]) >>> 0, i * 4);
    }
    
    const iv = Buffer.alloc(16);
    iv.writeUInt32BE(keyArray[4] >>> 0, 0);
    iv.writeUInt32BE(keyArray[5] >>> 0, 4);
    
    return { encKey, iv };
}

async function downloadMegaFile(downloadUrl, fileSize, decryptionKey, hasMac) {
    try {
        console.log(`[Download] Starting download...`);
        console.log(`[Download] Total size: ${formatBytes(fileSize)} (${fileSize} bytes)`);
        console.log(`[Download] MAC verification: ${hasMac ? 'enabled' : 'disabled'}`);
        
        console.log(`[Download] Fetching from MEGA servers...`);
        const response = await fetch(downloadUrl, {
            method: 'GET',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            },
            redirect: 'follow'
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const contentLength = parseInt(response.headers.get('content-length') || '0');
        console.log(`[Download] Content-Length: ${formatBytes(contentLength)} (${contentLength} bytes)`);
        
        const arrayBuffer = await response.arrayBuffer();
        let encryptedBuffer = Buffer.from(arrayBuffer);
        
        console.log(`[Download] Downloaded: ${formatBytes(encryptedBuffer.length)} (${encryptedBuffer.length} bytes)`);
        
        let mac = null;
        if (hasMac && encryptedBuffer.length >= 16) {
            mac = encryptedBuffer.slice(-16);
            encryptedBuffer = encryptedBuffer.slice(0, -16);
            console.log(`[Download] MAC found: ${mac.toString('hex').substring(0, 32)}...`);
            console.log(`[Download] Data size after MAC removal: ${formatBytes(encryptedBuffer.length)} (${encryptedBuffer.length} bytes)`);
        }
        
        console.log(`[Download] 🔓 Decrypting file...`);
        const { encKey, iv } = getMegaKeys(decryptionKey);
        
        console.log(`[Download] Encryption key: ${encKey.toString('hex').substring(0, 32)}...`);
        console.log(`[Download] IV: ${iv.toString('hex')}`);
        
        const decipher = crypto.createDecipheriv('aes-128-ctr', encKey, iv);
        decipher.setAutoPadding(false);
        
        const decryptedBuffer = Buffer.concat([
            decipher.update(encryptedBuffer),
            decipher.final()
        ]);
        
        console.log(`[Download] ✅ Decrypted: ${formatBytes(decryptedBuffer.length)} (${decryptedBuffer.length} bytes)`);
        
        if (decryptedBuffer.length >= 4) {
            const magic = decryptedBuffer.slice(0, 4);
            const magicHex = magic.toString('hex');
            console.log(`[Download] File signature: ${magicHex}`);
            
            const signatures = {
                '504b0304': 'ZIP archive',
                '504b0506': 'ZIP (empty)',
                '504b0708': 'ZIP (spanned)',
                '25504446': 'PDF document',
                'ffd8ffe0': 'JPEG image (JFIF)',
                'ffd8ffe1': 'JPEG image (Exif)',
                '89504e47': 'PNG image',
                '47494638': 'GIF image',
                '52494646': 'RIFF (WAV/AVI)',
                '00000018': 'MP4 video (ftyp)',
                '00000020': 'MP4 video (ftyp)',
            };
            
            const fileType = signatures[magicHex] || 'Unknown';
            console.log(`[Download] Detected type: ${fileType}`);
        }
        
        if (mac && hasMac) {
            console.log(`[Download] 🔐 Verifying MAC...`);
            const cbcKey = Buffer.alloc(16);
            encKey.copy(cbcKey);
            
            const chunks = [];
            for (let i = 0; i < decryptedBuffer.length; i += 16) {
                chunks.push(decryptedBuffer.slice(i, Math.min(i + 16, decryptedBuffer.length)));
            }
            
            let macCalc = Buffer.alloc(16, 0);
            const cipher = crypto.createCipheriv('aes-128-cbc', cbcKey, Buffer.alloc(16, 0));
            cipher.setAutoPadding(false);
            
            for (const chunk of chunks) {
                if (chunk.length === 16) {
                    const xored = Buffer.alloc(16);
                    for (let i = 0; i < 16; i++) {
                        xored[i] = macCalc[i] ^ chunk[i];
                    }
                    macCalc = cipher.update(xored);
                }
            }
            
            console.log(`[Download] Expected MAC: ${mac.toString('hex')}`);
            console.log(`[Download] Calculated MAC: ${macCalc.toString('hex')}`);
            
            if (!mac.equals(macCalc.slice(0, mac.length))) {
                console.log(`[Download] ⚠️  MAC verification failed, but continuing...`);
            } else {
                console.log(`[Download] ✅ MAC verified successfully`);
            }
        }
        
        return decryptedBuffer;
        
    } catch (error) {
        console.error(`[Download] Error: ${error.message}`);
        throw error;
    }
}

// ========== MEGA API ==========
async function getMegaDownloadUrl(megaUrl) {
    const debugInfo = {
        api: 'mega.co.nz',
        startTime: Date.now(),
        requestUrl: '',
        responseStatus: null,
        responseTime: null,
        dataStructure: {},
        fileInfo: {},
        errors: []
    };
    
    try {
        console.log(`\n╔════════════════════════════════════════════════════════════╗`);
        console.log(`║  [MEGA] 🔍 DEBUG: mega.co.nz API                          ║`);
        console.log(`╚════════════════════════════════════════════════════════════╝`);
        console.log(`📤 Original URL: ${megaUrl}`);
        console.log(`⏱️  Request started at: ${new Date(debugInfo.startTime).toISOString()}`);
        
        const match = megaUrl.match(/mega\.nz\/(?:#!|file\/)([a-zA-Z0-9_-]+)[!#]([a-zA-Z0-9_-]+)/);
        if (!match) {
            debugInfo.errors.push('Invalid MEGA URL format');
            console.log(`❌ Invalid URL format`);
            return { result: null, debug: debugInfo };
        }
        
        const [, fileId, key] = match;
        console.log(`📋 File ID: ${fileId}`);
        console.log(`🔑 Key: ${key.substring(0, 10)}...`);
        
        const keyBuffer = Buffer.from(
            (key.replace(/-/g, '+').replace(/_/g, '/') + 
            '='.repeat((4 - (key.length % 4)) % 4)), 
            'base64'
        );
        
        const apiUrl = 'https://g.api.mega.co.nz/cs';
        debugInfo.requestUrl = apiUrl;
        
        const requestBody = [{
            a: 'g',
            g: 1,
            p: fileId
        }];
        
        console.log(`\n📤 Requesting file info from MEGA API...`);
        const response = await fetch(apiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': 'Mozilla/5.0'
            },
            body: JSON.stringify(requestBody)
        });
        
        debugInfo.responseTime = Date.now() - debugInfo.startTime;
        debugInfo.responseStatus = response.status;
        
        console.log(`📥 Response Status: ${response.status} ${response.statusText}`);
        console.log(`⏱️  Response Time: ${debugInfo.responseTime}ms`);
        
        if (!response.ok) {
            debugInfo.errors.push(`HTTP ${response.status}`);
            console.log(`❌ HTTP Error: ${response.status}`);
            return { result: null, debug: debugInfo };
        }
        
        const data = await response.json();
        const fileInfo = data[0];
        
        console.log(`\n🔍 Full API Response:`);
        console.log(JSON.stringify(data, null, 2));
        
        debugInfo.dataStructure = {
            hasFileInfo: !!fileInfo,
            hasDownloadUrl: !!fileInfo?.g,
            hasAttributes: !!fileInfo?.at,
            hasSize: typeof fileInfo?.s !== 'undefined',
            hasMsd: !!fileInfo?.msd
        };
        
        const hasMac = fileInfo.msd === 1;
        
        console.log(`\n📊 Response Data Structure:`);
        console.log(`   - fileInfo: ${fileInfo ? 'exists' : 'null'}`);
        console.log(`   - downloadUrl (g): ${fileInfo?.g ? '✓' : '✗'}`);
        console.log(`   - attributes (at): ${fileInfo?.at ? '✓' : '✗'}`);
        console.log(`   - size (s): ${typeof fileInfo?.s !== 'undefined' ? '✓' : '✗'}`);
        
        if (!fileInfo || !fileInfo.at) {
            debugInfo.errors.push('File not found or no attributes');
            console.log(`❌ File not found or invalid response`);
            return { result: null, debug: debugInfo };
        }
        
        console.log(`\n🔓 Decrypting file attributes...`);
        const attributes = decryptFileAttributes(fileInfo.at, keyBuffer);
        const fileName = attributes.n || 'Unknown';
        const ext = fileName.split('.').pop() || null;
        const mimeType = lookup(ext?.toLowerCase()) || 'application/octet-stream';
        
        let downloadUrl = '';
        if (typeof fileInfo.g === 'string') {
            downloadUrl = fileInfo.g;
        } else if (Array.isArray(fileInfo.g)) {
            downloadUrl = fileInfo.g[0] || '';
            console.log(`   ├─ Multiple URLs found: ${fileInfo.g.length}`);
        } else if (typeof fileInfo.g === 'object' && fileInfo.g !== null) {
            downloadUrl = fileInfo.g.url || fileInfo.g.g || '';
        }
        
        debugInfo.fileInfo = {
            fileName: fileName,
            fileSize: fileInfo.s,
            fileSizeFormatted: formatBytes(fileInfo.s),
            mimeType: mimeType,
            extension: ext,
            downloadUrlType: Array.isArray(fileInfo.g) ? 'array' : typeof fileInfo.g,
            downloadUrlCount: Array.isArray(fileInfo.g) ? fileInfo.g.length : 1
        };
        
        console.log(`\n📁 File Information:`);
        console.log(`   ├─ Name: ${fileName}`);
        console.log(`   ├─ Size: ${formatBytes(fileInfo.s)} (${fileInfo.s} bytes)`);
        console.log(`   ├─ MIME: ${mimeType}`);
        console.log(`   ├─ Extension: ${ext || 'N/A'}`);
        console.log(`   ├─ Download URL Type: ${Array.isArray(fileInfo.g) ? 'array' : typeof fileInfo.g}`);
        if (Array.isArray(fileInfo.g)) {
            console.log(`   ├─ Available URLs: ${fileInfo.g.length}`);
            fileInfo.g.forEach((url, idx) => {
                console.log(`   │  └─ URL ${idx + 1}: ${url.substring(0, 60)}...`);
            });
        }
        console.log(`   └─ Selected URL: ${typeof downloadUrl === 'string' && downloadUrl ? downloadUrl.substring(0, 60) : 'N/A'}...`);
        
        console.log(`\n✅ MEGA API Success in ${debugInfo.responseTime}ms`);
        console.log(`═══════════════════════════════════════════════════════════════\n`);
        
        if (!downloadUrl || typeof downloadUrl !== 'string') {
            debugInfo.errors.push('Invalid download URL format');
            console.log(`❌ Invalid download URL: ${JSON.stringify(fileInfo.g)}`);
            return { result: null, debug: debugInfo };
        }
        
        return {
            result: {
                api: 'mega.co.nz',
                file: {
                    fileId: fileId,
                    fileName: fileName,
                    fileSize: formatBytes(fileInfo.s),
                    sizeBytes: fileInfo.s,
                    mimeType: mimeType,
                    extension: ext,
                    downloadUrl: downloadUrl,
                    decryptionKey: keyBuffer,
                    hasMac: hasMac
                },
                duration: debugInfo.responseTime
            },
            debug: debugInfo
        };
        
    } catch (error) {
        debugInfo.errors.push(error.message);
        console.log(`❌ MEGA API Error: ${error.message}`);
        console.log(`═══════════════════════════════════════════════════════════════\n`);
        return { result: null, debug: debugInfo };
    }
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    const megaUrl = args && args.length > 0 ? args.join(' ').trim() : '';
    
    if (!megaUrl) {
        let prefix = usedPrefix;
        if (!prefix && m.text) {
            const match = m.text.match(/^([.!#/])/);
            prefix = match ? match[1] : '.';
        }
        prefix = prefix || '.';
        
        const cmd = command || 'mega';
        
        return m.reply(`*📥 Format MEGA Downloader:*

🔹 Download: ${prefix}${cmd} url_mega

*Contoh:*
${prefix}${cmd} https://mega.nz/file/abc123!def456
${prefix}${cmd} https://mega.nz/#!abc123!def456

*Supported URL Formats:*
- mega.nz/file/[id]#[key]
- mega.nz/#![id]![key]

*✨ Fitur:*
✓ Dekripsi otomatis file attributes
✓ Deteksi MIME type
✓ Support semua jenis file (PDF, ZIP, RAR, dll)
✓ Verifikasi integritas file
✓ Debug mendalam
✓ URL shortening untuk file besar

*⚠️ Catatan:*
- Maksimal ukuran upload: 50MB
- File lebih besar akan diberikan link download
- ZIP/RAR files fully supported`);
    }
    
    if (!isValidMegaUrl(megaUrl)) {
        return m.reply('❌ URL bukan dari MEGA. Pastikan URL mengandung:\n- mega.nz/file/\n- mega.nz/#!');
    }
    
    try {
        await conn.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });
    } catch (e) {
        console.log('Gagal menambahkan reaksi:', e);
    }
    
    try {
        console.log(`\n╔═══════════════════════════════════════════════════════════════╗`);
        console.log(`║  🔄 STARTING MEGA DOWNLOAD PROCESSING                         ║`);
        console.log(`╚═══════════════════════════════════════════════════════════════╝`);
        console.log(`📍 MEGA URL: ${megaUrl}`);
        console.log(`⏰ Started at: ${new Date().toISOString()}`);
        
        const { result, debug } = await getMegaDownloadUrl(megaUrl);
        
        if (!result || !result.file) {
            console.log('❌ Gagal mendapatkan informasi file dari MEGA:', megaUrl);
            
            let debugMsg = '*❌ Gagal mendapatkan file*\n\n';
            debugMsg += '*📊 Debug Information:*\n\n';
            debugMsg += `*API: ${debug.api}*\n`;
            debugMsg += `├─ Status: ${debug.responseStatus || 'No response'}\n`;
            debugMsg += `├─ Time: ${debug.responseTime || 'N/A'}ms\n`;
            debugMsg += `└─ Errors: ${debug.errors.join(', ') || 'None'}\n`;
            
            await conn.sendMessage(m.chat, { text: debugMsg });
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return;
        }
        
        const file = result.file;
        const MAX_SIZE = 50 * 1024 * 1024;
        
        console.log(`\n╔═══════════════════════════════════════════════════════════════╗`);
        console.log(`║  ✅ MEGA API SUCCESS                                          ║`);
        console.log(`╚═══════════════════════════════════════════════════════════════╝`);
        console.log(`⏱️  Time: ${result.duration}ms`);
        console.log(`📁 File: ${file.fileName}`);
        console.log(`📏 Size: ${file.fileSize}`);
        
        try {
            await conn.sendMessage(m.chat, { react: { text: '📥', key: m.key } });
        } catch (e) {
            console.log('Gagal menambahkan reaksi download:', e);
        }
        
        try {
            if (file.sizeBytes > MAX_SIZE) {
                console.log(`File too large (${file.fileSize}), sending link only`);
                
                console.log(`Creating short URL...`);
                const shortDownloadUrl = await createShortUrl(file.downloadUrl);
                
                let caption = `*📥 MEGA Download*\n\n`;
                caption += `📂 *File:* ${file.fileName}\n`;
                caption += `📏 *Size:* ${file.fileSize}\n`;
                caption += `📄 *Type:* ${file.mimeType}\n`;
                caption += `⚠️ *File terlalu besar untuk diupload*\n\n`;
                caption += `🔗 *LINK DOWNLOAD:*\n`;
                
                if (shortDownloadUrl) {
                    caption += `${shortDownloadUrl}`;
                } else {
                    caption += `${file.downloadUrl}`;
                }
                
                await conn.sendMessage(m.chat, { text: caption });
                await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                
            } else {
                console.log(`Downloading file (${file.fileSize})...`);
                
                try {
                    await conn.sendMessage(m.chat, { react: { text: '⬇️', key: m.key } });
                } catch (e) {
                    console.log('Gagal menambahkan reaksi download:', e);
                }
                
                try {
                    const decryptedBuffer = await downloadMegaFile(
                        file.downloadUrl, 
                        file.sizeBytes, 
                        file.decryptionKey,
                        file.hasMac
                    );
                    
                    console.log(`File ready to send (${decryptedBuffer.length} bytes), sending...`);
                    
                    try {
                        await conn.sendMessage(m.chat, { react: { text: '⬆️', key: m.key } });
                    } catch (e) {
                        console.log('Gagal menambahkan reaksi upload:', e);
                    }
                    
                    let caption = `*📥 MEGA Download*\n\n`;
                    caption += `📂 *File:* ${file.fileName}\n`;
                    caption += `📏 *Size:* ${file.fileSize}\n`;
                    caption += `📄 *Type:* ${file.mimeType}`;
                    
                    const fileName = file.fileName.toLowerCase();
                    const mimeType = file.mimeType.toLowerCase();
                    
                    const isImage = /\.(jpg|jpeg|png|gif|bmp|webp)$/i.test(fileName) || 
                                    mimeType.startsWith('image/');
                    const isVideo = /\.(mp4|mkv|avi|mov|wmv|flv|webm|m4v)$/i.test(fileName) || 
                                    mimeType.startsWith('video/');
                    const isAudio = /\.(mp3|wav|ogg|m4a|flac|aac)$/i.test(fileName) || 
                                    mimeType.startsWith('audio/');
                    
                    try {
                        if (isImage) {
                            await conn.sendMessage(m.chat, {
                                image: decryptedBuffer,
                                caption: caption
                            }, { quoted: m });
                            console.log(`Sent as image`);
                        } else if (isVideo) {
                            await conn.sendMessage(m.chat, {
                                video: decryptedBuffer,
                                mimetype: file.mimeType,
                                caption: caption,
                                fileName: file.fileName
                            }, { quoted: m });
                            console.log(`Sent as video`);
                        } else if (isAudio) {
                            await conn.sendMessage(m.chat, {
                                audio: decryptedBuffer,
                                mimetype: file.mimeType,
                                fileName: file.fileName
                            }, { quoted: m });
                            console.log(`Sent as audio`);
                        } else {
                            await conn.sendMessage(m.chat, {
                                document: decryptedBuffer,
                                mimetype: file.mimeType,
                                fileName: file.fileName,
                                caption: caption
                            }, { quoted: m });
                            console.log(`Sent as document`);
                        }
                        
                        try {
                            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                        } catch (e) {
                            console.log('Gagal menambahkan reaksi sukses:', e);
                        }
                        
                    } catch (sendError) {
                        console.error('Error sending file:', sendError);
                        
                        try {
                            await conn.sendMessage(m.chat, {
                                document: decryptedBuffer,
                                mimetype: file.mimeType,
                                fileName: file.fileName
                            }, { quoted: m });
                            console.log(`Sent as document (fallback)`);
                            
                            await conn.sendMessage(m.chat, { 
                                text: caption 
                            }, { quoted: m });
                            
                            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                        } catch (fallbackError) {
                            throw new Error(`Send failed: ${sendError.message}`);
                        }
                    }
                    
                } catch (fetchError) {
                    if (fetchError.message.includes('timeout')) {
                        throw new Error('Download timeout (exceeded time limit)');
                    }
                    throw fetchError;
                }
            }
            
        } catch (fileError) {
            console.error('Error processing file:', fileError.message);
            await conn.sendMessage(m.chat, { 
                text: `❌ Error memproses file: ${fileError.message}` 
            });
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        }
        
    } catch (error) {
        console.error('Error downloading MEGA:', error);
        await conn.sendMessage(m.chat, { 
            text: `❌ Error: ${error.message}` 
        });
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    }
};

handler.help = ["mega", "megadl"];
handler.tags = ["downloader"];
handler.command = ["mega", "megadl", "megadownload"];

export default handler;