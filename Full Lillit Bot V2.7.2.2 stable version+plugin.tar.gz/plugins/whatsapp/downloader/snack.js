const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

async function getSnackVideoDownload(url) {
    try {
        const apiUrl = `https://api.deline.web.id/downloader/snackvideo?url=${encodeURIComponent(url)}`;
        
        const response = await fetch(apiUrl, {
            timeout: 15000 // 15 detik timeout
        });
        
        if (!response.ok) {
            throw new Error(`API Error: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (!data.status || !data.result || !data.result.video) {
            throw new Error('API tidak mengembalikan data yang valid');
        }
        
        return { 
            success: true, 
            videoUrl: data.result.video,
            creator: data.creator || 'Unknown'
        };
        
    } catch (error) {
        throw new Error(error.message);
    }
}

function generateUsageHelp(prefix, cmd) {
    return `*🎬 SNACKVIDEO DOWNLOADER*

📌 *Cara Penggunaan:*
${prefix}${cmd} [link snackvideo]

✨ *Fitur:*
• Download video dari SnackVideo
• Kualitas video original
• Tanpa watermark

📋 *Contoh:*
${prefix}${cmd} https://www.snackvideo.com/@username/video/xxxxx

⚠️ *Catatan:*
• Pastikan link video valid
• Support semua video publik SnackVideo`;
}

function isValidSnackVideoUrl(url) {
    const snackPattern = /^https?:\/\/(www\.)?snackvideo\.com\/@[^\/]+\/video\/\d+/i;
    return snackPattern.test(url);
}

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    // Deteksi prefix
    let prefix = usedPrefix;
    if (!prefix && m.text) {
        const match = m.text.match(/^([.!#/])/);
        prefix = match ? match[1] : '.';
    }
    prefix = prefix || '.';
    
    const cmd = command || 'snack';
    
    // Ambil URL dari text atau args
    let url = '';
    if (text) {
        url = text.trim();
    } else if (args && args.length > 0) {
        url = args[0].trim();
    }
    
    // Cek apakah user minta help atau tidak ada input
    if (!url || url.toLowerCase() === 'help' || url === '?') {
        return m.reply(generateUsageHelp(prefix, cmd));
    }
    
    // Validasi URL SnackVideo
    if (!isValidSnackVideoUrl(url)) {
        return m.reply(`❌ Link tidak valid!\n\n💡 Format yang benar:\n${prefix}${cmd} https://www.snackvideo.com/@username/video/xxxxx\n\n📌 Pastikan link dari SnackVideo!`);
    }
    
    try {
        // React dengan emoji untuk menunjukkan proses
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        const result = await getSnackVideoDownload(url);
        
        if (!result.success) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply('❌ Gagal mendapatkan video dari SnackVideo.\n\n💡 Pastikan link valid dan video masih tersedia.');
        }
        
        // Kirim video langsung tanpa caption
        await conn.sendMessage(m.chat, {
            video: { url: result.videoUrl }
        }, { quoted: m });
        
        // React dengan checkmark
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (error) {
        console.error('Error getting SnackVideo download:', error);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        
        let errorMsg = '❌ Terjadi kesalahan saat memproses video SnackVideo.\n\n';
        
        if (error.message.includes('timeout')) {
            errorMsg += '⚠️ Timeout: API tidak merespons\n💡 Coba lagi dalam beberapa saat';
        } else if (error.message.includes('404')) {
            errorMsg += '⚠️ Video tidak ditemukan\n💡 Pastikan link masih aktif';
        } else {
            errorMsg += `⚠️ Error: ${error.message}\n💡 Pastikan link valid dan coba lagi`;
        }
        
        m.reply(errorMsg);
    }
};

handler.help = ["snack [link]", "snackvideo [link]"];
handler.tags = ["downloader"];
handler.command = ["snack", "snackvideo", "snackvid", "sv"];
handler.limit = true; // Opsional: batasi penggunaan

export default handler;