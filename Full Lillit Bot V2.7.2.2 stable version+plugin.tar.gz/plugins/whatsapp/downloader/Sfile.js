import { randomBytes, createHash } from 'crypto';

const SF_BASE = 'https://sfile.co';
const UA      = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';

// ─── Debug ────────────────────────────────────────────────────────────────────

const DEBUG = true;
const dbg = (tag, ...a) => DEBUG && console.log(`[sfile:${tag}]`, ...a);

// ─── Helpers ──────────────────────────────────────────────────────────────────

function isValidUrl(u) { return /^(https?:\/\/)?(www\.)?sfile\.(co|mobi)\/[A-Za-z0-9]+/.test(u); }
function extractUrls(t) { return [...new Set(t.match(/(https?:\/\/)?(www\.)?sfile\.(co|mobi)\/[A-Za-z0-9]+/gi) || [])]; }
function normalizeUrl(u) { return u.replace(/^(https?:\/\/)?(www\.)?sfile\.(co|mobi)\//, `${SF_BASE}/`); }

function formatSize(b) {
    if (!b) return '-';
    if (b >= 1_073_741_824) return (b/1_073_741_824).toFixed(2)+' GB';
    if (b >= 1_048_576)     return (b/1_048_576).toFixed(2)+' MB';
    if (b >= 1_024)         return (b/1_024).toFixed(2)+' KB';
    return b+' B';
}
function getMime(f = '') {
    const e = f.split('.').pop().toLowerCase();
    return ({jpg:'image/jpeg',jpeg:'image/jpeg',png:'image/png',gif:'image/gif',webp:'image/webp',
             mp4:'video/mp4',mkv:'video/x-matroska',avi:'video/x-msvideo',mov:'video/quicktime',
             mp3:'audio/mpeg',m4a:'audio/mp4',ogg:'audio/ogg',flac:'audio/flac',wav:'audio/wav',
             pdf:'application/pdf',apk:'application/vnd.android.package-archive',
             zip:'application/zip',rar:'application/x-rar-compressed'})[e] || 'application/octet-stream';
}
function getIcon(f = '') {
    const e = f.split('.').pop().toLowerCase();
    return ({pdf:'📄',doc:'📝',docx:'📝',xls:'📊',xlsx:'📊',txt:'📃',zip:'🗜️',rar:'🗜️','7z':'🗜️',
             jpg:'🖼️',jpeg:'🖼️',png:'🖼️',gif:'🖼️',webp:'🖼️',mp4:'🎬',mkv:'🎬',avi:'🎬',mov:'🎬',
             mp3:'🎵',m4a:'🎵',flac:'🎵',ogg:'🎵',wav:'🎵',apk:'📱',exe:'💻'})[e] || '📁';
}

// ─── Headers & Cookies ────────────────────────────────────────────────────────

function createHeaders(referer, cookie = '') {
    return {
        'User-Agent': UA,
        'sec-ch-ua': '"Not/A)Brand";v="8", "Chromium";v="137", "Google Chrome";v="137"',
        'dnt': '1',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-dest': 'document',
        'Referer': referer,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        ...(cookie ? { Cookie: cookie } : {}),
    };
}

function extractCookies(headers) {
    const raw = headers.get('set-cookie');
    if (!raw) return '';
    return raw.split(',').map(c => c.split(';')[0].trim()).join('; ');
}

// ─── Core downloader ─────────────────────────────────────────────────────────

async function sfileDownload(url) {
    // ── Step 1: Info page ──
    dbg('step1', `GET ${url}`);
    const initRes = await fetch(url, { headers: createHeaders(SF_BASE) });
    if (!initRes.ok) throw new Error(`Info page HTTP ${initRes.status}`);

    const cookie1  = extractCookies(initRes.headers);
    const htmlInit = await initRes.text();
    dbg('step1', `len=${htmlInit.length} | cookies=${cookie1.slice(0,80)}`);

    // Ekstrak metadata dari HTML
    const filename = htmlInit.match(/class="h-8 w-8"[^>]+alt="([^"]+)"/)?.[1]?.trim()
                  || htmlInit.match(/<h1[^>]*class="[^"]*truncate[^"]*"[^>]*>\s*([^<]+?)\s*<\/h1>/)?.[1]?.trim()
                  || 'file';
    const sizeStr  = (htmlInit.match(/size\s+([\d.,]+\s*(?:GB|MB|KB|B))/i)
                  || htmlInit.match(/([\d.,]+\s*(?:GB|MB|KB|B))/i))?.[1]?.trim() || '-';
    const mime     = htmlInit.match(/<span[^>]*class="text-sm text-slate-600">\s*([a-z]+\/[a-z0-9.+-]+)\s*<\/span>/)?.[1] || null;

    // Ambil data-dw-url
    const dwUrl = htmlInit.match(/data-dw-url=["']([^"']+)["']/)?.[1]
                    ?.replace(/&amp;/g,'&').replace(/&#39;/g,"'").trim();
    if (!dwUrl) throw new Error('data-dw-url tidak ditemukan');
    dbg('step1', `file=${filename} | size=${sizeStr} | dwUrl=${dwUrl}`);

    // ── Step 2: Download page ──
    dbg('step2', `GET ${dwUrl}`);
    const procRes = await fetch(dwUrl, {
        headers: createHeaders(url, cookie1),
    });
    if (!procRes.ok) throw new Error(`Download page HTTP ${procRes.status}`);

    const cookie2  = extractCookies(procRes.headers) || cookie1;
    const htmlProc = await procRes.text();
    dbg('step2', `len=${htmlProc.length} | cookies=${cookie2.slice(0,80)}`);

    if (/expired download link/i.test(htmlProc))
        throw new Error('Link download expired — coba lagi');

    // ── Step 3: Cari URL final di <script> ──
    // URL di-escape dalam JS string: https:\/\/download\d+.sfile.co\/downloadfile\/...
    const scripts = htmlProc.match(/<script[\s\S]*?<\/script>/gi)?.join('\n') || htmlProc;

    const patterns = [
        // Escaped: https:\/\/download0926.sfile.co\/downloadfile\/...
        /https:\\\/\\\/download\d*\.sfile\.co\\\/downloadfile\\\/\d+\\\/\d+\\\/[a-z0-9]+\\\/[^\s'"\\]+/gi,
        // Normal: https://download0926.sfile.co/downloadfile/...
        /https?:\/\/download\d*\.sfile\.co\/downloadfile\/[^\s"'<>]+/gi,
        // CDN lain misal cdn*.sfile.co
        /https?:\/\/(?:cdn|dl|static)\d*\.sfile\.co\/[^\s"'<>]+/gi,
        // Numeric path di sfile.co sendiri
        /https?:\/\/sfile\.co\/download\/\d+\/\d+\/[a-f0-9]{32}\/[^\s"'<>&]+/gi,
    ];

    let finalUrl = null;
    for (const pat of patterns) {
        const m = scripts.match(pat);
        if (m?.[0]) {
            finalUrl = m[0].replace(/\\\//g, '/').replace(/\\u0026/g, '&');
            dbg('step3', `✅ found via pattern ${pat.source.slice(0,40)}: ${finalUrl.slice(0,100)}`);
            break;
        }
    }

    // Fallback: cari path numerik di HTML lalu follow redirect
    if (!finalUrl) {
        dbg('step3', '⚠️  not in script, trying numeric path + redirect...');
        const pathRe = /["'`](\/download\/(\d+)\/\d+\/[a-f0-9]{32}\/[^"'`\s<>]+)["'`]/g;
        for (const pm of htmlProc.matchAll(pathRe)) {
            const raw      = pm[1].replace(/&amp;/g,'&');
            const cleaned  = raw.replace(/^(\/download\/[^?&]+)&/, '$1?');
            const target   = `${SF_BASE}${cleaned}`;
            dbg('step3', `  trying redirect: ${target.slice(0,100)}`);
            try {
                const rr  = await fetch(target, {
                    headers: createHeaders(dwUrl, cookie2),
                    redirect: 'manual',
                });
                const loc = rr.headers.get('location');
                dbg('step3', `  → ${rr.status} | location=${loc||'-'}`);
                if ([301,302,303,307,308].includes(rr.status) && loc &&
                    (loc.includes('downloadfile') || /download\d+\.sfile\.co/.test(loc))) {
                    finalUrl = loc.startsWith('http') ? loc : `${SF_BASE}${loc}`;
                    dbg('step3', `✅ via redirect: ${finalUrl.slice(0,100)}`);
                    break;
                }
            } catch (e) { dbg('step3', `  error: ${e.message}`); }
        }
    }

    // Debug dump jika masih gagal
    if (!finalUrl) {
        dbg('step3', '❌ all patterns failed. Dumping scripts:');
        (htmlProc.match(/<script[\s\S]*?<\/script>/gi) || [])
            .forEach((s, i) => dbg(`script[${i}]`, s.slice(0,300)));
        throw new Error('URL download final tidak ditemukan');
    }

    return { filename, sizeStr, mime, finalUrl, cookie: cookie2 };
}

// ─── Process & Send ───────────────────────────────────────────────────────────

async function processUrl(conn, m, url) {
    url = normalizeUrl(url);

    const { filename, sizeStr, mime, finalUrl, cookie } = await sfileDownload(url);

    dbg('dl', `${filename} ← ${finalUrl.slice(0,100)}`);
    const fileRes = await fetch(finalUrl, {
        headers: createHeaders(SF_BASE, cookie),
    });
    if (!fileRes.ok) throw new Error(`Download file HTTP ${fileRes.status}`);

    const buf = Buffer.from(await fileRes.arrayBuffer());
    if (!buf?.length) throw new Error('Buffer kosong');

    // Nama file dari Content-Disposition jika ada
    const cd       = fileRes.headers.get('content-disposition') || '';
    const cdM      = cd.match(/filename\*?=(?:UTF-8'')?["']?([^"';\r\n]+)/i);
    const realName = cdM?.[1] ? decodeURIComponent(cdM[1].trim()) : filename;
    const realSize = formatSize(buf.length);

    dbg('dl', `✅ ${realName} (${realSize})`);

    const caption = `${getIcon(realName)} *${realName}*\n📦 ${realSize}\n🔗 ${url}`;
    const fileMime = mime || getMime(realName);
    const ext      = realName.split('.').pop().toLowerCase();

    if (['jpg','jpeg','png','webp','gif'].includes(ext))
        await conn.sendMessage(m.chat, { image: buf, caption }, { quoted: m });
    else if (['mp4','mkv','avi','mov','webm'].includes(ext))
        await conn.sendMessage(m.chat, { video: buf, mimetype: fileMime, caption, fileName: realName }, { quoted: m });
    else if (['mp3','m4a','ogg','flac','wav'].includes(ext))
        await conn.sendMessage(m.chat, { audio: buf, mimetype: fileMime, ptt: false, fileName: realName, caption }, { quoted: m });
    else
        await conn.sendMessage(m.chat, { document: buf, mimetype: fileMime, fileName: realName, caption }, { quoted: m });
}

// ─── Help & Handler ───────────────────────────────────────────────────────────

const HELP = (p, c) => `*📁 Sfile.co Downloader*\n\n${p}${c} <url>\n\nContoh:\n${p}${c} https://sfile.co/JYigDkY71K5`.trim();

let handler = async (m, { conn, args, usedPrefix, command }) => {
    const input  = args?.join(' ').trim() || '';
    const prefix = usedPrefix || '.';
    const cmd    = command || 'sfile';

    if (!input) return m.reply(HELP(prefix, cmd));

    const urls = extractUrls(input).filter(isValidUrl);
    if (!urls.length) return m.reply(`❌ URL sfile.co tidak ditemukan.\n\nContoh: ${prefix}${cmd} https://sfile.co/JYigDkY71K5`);

    const isBulk = urls.length > 1;
    if (isBulk) await m.reply(`📥 Memproses *${urls.length} file*…`);

    let ok = 0, fail = 0;
    for (let i = 0; i < urls.length; i++) {
        try {
            await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
            await processUrl(conn, m, urls[i]);
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            ok++;
        } catch (e) {
            console.error(`[sfile] ❌ [${urls[i]}]: ${e.message}`);
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            if (!isBulk) return m.reply(`❌ ${e.message}`);
            fail++;
        }
        if (isBulk && i < urls.length - 1) await new Promise(r => setTimeout(r, 1500));
    }
    if (isBulk) await m.reply(`📊 *Selesai*\n✅ ${ok}  ❌ ${fail}  dari ${urls.length}`);
};

handler.help    = ['sfile', 'sf'];
handler.tags    = ['downloader'];
handler.command = ['sfile', 'sf'];

export default handler;