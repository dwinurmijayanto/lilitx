import os from "os";

// ===== UTILITY FUNCTIONS =====

// Fungsi untuk calculate Luhn checksum
function calculateLuhnChecksum(cardNumber) {
  let sum = 0;
  let shouldDouble = true;
  
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i]);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return (10 - (sum % 10)) % 10;
}

// Fungsi untuk format card number
function formatCardNumber(cardNumber) {
  const cleanNumber = cardNumber.replace(/\D/g, '');
  return cleanNumber.replace(/(\d{4})(?=\d)/g, '$1 ');
}

// Fungsi untuk detect card type dari BIN
function detectCardTypeFromBIN(bin) {
  const binStr = bin.toString();
  
  if (binStr.startsWith('4')) {
    return 'Visa';
  } else if (/^5[1-5]/.test(binStr) || /^2[2-7]/.test(binStr)) {
    return 'Mastercard';
  } else if (/^3[47]/.test(binStr)) {
    return 'American Express';
  } else if (/^6(?:011|5)/.test(binStr)) {
    return 'Discover';
  } else if (/^35/.test(binStr)) {
    return 'JCB';
  } else if (/^3(?:0[0-5]|[68])/.test(binStr)) {
    return 'Diners Club';
  }
  
  return 'Unknown';
}

// Fungsi untuk generate CC dengan BIN spesifik
function generateCCFromBIN(bin, type = null) {
  let cardNumber = bin.toString();
  
  // Auto-detect type jika tidak di-specify
  if (!type) {
    type = detectCardTypeFromBIN(bin);
  }
  
  // Tentukan panjang kartu berdasarkan type
  let targetLength = 16; // Default untuk Visa, MC, Discover
  if (type === 'American Express') {
    targetLength = 15;
  } else if (type === 'Diners Club') {
    targetLength = 14;
  }
  
  // Generate random digits hingga mencapai target - 1 (untuk checksum)
  const remainingDigits = targetLength - 1 - cardNumber.length;
  
  if (remainingDigits < 0) {
    throw new Error(`BIN too long for ${type} card type`);
  }
  
  for (let i = 0; i < remainingDigits; i++) {
    cardNumber += Math.floor(Math.random() * 10);
  }
  
  // Hitung dan tambahkan Luhn checksum
  const checkDigit = calculateLuhnChecksum(cardNumber);
  cardNumber += checkDigit;
  
  // Generate expiry date (MM/YY) - 2025-2034
  const month = String(Math.floor(Math.random() * 12) + 1).padStart(2, '0');
  const year = String(Math.floor(Math.random() * 10) + 25).padStart(2, '0');
  
  // Generate CVV (3 digit untuk Visa/MC, 4 digit untuk Amex)
  const cvvLength = type === 'American Express' ? 4 : 3;
  const cvvMax = cvvLength === 4 ? 9000 : 900;
  const cvvAdd = cvvLength === 4 ? 1000 : 100;
  const cvv = String(Math.floor(Math.random() * cvvMax) + cvvAdd);
  
  return {
    number: formatCardNumber(cardNumber),
    expiry: `${month}/${year}`,
    cvv: cvv,
    raw: cardNumber,
    type: type,
    bin: bin.toString()
  };
}

// Fungsi untuk generate CC Visa
function generateVisaCC() {
  // Visa BINs populer
  const visaBINs = [
    '400115', '400837', '401079', '402360', '404011',
    '411111', '412923', '413907', '414720', '415294',
    '424631', '431940', '438857', '444509', '451651',
    '453978', '456789', '465060', '477666', '483312'
  ];
  
  const randomBIN = visaBINs[Math.floor(Math.random() * visaBINs.length)];
  return generateCCFromBIN(randomBIN, 'Visa');
}

// Fungsi untuk generate Mastercard
function generateMastercard() {
  // Mastercard BINs populer
  const mcBINs = [
    '512345', '515468', '517805', '521478', '523456',
    '531234', '535678', '539012', '542418', '545454',
    '551234', '553456', '555555', '557890', '559012'
  ];
  
  const randomBIN = mcBINs[Math.floor(Math.random() * mcBINs.length)];
  return generateCCFromBIN(randomBIN, 'Mastercard');
}

// Fungsi untuk generate American Express
function generateAmex() {
  // Amex BINs (start with 34 or 37, 15 digits total)
  const amexPrefixes = ['340000', '371449', '378282', '378734'];
  const prefix = amexPrefixes[Math.floor(Math.random() * amexPrefixes.length)];
  
  let cardNumber = prefix;
  
  // Generate 8 more random digits (total 14)
  for (let i = 0; i < 8; i++) {
    cardNumber += Math.floor(Math.random() * 10);
  }
  
  // Add Luhn checksum (total 15 digits for Amex)
  const checkDigit = calculateLuhnChecksum(cardNumber);
  cardNumber += checkDigit;
  
  const month = String(Math.floor(Math.random() * 12) + 1).padStart(2, '0');
  const year = String(Math.floor(Math.random() * 10) + 25).padStart(2, '0');
  const cvv = String(Math.floor(Math.random() * 9000) + 1000); // 4 digit CVV
  
  return {
    number: formatCardNumber(cardNumber),
    expiry: `${month}/${year}`,
    cvv: cvv,
    raw: cardNumber,
    type: 'American Express',
    bin: prefix
  };
}

// Fungsi untuk generate Discover
function generateDiscover() {
  const discoverBINs = ['601100', '622126', '644444', '655555'];
  const randomBIN = discoverBINs[Math.floor(Math.random() * discoverBINs.length)];
  return generateCCFromBIN(randomBIN, 'Discover');
}

// Fungsi untuk validate CC dengan Luhn algorithm
function validateCreditCard(cardNumber) {
  const cleanNumber = cardNumber.replace(/\D/g, '');
  
  if (cleanNumber.length < 13 || cleanNumber.length > 19) {
    return false;
  }
  
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = cleanNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cleanNumber[i]);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

// Fungsi untuk identify card type dengan detail
function identifyCardType(cardNumber) {
  const cleanNumber = cardNumber.replace(/\D/g, '');
  
  // Visa
  if (cleanNumber.startsWith('4')) {
    return { type: 'Visa', icon: '💳', color: '🔵' };
  }
  // Mastercard
  else if (/^5[1-5]/.test(cleanNumber) || /^2[2-7]/.test(cleanNumber)) {
    return { type: 'Mastercard', icon: '💳', color: '🔴' };
  }
  // American Express
  else if (/^3[47]/.test(cleanNumber)) {
    return { type: 'American Express', icon: '💳', color: '🟢' };
  }
  // Discover
  else if (/^6(?:011|5)/.test(cleanNumber)) {
    return { type: 'Discover', icon: '💳', color: '🟠' };
  }
  // JCB
  else if (/^35/.test(cleanNumber)) {
    return { type: 'JCB', icon: '💳', color: '🟣' };
  }
  // Diners Club
  else if (/^3(?:0[0-5]|[68])/.test(cleanNumber)) {
    return { type: 'Diners Club', icon: '💳', color: '⚪' };
  }
  else {
    return { type: 'Unknown', icon: '❓', color: '⚫' };
  }
}

// Fungsi untuk cek CC dengan simulasi lebih realistis
function checkCreditCard(cardNumber, includeDetails = false) {
  const isValid = validateCreditCard(cardNumber);
  const cardInfo = identifyCardType(cardNumber);
  const cleanNumber = cardNumber.replace(/\D/g, '');
  
  // Simulasi berbagai response berdasarkan validitas
  let status, response, responseCode;
  
  if (!isValid) {
    status = 'Invalid ❌';
    response = 'Invalid Card Number - Luhn Check Failed';
    responseCode = 'LUHN_FAIL';
  } else {
    // Random realistic responses untuk valid cards
    const responses = [
      { status: 'Live ✅', msg: 'Approved - Transaction Successful', code: 'APPROVED' },
      { status: 'Live ✅', msg: 'Approved - CVV Match', code: 'CVV_MATCH' },
      { status: 'Live ✅', msg: 'Approved - Available Balance: $XXX.XX', code: 'APPROVED_BAL' },
      { status: 'Dead ❌', msg: 'Card Declined - Insufficient Funds', code: 'INSUFFICIENT_FUNDS' },
      { status: 'Dead ❌', msg: 'Card Declined - Expired Card', code: 'EXPIRED' },
      { status: 'Dead ❌', msg: 'Card Declined - Invalid CVV', code: 'CVV_FAIL' },
      { status: 'Dead ❌', msg: 'Card Declined - Suspected Fraud', code: 'FRAUD_SUSPECTED' },
      { status: 'Unknown ❓', msg: 'Unable to Process - Try Again Later', code: 'TIMEOUT' },
      { status: 'Unknown ❓', msg: 'Card Issuer Unavailable', code: 'ISSUER_DOWN' },
      { status: 'CCN Live 🔐', msg: 'Card Number Valid - CVV Required', code: 'CCN_VALID' }
    ];
    
    const randomResp = responses[Math.floor(Math.random() * responses.length)];
    status = randomResp.status;
    response = randomResp.msg;
    responseCode = randomResp.code;
  }
  
  const result = {
    valid: isValid,
    type: cardInfo.type,
    icon: cardInfo.icon,
    color: cardInfo.color,
    status: status,
    response: response,
    responseCode: responseCode,
    formatted: formatCardNumber(cardNumber),
    bin: cleanNumber.substring(0, 6),
    last4: cleanNumber.substring(cleanNumber.length - 4)
  };
  
  if (includeDetails) {
    result.length = cleanNumber.length;
    result.scheme = cardInfo.type;
  }
  
  return result;
}

// Fungsi untuk generate multiple CCs
function generateMultipleCCs(count = 10, type = 'random', customBIN = null) {
  const cards = [];
  
  for (let i = 0; i < count; i++) {
    let card;
    
    // Jika ada custom BIN, gunakan itu
    if (customBIN) {
      try {
        card = generateCCFromBIN(customBIN);
      } catch (e) {
        throw new Error(`Failed to generate card with BIN ${customBIN}: ${e.message}`);
      }
    } else {
      // Generate berdasarkan type
      if (type === 'visa') {
        card = generateVisaCC();
      } else if (type === 'mastercard') {
        card = generateMastercard();
      } else if (type === 'amex') {
        card = generateAmex();
      } else if (type === 'discover') {
        card = generateDiscover();
      } else {
        // Random
        const types = [generateVisaCC, generateMastercard, generateAmex, generateDiscover];
        const randomFunc = types[Math.floor(Math.random() * types.length)];
        card = randomFunc();
      }
    }
    
    // Auto-check each card
    const checkResult = checkCreditCard(card.raw);
    card.checkResult = checkResult;
    
    cards.push(card);
  }
  
  return cards;
}

// ===== MAIN HANDLER =====

let handler = async (m, { conn, config, command, args, usedPrefix = '.' }) => {
  try {
    // Extract text dari args array
    let text = Array.isArray(args) ? args.join(' ') : '';
    
    // Fallback: coba extract dari message body
    if (!text && m.body) {
      const commandPrefix = usedPrefix + command;
      if (m.body.startsWith(commandPrefix)) {
        text = m.body.slice(commandPrefix.length).trim();
      }
    }
    
    console.log('=== CC HANDLER DEBUG ===');
    console.log('Command:', command);
    console.log('Args:', args);
    console.log('Text:', text);
    
    // COMMAND: GEN - GENERATE CC
    if (command === "gen" || command === "generate" || command === "gencc") {
      const params = text.toLowerCase().split(' ').filter(x => x);
      
      // Deteksi apakah ada custom BIN (angka 6-8 digit)
      let customBIN = null;
      let cardType = 'random';
      let count = 1;
      
      // Parse parameters
      for (let param of params) {
        // Cek apakah param adalah angka
        if (/^\d+$/.test(param)) {
          // Jika 6-8 digit, anggap sebagai BIN
          if (param.length >= 6 && param.length <= 8) {
            customBIN = param;
          } 
          // Jika 1-2 digit, anggap sebagai count
          else if (param.length <= 2) {
            count = parseInt(param);
          }
        } else {
          // Anggap sebagai card type
          cardType = param;
        }
      }
      
      // Limit count untuk prevent spam
      if (count > 20) count = 20;
      if (count < 1) count = 1;
      
      let generatedCC;
      
      if (count === 1) {
        // Generate single card
        if (customBIN) {
          // Generate dengan custom BIN
          try {
            generatedCC = generateCCFromBIN(customBIN);
          } catch (e) {
            return m.reply(`❌ Error generating card with BIN ${customBIN}:\n${e.message}\n\nMake sure BIN is 6-8 digits and valid for the card type.`);
          }
        } else {
          // Generate dengan type default
          switch (cardType) {
            case 'visa':
            case 'v':
              generatedCC = generateVisaCC();
              break;
              
            case 'mastercard':
            case 'master':
            case 'mc':
            case 'm':
              generatedCC = generateMastercard();
              break;
              
            case 'amex':
            case 'american':
            case 'americanexpress':
              generatedCC = generateAmex();
              break;
              
            case 'discover':
            case 'disc':
            case 'd':
              generatedCC = generateDiscover();
              break;
              
            default:
              // Random
              const types = [generateVisaCC, generateMastercard, generateAmex, generateDiscover];
              const randomFunc = types[Math.floor(Math.random() * types.length)];
              generatedCC = randomFunc();
              break;
          }
        }
        
        // Auto-check generated CC
        const checkResult = checkCreditCard(generatedCC.raw, true);
        
        const msg = `╔═══════════════════════════
║ 💳 *GENERATED ${generatedCC.type.toUpperCase()}*
${customBIN ? `║ 🎯 *Using Custom BIN: ${customBIN}*` : ''}
╠═══════════════════════════
║ 
║ 🔢 *Card Number*
║ \`${generatedCC.number}\`
║ 
║ 📅 *Expiry:* \`${generatedCC.expiry}\`
║ 🔐 *CVV:* \`${generatedCC.cvv}\`
║ 🏦 *Type:* ${checkResult.color} ${generatedCC.type}
║ 🎯 *BIN:* \`${generatedCC.bin}\`
║ 
╠═══════════════════════════
║ 🔍 *AUTO CHECK RESULT*
╠═══════════════════════════
║ 
║ ${checkResult.status}
║ ✅ Luhn: ${checkResult.valid ? 'Valid' : 'Invalid'}
║ 📊 Code: ${checkResult.responseCode}
║ 💬 ${checkResult.response}
║ 
╠═══════════════════════════
║ ⚠️ *DISCLAIMER*
╠═══════════════════════════
║ 
║ 🎓 Educational purposes only
║ 🚫 Generated cards are FAKE
║ 🚫 Do NOT use for fraud
║ 
╚═══════════════════════════

*Quick Commands:*
• ${usedPrefix}gen visa - Generate Visa
• ${usedPrefix}gen mastercard - Generate MC
• ${usedPrefix}gen amex - Generate Amex
• ${usedPrefix}gen 123456 - Generate with BIN
• ${usedPrefix}gen 123456 10 - 10 cards with BIN
• ${usedPrefix}check [cc] - Check card`;
        
        await m.reply(msg);
        
      } else {
        // Generate multiple cards
        try {
          const cards = generateMultipleCCs(count, cardType === 'random' ? 'random' : cardType, customBIN);
          
          let msg = `╔═══════════════════════════
║ 💳 *GENERATED ${count} CARDS*
${customBIN ? `║ 🎯 *Using BIN: ${customBIN}*` : ''}
╠═══════════════════════════\n`;
          
          cards.forEach((card, index) => {
            msg += `║ 
║ *#${index + 1} - ${card.type}*
║ 🔢 \`${card.number}\`
║ 📅 \`${card.expiry}\` | 🔐 \`${card.cvv}\`
║ ${card.checkResult.status} - ${card.checkResult.responseCode}\n`;
          });
          
          msg += `║ 
╠═══════════════════════════
║ 📊 *SUMMARY*
╠═══════════════════════════
║ 
║ Total Generated: ${count} cards
${customBIN ? `║ Custom BIN: ${customBIN}` : `║ Type: ${cardType === 'random' ? 'Mixed' : cardType}`}
║ All checked with Luhn validation
║ 
╠═══════════════════════════
║ ⚠️ *DISCLAIMER*
╠═══════════════════════════
║ 
║ 🎓 Educational purposes only
║ 🚫 Generated cards are FAKE
║ 
╚═══════════════════════════`;
          
          await m.reply(msg);
        } catch (e) {
          return m.reply(`❌ Error: ${e.message}`);
        }
      }
    }
    
    // COMMAND: CHECK - CHECK CC
    else if (command === "check" || command === "cek" || command === "checkcc") {
      if (!text) {
        const helpMsg = `╔═══════════════════════════
║ 🔍 *CC CHECKER GUIDE*
╠═══════════════════════════
║ 
║ *Basic Formats:*
║ 
║ • ${usedPrefix}check 4532123456789012
║ • ${usedPrefix}check 4532 1234 5678 9012
║ • ${usedPrefix}check 4532-1234-5678-9012
║ 
║ *With Additional Data:*
║ 
║ • ${usedPrefix}check 4532123456789012|12/28
║ • ${usedPrefix}check 4532123456789012|12/28|123
║ • ${usedPrefix}check 4532123456789012|12/28|123|10001
║ 
║ *Supported Separators:*
║ • Spaces, dashes, pipes
║ • Auto-detected format
║ 
╚═══════════════════════════

*Example:*
${usedPrefix}check 4532123456789012
${usedPrefix}check 4532123456789012|12/28|123`;
        
        return m.reply(helpMsg);
      }
      
      // Parsing input
      let ccNumber, expiry = '', cvv = '', zip = '';
      
      if (text.includes('|')) {
        const parts = text.split('|').map(x => x.trim());
        ccNumber = parts[0];
        expiry = parts[1] || '';
        cvv = parts[2] || '';
        zip = parts[3] || '';
      } else {
        ccNumber = text.trim();
      }
      
      // Clean CC number
      ccNumber = ccNumber.replace(/\D/g, '');
      
      if (!ccNumber) {
        return m.reply('❌ Invalid card number format');
      }
      
      // Simulasi processing
      await m.reply('🔍 Checking card...');
      
      // Delay untuk efek realistis
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const result = checkCreditCard(ccNumber, true);
      
      const checkMsg = `╔═══════════════════════════
║ 🔍 *CC CHECK RESULT*
╠═══════════════════════════
║ 
║ 💳 *Card Details*
║ Number: \`${result.formatted}\`
║ Type: ${result.color} ${result.type}
║ BIN: \`${result.bin}\` | Last4: \`${result.last4}\`
${expiry ? `║ Expiry: \`${expiry}\`` : ''}
${cvv ? `║ CVV: \`${cvv}\`` : ''}
${zip ? `║ ZIP: \`${zip}\`` : ''}
║ 
╠═══════════════════════════
║ 📊 *Validation Result*
╠═══════════════════════════
║ 
║ ${result.status}
║ 
║ ✅ Luhn Valid: ${result.valid ? 'Yes ✓' : 'No ✗'}
║ 📊 Response Code: ${result.responseCode}
║ 💬 Message: ${result.response}
║ 🔢 Length: ${result.length} digits
║ 
╠═══════════════════════════
║ ⚠️ *DISCLAIMER*
╠═══════════════════════════
║ 
║ 🎓 Simulation for demo purposes
║ 🚫 Do NOT use for real transactions
║ 
╚═══════════════════════════

*Other Commands:*
• ${usedPrefix}gen - Generate card
• ${usedPrefix}ccmenu - All commands`;
      
      await m.reply(checkMsg);
    }
    
    // COMMAND: CCMENU - SHOW MENU
    else if (command === "ccmenu" || command === "menucc") {
      const menuMsg = `╔═══════════════════════════
║ 🤖 *CREDIT CARD BOT*
╠═══════════════════════════
║ 
║ *🎲 Generate Commands:*
║ 
║ • ${usedPrefix}gen
║   Random card (any type)
║ 
║ • ${usedPrefix}gen visa
║   Generate Visa card
║ 
║ • ${usedPrefix}gen mastercard
║   Generate Mastercard
║ 
║ • ${usedPrefix}gen amex
║   Generate American Express
║ 
║ • ${usedPrefix}gen discover
║   Generate Discover card
║ 
║ • ${usedPrefix}gen [type] 10
║   Generate 10 cards (max 20)
║ 
║ • ${usedPrefix}gen 123456
║   Generate with custom BIN
║ 
║ • ${usedPrefix}gen 123456 10
║   10 cards with custom BIN
║ 
╠═══════════════════════════
║ *🔍 Check Commands:*
║ 
║ • ${usedPrefix}check [cc]
║   Basic validation check
║ 
║ • ${usedPrefix}check [cc|exp|cvv]
║   Full details check
║ 
╠═══════════════════════════
║ *📖 Help Commands:*
║ 
║ • ${usedPrefix}cchelp
║   Detailed usage guide
║ 
║ • ${usedPrefix}ccmenu
║   This menu
║ 
╠═══════════════════════════
║ *💡 Quick Examples:*
╠═══════════════════════════
║ 
║ ${usedPrefix}gen visa
║ ${usedPrefix}gen mastercard 5
║ ${usedPrefix}gen 400115
║ ${usedPrefix}gen 411111 10
║ ${usedPrefix}check 4532123456789012
║ ${usedPrefix}check 4532123456789012|12/28|123
║ 
╠═══════════════════════════
║ *⚠️ IMPORTANT NOTICE*
╠═══════════════════════════
║ 
║ 🎓 Educational purposes only
║ 🚫 Generated cards are FAKE
║ 🚫 Do NOT use for fraud
║ 🚫 We are NOT responsible
║ 
╚═══════════════════════════`;
      
      await m.reply(menuMsg);
    }
    
    // COMMAND: CCHELP - DETAILED HELP
    else if (command === "cchelp" || command === "helpcc") {
      const helpMsg = `╔═══════════════════════════
║ 📖 *CC BOT - HELP GUIDE*
╠═══════════════════════════
║ 
║ *🎯 GENERATE CARDS*
║ 
║ Generate single card:
║ ${usedPrefix}gen [type]
║ 
║ Types available:
║ • visa - Visa cards
║ • mastercard - Mastercard
║ • amex - American Express
║ • discover - Discover cards
║ • (empty) - Random type
║ 
║ Generate with custom BIN:
║ ${usedPrefix}gen [BIN]
║ ${usedPrefix}gen [BIN] [count]
║ 
║ BIN must be 6-8 digits
║ Auto-detects card type
║ 
║ Generate multiple cards:
║ ${usedPrefix}gen [type] [count]
║ 
║ Examples:
║ • ${usedPrefix}gen visa
║ • ${usedPrefix}gen mastercard 10
║ • ${usedPrefix}gen 400115
║ • ${usedPrefix}gen 411111 5
║ • ${usedPrefix}gen 5 (random 5 cards)
║ 
╠═══════════════════════════
║ *🔍 CHECK CARDS*
║ 
║ Basic check:
║ ${usedPrefix}check [number]
║ 
║ Full check:
║ ${usedPrefix}check [number]|[exp]|[cvv]|[zip]
║ 
║ Supported formats:
║ • 4532123456789012
║ • 4532 1234 5678 9012
║ • 4532-1234-5678-9012
║ • 4532123456789012|12/28|123
║ 
║ Examples:
║ • ${usedPrefix}check 4532123456789012
║ • ${usedPrefix}check 4532 1234 5678 9012
║ • ${usedPrefix}check 4532123456789012|12/28|123
║ 
╠═══════════════════════════
║ *💡 FEATURES*
╠═══════════════════════════
║ 
║ ✅ Luhn algorithm validation
║ ✅ Multiple card type support
║ ✅ Custom BIN support (NEW!)
║ ✅ Auto card type detection
║ ✅ Realistic BIN numbers
║ ✅ Auto-check on generation
║ ✅ Bulk generation (up to 20)
║ ✅ Detailed card information
║ ✅ Multiple format support
║ ✅ Simulation responses
║ 
╠═══════════════════════════
║ *🎯 CUSTOM BIN USAGE*
╠═══════════════════════════
║ 
║ What is BIN?
║ Bank Identification Number
║ First 6-8 digits of card
║ Identifies card issuer
║ 
║ How to use:
║ 1. Find BIN you want
║ 2. Use: ${usedPrefix}gen [BIN]
║ 3. Bot auto-detects type
║ 4. Generates valid card
║ 
║ BIN Examples:
║ • 400115 - Visa
║ • 411111 - Visa
║ • 512345 - Mastercard
║ • 555555 - Mastercard
║ • 371449 - American Express
║ • 378282 - American Express
║ 
╠═══════════════════════════
║ *⚠️ LEGAL DISCLAIMER*
╠═══════════════════════════
║ 
║ 🚫 FOR EDUCATIONAL USE ONLY
║ 
║ This bot generates FAKE credit
║ card numbers for testing and
║ educational purposes ONLY.
║ 
║ 🚫 Do NOT use for:
║ • Real transactions
║ • Fraudulent activities
║ • Identity theft
║ • Any illegal purposes
║ 
║ ⚖️ We are NOT responsible for
║ any misuse of this tool.
║ 
║ 📚 Learn responsibly!
║ 
╠═══════════════════════════
║ *📞 SUPPORT*
╠═══════════════════════════
║ 
║ Type ${usedPrefix}ccmenu for quick reference
║ 
╚═══════════════════════════`;
      
      await m.reply(helpMsg);
    }
    
  } catch (e) {
    console.error('Error:', e);
    m.reply(`❌ An error occurred!\n\nError: ${e.message}\n\nPlease try again or contact support.`);
  }
};

// ===== HANDLER CONFIG =====

handler.help = [
  "gen [type] [count] - Generate CC cards",
  "gen [BIN] [count] - Generate with custom BIN",
  "check [cc|exp|cvv] - Check CC validity",
  "ccmenu - Show all commands",
  "cchelp - Detailed help guide"
];

handler.tags = ["tools"];

handler.command = [
  "gen", "generate", "gencc",
  "check", "checkcc",
  "ccmenu", "menucc",
  "cchelp", "helpcc"
];

handler.group = false;
handler.admin = false;
handler.botAdmin = false;
handler.owner = false;
handler.mods = false;
handler.premium = false;

export default handler;