import fs from 'fs';
import path from 'path';

/**
 * BADWORDS MANAGEMENT PLUGIN
 * Plugin ini bekerja bersama badwords-monitor.js library
 * Fungsi: ON/OFF filter, Add/Remove badwords, List, Stats
 */

// ========== FILE PATHS ==========
const DATA_DIR = './data';
const BADWORDS_FILE = path.join(DATA_DIR, 'badwords.json');
const SETTINGS_FILE = path.join(DATA_DIR, 'badwords_settings.json');
const LOGS_DIR = path.join(DATA_DIR, 'badwords_logs');

// ========== AUTO CREATE DIRECTORIES & FILES ==========
function initializeDataFiles() {
  try {
    // Create data directory
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
      console.log('[Badwords Plugin] ✅ Created directory: ' + DATA_DIR);
    }
    
    // Create logs directory
    if (!fs.existsSync(LOGS_DIR)) {
      fs.mkdirSync(LOGS_DIR, { recursive: true });
      console.log('[Badwords Plugin] ✅ Created directory: ' + LOGS_DIR);
    }
    
    // Create badwords.json if not exists
    if (!fs.existsSync(BADWORDS_FILE)) {
      const DEFAULT_BADWORDS = [
        'anjing', 'asu', 'babi', 'bajingan', 'bangsat', 'brengsek', 'budek',
        'bego', 'bodoh', 'goblok', 'tolol', 'idiot', 'kampret', 'kontol',
        'memek', 'ngentot', 'pepek', 'puki', 'tai', 'taik', 'jancok',
        'kimak', 'monyet', 'bangke', 'perek', 'pelacur', 'sundal', 'lonte',
        'jablay', 'coli', 'colmek', 'ngocok', 'jembut', 'tempik', 'entot',
        'ewe', 'cukimai', 'cukimay', 'ajg', 'bgst', 'njir', 'njing',
        'fuck', 'shit', 'bitch', 'ass', 'asshole', 'bastard', 'damn',
        'dick', 'pussy', 'cock', 'cunt', 'whore', 'slut', 'nigger',
        'nigga', 'faggot', 'retard', 'motherfucker', 'fck', 'fuk',
        'cangcut', 'pekok', 'mbokne', 'matamu', 'cok', 'setan', 'iblis',
        'a n j i n g', 'a s u', 'k o n t o l', 'n g e n t o t', 'b a j i n g a n',
        'anying', 'anjg', 'anjir', 'asyu', 'kntl', 'mmk', 'pqpq',
      ];
      
      const defaultData = {
        words: DEFAULT_BADWORDS,
        lastUpdated: new Date().toISOString(),
        totalWords: DEFAULT_BADWORDS.length,
        createdAt: new Date().toISOString(),
        version: '1.0'
      };
      
      fs.writeFileSync(BADWORDS_FILE, JSON.stringify(defaultData, null, 2));
      console.log(`[Badwords Plugin] ✅ Created ${BADWORDS_FILE} with ${DEFAULT_BADWORDS.length} default words`);
    }
    
    // Create badwords_settings.json if not exists
    if (!fs.existsSync(SETTINGS_FILE)) {
      const defaultSettings = {
        createdAt: new Date().toISOString(),
        version: '1.0',
        groups: {}
      };
      
      fs.writeFileSync(SETTINGS_FILE, JSON.stringify(defaultSettings, null, 2));
      console.log(`[Badwords Plugin] ✅ Created ${SETTINGS_FILE}`);
    }
    
    console.log('[Badwords Plugin] ✅ All data files initialized');
    return true;
    
  } catch (error) {
    console.error('[Badwords Plugin] ❌ Error initializing data files:', error.message);
    return false;
  }
}

// ========== LOAD BADWORDS ==========
function loadBadwords() {
  try {
    initializeDataFiles();
    
    const fileContent = fs.readFileSync(BADWORDS_FILE, 'utf8');
    const data = JSON.parse(fileContent);
    return data.words || [];
  } catch (error) {
    console.error('[Badwords Plugin] Error loading badwords:', error.message);
    return [];
  }
}

// ========== SAVE BADWORDS ==========
function saveBadwords(wordsList) {
  try {
    const data = {
      words: wordsList,
      lastUpdated: new Date().toISOString(),
      totalWords: wordsList.length,
      version: '1.0'
    };
    
    fs.writeFileSync(BADWORDS_FILE, JSON.stringify(data, null, 2));
    console.log(`[Badwords Plugin] ✅ Saved ${wordsList.length} words to database`);
    return true;
  } catch (error) {
    console.error('[Badwords Plugin] Error saving badwords:', error.message);
    return false;
  }
}

// ========== LOAD SETTINGS ==========
function loadSettings(groupId) {
  try {
    initializeDataFiles();
    
    const fileContent = fs.readFileSync(SETTINGS_FILE, 'utf8');
    const data = JSON.parse(fileContent);
    
    if (!data.groups) {
      data.groups = {};
    }
    
    if (!data.groups[groupId]) {
      return { enabled: true }; // Default aktif
    }
    
    return data.groups[groupId];
  } catch (error) {
    console.error('[Badwords Plugin] Error loading settings:', error.message);
    return { enabled: true };
  }
}

// ========== SAVE SETTINGS ==========
function saveSettings(groupId, enabled) {
  try {
    initializeDataFiles();
    
    let data = {
      version: '1.0',
      groups: {}
    };
    
    if (fs.existsSync(SETTINGS_FILE)) {
      const fileContent = fs.readFileSync(SETTINGS_FILE, 'utf8');
      data = JSON.parse(fileContent);
    }
    
    if (!data.groups) {
      data.groups = {};
    }
    
    data.groups[groupId] = {
      enabled,
      lastUpdated: new Date().toISOString()
    };
    
    fs.writeFileSync(SETTINGS_FILE, JSON.stringify(data, null, 2));
    console.log(`[Badwords Plugin] ✅ Settings saved for ${groupId}: ${enabled}`);
    return true;
  } catch (error) {
    console.error('[Badwords Plugin] Error saving settings:', error.message);
    return false;
  }
}

// ========== GET LOGS ==========
function getViolationLogs(groupId, limit = 50) {
  try {
    const logFile = path.join(LOGS_DIR, `${groupId.replace(/[^a-zA-Z0-9]/g, '_')}.json`);
    
    if (!fs.existsSync(logFile)) {
      return [];
    }
    
    const content = fs.readFileSync(logFile, 'utf8');
    const logs = JSON.parse(content);
    
    return logs.slice(0, limit);
  } catch (error) {
    console.error('[Badwords Plugin] Error getting logs:', error.message);
    return [];
  }
}

// ========== CENSOR WORD ==========
function censorWord(word) {
  if (!word || word.length === 0) return word;
  
  const length = word.length;
  
  if (length === 1) return '*';
  if (length === 2) return word[0] + '*';
  if (length === 3) return word[0] + '*' + word[2];
  if (length === 4) return word[0] + '**' + word[3];
  
  const start = word.substring(0, 1);
  const end = word.substring(length - 1);
  const middle = '*'.repeat(length - 2);
  return start + middle + end;
}

// ========== CHECK ADMIN ==========
async function isUserAdmin(conn, chatId, userId) {
  try {
    const groupMetadata = await conn.groupMetadata(chatId);
    const participants = groupMetadata.participants;
    const userParticipant = participants.find(p => p.id === userId);
    
    if (userParticipant) {
      return userParticipant.admin === 'admin' || userParticipant.admin === 'superadmin';
    }
    return false;
  } catch (error) {
    console.error('[Badwords Plugin] Error checking admin:', error.message);
    return false;
  }
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, isAdmin, command, args, usedPrefix }) => {
  try {
    // Initialize files on first run
    initializeDataFiles();
    
    const chatId = m.chat;
    const isGroup = chatId?.endsWith('@g.us');
    
    // Fallback untuk usedPrefix jika undefined
    if (!usedPrefix) {
      usedPrefix = '.';
    }
    
    // Fallback untuk args jika undefined
    if (!args) {
      args = [];
    }
    
    // Cek admin dengan method yang reliable
    let userIsAdmin = false;
    if (isGroup) {
      userIsAdmin = isAdmin || await isUserAdmin(conn, chatId, m.sender);
    }
    
    console.log('[Badwords Plugin] ========== DEBUG ==========');
    console.log('[Badwords Plugin] Command:', command);
    console.log('[Badwords Plugin] Args:', args);
    console.log('[Badwords Plugin] Sender:', m.sender);
    console.log('[Badwords Plugin] Chat:', chatId);
    console.log('[Badwords Plugin] IsGroup:', isGroup);
    console.log('[Badwords Plugin] IsAdmin:', userIsAdmin);
    console.log('[Badwords Plugin] UsedPrefix:', usedPrefix);
    
    // ===== COMMAND: BADWORDS / ANTIBADWORDS =====
    if (command === 'badwords' || command === 'antibadwords') {
      if (!isGroup) {
        return m.reply('❌ Command ini hanya bisa digunakan di grup!');
      }
      
      const action = args[0]?.toLowerCase();
      
      // Show menu if no action
      if (!action || !['on', 'off', 'status'].includes(action)) {
        const currentSettings = loadSettings(chatId);
        const totalWords = loadBadwords().length;
        
        return m.reply(`*🛡️ BADWORDS FILTER*

*Status saat ini:* ${currentSettings.enabled ? '✅ Aktif' : '❌ Nonaktif'}
*Total kata dalam database:* ${totalWords}

*📁 Files:*
• Database: \`${BADWORDS_FILE}\`
• Settings: \`${SETTINGS_FILE}\`
• Logs: \`${LOGS_DIR}/\`

*Perintah Dasar:*
• ${usedPrefix}badwords on - Aktifkan filter
• ${usedPrefix}badwords off - Nonaktifkan filter
• ${usedPrefix}badwords status - Cek status

*Perintah Database:*
• ${usedPrefix}addbadword <kata> - Tambah kata
• ${usedPrefix}delbadword <kata> - Hapus kata
• ${usedPrefix}listbadword [page] - Lihat daftar
• ${usedPrefix}logsbadword [limit] - Lihat log pelanggaran

*Fitur:*
✓ Auto delete pesan badwords
✓ Warning otomatis ke user
✓ Database dinamis (JSON)
✓ Bypass-proof detection
✓ Logging system

*Catatan:* Hanya admin yang bisa mengatur`);
      }
      
      // STATUS
      if (action === 'status') {
        const currentSettings = loadSettings(chatId);
        const totalWords = loadBadwords().length;
        const logs = getViolationLogs(chatId, 10);
        
        let groupName = 'Unknown Group';
        try {
          const metadata = await conn.groupMetadata(chatId);
          groupName = metadata.subject;
        } catch (err) {
          console.error('[Badwords Plugin] Error getting group name:', err.message);
        }
        
        let statusMsg = `*🛡️ STATUS BADWORDS FILTER*\n\n`;
        statusMsg += `*Status:* ${currentSettings.enabled ? '✅ Aktif' : '❌ Nonaktif'}\n`;
        statusMsg += `*Grup:* ${groupName}\n`;
        statusMsg += `*Total kata di database:* ${totalWords}\n`;
        statusMsg += `*Total pelanggaran tercatat:* ${logs.length > 0 ? logs.length + '+' : '0'}\n\n`;
        
        statusMsg += `*📁 Database Files:*\n`;
        statusMsg += `• ${fs.existsSync(BADWORDS_FILE) ? '✅' : '❌'} badwords.json\n`;
        statusMsg += `• ${fs.existsSync(SETTINGS_FILE) ? '✅' : '❌'} badwords_settings.json\n`;
        statusMsg += `• ${fs.existsSync(LOGS_DIR) ? '✅' : '❌'} badwords_logs/\n\n`;
        
        if (currentSettings.enabled) {
          statusMsg += `✓ Filter aktif, pesan dengan badwords akan dihapus otomatis`;
        } else {
          statusMsg += `⚠️ Filter nonaktif, pesan dengan badwords tidak akan difilter`;
        }
        
        return m.reply(statusMsg);
      }
      
      // ON / OFF - NEED ADMIN
      if (!userIsAdmin) {
        return m.reply('❌ Maaf, hanya admin grup yang dapat mengatur fitur badwords.');
      }
      
      if (action === 'on') {
        saveSettings(chatId, true);
        const totalWords = loadBadwords().length;
        
        return m.reply(`✅ *Badwords Filter Diaktifkan*

✓ Filter badwords sekarang aktif
✓ Pesan dengan kata kasar akan dihapus otomatis
✓ User akan diberi peringatan

*Database:* ${totalWords} kata kasar
*Diaktifkan oleh:* @${m.sender.split('@')[0]}

💡 Gunakan ${usedPrefix}listbadword untuk melihat daftar kata`, null, {
          mentions: [m.sender]
        });
      }
      
      if (action === 'off') {
        saveSettings(chatId, false);
        
        return m.reply(`❌ *Badwords Filter Dinonaktifkan*

⚠️ Filter badwords sekarang nonaktif
⚠️ Pesan dengan kata kasar tidak akan dihapus

*Dinonaktifkan oleh:* @${m.sender.split('@')[0]}`, null, {
          mentions: [m.sender]
        });
      }
    }
    
    // ===== COMMAND: ADDBADWORD =====
    if (command === 'addbadword' || command === 'addbad') {
      console.log('[Badwords Plugin] ADDBADWORD command triggered');
      console.log('[Badwords Plugin] Args received:', args);
      
      if (!isGroup) {
        return m.reply('❌ Command ini hanya bisa digunakan di grup!');
      }
      
      if (!userIsAdmin) {
        return m.reply('❌ Maaf, hanya admin grup yang dapat menambah badword.');
      }
      
      // Extract word dari args dengan fallback ke text message
      let word = '';
      
      if (args && args.length > 0) {
        word = args.join(' ').trim().toLowerCase();
      } else if (m.text) {
        // Fallback: extract dari m.text
        const commandPattern = new RegExp(`^[.!#/](addbadword|addbad)\\s+(.+)`, 'i');
        const match = m.text.match(commandPattern);
        if (match && match[2]) {
          word = match[2].trim().toLowerCase();
        }
      }
      
      console.log('[Badwords Plugin] Extracted word:', word);
      
      if (!word || word === '') {
        return m.reply(`*➕ TAMBAH BADWORD*

*Cara penggunaan:*
${usedPrefix}addbadword <kata>

*Contoh:*
${usedPrefix}addbadword kontol
${usedPrefix}addbadword k o n t o l

*Catatan:*
• Kata akan otomatis di-lowercase
• Kata yang sudah ada tidak akan duplikat
• Hanya admin yang bisa menambah`);
      }
      
      const currentWords = loadBadwords();
      
      if (currentWords.includes(word)) {
        return m.reply(`❌ *Gagal Menambahkan Badword*

*Kata:* ${censorWord(word)}
*Alasan:* Kata sudah ada dalam database

Gunakan ${usedPrefix}listbadword untuk melihat daftar`);
      }
      
      currentWords.push(word);
      
      if (saveBadwords(currentWords)) {
        console.log(`[Badwords Plugin] Word added by ${m.sender}: "${word}"`);
        
        return m.reply(`✅ *Badword Berhasil Ditambahkan*

*Kata:* ${censorWord(word)}
*Total kata di database:* ${currentWords.length}
*Ditambahkan oleh:* @${m.sender.split('@')[0]}

Database berhasil diupdate!
File: \`${BADWORDS_FILE}\``, null, {
          mentions: [m.sender]
        });
      } else {
        return m.reply('❌ Gagal menyimpan ke database. Cek console untuk detail error.');
      }
    }
    
    // ===== COMMAND: DELBADWORD =====
    if (command === 'delbadword' || command === 'delbad' || command === 'removebadword') {
      console.log('[Badwords Plugin] DELBADWORD command triggered');
      
      if (!isGroup) {
        return m.reply('❌ Command ini hanya bisa digunakan di grup!');
      }
      
      if (!userIsAdmin) {
        return m.reply('❌ Maaf, hanya admin grup yang dapat menghapus badword.');
      }
      
      // Extract word dari args dengan fallback
      let word = '';
      
      if (args && args.length > 0) {
        word = args.join(' ').trim().toLowerCase();
      } else if (m.text) {
        const commandPattern = new RegExp(`^[.!#/](delbadword|delbad|removebadword)\\s+(.+)`, 'i');
        const match = m.text.match(commandPattern);
        if (match && match[2]) {
          word = match[2].trim().toLowerCase();
        }
      }
      
      console.log('[Badwords Plugin] Word to delete:', word);
      
      if (!word || word === '') {
        return m.reply(`*➖ HAPUS BADWORD*

*Cara penggunaan:*
${usedPrefix}delbadword <kata>

*Contoh:*
${usedPrefix}delbadword kontol

*Catatan:*
• Kata harus persis sama dengan di database
• Gunakan ${usedPrefix}listbadword untuk cek daftar
• Hanya admin yang bisa menghapus`);
      }
      
      const currentWords = loadBadwords();
      const index = currentWords.indexOf(word);
      
      if (index === -1) {
        return m.reply(`❌ *Gagal Menghapus Badword*

*Kata:* ${word}
*Alasan:* Kata tidak ditemukan dalam database

Gunakan ${usedPrefix}listbadword untuk melihat daftar kata yang tersedia.`);
      }
      
      currentWords.splice(index, 1);
      
      if (saveBadwords(currentWords)) {
        console.log(`[Badwords Plugin] Word removed by ${m.sender}: "${word}"`);
        
        return m.reply(`✅ *Badword Berhasil Dihapus*

*Kata:* ${censorWord(word)}
*Total kata di database:* ${currentWords.length}
*Dihapus oleh:* @${m.sender.split('@')[0]}

Database berhasil diupdate!`, null, {
          mentions: [m.sender]
        });
      } else {
        return m.reply('❌ Gagal menyimpan ke database. Cek console untuk detail error.');
      }
    }
    
    // ===== COMMAND: LISTBADWORD =====
    if (command === 'listbadword' || command === 'listbad' || command === 'badwordlist') {
      const page = parseInt(args[0]) || 1;
      const perPage = 20;
      
      const allWords = loadBadwords();
      const totalWords = allWords.length;
      const totalPages = Math.ceil(totalWords / perPage);
      
      if (totalWords === 0) {
        return m.reply('📝 Database badwords kosong!');
      }
      
      const validPage = Math.max(1, Math.min(page, totalPages));
      const startIndex = (validPage - 1) * perPage;
      const endIndex = startIndex + perPage;
      const pageWords = allWords.slice(startIndex, endIndex);
      
      let listText = `*📝 DAFTAR BADWORDS*\n\n`;
      listText += `*Halaman:* ${validPage}/${totalPages}\n`;
      listText += `*Menampilkan:* ${startIndex + 1}-${Math.min(endIndex, totalWords)} dari ${totalWords}\n`;
      listText += `*Database:* \`${BADWORDS_FILE}\`\n\n`;
      listText += `*Kata-kata:*\n`;
      
      pageWords.forEach((word, index) => {
        const number = startIndex + index + 1;
        listText += `${number}. ${censorWord(word)}\n`;
      });
      
      if (totalPages > 1) {
        listText += `\n*Navigasi:*\n`;
        if (validPage > 1) {
          listText += `← ${usedPrefix}listbadword ${validPage - 1}\n`;
        }
        if (validPage < totalPages) {
          listText += `→ ${usedPrefix}listbadword ${validPage + 1}\n`;
        }
      }
      
      listText += `\n*Perintah:*\n`;
      listText += `• ${usedPrefix}addbadword <kata> - Tambah\n`;
      listText += `• ${usedPrefix}delbadword <kata> - Hapus`;
      
      return m.reply(listText);
    }
    
    // ===== COMMAND: LOGS BADWORD =====
    if (command === 'logsbadword' || command === 'badwordlogs') {
      if (!isGroup) {
        return m.reply('❌ Command ini hanya bisa digunakan di grup!');
      }
      
      if (!userIsAdmin) {
        return m.reply('❌ Maaf, hanya admin grup yang dapat melihat logs.');
      }
      
      const limit = parseInt(args[0]) || 10;
      const logs = getViolationLogs(chatId, limit);
      
      if (logs.length === 0) {
        return m.reply(`*📊 LOG PELANGGARAN BADWORDS*

Belum ada pelanggaran tercatat di grup ini.

✅ Grup bersih dari badwords!`);
      }
      
      let logsText = `*📊 LOG PELANGGARAN BADWORDS*\n\n`;
      logsText += `*Total tercatat:* ${logs.length}\n`;
      logsText += `*Menampilkan:* ${Math.min(limit, logs.length)} terakhir\n\n`;
      
      logs.forEach((log, index) => {
        const date = new Date(log.timestamp);
        const timeStr = date.toLocaleString('id-ID', { 
          day: '2-digit', 
          month: '2-digit',
          hour: '2-digit', 
          minute: '2-digit' 
        });
        
        logsText += `*${index + 1}.* ${timeStr}\n`;
        logsText += `   User: @${log.sender.split('@')[0]}\n`;
        logsText += `   Kata: ${log.detectedWords.map(w => censorWord(w)).join(', ')}\n`;
        logsText += `   Preview: "${log.messagePreview.substring(0, 30)}..."\n\n`;
      });
      
      logsText += `*File log:* \`${LOGS_DIR}/${chatId.replace(/[^a-zA-Z0-9]/g, '_')}.json\``;
      
      return m.reply(logsText);
    }
    
  } catch (error) {
    console.error('[Badwords Plugin] ===== ERROR =====');
    console.error('[Badwords Plugin] Command:', command);
    console.error('[Badwords Plugin] Error:', error.message);
    console.error('[Badwords Plugin] Stack:', error.stack);
    return m.reply('❌ Terjadi kesalahan saat menjalankan command. Cek console untuk detail.');
  }
};

// ========== HANDLER CONFIG ==========
handler.help = ['badwords', 'antibadwords', 'addbadword', 'delbadword', 'listbadword', 'logsbadword'];
handler.tags = ['group'];
handler.command = ['badwords', 'antibadwords', 'addbadword', 'addbad', 'delbadword', 'delbad', 'removebadword', 'listbadword', 'listbad', 'badwordlist', 'logsbadword', 'badwordlogs'];
handler.group = true;
handler.admin = false;
handler.limit = false;

export default handler;