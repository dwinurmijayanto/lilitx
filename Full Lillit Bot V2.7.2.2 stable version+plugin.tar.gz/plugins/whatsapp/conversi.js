import fetch from 'node-fetch';
import FormData from 'form-data';
import { downloadContentFromMessage } from 'baileys';
import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const execPromise = promisify(exec);

console.log('[Media Tools Handler] Loading handler...');

// ========== CONFIGURATION ==========
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const TEMP_DIR = path.join(__dirname, '../tmp');
const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB
const TIMEOUT_MS = 60000; // 60 detik

if (!fs.existsSync(TEMP_DIR)) {
    fs.mkdirSync(TEMP_DIR, { recursive: true });
}

// ========== DOWNLOAD MEDIA FUNCTION ==========
async function downloadMedia(message, type = 'image') {
    try {
        const mimeMap = {
            imageMessage: 'image',
            videoMessage: 'video',
            audioMessage: 'audio',
            documentMessage: 'document'
        };

        const msgKeys = Object.keys(message || {});
        if (msgKeys.length === 0) return null;

        const msgType = msgKeys[0];
        if (!msgType) return null;

        const m = message[msgType];
        if (!m) return null;

        const mediaType = mimeMap[msgType];
        if (!mediaType) return null;

        console.log(`[Media Tools] Downloading ${mediaType}...`);
        
        const stream = await downloadContentFromMessage(m, mediaType);
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        
        const buffer = Buffer.concat(chunks);
        console.log(`[Media Tools] Downloaded, size: ${buffer.length} bytes`);
        
        return buffer;
    } catch (error) {
        console.error('[Media Tools] Download error:', error);
        return null;
    }
}

// ========== CONVERSION FUNCTIONS ==========
/**
 * Konversi video ke audio MP3
 */
async function videoToMP3(videoBuffer) {
    const tempVideoPath = path.join(TEMP_DIR, `video_${Date.now()}.mp4`);
    const tempAudioPath = path.join(TEMP_DIR, `audio_${Date.now()}.mp3`);
    
    try {
        if (videoBuffer.length > MAX_FILE_SIZE) {
            throw new Error('File terlalu besar!');
        }
        
        fs.writeFileSync(tempVideoPath, videoBuffer);
        
        const ffmpegCmd = `ffmpeg -i "${tempVideoPath}" -vn -c:a libmp3lame -b:a 192k -ar 44100 "${tempAudioPath}"`;
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Timeout')), TIMEOUT_MS)
        );
        
        await Promise.race([execPromise(ffmpegCmd), timeoutPromise]);
        
        if (!fs.existsSync(tempAudioPath)) {
            throw new Error('Konversi gagal');
        }
        
        const audioBuffer = fs.readFileSync(tempAudioPath);
        
        fs.unlinkSync(tempVideoPath);
        fs.unlinkSync(tempAudioPath);
        
        return { success: true, buffer: audioBuffer, size: audioBuffer.length };
    } catch (error) {
        try {
            if (fs.existsSync(tempVideoPath)) fs.unlinkSync(tempVideoPath);
            if (fs.existsSync(tempAudioPath)) fs.unlinkSync(tempAudioPath);
        } catch (e) {}
        
        return { success: false, message: error.message };
    }
}

/**
 * Konversi voice note ke audio MP3
 */
async function voiceToMP3(audioBuffer) {
    const tempInputPath = path.join(TEMP_DIR, `voice_${Date.now()}.ogg`);
    const tempOutputPath = path.join(TEMP_DIR, `audio_${Date.now()}.mp3`);
    
    try {
        fs.writeFileSync(tempInputPath, audioBuffer);
        
        const ffmpegCmd = `ffmpeg -i "${tempInputPath}" -c:a libmp3lame -b:a 192k -ar 44100 "${tempOutputPath}"`;
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Timeout')), TIMEOUT_MS)
        );
        
        await Promise.race([execPromise(ffmpegCmd), timeoutPromise]);
        
        if (!fs.existsSync(tempOutputPath)) {
            throw new Error('Konversi gagal');
        }
        
        const mp3Buffer = fs.readFileSync(tempOutputPath);
        
        fs.unlinkSync(tempInputPath);
        fs.unlinkSync(tempOutputPath);
        
        return { success: true, buffer: mp3Buffer, size: mp3Buffer.length };
    } catch (error) {
        try {
            if (fs.existsSync(tempInputPath)) fs.unlinkSync(tempInputPath);
            if (fs.existsSync(tempOutputPath)) fs.unlinkSync(tempOutputPath);
        } catch (e) {}
        
        return { success: false, message: error.message };
    }
}

/**
 * Ambil thumbnail dari video
 */
async function getVideoThumbnail(videoBuffer) {
    const tempVideoPath = path.join(TEMP_DIR, `video_${Date.now()}.mp4`);
    const tempThumbPath = path.join(TEMP_DIR, `thumb_${Date.now()}.jpg`);
    
    try {
        fs.writeFileSync(tempVideoPath, videoBuffer);
        
        // Ambil frame di detik ke-1
        const ffmpegCmd = `ffmpeg -i "${tempVideoPath}" -ss 00:00:01 -vframes 1 -q:v 2 "${tempThumbPath}"`;
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Timeout')), TIMEOUT_MS)
        );
        
        await Promise.race([execPromise(ffmpegCmd), timeoutPromise]);
        
        if (!fs.existsSync(tempThumbPath)) {
            throw new Error('Gagal ambil thumbnail');
        }
        
        const thumbBuffer = fs.readFileSync(tempThumbPath);
        
        fs.unlinkSync(tempVideoPath);
        fs.unlinkSync(tempThumbPath);
        
        return { success: true, buffer: thumbBuffer, size: thumbBuffer.length };
    } catch (error) {
        try {
            if (fs.existsSync(tempVideoPath)) fs.unlinkSync(tempVideoPath);
            if (fs.existsSync(tempThumbPath)) fs.unlinkSync(tempThumbPath);
        } catch (e) {}
        
        return { success: false, message: error.message };
    }
}

/**
 * Kompres gambar
 */
async function compressImage(imageBuffer, quality = 75) {
    const tempInputPath = path.join(TEMP_DIR, `image_${Date.now()}.jpg`);
    const tempOutputPath = path.join(TEMP_DIR, `compressed_${Date.now()}.jpg`);
    
    try {
        fs.writeFileSync(tempInputPath, imageBuffer);
        
        const ffmpegCmd = `ffmpeg -i "${tempInputPath}" -q:v ${quality} "${tempOutputPath}"`;
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Timeout')), TIMEOUT_MS)
        );
        
        await Promise.race([execPromise(ffmpegCmd), timeoutPromise]);
        
        if (!fs.existsSync(tempOutputPath)) {
            throw new Error('Kompresi gagal');
        }
        
        const compressedBuffer = fs.readFileSync(tempOutputPath);
        
        fs.unlinkSync(tempInputPath);
        fs.unlinkSync(tempOutputPath);
        
        return { success: true, buffer: compressedBuffer, size: compressedBuffer.length };
    } catch (error) {
        try {
            if (fs.existsSync(tempInputPath)) fs.unlinkSync(tempInputPath);
            if (fs.existsSync(tempOutputPath)) fs.unlinkSync(tempOutputPath);
        } catch (e) {}
        
        return { success: false, message: error.message };
    }
}

/**
 * Konversi gambar ke format lain
 */
async function convertImageFormat(imageBuffer, outputFormat = 'png') {
    const tempInputPath = path.join(TEMP_DIR, `image_${Date.now()}.jpg`);
    const tempOutputPath = path.join(TEMP_DIR, `converted_${Date.now()}.${outputFormat}`);
    
    try {
        fs.writeFileSync(tempInputPath, imageBuffer);
        
        const ffmpegCmd = `ffmpeg -i "${tempInputPath}" "${tempOutputPath}"`;
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Timeout')), TIMEOUT_MS)
        );
        
        await Promise.race([execPromise(ffmpegCmd), timeoutPromise]);
        
        if (!fs.existsSync(tempOutputPath)) {
            throw new Error('Konversi gagal');
        }
        
        const convertedBuffer = fs.readFileSync(tempOutputPath);
        
        fs.unlinkSync(tempInputPath);
        fs.unlinkSync(tempOutputPath);
        
        return { success: true, buffer: convertedBuffer, size: convertedBuffer.length };
    } catch (error) {
        try {
            if (fs.existsSync(tempInputPath)) fs.unlinkSync(tempInputPath);
            if (fs.existsSync(tempOutputPath)) fs.unlinkSync(tempOutputPath);
        } catch (e) {}
        
        return { success: false, message: error.message };
    }
}

// ========== HELPER FUNCTIONS ==========
function formatSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

function generateUsageHelp(prefix, cmd) {
    return `*🛠️ MEDIA TOOLS & CONVERTER*

📌 *Cara Penggunaan:*

*1. Video to MP3:*
Reply video → ${prefix}tomp3

*2. Voice Note to MP3:*
Reply voice note → ${prefix}tomp3

*3. Video Thumbnail:*
Reply video → ${prefix}thumbnail
Alias: ${prefix}thumb

*4. Compress Image:*
Reply gambar → ${prefix}compress
Custom quality: ${prefix}compress 50

*5. Convert Image Format:*
Reply gambar → ${prefix}topng
Reply gambar → ${prefix}tojpg

⚙️ *Fitur:*
• Multi-format converter
• Smart compression
• Auto quality optimization
• Fast processing

⚠️ *Batasan:*
• Max file: ${MAX_FILE_SIZE / 1024 / 1024}MB
• Requires FFmpeg

*Command List:*
${prefix}tomp3, ${prefix}thumbnail, ${prefix}thumb
${prefix}compress, ${prefix}topng, ${prefix}tojpg
`;
}

async function getMediaFromMessage(m) {
    let mediaBuffer = null;
    let mediaType = null;
    let mime = '';
    
    let rawMessage = m.message;
    let contextInfo = null;
    let quotedMessage = null;
    
    if (rawMessage) {
        if (rawMessage.extendedTextMessage) {
            contextInfo = rawMessage.extendedTextMessage.contextInfo;
        } else if (rawMessage.imageMessage) {
            contextInfo = rawMessage.imageMessage.contextInfo;
        } else if (rawMessage.videoMessage) {
            contextInfo = rawMessage.videoMessage.contextInfo;
        } else if (rawMessage.audioMessage) {
            contextInfo = rawMessage.audioMessage.contextInfo;
        }
        
        if (contextInfo) {
            quotedMessage = contextInfo.quotedMessage;
        }
    }
    
    // Check berbagai tipe media
    if (rawMessage?.imageMessage) {
        mediaType = 'image';
        mime = rawMessage.imageMessage.mimetype;
        mediaBuffer = await downloadMedia(rawMessage, 'image');
    } else if (quotedMessage?.imageMessage) {
        mediaType = 'image';
        mime = quotedMessage.imageMessage.mimetype;
        mediaBuffer = await downloadMedia(quotedMessage, 'image');
    } else if (m.quoted?.message?.imageMessage) {
        mediaType = 'image';
        mime = m.quoted.message.imageMessage.mimetype;
        mediaBuffer = await downloadMedia(m.quoted.message, 'image');
    } else if (rawMessage?.videoMessage) {
        mediaType = 'video';
        mime = rawMessage.videoMessage.mimetype;
        mediaBuffer = await downloadMedia(rawMessage, 'video');
    } else if (quotedMessage?.videoMessage) {
        mediaType = 'video';
        mime = quotedMessage.videoMessage.mimetype;
        mediaBuffer = await downloadMedia(quotedMessage, 'video');
    } else if (m.quoted?.message?.videoMessage) {
        mediaType = 'video';
        mime = m.quoted.message.videoMessage.mimetype;
        mediaBuffer = await downloadMedia(m.quoted.message, 'video');
    } else if (rawMessage?.audioMessage) {
        mediaType = 'audio';
        mime = rawMessage.audioMessage.mimetype;
        mediaBuffer = await downloadMedia(rawMessage, 'audio');
    } else if (quotedMessage?.audioMessage) {
        mediaType = 'audio';
        mime = quotedMessage.audioMessage.mimetype;
        mediaBuffer = await downloadMedia(quotedMessage, 'audio');
    } else if (m.quoted?.message?.audioMessage) {
        mediaType = 'audio';
        mime = m.quoted.message.audioMessage.mimetype;
        mediaBuffer = await downloadMedia(m.quoted.message, 'audio');
    }
    
    return { mediaBuffer, mediaType, mime };
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    let prefix = usedPrefix || '.';
    const cmd = command || 'tomp3';
    
    try {
        // Help command
        if (text?.toLowerCase() === 'help' || text === '?') {
            return m.reply(generateUsageHelp(prefix, cmd));
        }
        
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        const { mediaBuffer, mediaType, mime } = await getMediaFromMessage(m);
        
        if (!mediaBuffer || !mediaType) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ Media tidak ditemukan!\n\n💡 Reply gambar/video/audio lalu ketik ${prefix}${cmd}\n📌 Ketik ${prefix}${cmd} help untuk panduan`);
        }
        
        let result;
        let outputType = '';
        
        // ========== ROUTING BERDASARKAN COMMAND ==========
        if (cmd === 'tomp3') {
            if (mediaType === 'video') {
                result = await videoToMP3(mediaBuffer);
                outputType = 'audio';
            } else if (mediaType === 'audio') {
                result = await voiceToMP3(mediaBuffer);
                outputType = 'audio';
            } else {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply('❌ Command ini hanya untuk video atau audio!');
            }
        }
        else if (cmd === 'thumbnail' || cmd === 'thumb') {
            if (mediaType !== 'video') {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply('❌ Command ini hanya untuk video!');
            }
            result = await getVideoThumbnail(mediaBuffer);
            outputType = 'image';
        }
        else if (cmd === 'compress') {
            if (mediaType !== 'image') {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply('❌ Command ini hanya untuk gambar!');
            }
            const quality = parseInt(text) || 75;
            result = await compressImage(mediaBuffer, quality);
            outputType = 'image';
        }
        else if (cmd === 'topng' || cmd === 'tojpg') {
            if (mediaType !== 'image') {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply('❌ Command ini hanya untuk gambar!');
            }
            const format = cmd === 'topng' ? 'png' : 'jpg';
            result = await convertImageFormat(mediaBuffer, format);
            outputType = 'image';
        }
        
        // ========== HANDLE RESULT ==========
        if (!result || !result.success) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            let errorMsg = '❌ Proses gagal!\n\n';
            if (result?.message?.includes('FFmpeg')) {
                errorMsg += '⚠️ FFmpeg tidak tersedia.\n💡 Hubungi admin.';
            } else {
                errorMsg += `⚠️ ${result?.message || 'Unknown error'}`;
            }
            return m.reply(errorMsg);
        }
        
        // ========== SEND RESULT ==========
        const originalSize = formatSize(mediaBuffer.length);
        const resultSize = formatSize(result.size);
        const reduction = ((1 - result.size / mediaBuffer.length) * 100).toFixed(1);
        
        let infoMsg = `✅ *Proses Berhasil!*\n\n` +
                     `📊 *Info:*\n` +
                     `├ 📥 Original: ${originalSize}\n` +
                     `├ 📤 Result: ${resultSize}\n` +
                     `└ 📉 Reduction: ${reduction}%`;
        
        if (outputType === 'audio') {
            await conn.sendMessage(m.chat, {
                audio: result.buffer,
                mimetype: 'audio/mpeg',
                fileName: `audio_${Date.now()}.mp3`
            }, { quoted: m });
        } else if (outputType === 'image') {
            await conn.sendMessage(m.chat, {
                image: result.buffer,
                caption: infoMsg
            }, { quoted: m });
        }
        
        if (outputType === 'audio') {
            await m.reply(infoMsg);
        }
        
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (error) {
        console.error('[Media Tools] ERROR:', error.message);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        return m.reply(`❌ Terjadi kesalahan!\n💡 Ketik ${prefix}${cmd} help`);
    }
};

// ========== HANDLER PROPERTIES ==========
handler.help = [
    "tomp3 (reply video/audio)",
    "thumbnail (reply video)",
    "compress (reply gambar)",
    "topng/tojpg (reply gambar)"
];
handler.tags = ["tools"];
handler.command = [
    "compress",
    "tomp3", "mp3",
    "thumbnail", "thumb",
    "topng", "tojpg"
];
handler.limit = true;

console.log('[Media Tools Handler] Handler loaded successfully');

export default handler;