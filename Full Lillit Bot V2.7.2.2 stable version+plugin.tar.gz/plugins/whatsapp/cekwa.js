// Anti-double activity manager
class AntiDoubleActivity {
    constructor() {
        this.activities = new Map();
    }
    
    checkAndMark(userId, commandName) {
        const key = `${userId}_${commandName}`;
        if (this.activities.has(key)) {
            return false;
        }
        this.activities.set(key, true);
        return true;
    }
    
    markAsComplete(userId, commandName) {
        const key = `${userId}_${commandName}`;
        this.activities.delete(key);
    }
}

const antiDoubleActivity = new AntiDoubleActivity();

/**
 * Extract text dari quoted message (reply)
 * @param {Object} m - Message object
 * @returns {string|null} - Text dari quoted message atau null
 */
function extractQuotedText(m) {
    try {
        let rawMessage = m.message;
        let contextInfo = null;
        let quotedMessage = null;
        
        if (rawMessage) {
            if (rawMessage.extendedTextMessage) {
                contextInfo = rawMessage.extendedTextMessage.contextInfo;
            } else if (rawMessage.imageMessage) {
                contextInfo = rawMessage.imageMessage.contextInfo;
            } else if (rawMessage.videoMessage) {
                contextInfo = rawMessage.videoMessage.contextInfo;
            }
            
            if (contextInfo) {
                quotedMessage = contextInfo.quotedMessage;
            }
        }
        
        if (quotedMessage) {
            if (quotedMessage.conversation) {
                return quotedMessage.conversation;
            } else if (quotedMessage.extendedTextMessage?.text) {
                return quotedMessage.extendedTextMessage.text;
            }
        }
        
        if (m.quoted?.text) {
            return m.quoted.text;
        }
        
        return null;
    } catch (error) {
        console.error('[CekWA Handler] Error extracting quoted text:', error);
        return null;
    }
}

function generateUsageHelp(prefix, cmd) {
    return `*📱 CEK NOMOR WHATSAPP*

📌 *Cara Penggunaan:*

*1. Cek satu nomor:*
${prefix}${cmd} 628123456789

*2. Cek banyak nomor:*
${prefix}${cmd} 628123456789 628987654321
${prefix}${cmd} 628123456789, 628987654321

*3. Reply pesan:*
Reply pesan berisi nomor, lalu: ${prefix}${cmd}

*4. Kirim dengan caption:*
Kirim pesan nomor dengan caption: ${prefix}${cmd}

✨ *Fitur:*
• Cek sampai 50 nomor sekaligus
• Deteksi otomatis format nomor
• Pemisah: spasi atau koma
• Anti-double activity protection

📝 *Format Nomor:*
• 628123456789 (dengan 62)
• 08123456789 (dengan 0)
• 8123456789 (tanpa awalan)

⚠️ *Batasan:*
• Maksimal 50 nomor per request
• Delay otomatis untuk banyak nomor
`;
}

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    const userId = m.sender;
    const commandName = 'cekwa';
    
    // Deteksi prefix
    let prefix = usedPrefix;
    if (!prefix && m.text) {
        const match = m.text.match(/^([.!#/])/);
        prefix = match ? match[1] : '.';
    }
    prefix = prefix || '.';
    
    const cmd = command || 'cekwa';
    
    // Cek apakah pengguna boleh menjalankan perintah ini
    if (!antiDoubleActivity.checkAndMark(userId, commandName)) {
        return m.reply('⚠️ Proses cek nomor sedang berjalan. Mohon tunggu hingga proses selesai.');
    }
    
    try {
        // ========== EXTRACT INPUT ==========
        let inputText = '';
        
        // Prioritas 1: Text/args dari command langsung
        if (text) {
            inputText = text.trim();
        } else if (args && args.length > 0) {
            inputText = args.join(' ').trim();
        }
        
        // Prioritas 2: Text dari quoted message (reply)
        if (!inputText) {
            const quotedText = extractQuotedText(m);
            if (quotedText) {
                inputText = quotedText.trim();
                console.log('[CekWA Handler] Using quoted text:', inputText);
            }
        }
        
        // ========== CEK HELP ==========
        if (inputText && (inputText.toLowerCase() === 'help' || inputText === '?')) {
            antiDoubleActivity.markAsComplete(userId, commandName);
            return m.reply(generateUsageHelp(prefix, cmd));
        }
        
        // ========== VALIDASI INPUT ==========
        if (!inputText) {
            antiDoubleActivity.markAsComplete(userId, commandName);
            return m.reply(`❌ Format salah!\n\n💡 Cara penggunaan:\n${prefix}${cmd} 628123456789\n${prefix}${cmd} 628123456789 628987654321\n\nReply pesan dengan nomor, lalu: ${prefix}${cmd}\n\nAtau ketik: ${prefix}${cmd} help`);
        }
        
        // ========== PROSES CEK NOMOR ==========
        let rawNumbers = inputText.split(/[\s,]+/).filter(n => n);
        
        if (rawNumbers.length > 50) {
            antiDoubleActivity.markAsComplete(userId, commandName);
            return m.reply('❌ Maksimal 50 nomor yang bisa dicek sekaligus!\n\n💡 Pisahkan request menjadi beberapa bagian.');
        }

        let validList = [];
        let invalidList = [];
        let errorList = [];

        // React dengan emoji untuk menunjukkan proses
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        // Send processing notification for large requests
        if (rawNumbers.length > 10) {
            await m.reply(`🔍 Memproses ${rawNumbers.length} nomor. Mohon tunggu...`);
        }

        for (let rawNumber of rawNumbers) {
            let inputNumber = rawNumber.replace(/[^0-9]/g, '');
            let formattedNumber = '';
            
            if (inputNumber.startsWith('62')) {
                formattedNumber = inputNumber;
            } else if (inputNumber.startsWith('0')) {
                formattedNumber = '62' + inputNumber.slice(1);
            } else if (inputNumber.startsWith('8')) {
                formattedNumber = '62' + inputNumber;
            } else {
                formattedNumber = '62' + inputNumber;
            }
            
            if (formattedNumber.length < 10 || formattedNumber.length > 15) {
                errorList.push(formattedNumber);
                continue;
            }
            
            try {
                const res = await conn.onWhatsApp(formattedNumber);
                if (res && res.length > 0) {
                    validList.push(formattedNumber);
                } else {
                    invalidList.push(formattedNumber);
                }
                // Add small delay between API calls to prevent rate limiting
                if (rawNumbers.length > 5) await sleep(100);
            } catch (err) {
                console.error(`[CekWA Handler] Error checking number ${formattedNumber}:`, err);
                errorList.push(formattedNumber);
            }
        }
        
        // ========== FORMAT OUTPUT ==========
        let groupedOutput = [];
        
        if (validList.length > 0) {
            groupedOutput.push(`✅ *Terdaftar di WhatsApp* [${validList.length}]:\n${validList.join('\n')}`);
        }
        if (invalidList.length > 0) {
            groupedOutput.push(`❌ *Tidak terdaftar di WhatsApp* [${invalidList.length}]:\n${invalidList.join('\n')}`);
        }
        if (errorList.length > 0) {
            groupedOutput.push(`⚠️ *Format salah atau gagal dicek* [${errorList.length}]:\n${errorList.join('\n')}`);
        }
        
        if (groupedOutput.length === 0) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply('❌ Tidak ada nomor yang berhasil diproses.\n\n💡 Periksa format nomor Anda.');
        }
        
        // Kirim hasil dalam batch
        const batchSize = 10;
        const maxMessages = 5;
        const totalMessages = Math.min(Math.ceil(groupedOutput.length / batchSize), maxMessages);
        
        for (let i = 0; i < totalMessages; i++) {
            const batchText = groupedOutput.slice(i * batchSize, (i + 1) * batchSize).join('\n\n');
            if (batchText.trim()) {
                await conn.sendMessage(m.chat, {
                    text: batchText
                }, { quoted: m });
                
                if (i < totalMessages - 1) {
                    await sleep(4000); // jeda 4 detik antar pesan
                }
            }
        }
        
        // React dengan checkmark
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (error) {
        console.error('[CekWA Handler] CRITICAL ERROR:', error.message);
        console.error('[CekWA Handler] Stack:', error.stack);
        
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        
        return m.reply(`❌ Terjadi kesalahan saat memproses.\n💡 Coba lagi atau ketik ${prefix}${cmd} help`);
    } finally {
        // Tandai aktivitas sebagai selesai
        antiDoubleActivity.markAsComplete(userId, commandName);
    }
};

handler.help = ["cekwa <nomor>", "cekwa <nomor1> <nomor2> ..."];
handler.tags = ["tools"];
handler.command = ["cekwa", "checkwa", "wacheck"];
handler.limit = true; // Opsional: batasi penggunaan

export default handler;