// =========================================
// FILE: plugins/whatsapp/group-welcome.js
// Plugin untuk semua command welcome/bye
// =========================================

import { 
  loadGroupSettings, 
  saveGroupSettings, 
  loadGroupData,
  formatTimestamp,
  isAdmin,
  DEFAULT_SETTINGS
} from '../../lib/whatsapp/welcome-bye-handler.js';

/**
 * MAIN HANDLER - Welcome/Bye System
 * Satu handler untuk semua command welcome/bye
 */

async function handler(m, { conn, text, command, isAdmin: isAdminCheck, args, usedPrefix }) {
  const groupId = m.chat;
  const sender = m.sender;
  
  // Check if group
  if (!m.isGroup) {
    return m.reply('❌ Command ini hanya bisa digunakan di grup!');
  }
  
  // Ambil text dari quoted message (dengan line break)
  let fullText = '';
  
  if (m.quoted) {
    // Ambil text dari quoted message
    fullText = m.quoted.text || '';
  } else if (args.length > 0) {
    // Ambil dari args
    fullText = args.join(' ').trim();
  }
  
  // Get admin status
  const isAdminUser = isAdminCheck || await isAdmin(conn, groupId, sender);
  
  // Commands yang butuh admin
  const adminCommands = [
    'welcomeon', 'welkon',
    'welcomeoff', 'welkoff',
    'welcometext', 'setwelcome', 'welktext',
    'welcomevideo', 'welkvideo', 'setwelcomevideo',
    'welcomereset', 'resetwelcome', 'welkreset',
    'byeon',
    'byeoff',
    'byetext', 'setbye',
    'byereset', 'resetbye'
  ];
  
  if (adminCommands.includes(command) && !isAdminUser) {
    return m.reply('❌ Hanya admin yang bisa menggunakan command ini!');
  }
  
  const settings = loadGroupSettings(groupId);
  
  // ========== WELCOME IMPORT (NEW) ==========
  
  if (command === 'welcomeimport' || command === 'importwelcome') {
    // Ambil dari document/file yang di-upload
    if (m.quoted && m.quoted.mtype === 'documentMessage') {
      try {
        const buffer = await m.quoted.download();
        const textContent = buffer.toString('utf8');
        
        settings.welcome.message = textContent;
        saveGroupSettings(groupId, settings);
        
        return m.reply(`✅ Welcome text berhasil diimport dari file!

Preview (100 karakter pertama):
${textContent.substring(0, 100)}...

Total karakter: ${textContent.length}
Gunakan .welcomestatus untuk melihat preview lengkap`);
      } catch (err) {
        return m.reply('❌ Gagal membaca file! Pastikan file adalah text (.txt)');
      }
    }
    
    // Atau dari quoted text message
    if (m.quoted && m.quoted.text) {
      const textContent = m.quoted.text;
      
      settings.welcome.message = textContent;
      saveGroupSettings(groupId, settings);
      
      return m.reply(`✅ Welcome text berhasil diimport!

Preview:
${textContent}

Gunakan .welcomestatus untuk verifikasi`);
    }
    
    return m.reply(`❌ Reply ke pesan text atau file .txt dengan command ini!

*Cara 1 - Reply text message:*
1. Ketik/paste text welcome dengan format yang diinginkan
2. Kirim ke grup
3. Reply text tersebut: ${usedPrefix}welcomeimport

*Cara 2 - Upload file .txt:*
1. Buat file welcome.txt dengan format yang diinginkan
2. Upload ke grup
3. Reply file: ${usedPrefix}welcomeimport`);
  }
  
  // ========== WELCOME COMMANDS ==========
  
  if (command === 'welcomeon' || command === 'welkon') {
    settings.welcome.enabled = true;
    saveGroupSettings(groupId, settings);
    return m.reply('✅ Welcome message berhasil diaktifkan!');
  }
  
  if (command === 'welcomeoff' || command === 'welkoff') {
    settings.welcome.enabled = false;
    saveGroupSettings(groupId, settings);
    return m.reply('❌ Welcome message berhasil dinonaktifkan!');
  }
  
  if (command === 'welcometext' || command === 'setwelcome' || command === 'welktext') {
    if (!fullText) {
      return m.reply(`❌ Masukkan text welcome!

*Cara 1 - Reply message:*
1. Ketik text welcome dengan format yang diinginkan
2. Reply text tersebut dengan command: ${usedPrefix}welcometext

*Cara 2 - Langsung ketik:*
${usedPrefix}welcometext Halo @userName, selamat datang!

*Variabel yang bisa digunakan:*
• @userName - Mention user
• @group - Nama grup
• @count - Total member yang join

*Tips:* Gunakan metode reply untuk mempertahankan format baris baru!`);
    }
    
    settings.welcome.message = fullText;
    
    // Escape untuk JSON save
    if (saveGroupSettings(groupId, settings)) {
      return m.reply(`✅ Welcome text berhasil diubah!

Preview:
${fullText}`);
    } else {
      return m.reply('❌ Gagal menyimpan settings!');
    }
  }
  
  if (command === 'welcomevideo' || command === 'welkvideo' || command === 'setwelcomevideo') {
    if (!fullText || fullText.toLowerCase() === 'off') {
      settings.welcome.sendVideo = false;
      saveGroupSettings(groupId, settings);
      return m.reply('❌ Welcome video berhasil dinonaktifkan!');
    }
    
    if (!fullText.startsWith('http')) {
      return m.reply(`❌ Masukkan URL video yang valid!

*Contoh:*
${usedPrefix}welcomevideo https://example.com/video.mp4

Atau matikan video:
${usedPrefix}welcomevideo off`);
    }
    
    settings.welcome.videoUrl = fullText;
    settings.welcome.sendVideo = true;
    saveGroupSettings(groupId, settings);
    return m.reply(`✅ Welcome video berhasil diset!

URL: ${fullText}`);
  }
  
  if (command === 'welcomestatus' || command === 'welkstatus' || command === 'cekwelcome') {
    const status = `╭─「 *WELCOME SETTINGS* 」
│ 
│ *Status:* ${settings.welcome.enabled ? '✅ Aktif' : '❌ Nonaktif'}
│ *Video:* ${settings.welcome.sendVideo ? '✅ Aktif' : '❌ Nonaktif'}
│ *Video URL:* ${settings.welcome.videoUrl || 'Tidak diset'}
│
│ *Message Preview:*
│ ${settings.welcome.message.substring(0, 150)}${settings.welcome.message.length > 150 ? '...' : ''}
│
╰────────────────

*Commands:*
• .welcomeon - Aktifkan welcome
• .welcomeoff - Nonaktifkan welcome
• .welcometext <text> - Set welcome text
• .welcomevideo <url> - Set video
• .welcomevideo off - Matikan video
• .welcomereset - Reset settings`;
    
    return m.reply(status);
  }
  
  if (command === 'welcomereset' || command === 'resetwelcome' || command === 'welkreset') {
    settings.welcome = JSON.parse(JSON.stringify(DEFAULT_SETTINGS.welcome));
    saveGroupSettings(groupId, settings);
    return m.reply('✅ Welcome settings berhasil direset ke default!');
  }
  
  // ========== BYE IMPORT (NEW) ==========
  
  if (command === 'byeimport' || command === 'importbye') {
    // Ambil dari document/file yang di-upload
    if (m.quoted && m.quoted.mtype === 'documentMessage') {
      try {
        const buffer = await m.quoted.download();
        const textContent = buffer.toString('utf8');
        
        settings.bye.message = textContent;
        saveGroupSettings(groupId, settings);
        
        return m.reply(`✅ Bye text berhasil diimport dari file!

Preview:
${textContent}`);
      } catch (err) {
        return m.reply('❌ Gagal membaca file! Pastikan file adalah text (.txt)');
      }
    }
    
    // Atau dari quoted text message
    if (m.quoted && m.quoted.text) {
      const textContent = m.quoted.text;
      
      settings.bye.message = textContent;
      saveGroupSettings(groupId, settings);
      
      return m.reply(`✅ Bye text berhasil diimport!

Preview:
${textContent}`);
    }
    
    return m.reply(`❌ Reply ke pesan text atau file .txt dengan command ini!

*Cara:*
1. Ketik/paste text bye
2. Kirim ke grup
3. Reply: ${usedPrefix}byeimport`);
  }
  
  // ========== BYE COMMANDS ==========
  
  if (command === 'byeon') {
    settings.bye.enabled = true;
    saveGroupSettings(groupId, settings);
    return m.reply('✅ Bye message berhasil diaktifkan!');
  }
  
  if (command === 'byeoff') {
    settings.bye.enabled = false;
    saveGroupSettings(groupId, settings);
    return m.reply('❌ Bye message berhasil dinonaktifkan!');
  }
  
  if (command === 'byetext' || command === 'setbye') {
    if (!fullText) {
      return m.reply(`❌ Masukkan text bye!

*Cara 1 - Reply message:*
1. Ketik text bye dengan format yang diinginkan
2. Reply text tersebut dengan command: ${usedPrefix}byetext

*Cara 2 - Langsung ketik:*
${usedPrefix}byetext Selamat tinggal @userName!

*Variabel yang bisa digunakan:*
• @userName - Mention user
• @group - Nama grup
• @count - Total member yang keluar`);
    }
    
    settings.bye.message = fullText;
    saveGroupSettings(groupId, settings);
    return m.reply(`✅ Bye text berhasil diubah!

Preview:
${fullText}`);
  }
  
  if (command === 'byestatus' || command === 'cekbye') {
    const status = `╭─「 *BYE SETTINGS* 」
│ 
│ *Status:* ${settings.bye.enabled ? '✅ Aktif' : '❌ Nonaktif'}
│
│ *Message Preview:*
│ ${settings.bye.message.substring(0, 150)}${settings.bye.message.length > 150 ? '...' : ''}
│
╰────────────────

*Commands:*
• .byeon - Aktifkan bye
• .byeoff - Nonaktifkan bye
• .byetext <text> - Set bye text
• .byereset - Reset settings`;
    
    return m.reply(status);
  }
  
  if (command === 'byereset' || command === 'resetbye') {
    settings.bye = JSON.parse(JSON.stringify(DEFAULT_SETTINGS.bye));
    saveGroupSettings(groupId, settings);
    return m.reply('✅ Bye settings berhasil direset ke default!');
  }
  
  // ========== STATS COMMAND ==========
  
  if (command === 'groupstats' || command === 'gstats' || command === 'statsgrup') {
    const groupData = loadGroupData(groupId);
    const recentEvents = groupData.events.slice(0, 10);
    
    let eventsList = '';
    for (const event of recentEvents) {
      const icon = event.type === 'join' ? '➕' : '➖';
      eventsList += `${icon} *${event.participantName}* (${event.type})\n   _${event.formattedTime}_\n\n`;
    }
    
    const stats = `╭─「 *GROUP STATISTICS* 」
│ 
│ *Total Join:* ${groupData.stats.totalJoins}
│ *Total Leave:* ${groupData.stats.totalLeaves}
│ *Net Change:* ${groupData.stats.totalJoins - groupData.stats.totalLeaves}
│
│ *Last Update:*
│ ${formatTimestamp(groupData.stats.lastUpdate)}
│
╰────────────────

*Recent Events (10 terakhir):*

${eventsList || '_Belum ada event_'}`;
    
    return m.reply(stats);
  }
}

// Handler config
handler.help = [
  "welcomeon - Aktifkan welcome message",
  "welcomeoff - Nonaktifkan welcome message",
  "welcometext <text> - Set custom welcome text",
  "welcomeimport - Import welcome dari text/file (reply)",
  "welcomevideo <url|off> - Set/matikan welcome video",
  "welcomestatus - Cek status welcome settings",
  "welcomereset - Reset welcome ke default",
  "byeon - Aktifkan bye message",
  "byeoff - Nonaktifkan bye message",
  "byetext <text> - Set custom bye text",
  "byeimport - Import bye dari text/file (reply)",
  "byestatus - Cek status bye settings",
  "byereset - Reset bye ke default",
  "groupstats - Lihat statistik grup"
];

handler.tags = ["group"];

handler.command = [
  // Welcome commands
  "welcomeon", "welkon",
  "welcomeoff", "welkoff",
  "welcometext", "setwelcome", "welktext",
  "welcomeimport", "importwelcome",
  "welcomevideo", "welkvideo", "setwelcomevideo",
  "welcomestatus", "welkstatus", "cekwelcome",
  "welcomereset", "resetwelcome", "welkreset",
  // Bye commands
  "byeon",
  "byeoff",
  "byetext", "setbye",
  "byeimport", "importbye",
  "byestatus", "cekbye",
  "byereset", "resetbye",
  // Stats
  "groupstats", "gstats", "statsgrup"
];

handler.group = true;

export default handler;


// =========================================
// CARA PENGGUNAAN
// =========================================

/*

WELCOME COMMANDS:
─────────────────
.welcomeon              → Aktifkan welcome
.welcomeoff             → Nonaktifkan welcome
.welcometext <text>     → Set custom text
.welcomevideo <url>     → Set video URL
.welcomevideo off       → Matikan video
.welcomestatus          → Cek status
.welcomereset           → Reset ke default

BYE COMMANDS:
─────────────────
.byeon                  → Aktifkan bye
.byeoff                 → Nonaktifkan bye
.byetext <text>         → Set custom text
.byestatus              → Cek status
.byereset               → Reset ke default

STATS:
─────────────────
.groupstats             → Lihat statistik grup

VARIABEL TEXT:
─────────────────
@userName               → Mention user (otomatis)
@group                  → Nama grup
@count                  → Total join/leave count

CONTOH:
─────────────────
.welcometext Halo @userName! Selamat datang di @group 🎉
.byetext Dadah @userName, semoga sukses! 👋
.welcomevideo https://example.com/video.mp4

*/