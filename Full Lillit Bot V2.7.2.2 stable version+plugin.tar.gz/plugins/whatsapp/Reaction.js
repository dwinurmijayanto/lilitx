import fetch from 'node-fetch';

// ========== API CONFIGURATION ==========
const API_CONFIG = {
    // Shared API Keys untuk NEW API
    // https://asitha.top/login?ref=almirasa5041
    sharedApiKeys: [
        'a6c2b6b9704207dff96fdb34a68cebee5d438086042eba1716ccc3b4f52917d6',  
        '5bd11757ce5d52f8d37ef7c72bf3dc37559fdb06d5c1aa0df7b4fcd2d7f59123',     
        'd16501757a04a0b7270bee2d374b50122a1df52dda402f7979d63e6b60ef037e',
        '680a79f94fbf200175142b7f1a99cfe31d9470188653cfa87fa0b5e66bcdcbcc',
        '2073d424b09ff2883d58cab9c4bb52b86302a9c4a689c1bf4fd760de406d10c7', 
		'b62c232e846ab8398fa8bed91949b2876c53c11a704995a71b92700d8924433d', // hasanrank1
		'f7dade470f57f455298ddd97db1574a683be894df91983823f51210183bb123f', // hasinrank1
		'fa010af41cd7fdcd8372318e6bdc72a010f26e8063c5ebee960a0489b45ef37f', // amandarank1
        '827d05bdd80afe5c9175692bf8eddbf41873e0f5dd4949a75c65afab10160662' // gut1may@ranking.my.id (@Girilaya1)
    ],
    
    // NEW API
    newApi: {
        baseUrl: 'https://react.whyux-xec.my.id/api/rch',
        timeout: 15000
    },
    
    // Bulk config
    bulkMinDelay: 3000,  // 3 detik
    bulkMaxDelay: 7000,  // 7 detik
    defaultEmoji: '👍'
};

// ========== API KEY MANAGER ==========
const API_KEY_MANAGER = {
    // Tambah API key baru
    addKey(apiKey, label = '') {
        if (!apiKey || typeof apiKey !== 'string') {
            return { success: false, message: 'API key tidak valid' };
        }
        
        const cleanKey = apiKey.trim();
        
        if (cleanKey.length < 20) {
            return { success: false, message: 'API key terlalu pendek' };
        }
        
        if (API_CONFIG.sharedApiKeys.includes(cleanKey)) {
            return { success: false, message: 'API key sudah ada dalam list' };
        }
        
        API_CONFIG.sharedApiKeys.push(cleanKey);
        
        return {
            success: true,
            message: `API key berhasil ditambahkan${label ? ` (${label})` : ''}`,
            totalKeys: API_CONFIG.sharedApiKeys.length
        };
    },
    
    // Hapus API key
    removeKey(index) {
        if (index < 1 || index > API_CONFIG.sharedApiKeys.length) {
            return { success: false, message: 'Index tidak valid' };
        }
        
        const removed = API_CONFIG.sharedApiKeys.splice(index - 1, 1);
        
        return {
            success: true,
            message: `API key #${index} berhasil dihapus`,
            removedKey: removed[0].substring(0, 10) + '...',
            totalKeys: API_CONFIG.sharedApiKeys.length
        };
    },
    
    // List semua API keys
    listKeys() {
        return API_CONFIG.sharedApiKeys.map((key, index) => ({
            index: index + 1,
            preview: key.substring(0, 10) + '...' + key.substring(key.length - 6),
            length: key.length
        }));
    },
    
    // Get total API keys
    getTotalKeys() {
        return API_CONFIG.sharedApiKeys.length;
    }
};

// ========== COOLDOWN MANAGER ==========
const API_COOLDOWN = {
    cooldowns: new Map(),
    duration: 3000,
    
    isOnCooldown(userId) {
        const cooldownUntil = this.cooldowns.get(userId);
        if (!cooldownUntil) return false;
        
        if (Date.now() < cooldownUntil) {
            const remaining = Math.ceil((cooldownUntil - Date.now()) / 1000);
            return remaining;
        }
        
        this.cooldowns.delete(userId);
        return false;
    },
    
    setCooldown(userId) {
        this.cooldowns.set(userId, Date.now() + this.duration);
    }
};

// ========== HELPER FUNCTIONS ==========

function isValidWhatsAppChannelUrl(url) {
    const patterns = [
        /^(https?:\/\/)?(www\.)?whatsapp\.com\/channel\//,
        /^whatsapp\.com\/channel\//
    ];
    return patterns.some(p => p.test(url));
}

function normalizeChannelUrl(url) {
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
        url = 'https://' + url;
    }
    return url;
}

function extractChannelInfo(url) {
    try {
        const match = url.match(/channel\/([^\/]+)\/(\d+)/);
        if (match) {
            return {
                channelId: match[1],
                messageId: match[2],
                fullUrl: url
            };
        }
        return null;
    } catch (error) {
        console.error('Error extracting channel info:', error.message);
        return null;
    }
}

function isValidEmoji(text) {
    const emojiRegex = /[\p{Emoji_Presentation}\p{Extended_Pictographic}]/gu;
    return emojiRegex.test(text);
}

function getEmojiList() {
    return [
        '👍', '❤️', '😂', '😮', '😢', '🙏',
        '👏', '🔥', '🎉', '💯', '⭐', '✨',
        '💪', '🤝', '🤔', '😍', '🥰', '😊',
        '🎊', '🎈', '🌟', '💝', '💖', '💗',
        '🦄', '🩷', '🌼', '🤍'
    ];
}

function getRandomEmoji() {
    const list = getEmojiList();
    return list[Math.floor(Math.random() * list.length)];
}

function getRandomDelay() {
    const { bulkMinDelay, bulkMaxDelay } = API_CONFIG;
    return Math.floor(Math.random() * (bulkMaxDelay - bulkMinDelay + 1)) + bulkMinDelay;
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// ========== NEW API ==========

async function sendReactionViaNewApi(channelUrl, emoji) {
    const normalizedUrl = normalizeChannelUrl(channelUrl);
    
    if (!isValidWhatsAppChannelUrl(normalizedUrl)) {
        return { success: false, message: 'URL channel WhatsApp tidak valid' };
    }
    
    const channelInfo = extractChannelInfo(normalizedUrl);
    if (!channelInfo) {
        return { success: false, message: 'Tidak dapat mengekstrak informasi channel' };
    }
    
    const apiKeys = API_CONFIG.sharedApiKeys;
    let lastError = null;
    
    // Coba setiap API key secara berurutan
    for (let i = 0; i < apiKeys.length; i++) {
        const apiKey = apiKeys[i];
        const keyLabel = `Key ${i + 1}/${apiKeys.length}`;
        
        console.log(`[NEW API] Mencoba ${keyLabel}...`);
        
        try {
            const encodedUrl = encodeURIComponent(normalizedUrl);
            const encodedEmoji = encodeURIComponent(emoji);
            const apiUrl = `${API_CONFIG.newApi.baseUrl}?link=${encodedUrl}&emoji=${encodedEmoji}`;
            
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), API_CONFIG.newApi.timeout);
            
            const response = await fetch(apiUrl, {
                method: 'GET',
                headers: {
                    'x-api-key': apiKey,
                    'Accept': 'application/json',
                    'User-Agent': 'Mozilla/5.0'
                },
                signal: controller.signal
            });
            
            clearTimeout(timeoutId);
            
            // Jika status OK, coba parse response
            if (response.ok) {
                const data = await response.json();
                
                // Cek berbagai format success response
                if (data.success === true || data.status === 'success' || data.status === true) {
                    console.log(`[NEW API] ✓ Berhasil dengan ${keyLabel}`);
                    return {
                        success: true,
                        message: data.message || 'Reaction berhasil dikirim ^_^',
                        channelUrl: normalizedUrl,
                        emoji: emoji,
                        channelId: channelInfo.channelId,
                        messageId: channelInfo.messageId,
                        api: 'NEW',
                        apiKeyUsed: keyLabel,
                        rawResponse: data
                    };
                }
                
                // Response OK tapi status tidak success
                lastError = data.message || data.error || 'Status tidak success';
                console.log(`[NEW API] ✗ ${keyLabel} gagal: ${lastError}`);
                
            } else {
                // HTTP error
                lastError = `HTTP ${response.status}`;
                console.log(`[NEW API] ✗ ${keyLabel} HTTP error: ${response.status}`);
                
                // Jika unauthorized (401/403), kemungkinan API key invalid, coba key berikutnya
                if (response.status === 401 || response.status === 403) {
                    console.log(`[NEW API] ${keyLabel} unauthorized, mencoba key berikutnya...`);
                    continue;
                }
            }
            
        } catch (error) {
            if (error.name === 'AbortError') {
                lastError = 'Timeout';
                console.log(`[NEW API] ✗ ${keyLabel} timeout`);
            } else {
                lastError = error.message;
                console.log(`[NEW API] ✗ ${keyLabel} error: ${error.message}`);
            }
        }
        
        // Delay kecil sebelum mencoba key berikutnya (kecuali key terakhir)
        if (i < apiKeys.length - 1) {
            await sleep(500);
        }
    }
    
    // Semua API key gagal
    return { 
        success: false, 
        message: `NEW API gagal dengan semua ${apiKeys.length} API keys. Last error: ${lastError}`,
        api: 'NEW'
    };
}

// ========== BULK REACTION ==========

async function sendBulkReaction(channelUrls, emoji = null) {
    try {
        console.log('\n=== BULK REACTION ===');
        console.log(`Jumlah URL: ${channelUrls.length}`);
        console.log(`Emoji: ${emoji || 'Random'}`);
        
        const results = {
            total: channelUrls.length,
            success: 0,
            failed: 0,
            details: []
        };
        
        for (let i = 0; i < channelUrls.length; i++) {
            const url = channelUrls[i].trim();
            if (!url) continue;
            
            const selectedEmoji = emoji || getRandomEmoji();
            
            console.log(`\n[${i + 1}/${channelUrls.length}] Processing: ${url}`);
            console.log(`Emoji: ${selectedEmoji}`);
            
            const result = await sendReactionViaNewApi(url, selectedEmoji);
            
            if (result.success) {
                results.success++;
                results.details.push({
                    index: i + 1,
                    url: url,
                    emoji: selectedEmoji,
                    status: 'success',
                    api: result.api,
                    channelId: result.channelId,
                    messageId: result.messageId
                });
                console.log(`✓ Berhasil via ${result.api}: ${url}`);
            } else {
                results.failed++;
                results.details.push({
                    index: i + 1,
                    url: url,
                    emoji: selectedEmoji,
                    status: 'failed',
                    error: result.message
                });
                console.log(`✗ Gagal: ${url}`);
            }
            
            // Delay sebelum URL berikutnya
            if (i < channelUrls.length - 1) {
                const delay = getRandomDelay();
                console.log(`Menunggu ${delay / 1000} detik...`);
                await sleep(delay);
            }
        }
        
        console.log('\n=== BULK REACTION SELESAI ===');
        console.log(`Sukses: ${results.success}/${results.total}`);
        console.log(`Gagal: ${results.failed}/${results.total}`);
        
        return results;
        
    } catch (error) {
        console.error('Error in bulk reaction:', error.message);
        return {
            total: channelUrls.length,
            success: 0,
            failed: channelUrls.length,
            details: [],
            error: error.message
        };
    }
}

// ========== COMMAND HANDLER ==========

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    const input = args && args.length > 0 ? args.join(' ').trim() : '';
    
    // ========== API KEY MANAGEMENT ==========
    
    // List API Keys
    if (input.toLowerCase() === 'listkey' || input.toLowerCase() === 'listkeys') {
        const keys = API_KEY_MANAGER.listKeys();
        
        let listText = `*🔑 API Keys Management*\n\n`;
        listText += `*Total Keys:* ${keys.length}\n\n`;
        
        keys.forEach(key => {
            listText += `*${key.index}.* ${key.preview}\n`;
        });
        
        listText += `\n*Commands:*\n`;
        listText += `• ${usedPrefix}${command} addkey <api_key> <label>\n`;
        listText += `• ${usedPrefix}${command} removekey <index>\n`;
        listText += `• ${usedPrefix}${command} listkey`;
        
        return m.reply(listText);
    }
    
    // Add API Key
    if (input.toLowerCase().startsWith('addkey')) {
        const addMatch = input.match(/^addkey\s+(\S+)(?:\s+(.+))?$/i);
        
        if (!addMatch) {
            return m.reply(`❌ Format tidak valid!

*Format:*
${usedPrefix}${command} addkey <api_key> <label>

*Contoh:*
${usedPrefix}${command} addkey abc123def456... MyKey
${usedPrefix}${command} addkey abc123def456...`);
        }
        
        const apiKey = addMatch[1];
        const label = addMatch[2] || '';
        
        const result = API_KEY_MANAGER.addKey(apiKey, label);
        
        if (result.success) {
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            return m.reply(`✅ ${result.message}\n\n*Total API Keys:* ${result.totalKeys}`);
        } else {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ ${result.message}`);
        }
    }
    
    // Remove API Key
    if (input.toLowerCase().startsWith('removekey')) {
        const removeMatch = input.match(/^removekey\s+(\d+)$/i);
        
        if (!removeMatch) {
            return m.reply(`❌ Format tidak valid!

*Format:*
${usedPrefix}${command} removekey <index>

*Contoh:*
${usedPrefix}${command} removekey 5

*Gunakan ${usedPrefix}${command} listkey untuk melihat index*`);
        }
        
        const index = parseInt(removeMatch[1]);
        const result = API_KEY_MANAGER.removeKey(index);
        
        if (result.success) {
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            return m.reply(`✅ ${result.message}\n\n*Key:* ${result.removedKey}\n*Total API Keys:* ${result.totalKeys}`);
        } else {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ ${result.message}`);
        }
    }
    
    // ========== NORMAL COMMANDS ==========
    
    // Cek cooldown
    const cooldownRemaining = API_COOLDOWN.isOnCooldown(m.sender);
    if (cooldownRemaining) {
        return m.reply(`⏳ Tunggu ${cooldownRemaining} detik sebelum menggunakan command ini lagi.`);
    }
    
    if (!input) {
        let prefix = usedPrefix || '.';
        const cmd = command || 'react';
        const emojiList = getEmojiList();
        
        return m.reply(`*🚀 WhatsApp Channel Reaction Bot - NEW API*

Bot ini menggunakan NEW API dengan sistem multi API keys!

*📍 Format Penggunaan:*

*Single Reaction:*
${prefix}${cmd} <url> <emoji>
${prefix}${cmd} <url> random

*Bulk Reaction:*
${prefix}${cmd} bulk <emoji> <url1>, <url2>, <url3>
${prefix}${cmd} bulk random <url1>, <url2>

*📝 Contoh:*
${prefix}${cmd} https://whatsapp.com/channel/xxx/109 ❤️
${prefix}${cmd} https://whatsapp.com/channel/xxx/109 random
${prefix}${cmd} bulk random <url1>, <url2>, <url3>
${prefix}${cmd} bulk 🦄 <url1>, <url2>
${prefix}${cmd} addkey abc123def... MyNewKey

*🎨 Emoji Populer:*
${emojiList.join(' ')}

*⚙️ Fitur:*
- Multi API Keys (${API_KEY_MANAGER.getTotalKeys()} keys aktif)
- Auto fallback antar keys
- Random emoji support
- Bulk reaction (max 20 URL)
- Dynamic API key management

*ℹ️ Info:*
- Delay bulk: 3-7 detik per URL
- Cooldown: 3 detik per user
- Max bulk: 20 URL
- API: NEW ( https://asitha.top/login?ref=almirasa5041 )`);
    }
    
    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    // ========== BULK MODE ==========
    if (input.toLowerCase().startsWith('bulk')) {
        console.log('Mode: BULK REACTION');
        
        // Parse: bulk <emoji/random> <url1>, <url2>
        const bulkMatch = input.match(/^bulk\s+(\S+)\s+(.+)$/i);
        
        if (!bulkMatch) {
            return m.reply(`❌ Format bulk tidak valid!

*Format yang benar:*
${usedPrefix}${command} bulk <emoji> <url1>, <url2>
${usedPrefix}${command} bulk random <url1>, <url2>`);
        }
        
        const emojiPart = bulkMatch[1].trim();
        const urlsPart = bulkMatch[2].trim();
        
        let emoji = null;
        if (emojiPart.toLowerCase() === 'random' || emojiPart.toLowerCase() === 'acak') {
            emoji = null;
        } else if (isValidEmoji(emojiPart)) {
            emoji = emojiPart;
        } else {
            return m.reply(`❌ Emoji tidak valid: ${emojiPart}`);
        }
        
        const urlCandidates = urlsPart.split(',').map(u => u.trim()).filter(u => u);
        const urls = [];
        
        for (const urlCandidate of urlCandidates) {
            const normalized = normalizeChannelUrl(urlCandidate);
            if (isValidWhatsAppChannelUrl(normalized)) {
                urls.push(normalized);
            }
        }
        
        if (urls.length === 0) {
            return m.reply('❌ Tidak ada URL channel yang valid!');
        }
        
        if (urls.length > 20) {
            return m.reply('❌ Maksimal 20 URL per bulk reaction.');
        }
        
        const minTime = Math.ceil((urls.length * API_CONFIG.bulkMinDelay) / 1000);
        const maxTime = Math.ceil((urls.length * API_CONFIG.bulkMaxDelay) / 1000);
        
        let confirmText = `*🔄 Bulk Reaction Mode*\n\n`;
        confirmText += `*Jumlah URL:* ${urls.length}\n`;
        confirmText += `*API:* NEW API (${API_KEY_MANAGER.getTotalKeys()} keys)\n`;
        confirmText += `*Emoji:* ${emoji || 'Random 🎲'}\n`;
        confirmText += `*Estimasi Waktu:* ${minTime}-${maxTime} detik\n\n`;
        confirmText += `⏳ Memulai proses...`;
        
        await m.reply(confirmText);
        await conn.sendMessage(m.chat, { react: { text: '🔄', key: m.key } });
        
        try {
            const bulkResults = await sendBulkReaction(urls, emoji);
            
            if (bulkResults.error) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ Bulk reaction gagal: ${bulkResults.error}`);
            }
            
            API_COOLDOWN.setCooldown(m.sender);
            
            if (bulkResults.success > 0) {
                await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                
                let resultText = `*✅ Bulk Reaction Selesai!*\n\n`;
                resultText += `*Total:* ${bulkResults.total}\n`;
                resultText += `*Berhasil:* ${bulkResults.success} ✓\n`;
                resultText += `*Gagal:* ${bulkResults.failed} ✗\n`;
                resultText += `*Success Rate:* ${Math.round((bulkResults.success / bulkResults.total) * 100)}%\n\n`;
                
                const successDetails = bulkResults.details.filter(d => d.status === 'success').slice(0, 5);
                if (successDetails.length > 0) {
                    resultText += `*✓ Berhasil:*\n`;
                    successDetails.forEach(d => {
                        resultText += `${d.emoji} • ${d.api} • CH ${d.channelId.substring(0, 10)}...\n`;
                    });
                    if (bulkResults.success > 5) {
                        resultText += `... dan ${bulkResults.success - 5} lainnya\n`;
                    }
                }
                
                await m.reply(resultText);
            } else {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply('❌ Semua bulk reaction gagal.');
            }
            
            return;
            
        } catch (bulkError) {
            console.error('Bulk error:', bulkError);
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ Error: ${bulkError.message}`);
        }
    }
    
    // ========== SINGLE MODE ==========
    const parts = input.split(/\s+/);
    let channelUrl = parts[0];
    let emojiParam = parts[1] || API_CONFIG.defaultEmoji;
    
    let emoji = emojiParam;
    
    if (emoji.toLowerCase() === 'random' || emoji.toLowerCase() === 'acak') {
        emoji = getRandomEmoji();
    }
    
    try {
        console.log(`Processing single reaction from ${m.sender}`);
        
        const result = await sendReactionViaNewApi(channelUrl, emoji);
        
        if (result.success) {
            API_COOLDOWN.setCooldown(m.sender);
            
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            
            let successText = `*✅ Reaction Berhasil!*\n\n`;
            successText += `*API Used:* ${result.api}`;
            if (result.apiKeyUsed) {
                successText += ` (${result.apiKeyUsed})`;
            }
            successText += `\n*Emoji:* ${result.emoji}\n`;
            successText += `*Channel ID:* ${result.channelId}\n`;
            successText += `*Message ID:* ${result.messageId}\n\n`;
            successText += `💬 ${result.message}`;
            
            await m.reply(successText);
            
        } else {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            
            let errorText = `*❌ Gagal Mengirim Reaction*\n\n`;
            errorText += `*Alasan:* ${result.message}\n\n`;
            errorText += `*Tips:*\n`;
            errorText += `- Pastikan URL channel valid\n`;
            errorText += `- Tunggu beberapa saat dan coba lagi\n`;
            errorText += `- Cek koneksi internet Anda`;
            
            await m.reply(errorText);
        }
        
    } catch (error) {
        console.error('Handler error:', error);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        m.reply(`❌ Error: ${error.message}`);
    }
};

handler.help = ["react", "reactchannel", "rch"];
handler.tags = ["tools"];
handler.command = ["react", "reactchannel", "chanreact", "reactwa", "rch"];

export default handler;