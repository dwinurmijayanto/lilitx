import { exec } from 'child_process';
import { promisify } from 'util';
import os from 'os';
import fs from 'fs';

const execPromise = promisify(exec);

// Storage untuk schedule restart
global.autoRestartSchedule = global.autoRestartSchedule || {
    enabled: false,
    interval: null,
    startTime: null,
    intervalId: null
};

// ==================== HELPER FUNCTIONS ====================

// Fungsi untuk mendapatkan uptime bot
const getBotUptime = () => {
    const uptime = process.uptime();
    const days = Math.floor(uptime / 86400);
    const hours = Math.floor((uptime % 86400) / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);
    
    let uptimeStr = '';
    if (days > 0) uptimeStr += `${days}d `;
    if (hours > 0) uptimeStr += `${hours}h `;
    if (minutes > 0) uptimeStr += `${minutes}m `;
    uptimeStr += `${seconds}s`;
    
    return uptimeStr.trim();
};

// Fungsi untuk mendapatkan info sistem
const getSystemInfo = () => {
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    const memUsagePercent = ((usedMem / totalMem) * 100).toFixed(2);
    
    return {
        platform: os.platform(),
        arch: os.arch(),
        nodeVersion: process.version,
        memUsage: `${(usedMem / 1024 / 1024 / 1024).toFixed(2)} GB / ${(totalMem / 1024 / 1024 / 1024).toFixed(2)} GB (${memUsagePercent}%)`,
        cpus: os.cpus().length
    };
};

// Fungsi untuk menyimpan log restart
const saveRestartLog = (sender, type = 'manual') => {
    try {
        const logPath = './restart_log.json';
        let logs = [];
        
        if (fs.existsSync(logPath)) {
            logs = JSON.parse(fs.readFileSync(logPath, 'utf-8'));
        }
        
        logs.push({
            timestamp: new Date().toISOString(),
            sender: sender,
            uptime: getBotUptime(),
            type: type // 'manual', 'force', atau 'auto'
        });
        
        // Simpan maksimal 50 log terakhir
        if (logs.length > 50) {
            logs = logs.slice(-50);
        }
        
        fs.writeFileSync(logPath, JSON.stringify(logs, null, 2));
    } catch (e) {
        console.error('Error saving restart log:', e);
    }
};

// Helper function untuk menghitung waktu restart berikutnya
const getNextRestartTime = () => {
    if (!global.autoRestartSchedule.enabled) return 'N/A';
    
    const startTime = global.autoRestartSchedule.startTime;
    const interval = global.autoRestartSchedule.interval * 60 * 60 * 1000;
    const elapsed = Date.now() - startTime;
    const remaining = interval - (elapsed % interval);
    const nextRestart = new Date(Date.now() + remaining);
    
    return nextRestart.toLocaleString('id-ID');
};

// Fungsi untuk melakukan restart
const performRestart = async (conn, sender, type = 'manual') => {
    // Simpan log restart
    saveRestartLog(sender, type);
    
    console.log(`🔄 Bot restart diminta oleh: ${sender}`);
    console.log(`⏰ Uptime: ${getBotUptime()}`);
    console.log(`⚡ Type: ${type}`);
    
    // Broadcast restart ke owner (opsional)
    if (global.owner && global.owner.length > 0) {
        for (let owner of global.owner) {
            const ownerJid = owner[0] + '@s.whatsapp.net';
            if (ownerJid !== sender) {
                try {
                    await conn.sendMessage(ownerJid, {
                        text: `🔔 *BOT RESTART NOTIFICATION*\n\n` +
                            `Type: ${type.toUpperCase()}\n` +
                            `Bot telah direstart oleh @${sender.split('@')[0]}\n` +
                            `Uptime sebelumnya: ${getBotUptime()}`,
                        mentions: [sender]
                    });
                } catch (e) {
                    console.error(`Error sending notification to owner ${owner[0]}:`, e);
                }
            }
        }
    }
    
    // Restart bot setelah delay
    setTimeout(() => {
        if (global.restart) {
            global.restart();
        } else {
            process.exit(1);
        }
    }, 2000);
};

// ==================== MAIN HANDLER ====================

let handler = async (m, { conn, args, usedPrefix = '.', command }) => {
    try {
        // Cek apakah di grup
        if (m.isGroup) {
            const groupMetadata = await conn.groupMetadata(m.chat);
            const participants = groupMetadata.participants;
            const userParticipant = participants.find(p => p.id === m.sender);
            const isUserAdmin = userParticipant?.admin === 'admin' || userParticipant?.admin === 'superadmin';
            
            if (!isUserAdmin) {
                return m.reply("⚠️ Command ini hanya untuk admin grup!");
            }
        }
        
        const option = args[0]?.toLowerCase();
        
        // ==================== AUTO RESTART COMMANDS ====================
        
        // Command: auto status atau auto tanpa argumen
        if (option === 'auto' && !args[1]) {
            const status = global.autoRestartSchedule.enabled 
                ? `✅ *Aktif*\n├ Interval: Setiap ${global.autoRestartSchedule.interval} jam\n└ Restart berikutnya: ${getNextRestartTime()}`
                : '❌ *Nonaktif*';
            
            const helpMsg = `
╔═══════════════════════╗
║  🔄 *AUTO RESTART BOT*  ║
╚═══════════════════════╝

📊 *Status:* ${status}

📝 *Cara Penggunaan:*

1️⃣ Aktifkan auto restart:
   *${usedPrefix}${command} auto on [jam]*
   Contoh: *${usedPrefix}${command} auto on 6*
   (Restart otomatis setiap 6 jam)

2️⃣ Nonaktifkan:
   *${usedPrefix}${command} auto off*

3️⃣ Cek status:
   *${usedPrefix}${command} auto*

💡 *Tips:*
Disarankan restart setiap 12-24 jam
untuk menjaga performa bot optimal.
`.trim();

            return m.reply(helpMsg);
        }
        
        // Command: auto on
        if (option === 'auto' && args[1]?.toLowerCase() === 'on') {
            const hours = parseInt(args[2]);
            
            if (!hours || hours < 1 || hours > 72) {
                return m.reply("⚠️ *Format salah!*\n\nGunakan: *" + usedPrefix + command + " auto on [jam]*\nContoh: *" + usedPrefix + command + " auto on 12*\n\n📌 Interval: 1-72 jam");
            }

            // Clear interval lama jika ada
            if (global.autoRestartSchedule.intervalId) {
                clearInterval(global.autoRestartSchedule.intervalId);
            }

            // Set interval baru
            const milliseconds = hours * 60 * 60 * 1000;
            global.autoRestartSchedule = {
                enabled: true,
                interval: hours,
                startTime: Date.now(),
                intervalId: setInterval(async () => {
                    console.log('🔄 Auto restart triggered');
                    
                    // Kirim notifikasi ke owner jika ada
                    if (global.owner && global.owner.length > 0) {
                        const ownerJid = global.owner[0] + '@s.whatsapp.net';
                        await conn.sendMessage(ownerJid, { 
                            text: '🔄 *Auto Restart*\n\nBot akan restart otomatis dalam 10 detik...' 
                        });
                    }

                    // Restart setelah 10 detik
                    setTimeout(() => {
                        saveRestartLog('system', 'auto');
                        if (global.restart) {
                            global.restart();
                        } else {
                            process.exit(1);
                        }
                    }, 10000);
                }, milliseconds)
            };

            return m.reply(`✅ *Auto Restart Diaktifkan!*

├ Interval: Setiap ${hours} jam
├ Mulai: ${new Date().toLocaleString('id-ID')}
└ Restart pertama: ${getNextRestartTime()}

💡 Bot akan restart otomatis sesuai jadwal.`);
        }

        // Command: auto off
        if (option === 'auto' && args[1]?.toLowerCase() === 'off') {
            if (!global.autoRestartSchedule.enabled) {
                return m.reply("⚠️ Auto restart sudah nonaktif!");
            }

            // Clear interval
            if (global.autoRestartSchedule.intervalId) {
                clearInterval(global.autoRestartSchedule.intervalId);
            }

            global.autoRestartSchedule = {
                enabled: false,
                interval: null,
                startTime: null,
                intervalId: null
            };

            return m.reply("✅ *Auto Restart Dinonaktifkan!*\n\nBot tidak akan restart otomatis.");
        }
        
        // ==================== INFO COMMAND ====================
        
        if (option === 'info' || option === 'i') {
            const uptime = getBotUptime();
            const sysInfo = getSystemInfo();
            const autoStatus = global.autoRestartSchedule.enabled 
                ? `✅ Aktif (Setiap ${global.autoRestartSchedule.interval}h)\n   Restart berikutnya: ${getNextRestartTime()}`
                : '❌ Nonaktif';
            
            const infoMsg = `
╔═══════════════════════╗
║  📊 *BOT INFORMATION*  ║
╚═══════════════════════╝

⏰ *Uptime:* ${uptime}
💾 *Memory:* ${sysInfo.memUsage}
🖥️ *Platform:* ${sysInfo.platform} (${sysInfo.arch})
🟢 *Node:* ${sysInfo.nodeVersion}
⚙️ *CPU Cores:* ${sysInfo.cpus}
📁 *PID:* ${process.pid}
🔄 *Auto Restart:* 
   ${autoStatus}

╔═══════════════════════╗
║  📝 *AVAILABLE COMMANDS*  ║
╚═══════════════════════╝

🔄 *${usedPrefix}${command}* - Restart bot
🔄 *${usedPrefix}${command} force* - Force restart
📊 *${usedPrefix}${command} info* - Info bot
📝 *${usedPrefix}${command} log* - Riwayat restart
⚙️ *${usedPrefix}${command} auto* - Auto restart menu
`.trim();
            
            return m.reply(infoMsg);
        }
        
        // ==================== LOG COMMAND ====================
        
        if (option === 'log' || option === 'history') {
            try {
                const logPath = './restart_log.json';
                
                if (!fs.existsSync(logPath)) {
                    return m.reply("📝 Belum ada riwayat restart.");
                }
                
                const logs = JSON.parse(fs.readFileSync(logPath, 'utf-8'));
                
                if (logs.length === 0) {
                    return m.reply("📝 Belum ada riwayat restart.");
                }
                
                // Ambil 10 log terakhir
                const recentLogs = logs.slice(-10).reverse();
                
                let logMsg = `📝 *RESTART HISTORY* (${logs.length} total)\n\n`;
                
                recentLogs.forEach((log, index) => {
                    const date = new Date(log.timestamp);
                    const formattedDate = date.toLocaleString('id-ID');
                    const typeIcon = log.type === 'auto' ? '⚙️' : log.type === 'force' ? '⚡' : '👤';
                    logMsg += `${index + 1}. ${formattedDate}\n`;
                    logMsg += `   ${typeIcon} Type: ${log.type}\n`;
                    logMsg += `   👤 ${log.sender.split('@')[0]}\n`;
                    logMsg += `   ⏰ Uptime: ${log.uptime}\n\n`;
                });
                
                return m.reply(logMsg);
            } catch (e) {
                return m.reply("❌ Error membaca log restart.");
            }
        }
        
        // ==================== RESTART COMMAND ====================
        
        const isForceRestart = option === 'force' || option === 'f';
        
        // Inisialisasi global.restartConfirmed jika belum ada
        if (!global.restartConfirmed) {
            global.restartConfirmed = {};
        }
        
        // Cek apakah sudah ada konfirmasi sebelumnya
        const lastConfirm = global.restartConfirmed[m.sender];
        const now = Date.now();
        
        if (!isForceRestart && option) {
            // Jika ada option yang tidak dikenali
            return m.reply(`⚠️ *Command tidak dikenal!*\n\nGunakan *${usedPrefix}${command} info* untuk melihat daftar command.`);
        }
        
        if (!isForceRestart) {
            // Jika belum ada konfirmasi atau konfirmasi sudah expired
            if (!lastConfirm || (now - lastConfirm > 30000)) {
                // Simpan timestamp konfirmasi baru
                global.restartConfirmed[m.sender] = now;
                
                const uptime = getBotUptime();
                const confirmMsg = `⚠️ *RESTART CONFIRMATION*\n\n` +
                    `📊 Bot sudah berjalan selama: *${uptime}*\n\n` +
                    `Apakah Anda yakin ingin restart?\n` +
                    `Kirim perintah yang sama dalam 30 detik untuk konfirmasi.\n\n` +
                    `💡 Atau gunakan *${usedPrefix}${command} force* untuk langsung restart.`;
                
                await m.reply(confirmMsg);
                
                // Hapus konfirmasi setelah 30 detik
                setTimeout(() => {
                    if (global.restartConfirmed && global.restartConfirmed[m.sender]) {
                        delete global.restartConfirmed[m.sender];
                    }
                }, 30000);
                
                return;
            }
            
            // Jika konfirmasi masih valid, lanjutkan restart
            delete global.restartConfirmed[m.sender];
        }
        
        // Kirim pesan konfirmasi
        const uptime = getBotUptime();
        const restartType = isForceRestart ? 'force' : 'manual';
        const restartMsg = `🔄 *RESTARTING BOT...*\n\n` +
            `⏰ Uptime sebelum restart: ${uptime}\n` +
            `👤 Direstart oleh: @${m.sender.split('@')[0]}\n` +
            `⚡ Mode: ${isForceRestart ? 'Force Restart' : 'Normal Restart'}\n\n` +
            `⏳ Bot akan restart dalam 2 detik...\n` +
            `✅ Tunggu beberapa saat hingga bot kembali online.`;
        
        await conn.sendMessage(m.chat, {
            text: restartMsg,
            mentions: [m.sender]
        });
        
        // Lakukan restart
        await performRestart(conn, m.sender, restartType);
        
    } catch (e) {
        console.error('❌ Error saat restart:', e);
        console.error('Stack trace:', e.stack);
        m.reply(`❌ *ERROR SAAT RESTART*\n\n` +
            `${e.message}\n\n` +
            `💡 Cek console untuk detail lengkap.`);
    }
};

handler.help = ["restart", "rs", "reboot"];
handler.tags = ["owner"];
handler.command = ["restart", "rs", "rest", "reboot"];
handler.owner = true;
handler.group = false;
handler.admin = false;
handler.botAdmin = false;

export default handler;