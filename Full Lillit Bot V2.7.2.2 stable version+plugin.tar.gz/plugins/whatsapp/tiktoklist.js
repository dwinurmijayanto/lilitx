import crypto from "crypto";
import fs from "fs";
import path from "path";
import https from "https";
import { URL } from "url";

// Storage management
const dataDir = './data';
const storageFile = path.join(dataDir, 'tiktok_autoviews.json');
const configFile = path.join(dataDir, 'autoviews_config.json');

function ensureDataDir() {
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
}

function loadStorage() {
  ensureDataDir();
  if (fs.existsSync(storageFile)) {
    return JSON.parse(fs.readFileSync(storageFile, 'utf8'));
  }
  return {};
}

function saveStorage(data) {
  ensureDataDir();
  fs.writeFileSync(storageFile, JSON.stringify(data, null, 2));
}

function loadConfig() {
  ensureDataDir();
  if (fs.existsSync(configFile)) {
    return JSON.parse(fs.readFileSync(configFile, 'utf8'));
  }
  return {
    enabled: false,
    interval: 86400000, // 24 hours in milliseconds
    maxRetries: 3,
    useProxy: false,
    proxies: [
      // Format: "host:port:username:password" or "host:port"
      // Example: "proxy1.example.com:8080:user:pass"
      // Example: "proxy2.example.com:3128"
    ],
    providers: [
      {
        name: 'provider1',
        url: 'https://leofame.com/free-tiktok-views',
        endpoint: 'https://leofame.com/free-tiktok-views',
        method: 'POST',
        enabled: true
      }
    ]
  };
}

function saveConfig(config) {
  ensureDataDir();
  fs.writeFileSync(configFile, JSON.stringify(config, null, 2));
}

// HTTP Request Helper with dynamic user agent and IP rotation
function makeRequest(url, options = {}, postData = null) {
  return new Promise((resolve, reject) => {
    const urlObj = new URL(url);
    
    // Random User-Agent rotation
    const userAgents = [
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
      'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
      'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15'
    ];
    
    // Random timezone offset
    const timezones = ['-480', '-420', '-360', '-300', '-240', '-180', '0', '60', '120', '180', '240', '300', '360', '420', '480'];
    const randomTZ = timezones[Math.floor(Math.random() * timezones.length)];
    
    const requestOptions = {
      hostname: urlObj.hostname,
      port: urlObj.port || 443,
      path: urlObj.pathname + urlObj.search,
      method: options.method || 'GET',
      headers: {
        'User-Agent': userAgents[Math.floor(Math.random() * userAgents.length)],
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9,id;q=0.8',
        'Accept-Encoding': 'identity', // Changed from gzip to get raw response
        'DNT': '1',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': '?1',
        'Cache-Control': 'max-age=0',
        ...options.headers
      }
    };

    const req = https.request(requestOptions, (res) => {
      let data = '';

      res.on('data', (chunk) => {
        data += chunk;
      });

      res.on('end', () => {
        resolve({
          statusCode: res.statusCode,
          headers: res.headers,
          body: data,
          userAgent: requestOptions.headers['User-Agent'],
          timezone: randomTZ
        });
      });
    });

    req.on('error', (error) => {
      reject(error);
    });

    if (postData) {
      req.write(postData);
    }

    req.end();
  });
}

// Fetch proxies from GitHub
async function fetchProxiesFromGitHub() {
  try {
    const url = 'https://raw.githubusercontent.com/vmheaven/VMHeaven-Free-Proxy-Updated/main/all_proxies.txt';
    console.log('[PROXY] Fetching proxies from GitHub...');
    
    const response = await makeRequest(url);
    
    if (response.statusCode !== 200) {
      throw new Error(`Failed to fetch proxies: ${response.statusCode}`);
    }

    // Parse proxy list (format: ip:port)
    const proxies = response.body
      .split('\n')
      .map(line => line.trim())
      .filter(line => line && !line.startsWith('#') && line.includes(':'))
      .filter(line => {
        const parts = line.split(':');
        return parts.length >= 2 && !isNaN(parseInt(parts[1]));
      });

    console.log(`[PROXY] Found ${proxies.length} proxies`);
    return proxies;

  } catch (error) {
    console.error(`[PROXY] Error fetching proxies: ${error.message}`);
    return [];
  }
}

// Update config with GitHub proxies
async function updateProxiesFromGitHub() {
  const config = loadConfig();
  const proxies = await fetchProxiesFromGitHub();
  
  if (proxies.length > 0) {
    config.proxies = proxies;
    config.proxySource = 'github';
    config.proxyLastUpdate = Date.now();
    saveConfig(config);
    console.log(`[PROXY] Config updated with ${proxies.length} proxies`);
    return proxies.length;
  }
  
  return 0;
}

// Parse proxy string
function parseProxy(proxyString) {
  const parts = proxyString.split(':');
  
  if (parts.length === 2) {
    // Format: host:port
    return {
      host: parts[0],
      port: parseInt(parts[1])
    };
  } else if (parts.length === 4) {
    // Format: host:port:username:password
    return {
      host: parts[0],
      port: parseInt(parts[1]),
      username: parts[2],
      password: parts[3]
    };
  }
  
  return null;
}

// Get random proxy from config
function getRandomProxy(config) {
  if (!config.useProxy || !config.proxies || config.proxies.length === 0) {
    return null;
  }
  
  const proxyString = config.proxies[Math.floor(Math.random() * config.proxies.length)];
  return parseProxy(proxyString);
}

// Extract token from HTML - improved with multiple patterns
function extractToken(html) {
  // Pattern 1: Standard input hidden
  let tokenMatch = html.match(/name="token"\s+value="([^"]+)"/);
  if (tokenMatch) return tokenMatch[1];
  
  // Pattern 2: Value before name
  tokenMatch = html.match(/value="([^"]+)"\s+name="token"/);
  if (tokenMatch) return tokenMatch[1];
  
  // Pattern 3: JavaScript variable
  tokenMatch = html.match(/var\s+token\s*=\s*['"]([^'"]+)['"]/);
  if (tokenMatch) return tokenMatch[1];
  
  // Pattern 4: In script tag
  tokenMatch = html.match(/token['"]\s*[:=]\s*['"]([^'"]+)['"]/);
  if (tokenMatch) return tokenMatch[1];
  
  // Pattern 5: Data attribute
  tokenMatch = html.match(/data-token=['"]([^'"]+)['"]/);
  if (tokenMatch) return tokenMatch[1];
  
  console.log('[DEBUG] Token patterns tested: All failed');
  console.log('[DEBUG] HTML sample:', html.substring(0, 1000));
  
  return null;
}

// Submit free views request to provider with fingerprint randomization
async function submitFreeViews(provider, videoUrl, quantity = 400) {
  try {
    console.log(`[DEBUG] Starting request to ${provider.name}`);
    console.log(`[DEBUG] Video URL: ${videoUrl}`);
    console.log(`[DEBUG] Quantity: ${quantity}`);
    
    // Random delay to avoid pattern detection
    await new Promise(resolve => setTimeout(resolve, Math.random() * 2000 + 1000));
    
    // First, get the page to extract token (with clean session)
    const pageResponse = await makeRequest(provider.url);
    console.log(`[DEBUG] Page load status: ${pageResponse.statusCode}`);
    console.log(`[DEBUG] User-Agent: ${pageResponse.userAgent.substring(0, 50)}...`);
    console.log(`[DEBUG] Response size: ${pageResponse.body.length} bytes`);
    
    if (pageResponse.statusCode !== 200) {
      throw new Error(`Failed to load page: ${pageResponse.statusCode}`);
    }

    // Check if we got valid HTML
    if (!pageResponse.body.includes('<html') && !pageResponse.body.includes('<!DOCTYPE')) {
      console.log('[DEBUG] Response is not HTML, possibly blocked or redirected');
      throw new Error('Invalid response format');
    }

    const token = extractToken(pageResponse.body);
    console.log(`[DEBUG] Token extracted: ${token ? 'Yes' : 'No'}`);
    
    if (token) {
      console.log(`[DEBUG] Token value: ${token}`);
    } else {
      // Save failed HTML for debugging
      console.log('[DEBUG] Failed to extract token. HTML preview:');
      console.log(pageResponse.body.substring(0, 2000));
      throw new Error('Failed to extract token from page');
    }

    // Get cookies from response - only use fresh session
    const cookies = pageResponse.headers['set-cookie'] || [];
    const cookieString = cookies.map(c => c.split(';')[0]).join('; ');
    console.log(`[DEBUG] Cookies count: ${cookies.length}`);
    console.log(`[DEBUG] Fresh session: ${cookieString.substring(0, 50)}...`);

    // Random timezone offset for each request
    const timezones = ['empty', '-480', '-420', '-360', '-300', '-240', '0', '240', '360', '480'];
    const randomTimezone = timezones[Math.floor(Math.random() * timezones.length)];

    // Prepare POST data with randomized timezone
    const postData = new URLSearchParams({
      token: token,
      timezone_offset: randomTimezone,
      free_link: videoUrl,
      quantity: quantity.toString()
    }).toString();
    
    console.log(`[DEBUG] POST data: ${postData}`);
    console.log(`[DEBUG] Timezone: ${randomTimezone}`);

    // Random delay before submit
    await new Promise(resolve => setTimeout(resolve, Math.random() * 1500 + 500));

    // Submit the form with fresh session
    const urlObj = new URL(provider.endpoint);
    const submitResponse = await makeRequest(provider.endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(postData),
        'Cookie': cookieString, // Fresh session cookie
        'Referer': provider.url,
        'Origin': `https://${urlObj.hostname}`,
        'X-Requested-With': 'XMLHttpRequest',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin'
      }
    }, postData);

    console.log(`[DEBUG] Submit status: ${submitResponse.statusCode}`);
    console.log(`[DEBUG] Response length: ${submitResponse.body.length}`);
    console.log(`[DEBUG] Response preview: ${submitResponse.body.substring(0, 500)}`);

    return {
      success: submitResponse.statusCode === 200,
      statusCode: submitResponse.statusCode,
      response: submitResponse.body,
      provider: provider.name,
      token: token,
      cookies: cookieString,
      postData: postData,
      userAgent: pageResponse.userAgent,
      timezone: randomTimezone
    };

  } catch (error) {
    console.error(`[DEBUG] Error occurred: ${error.message}`);
    console.error(`[DEBUG] Error stack: ${error.stack}`);
    
    return {
      success: false,
      error: error.message,
      provider: provider.name,
      stack: error.stack
    };
  }
}

// Validate TikTok URL
function validateTikTokUrl(url) {
  const patterns = [
    /^https?:\/\/(www\.)?tiktok\.com\/@[\w.-]+\/video\/\d+/,
    /^https?:\/\/vm\.tiktok\.com\/[\w]+/,
    /^https?:\/\/vt\.tiktok\.com\/[\w]+/,
    /^https?:\/\/m\.tiktok\.com\/v\/\d+/
  ];
  
  return patterns.some(pattern => pattern.test(url));
}

// Process auto views for all saved videos
async function processAutoViews(userId) {
  const storage = loadStorage();
  const config = loadConfig();
  
  if (!storage[userId] || !storage[userId].videos) {
    return { success: false, message: 'No videos found' };
  }

  const results = [];
  const now = Date.now();

  for (const video of storage[userId].videos) {
    if (!video.autoViews) continue;

    const lastRequest = video.lastRequest || 0;
    const timeSinceLastRequest = now - lastRequest;

    // Check if 24 hours have passed
    if (timeSinceLastRequest < config.interval) {
      const hoursRemaining = Math.ceil((config.interval - timeSinceLastRequest) / 3600000);
      results.push({
        url: video.url,
        skipped: true,
        reason: `Wait ${hoursRemaining} more hours`
      });
      continue;
    }

    // Try each enabled provider
    let success = false;
    for (const provider of config.providers) {
      if (!provider.enabled) continue;

      const result = await submitFreeViews(provider, video.url, video.quantity || 400);
      
      if (result.success) {
        video.lastRequest = now;
        video.totalRequests = (video.totalRequests || 0) + 1;
        video.lastProvider = provider.name;
        success = true;
        
        results.push({
          url: video.url,
          success: true,
          quantity: video.quantity || 400
        });
        break;
      }
    }

    if (!success) {
      results.push({
        url: video.url,
        success: false,
        reason: 'All providers failed'
      });
    }

    // Add delay between requests
    await new Promise(resolve => setTimeout(resolve, 3000));
  }

  saveStorage(storage);
  
  return {
    success: true,
    results: results,
    timestamp: new Date().toISOString()
  };
}

// Main handler
let handler = async (m, { conn, command, args, usedPrefix = '.' }) => {
  try {
    let text = Array.isArray(args) ? args.join(' ') : '';
    
    if (!text && m.body) {
      const commandPrefix = usedPrefix + command;
      if (m.body.startsWith(commandPrefix)) {
        text = m.body.slice(commandPrefix.length).trim();
      }
    }
    
    const storage = loadStorage();
    const config = loadConfig();
    const userId = m.sender;
    
    if (!storage[userId]) {
      storage[userId] = { videos: [] };
    }
    
    // Command: tiktok-add - Add video for auto views
    if (['tiktok-add', 'ttadd'].includes(command)) {
      const parts = text.split(' ');
      if (parts.length < 1) {
        return m.reply(`📱 *Add TikTok Video*

Usage: ${usedPrefix}tiktok-add [url] [label]

Example:
${usedPrefix}tiktok-add https://vm.tiktok.com/TMYUVDcHs myvideo

Views: Random between 320-400 (maximum available)`);
      }

      const videoUrl = parts[0];
      // Random quantity between 320-400 for maximum benefit
      const quantity = Math.floor(Math.random() * (400 - 320 + 1)) + 320;
      const label = parts[1] || `video_${Date.now()}`;

      if (!validateTikTokUrl(videoUrl)) {
        return m.reply(`❌ Invalid TikTok URL!

Supported formats:
- https://www.tiktok.com/@user/video/123456
- https://vm.tiktok.com/xxxxx
- https://vt.tiktok.com/xxxxx`);
      }

      // Check if video already exists
      const existing = storage[userId].videos.find(v => v.url === videoUrl);
      if (existing) {
        return m.reply(`❌ Video already added!\n\nLabel: ${existing.label}\nUse ${usedPrefix}tiktok-list to see all videos`);
      }

      storage[userId].videos.push({
        url: videoUrl,
        label: label,
        quantity: quantity,
        autoViews: true,
        addedAt: Date.now(),
        lastRequest: 0,
        totalRequests: 0
      });

      saveStorage(storage);

      await m.reply(`✅ *Video Added Successfully!*

Label: ${label}
URL: ${videoUrl}
Quantity: ${quantity} views
Auto Views: Enabled

Next request: Available now
Use ${usedPrefix}tiktok-run to start auto views`);
    }

    // Command: tiktok-list - List all saved videos
    else if (['tiktok-list', 'ttlist'].includes(command)) {
      const videos = storage[userId].videos || [];

      if (videos.length === 0) {
        return m.reply(`📋 *No Videos Saved*

Use ${usedPrefix}tiktok-add to add videos`);
      }

      const now = Date.now();
      let message = `📋 *TikTok Auto Views* (${videos.length})\n\n`;

      videos.forEach((video, i) => {
        const timeSinceLastRequest = now - (video.lastRequest || 0);
        const canRequest = timeSinceLastRequest >= config.interval;
        const status = canRequest ? '✅ Ready' : '⏳ Waiting';
        
        let timeInfo = '';
        if (!canRequest) {
          const hoursRemaining = Math.ceil((config.interval - timeSinceLastRequest) / 3600000);
          timeInfo = ` (${hoursRemaining}h)`;
        }

        message += `${i + 1}. ${video.label}\n`;
        message += `   Status: ${status}${timeInfo}\n`;
        message += `   Quantity: ${video.quantity} views\n`;
        message += `   Requests: ${video.totalRequests || 0}\n\n`;
      });

      message += `\n🔄 Auto: ${config.enabled ? 'ON' : 'OFF'}\n`;
      message += `⏱️ Interval: 24 hours`;

      await m.reply(message);
    }

    // Command: tiktok-delete - Delete saved video
    else if (['tiktok-delete', 'ttdel'].includes(command)) {
      if (!text) {
        return m.reply(`🗑️ *Delete Video*

Usage: ${usedPrefix}tiktok-delete [label]

Example:
${usedPrefix}tiktok-delete myvideo`);
      }

      const label = text.toLowerCase();
      const videoIndex = storage[userId].videos.findIndex(v => v.label === label);

      if (videoIndex === -1) {
        return m.reply(`❌ Video "${label}" not found

Use ${usedPrefix}tiktok-list to see all videos`);
      }

      storage[userId].videos.splice(videoIndex, 1);
      saveStorage(storage);

      await m.reply(`✅ Video "${label}" deleted successfully`);
    }

    // Command: tiktok-run - Run auto views for all videos
    else if (['tiktok-run', 'ttrun'].includes(command)) {
      await m.reply(`🔄 *Processing Auto Views...*

This may take a few minutes...`);

      const result = await processAutoViews(userId);

      if (!result.success) {
        return m.reply(`❌ ${result.message}`);
      }

      let message = `✅ *Auto Views Completed*\n\n`;
      
      result.results.forEach((res, i) => {
        const url = res.url.substring(0, 30) + '...';
        
        if (res.skipped) {
          message += `${i + 1}. ⏭️ Skipped\n   ${res.reason}\n\n`;
        } else if (res.success) {
          message += `${i + 1}. ✅ Success\n   Views: ${res.quantity}\n\n`;
        } else {
          message += `${i + 1}. ❌ Failed\n   ${res.reason}\n\n`;
        }
      });

      message += `\nTime: ${new Date(result.timestamp).toLocaleString()}`;

      await m.reply(message);
    }

    // Command: tiktok-now - Get free views now (manual)
    else if (['tiktok-now', 'ttnow'].includes(command)) {
      if (!text) {
        return m.reply(`🎯 *Get Free Views Now*

Usage: ${usedPrefix}tiktok-now [url]

Example:
${usedPrefix}tiktok-now https://vm.tiktok.com/TMYUVDcHs

Views: Random maximum (320-400)
Note: This bypasses the 24h cooldown`);
      }

      const videoUrl = text.trim();
      // Random quantity between 320-400 for maximum benefit
      const quantity = Math.floor(Math.random() * (400 - 320 + 1)) + 320;

      if (!validateTikTokUrl(videoUrl)) {
        return m.reply(`❌ Invalid TikTok URL!`);
      }

      await m.reply(`🔄 *Requesting Views...*\n\nQuantity: ${quantity} views\nPlease wait...`);

      const provider = config.providers.find(p => p.enabled);
      if (!provider) {
        return m.reply(`❌ No providers enabled!`);
      }

      const result = await submitFreeViews(provider, videoUrl, quantity, config.useProxy);

      if (result.success) {
        await m.reply(`✅ Request sent successfully\n\n🎯 Quantity: ${quantity} views\n⏰ Time: ${new Date().toLocaleTimeString()}`);
      } else {
        await m.reply(`❌ *Request Failed*

Error: ${result.error || 'Unknown error'}

Try again later or use ${usedPrefix}tiktok-add to auto-retry`);
      }
    }

    // Command: tiktok-auto - Toggle auto views
    else if (['tiktok-auto', 'ttauto'].includes(command)) {
      if (!text) {
        return m.reply(`⚙️ *Auto Views Settings*

Current: ${config.enabled ? 'ON' : 'OFF'}

Usage: ${usedPrefix}tiktok-auto [on|off]

Example:
${usedPrefix}tiktok-auto on`);
      }

      const action = text.toLowerCase();
      
      if (action === 'on') {
        config.enabled = true;
        saveConfig(config);
        await m.reply(`✅ *Auto Views Enabled*

Videos will be processed automatically every 24 hours.
Use ${usedPrefix}tiktok-run to process now`);
      } else if (action === 'off') {
        config.enabled = false;
        saveConfig(config);
        await m.reply(`⏸️ *Auto Views Disabled*

Videos will not be processed automatically.
Use ${usedPrefix}tiktok-run to process manually`);
      } else {
        await m.reply(`❌ Invalid option. Use: on or off`);
      }
    }

    // Command: tiktok-info - Show video info
    else if (['tiktok-info', 'ttinfo'].includes(command)) {
      if (!text) {
        return m.reply(`ℹ️ *Video Info*

Usage: ${usedPrefix}tiktok-info [label]

Example:
${usedPrefix}tiktok-info myvideo`);
      }

      const label = text.toLowerCase();
      const video = storage[userId].videos.find(v => v.label === label);

      if (!video) {
        return m.reply(`❌ Video "${label}" not found`);
      }

      const now = Date.now();
      const timeSinceLastRequest = now - (video.lastRequest || 0);
      const canRequest = timeSinceLastRequest >= config.interval;

      let timeInfo = '';
      if (!canRequest) {
        const hoursRemaining = Math.ceil((config.interval - timeSinceLastRequest) / 3600000);
        timeInfo = `⏳ ${hoursRemaining} hours remaining`;
      } else {
        timeInfo = `✅ Ready to request`;
      }

      await m.reply(`ℹ️ *Video Information*

Label: ${video.label}
URL: ${video.url}
Quantity: ${video.quantity} views
Auto Views: ${video.autoViews ? 'ON' : 'OFF'}

Statistics:
- Total Requests: ${video.totalRequests || 0}
- Last Request: ${video.lastRequest ? new Date(video.lastRequest).toLocaleString() : 'Never'}
- Added: ${new Date(video.addedAt).toLocaleString()}

Status: ${timeInfo}`);
    }

    // Command: tiktok-multi - Send multiple requests to same video
    else if (['tiktok-multi', 'ttmulti'].includes(command)) {
      const parts = text.split(' ');
      if (parts.length < 2) {
        return m.reply(`🔥 *Multi-Hit Request*

Usage: ${usedPrefix}tiktok-multi [url] [times]

Example:
${usedPrefix}tiktok-multi https://vm.tiktok.com/xxx 5

This will send 5 separate requests with:
- Different User-Agents
- Different Sessions
- Different Timezones
- Random delays

Max: 10 times per command`);
      }

      const videoUrl = parts[0];
      const times = Math.min(parseInt(parts[1]) || 3, 10); // Max 10

      if (!validateTikTokUrl(videoUrl)) {
        return m.reply(`❌ Invalid TikTok URL!`);
      }

      await m.reply(`🔄 *Multi-Hit Starting...*

Requests: ${times}x
Each with unique fingerprint
Please wait...`);

      const provider = config.providers.find(p => p.enabled);
      if (!provider) {
        return m.reply(`❌ No providers enabled!`);
      }

      const results = [];
      let successCount = 0;
      let totalViews = 0;

      for (let i = 0; i < times; i++) {
        const quantity = Math.floor(Math.random() * (400 - 320 + 1)) + 320;
        
        console.log(`[MULTI-HIT] Request ${i + 1}/${times}`);
        
        const result = await submitFreeViews(provider, videoUrl, quantity, config.useProxy);
        
        if (result.success) {
          successCount++;
          totalViews += quantity;
          results.push(`✅ #${i + 1}: ${quantity} views`);
        } else {
          results.push(`❌ #${i + 1}: Failed`);
        }

        // Random delay between requests (3-7 seconds)
        if (i < times - 1) {
          const delay = Math.random() * 4000 + 3000;
          console.log(`[MULTI-HIT] Waiting ${Math.round(delay / 1000)}s...`);
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      }

      let message = `🎯 *Multi-Hit Complete*\n\n`;
      message += `Success: ${successCount}/${times}\n`;
      message += `Total Views: ~${totalViews}\n\n`;
      message += `Results:\n`;
      message += results.join('\n');
      message += `\n\n⏰ ${new Date().toLocaleTimeString()}`;

      await m.reply(message);
    }
    else if (['tiktok-config', 'ttconfig'].includes(command)) {
      const totalVideos = storage[userId]?.videos?.length || 0;
      const activeVideos = storage[userId]?.videos?.filter(v => v.autoViews)?.length || 0;

      await m.reply(`⚙️ *Auto Views Configuration*

Status: ${config.enabled ? '🟢 Enabled' : '🔴 Disabled'}
Interval: ${config.interval / 3600000} hours
Max Retries: ${config.maxRetries}
Proxy: ${config.useProxy ? '🟢 Enabled' : '🔴 Disabled'} (${config.proxies?.length || 0} proxies)

Videos:
- Total: ${totalVideos}
- Active: ${activeVideos}

Providers: ${config.providers.filter(p => p.enabled).length} active

Commands:
${usedPrefix}tiktok-add - Add video
${usedPrefix}tiktok-list - List videos
${usedPrefix}tiktok-run - Process all
${usedPrefix}tiktok-now - Get views now
${usedPrefix}tiktok-multi - Multi-hit
${usedPrefix}tiktok-proxy - Proxy settings
${usedPrefix}tiktok-auto - Toggle auto`);
    }

  } catch (e) {
    console.error('TikTok Auto Views Error:', e);
    m.reply(`❌ Error: ${e.message}`);
  }
};

// Handler config
handler.help = [
  "tiktok-add [url] [label] - Add video (random max views 320-400)",
  "tiktok-list - List all saved videos",
  "tiktok-delete [label] - Delete saved video",
  "tiktok-run - Run auto views for all videos",
  "tiktok-now [url] - Get free views now (random max)",
  "tiktok-multi [url] [times] - Multi-hit same video (bypass cooldown)",
  "tiktok-proxy [action] - Manage proxy settings",
  "tiktok-auto [on|off] - Toggle auto views",
  "tiktok-info [label] - Show video info",
  "tiktok-config - Show configuration"
];

handler.tags = ["tiktok"];

handler.command = [
  "tiktok-add", "ttadd",
  "tiktok-list", "ttlist",
  "tiktok-delete", "ttdel",
  "tiktok-run", "ttrun",
  "tiktok-now", "ttnow",
  "tiktok-multi", "ttmulti",
  "tiktok-proxy", "ttproxy",
  "tiktok-auto", "ttauto",
  "tiktok-info", "ttinfo",
  "tiktok-config", "ttconfig"
];

export default handler;