import axios from "axios";
import util from "util";
import path from "path";
import { sizeFormatter } from "human-readable";
import { exec } from "child_process";
import { promisify } from "util";
import { writeFile, unlink } from "fs/promises";
import { tmpdir } from "os";

const execPromise = promisify(exec);

// ========================================
// UTILITY: Format ukuran file ke format human-readable
// ========================================
const formatSize = sizeFormatter({
  std: "JEDEC",
  decimalPlaces: 2,
  keepTrailingZeroes: false,
  render: (literal, symbol) => `${literal} ${symbol}B`,
});

// ========================================
// FUNGSI: Konversi audio ke format Opus dengan ffmpeg
// ========================================
async function convertAudio(buffer) {
  const tempInput = path.join(tmpdir(), `audio_input_${Date.now()}`);
  const tempOutput = path.join(tmpdir(), `audio_output_${Date.now()}.opus`);
  
  console.log("[AUDIO] Memulai konversi audio ke Opus");
  console.log("[AUDIO] Input temp file:", tempInput);
  console.log("[AUDIO] Output temp file:", tempOutput);
  
  try {
    // Tulis buffer ke file temporary
    await writeFile(tempInput, buffer);
    console.log("[AUDIO] File input berhasil ditulis");
    
    // Eksekusi ffmpeg dengan parameter optimal untuk VoIP
    const ffmpegCommand = `ffmpeg -i "${tempInput}" -c:a libopus -b:a 64k -vbr on -compression_level 10 -frame_duration 60 -application voip -ar 48000 -ac 1 "${tempOutput}"`;
    console.log("[AUDIO] Menjalankan ffmpeg:", ffmpegCommand);
    
    await execPromise(ffmpegCommand);
    console.log("[AUDIO] Konversi ffmpeg selesai");
    
    // Baca hasil konversi
    const { readFile } = await import("fs/promises");
    const outputBuffer = await readFile(tempOutput);
    console.log("[AUDIO] File output berhasil dibaca, ukuran:", outputBuffer.length, "bytes");
    
    // Cleanup file temporary
    await unlink(tempInput).catch(() => {});
    await unlink(tempOutput).catch(() => {});
    console.log("[AUDIO] Cleanup file temporary selesai");
    
    return outputBuffer;
  } catch (error) {
    console.error("[AUDIO] Error saat konversi:", error.message);
    // Cleanup on error
    await unlink(tempInput).catch(() => {});
    await unlink(tempOutput).catch(() => {});
    throw error;
  }
}

// ========================================
// FUNGSI: Validasi URL
// ========================================
function isValidUrl(url) {
  return /^(https|http):\/\/[^\s/$.?#].[^\s]*$/i.test(url);
}

// ========================================
// FUNGSI: Extract MIME type dari content-type header
// ========================================
function getMimeType(contentType) {
  return (contentType || "application/octet-stream").toLowerCase().split(';')[0].trim();
}

// ========================================
// MAIN HANDLER
// ========================================
const handler = async (m, { conn, command, args, usedPrefix = '.' }) => {
  console.log("\n==============================================");
  console.log("[GET] Handler dipanggil");
  console.log("[GET] Command:", command);
  console.log("[GET] Raw args:", JSON.stringify(args));
  console.log("[GET] Message body:", m.body);
  console.log("[GET] Used prefix:", usedPrefix);
  console.log("==============================================\n");
  
  try {
    // ========================================
    // STEP 1: Extract text/URL dari berbagai sumber
    // ========================================
    let text = '';
    
    // Prioritas 1: Extract dari args array
    if (Array.isArray(args) && args.length > 0) {
      text = args.join(' ').trim();
      console.log("[EXTRACT] Dari args array:", text);
    }
    
    // Prioritas 2: Extract dari message body jika args kosong
    if (!text && m.body) {
      const commandPrefix = usedPrefix + command;
      if (m.body.startsWith(commandPrefix)) {
        text = m.body.slice(commandPrefix.length).trim();
        console.log("[EXTRACT] Dari message body:", text);
      }
    }
    
    // Prioritas 3: Extract dari quoted message jika ada
    if (!text && m.quoted && m.quoted.text) {
      text = m.quoted.text.trim();
      console.log("[EXTRACT] Dari quoted message:", text);
    }
    
    // Validasi text tidak kosong
    if (!text || typeof text !== 'string') {
      console.log("[VALIDATION] Text kosong atau invalid");
      return m.reply(`❌ *Perintah salah!*\n\nContoh penggunaan:\n${usedPrefix}${command} https://example.com/file.jpg`);
    }
    
    const url = text.trim();
    console.log("[VALIDATION] URL final:", url);
    
    // ========================================
    // STEP 2: Validasi format URL
    // ========================================
    if (!isValidUrl(url)) {
      console.log("[VALIDATION] URL tidak valid");
      return m.reply("❌ *URL tidak valid!*\n\nURL harus dimulai dengan http:// atau https://");
    }
    
    console.log("[VALIDATION] URL valid, memulai download...");

    // ========================================
    // STEP 3: Download file dari URL
    // ========================================
    let response;
    try {
      console.log("[DOWNLOAD] Mengirim request ke:", url);
      const startTime = Date.now();
      
      response = await axios.get(url, {
        responseType: "arraybuffer",
        timeout: 60000, // Timeout ditingkatkan ke 60 detik
        maxContentLength: 100 * 1024 * 1024, // Max 100MB
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
          "Accept": "*/*",
          "Accept-Encoding": "gzip, deflate, br"
        }
      });
      
      const downloadTime = Date.now() - startTime;
      console.log("[DOWNLOAD] Berhasil dalam", downloadTime, "ms");
      console.log("[DOWNLOAD] Status:", response.status);
      console.log("[DOWNLOAD] Content-Type:", response.headers["content-type"]);
      console.log("[DOWNLOAD] Content-Length:", response.headers["content-length"]);
      
    } catch (e) {
      console.error("[DOWNLOAD] Error:", e.message);
      console.error("[DOWNLOAD] Error details:", {
        code: e.code,
        status: e.response?.status,
        statusText: e.response?.statusText
      });
      
      let errorMsg = `❌ *Gagal mengambil data*\n\n`;
      
      if (e.code === 'ECONNABORTED') {
        errorMsg += `⏱️ Timeout - Server terlalu lama merespons`;
      } else if (e.code === 'ERR_BAD_REQUEST') {
        errorMsg += `🚫 Request ditolak - URL tidak dapat diakses`;
      } else if (e.response) {
        const statusCode = e.response.status;
        let errorData = e.response.data;

        // Parse error response
        try {
          if (errorData instanceof ArrayBuffer || errorData instanceof Buffer) {
            errorData = Buffer.from(errorData).toString("utf8");
          }

          const jsonError = JSON.parse(errorData);
          errorMsg += `HTTP ${statusCode}\n\n\`\`\`json\n${JSON.stringify(jsonError, null, 2)}\`\`\``;
        } catch (parseError) {
          errorMsg += `HTTP ${statusCode}\n\n\`\`\`\n${String(errorData).slice(0, 500)}\`\`\``;
        }
      } else {
        errorMsg += `Error: ${e.message}`;
      }
      
      return m.reply(errorMsg);
    }

    // ========================================
    // STEP 4: Prepare data untuk dikirim
    // ========================================
    const buffer = Buffer.from(response.data);
    const mimeType = getMimeType(response.headers["content-type"]);
    const contentLength = response.headers["content-length"] || buffer.length;
    const size = formatSize(contentLength);
    
    console.log("[PROCESS] Buffer size:", buffer.length, "bytes");
    console.log("[PROCESS] MIME type:", mimeType);
    console.log("[PROCESS] Formatted size:", size);
    
    // Caption standar untuk media
    const caption = `📦 *File Info*\n\n*Type:* ${mimeType}\n*Size:* ${size}\n*URL:* ${url}`;
    
    // ========================================
    // STEP 5: Handle berdasarkan tipe konten
    // ========================================
    
    // Handle: IMAGE
    if (mimeType.startsWith("image/")) {
      console.log("[SEND] Mengirim sebagai gambar");
      return await conn.sendMessage(m.chat, {
        image: buffer,
        caption: caption
      }, { quoted: m });
    }

    // Handle: VIDEO
    if (mimeType.startsWith("video/")) {
      console.log("[SEND] Mengirim sebagai video");
      return await conn.sendMessage(m.chat, {
        video: buffer,
        caption: caption,
        mimetype: mimeType
      }, { quoted: m });
    }

    // Handle: AUDIO
    if (mimeType.startsWith("audio/")) {
      console.log("[SEND] Mengirim sebagai audio");
      
      try {
        // Coba konversi ke Opus untuk kualitas lebih baik
        const convertedAudio = await convertAudio(buffer);
        
        console.log("[SEND] Mengirim audio yang sudah dikonversi");
        return await conn.sendMessage(m.chat, {
          audio: convertedAudio,
          mimetype: "audio/ogg; codecs=opus",
          ptt: false
        }, { quoted: m });
        
      } catch (conversionError) {
        console.error("[SEND] Konversi gagal, kirim audio original");
        // Fallback: kirim audio asli tanpa konversi
        return await conn.sendMessage(m.chat, {
          audio: buffer,
          mimetype: mimeType,
          ptt: false
        }, { quoted: m });
      }
    }

    // Handle: TEXT atau JSON
    const TEXT_MAX_LENGTH = 4096; // Batas karakter WhatsApp
    
    if (mimeType.startsWith("text/") || mimeType.includes("application/json")) {
      console.log("[SEND] Mengirim sebagai text/json");
      const textData = buffer.toString("utf8");
      console.log("[SEND] Text length:", textData.length, "characters");

      // Jika text cukup pendek, kirim langsung
      if (textData.length < TEXT_MAX_LENGTH) {
        let contentToSend = textData;
        let header = `📄 *Text (${size})*\n\n`;

        // Format khusus untuk JSON
        if (mimeType.includes("application/json")) {
          try {
            const jsonObj = JSON.parse(textData);
            header = `📋 *JSON (${size})*\n\n`;
            contentToSend = util.inspect(jsonObj, { depth: 10, colors: false });
            console.log("[SEND] JSON berhasil di-parse");
          } catch (e) {
            console.log("[SEND] Gagal parse JSON, kirim sebagai text biasa");
          }
        }
        
        return m.reply(header + "```\n" + contentToSend + "\n```");
        
      } else {
        // Jika text terlalu panjang, kirim sebagai document
        console.log("[SEND] Text terlalu panjang, kirim sebagai document");
        const extension = mimeType.includes("json") ? "json" : mimeType.split("/")[1] || "txt";
        const fileName = path.basename(url).split('?')[0] || `response.${extension}`;
        
        return await conn.sendMessage(m.chat, {
          document: buffer,
          mimetype: mimeType,
          fileName: fileName,
          caption: `📄 *Text terlalu panjang*\n\n*Type:* ${mimeType}\n*Size:* ${size}\n*URL:* ${url}`
        }, { quoted: m });
      }
    }

    // Handle: FILE/DOCUMENT (default untuk tipe lainnya)
    console.log("[SEND] Mengirim sebagai document");
    const extension = path.extname(url).split('?')[0] || "";
    let fileName = path.basename(url).split('?')[0];
    
    // Generate nama file jika tidak ada
    if (!fileName || fileName.length < 3) {
      fileName = `file_${Date.now()}${extension || '.bin'}`;
    }
    
    console.log("[SEND] Filename:", fileName);

    return await conn.sendMessage(m.chat, {
      document: buffer,
      mimetype: mimeType,
      fileName: fileName,
      caption: caption
    }, { quoted: m });

  } catch (e) {
    console.error("\n[ERROR] ==========================================");
    console.error("[ERROR] Unhandled error:", e.message);
    console.error("[ERROR] Stack trace:", e.stack);
    console.error("[ERROR] ==========================================\n");
    
    // Kirim pesan error ke user
    m.reply(`❌ *Terjadi kesalahan*\n\n${e.message}`);
  }
};

// ========================================
// HANDLER METADATA
// ========================================
handler.help = ["get <url>", "fetch <url>"];
handler.command = ["get", "fetch"];
handler.tags = ["downloader"];
handler.description = "Mengambil dan mendownload file dari URL";

export default handler;