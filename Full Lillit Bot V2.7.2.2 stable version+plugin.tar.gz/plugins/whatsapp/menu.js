let handler = async (m, { conn, config, commands }) => {
  try {
    const ownerNumber = config?.ownerWhatsapp ? config.ownerWhatsapp.toString() : "";
    const isOwner = ownerNumber && m.sender ? m.sender.split('@')[0] === ownerNumber : false;

    const commandsByCategory = {};
    const seenCommands = new Set(); // untuk mencegah duplikat global

    // Group commands → hanya masuk ke kategori pertama
    commands.forEach(command => {
      if (command.isOwner && !isOwner) return;
      if (command.hidden && !isOwner) return;

      // Skip jika sudah ditampilkan di kategori sebelumnya
      if (seenCommands.has(command.name)) return;
      seenCommands.add(command.name);

      const commandRef = {
        name: command.name,
        hidden: command.hidden || false
      };

      // Ambil kategori pertama (primary category)
      let assigned = false;

      if (command.category && command.category.length > 0) {
        // Urutkan kategori supaya konsisten (opsional: bisa diatur prioritas)
        const sortedCats = [...command.category].sort(); 
        const primaryCat = sortedCats[0]; // ← kategori pertama setelah di-sort

        if (!commandsByCategory[primaryCat]) commandsByCategory[primaryCat] = [];
        commandsByCategory[primaryCat].push(commandRef);
        assigned = true;
      }

      // Jika tidak punya kategori sama sekali → uncategorized
      if (!assigned) {
        if (!commandsByCategory['uncategorized']) commandsByCategory['uncategorized'] = [];
        commandsByCategory['uncategorized'].push(commandRef);
      }
    });

    // Icon kategori (tambahkan yang kurang jika perlu)
    const categoryIcons = {
      'ai': '🤖',
      'converter': '🔄',
      'downloader': '⬇️',
      'fun': '🎮',
      'group': '👥',
      'info': 'ℹ️',
      'main': '🏠',
      'service': '⚙️',
      'sticker': '🎨',
      'tools': '🛠️',
      'uncategorized': '📦',
      'maker': '🖼️',
      'meme': '😂',
      'music': '🎵',
      'tiktok': '🎬',
      // tambah manual jika ada kategori lain
    };

    // Hitung total command yang benar-benar ditampilkan
    let totalDisplayed = 0;
    Object.values(commandsByCategory).forEach(arr => {
      totalDisplayed += arr.length;
    });

    const userName = m.sender ? m.sender.split('@')[0] : 'User';
    let menuText = `╭━━━『 *${config?.botName || 'Lilith Bot'}* 』━━━╮\n`;
    menuText += `│ 📊 Total Commands: ${totalDisplayed}\n`;
    menuText += `│ 👤 User: @${userName}\n`;
    menuText += `╰━━━━━━━━━━━━━━━━━╯\n\n`;

    const categories = Object.keys(commandsByCategory).sort();

    for (const category of categories) {
      const catCommands = commandsByCategory[category];
      if (!catCommands || catCommands.length === 0) continue;

      const categoryTitle = category.charAt(0).toUpperCase() + category.slice(1);
      const icon = categoryIcons[category.toLowerCase()] || '📌';

      menuText += `┏━━ ${icon} *${categoryTitle}* ━━\n`;

      // Sortir nama command supaya rapi
      catCommands.sort((a, b) => a.name.localeCompare(b.name));

      for (const cmd of catCommands) {
        const hiddenBadge = cmd.hidden && isOwner ? ' 🔒' : '';
        menuText += `┃ /${cmd.name}${hiddenBadge}\n`;
      }

      menuText += `┗━━━━━━━━━━━━━\n\n`;
    }

    // Footer
    menuText += `╭━━━『 *Info* 』━━━╮\n`;
    menuText += `│ 💡 Ketik /<command> untuk\n`;
    menuText += `│ menggunakan perintah\n`;

    if (isOwner) {
      const hiddenCount = commands.filter(cmd => cmd.hidden).length;
      if (hiddenCount > 0) {
        menuText += `│ 🔒 ${hiddenCount} hidden commands\n`;
      }
    }

    menuText += `╰━━━━━━━━━━━━━━━━━╯`;

    await conn.sendMessage(m.chat, {
      text: menuText,
      mentions: m.sender ? [m.sender] : []
    });

  } catch (e) {
    m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ["menu", "help"];
handler.tags = ["main"];
handler.command = ["menu", "help"];
export default handler;