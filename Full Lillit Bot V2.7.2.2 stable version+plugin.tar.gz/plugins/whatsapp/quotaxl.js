import https from 'https';
const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

console.log('[XL/AXIS Quota Checker] Loading handler v1.0 (Fast & Minimalist)...');

// ===========================================
// ========== CONFIG ==========
// ===========================================
const API_URL = 'https://bendith.my.id/end.php';
const TIMEOUT_MS = 10000; // 10 detik - lebih cepat

// SSL Agent
const httpsAgent = new https.Agent({
    rejectUnauthorized: false
});

// ===========================================
// ========== API FETCH ==========
// ===========================================

async function fetchQuotaData(number) {
    let formattedNumber = number.startsWith('0') ? '62' + number.substring(1) : 
                          number.startsWith('62') ? number : '62' + number;
    
    const url = `${API_URL}?check=package&number=${formattedNumber}&version=2.201`;
    
    const response = await Promise.race([
        fetch(url, {
            method: 'GET',
            headers: {
                'User-Agent': 'Mozilla/5.0',
                'Accept': 'application/json'
            },
            agent: httpsAgent,
            timeout: TIMEOUT_MS
        }),
        new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Timeout')), TIMEOUT_MS)
        )
    ]);

    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    
    const data = await response.json();
    
    if (!data.success || data.code !== '000' || !data.data?.subs_info) {
        throw new Error(data.message || 'Data tidak valid');
    }
    
    return data.data;
}

// ===========================================
// ========== VALIDATION ==========
// ===========================================

function validatePhoneNumber(number) {
    let clean = number.replace(/\D/g, '');
    
    if (clean.startsWith('62')) clean = '0' + clean.substring(2);
    else if (!clean.startsWith('0')) clean = '0' + clean;
    
    if (clean.length < 10 || clean.length > 13) {
        return { valid: false, message: '❌ Panjang nomor tidak valid (10-13 digit)' };
    }
    
    const xlPrefixes = ['0817', '0818', '0819', '0859', '0877', '0878'];
    const axisPrefixes = ['0831', '0832', '0833', '0838'];
    const prefix = clean.substring(0, 4);
    
    if (![...xlPrefixes, ...axisPrefixes].includes(prefix)) {
        return { 
            valid: false, 
            message: '❌ Bukan XL/AXIS!\n\n*XL:* 0817|0818|0819|0859|0877|0878\n*AXIS:* 0831|0832|0833|0838' 
        };
    }
    
    return { 
        valid: true, 
        number: clean, 
        operator: xlPrefixes.includes(prefix) ? 'XL' : 'AXIS' 
    };
}

// ===========================================
// ========== FORMAT MINIMALIS ==========
// ===========================================

function formatQuotaMinimal(data) {
    const s = data.subs_info;
    const pkgs = data.package_info?.packages || [];
    
    const emoji = s.operator === 'XL' ? '🔵' : '🟡';
    
    // Header dengan box style
    let msg = `${emoji} *CEK KUOTA ${s.operator}*\n\n`;
    
    // Info Pelanggan
    msg += `┌─ *INFO PELANGGAN*\n`;
    msg += `├ Nomor: *${s.msisdn}*\n`;
    msg += `├ Operator: *${s.operator}*\n`;
    msg += `├ Verifikasi ID: *${s.id_verified}*\n`;
    msg += `├ Jaringan: *${s.net_type}*\n`;
    msg += `├ Masa Berlangganan: *${s.tenure}*\n`;
    msg += `├ Expired: *${s.exp_date}*\n`;
    msg += `└ Grace Period: *${s.grace_until}*\n`;
    
    // VoLTE Status
    if (s.volte) {
        const v = s.volte;
        msg += `\n┌─ *STATUS VoLTE*\n`;
        msg += `├ Device Support: *${v.device ? 'Ya' : 'Tidak'}*\n`;
        msg += `├ Area Coverage: *${v.area ? 'Tersedia' : 'Tidak Tersedia'}*\n`;
        msg += `└ Simcard Support: *${v.simcard ? 'Ya' : 'Tidak'}*\n`;
    }
    
    // Paket & Kuota
    if (pkgs.length === 0) {
        msg += `📦 *TIDAK ADA PAKET AKTIF*\n`;
        msg += `💡 Beli paket terlebih dahulu`;
    } else {
        msg += `📦 *${pkgs.length} PAKET AKTIF*\n\n`;
        
        pkgs.forEach((pkg, idx) => {
            const expDate = new Date(pkg.timestamp * 1000);
            const daysLeft = Math.ceil((expDate - new Date()) / 86400000);
            const warn = daysLeft <= 3 ? ' ⚠️' : daysLeft <= 7 ? ' ⏰' : '';
            
            msg += `*${idx + 1}. ${pkg.name}*\n`;
            msg += `⏰ ${pkg.expiry} (${daysLeft}h${warn})\n`;
            
            if (pkg.quotas?.length > 0) {
                pkg.quotas.forEach(q => {
                    const bar = miniBar(q.percent);
                    const status = q.percent >= 90 ? '🚨' : q.percent >= 75 ? '⚠️' : q.percent >= 50 ? '💡' : '✨';
                    const used = calcUsed(q.total, q.remaining);
                    
                    msg += `\n  ${bar} *${q.percent}%* ${status}\n`;
                    msg += `  📊 ${q.name}\n`;
                    msg += `  💾 ${q.remaining}/${q.total} • 📉 ${used}\n`;
                });
            }
            
            if (idx < pkgs.length - 1) msg += `\n`;
        });
        
        // Summary 1 line
        const totalQuotas = pkgs.reduce((sum, pkg) => sum + (pkg.quotas?.length || 0), 0);
        const nearExp = pkgs.filter(pkg => {
            const days = Math.ceil((new Date(pkg.timestamp * 1000) - new Date()) / 86400000);
            return days <= 7;
        }).length;
        
        msg += `\n━━━━━━━━━━━━━━━━━━\n`;
        msg += `📊 ${pkgs.length} Paket • ${totalQuotas} Kuota`;
        if (nearExp > 0) msg += ` • ${nearExp} akan exp`;
    }
    
    msg += `\n⏰ ${new Date().toLocaleString('id-ID', { 
        timeZone: 'Asia/Jakarta',
        hour: '2-digit',
        minute: '2-digit',
        day: '2-digit',
        month: '2-digit'
    })} WIB`;
    
    return msg;
}

// Mini progress bar (10 blocks untuk detail lebih baik)
function miniBar(percent) {
    const blocks = ['⚪', '🟢', '🟡', '🔴'];
    const total = 10;
    const filled = Math.round(percent / 10);
    const empty = total - filled;
    
    let bar = '';
    let color = blocks[1]; // green
    
    if (percent >= 80) color = blocks[3]; // red
    else if (percent >= 50) color = blocks[2]; // yellow
    
    for (let i = 0; i < filled; i++) bar += color;
    for (let i = 0; i < empty; i++) bar += blocks[0];
    
    return bar;
}

function calcUsed(total, remaining) {
    const parse = (str) => {
        const m = str.match(/(\d+(?:\.\d+)?)\s*(GB|MB|KB)/i);
        if (!m) return 0;
        const v = parseFloat(m[1]);
        const u = m[2].toUpperCase();
        return u === 'GB' ? v * 1024 : u === 'MB' ? v : v / 1024;
    };
    
    const used = parse(total) - parse(remaining);
    return used >= 1024 ? `${(used / 1024).toFixed(1)}GB` : `${used.toFixed(0)}MB`;
}

function generateHelp(prefix) {
    return `*CEK KUOTA XL & AXIS*

*CARA PENGGUNAAN:*
${prefix}kuota <nomor-xl/axis>
${prefix}kuota 087874983280

*XL AXIATA:*
• 0817, 0818, 0819
• 0859, 0877, 0878

*AXIS:*
• 0831, 0832, 0833, 0838

*FITUR:*
✅ Fast API (10s timeout)
✅ Output clean dengan box style
✅ Info lengkap & detail
✅ Progress bar usage
✅ Warning otomatis
✅ Real-time dari operator

*INFO YANG DITAMPILKAN:*
• Data pelanggan lengkap
• Status VoLTE
• Detail paket & kuota
• Kuota tersisa & terpakai
• Tanggal expired
• Ringkasan paket`;
}

// ===========================================
// ========== MAIN HANDLER ==========
// ===========================================

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    const prefix = usedPrefix || '.';
    const input = text?.trim() || args?.join(' ').trim() || '';
    
    if (!input || input.toLowerCase() === 'help' || input === '?') {
        return m.reply(generateHelp(prefix));
    }
    
    try {
        // Validate
        const validation = validatePhoneNumber(input);
        
        if (!validation.valid) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`${validation.message}\n\n💡 ${prefix}${command} 087874983280\n📝 ${prefix}${command} help`);
        }
        
        // Loading
        const emoji = validation.operator === 'XL' ? '🔵' : '🟡';
        await conn.sendMessage(m.chat, { react: { text: emoji, key: m.key } });
        
        // Fetch (fast)
        const data = await fetchQuotaData(validation.number);
        
        // Verify operator
        const apiOp = data.subs_info?.operator;
        if (apiOp && apiOp !== 'XL' && apiOp !== 'AXIS') {
            throw new Error(`Operator ${apiOp} tidak support`);
        }
        
        // Format minimalis
        const result = formatQuotaMinimal(data);
        
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        return m.reply(result);
        
    } catch (error) {
        console.error('[Quota] Error:', error.message);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        
        let errorMsg = '❌ *GAGAL CEK KUOTA*\n\n';
        
        if (error.message.includes('Timeout')) {
            errorMsg += '⏰ Koneksi timeout (>10s)\n💡 Coba lagi';
        } else if (error.message.includes('HTTP')) {
            errorMsg += `🔒 ${error.message}\n💡 Server error`;
        } else if (error.message.includes('tidak support')) {
            errorMsg += `${error.message}\n💡 Hanya XL/AXIS`;
        } else {
            errorMsg += `⚠️ ${error.message}\n💡 ${prefix}${command} help`;
        }
        
        return m.reply(errorMsg);
    }
};

// ===========================================
// ========== HANDLER CONFIG ==========
// ===========================================

handler.help = ["kuota <nomor-xl/axis>"];
handler.tags = ["tools"];
handler.command = ["xl", "cekquota", "xlquota", "axisquota", "axis"];
handler.limit = true;

console.log('[XL/AXIS Quota Checker] v1.0 loaded successfully (Fast & Minimalist)');

export default handler;