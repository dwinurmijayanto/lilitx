import fs from "fs";
import path from "path";

// Helper untuk baca/tulis storage
const storageDir = './data/group-storage';

if (!fs.existsSync(storageDir)) {
  fs.mkdirSync(storageDir, { recursive: true });
}

const getStoragePath = (key) => {
  const safeName = key.replace(/[^a-z0-9_-]/gi, '_');
  return path.join(storageDir, `${safeName}.json`);
};

const storageGet = (key) => {
  try {
    const filePath = getStoragePath(key);
    if (fs.existsSync(filePath)) {
      const data = fs.readFileSync(filePath, 'utf8');
      return { key, value: data };
    }
    return null;
  } catch (e) {
    console.error('Storage get error:', e);
    return null;
  }
};

const storageSet = (key, value) => {
  try {
    const filePath = getStoragePath(key);
    fs.writeFileSync(filePath, value, 'utf8');
    return { key, value };
  } catch (e) {
    console.error('Storage set error:', e);
    return null;
  }
};

const storageDelete = (key) => {
  try {
    const filePath = getStoragePath(key);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      return { key, deleted: true };
    }
    return { key, deleted: false };
  } catch (e) {
    console.error('Storage delete error:', e);
    return null;
  }
};

let handler = async (m, { conn, config, command, args, usedPrefix = '.' }) => {
  try {
    let text = Array.isArray(args) ? args.join(' ') : '';
    
    if (!text && m.body) {
      const commandPrefix = usedPrefix + command;
      if (m.body.startsWith(commandPrefix)) {
        text = m.body.slice(commandPrefix.length).trim();
      }
    }
    
    const isGroup = m.isGroup;
    
    if (!isGroup) {
      return m.reply("❌ Command ini hanya bisa digunakan di grup!");
    }
    
    const groupMetadata = await conn.groupMetadata(m.chat);
    const participants = groupMetadata.participants;
    
    const extractCleanNumber = (jid) => {
      if (!jid) return null;
      const match = jid.match(/^(\d+)/);
      return match ? match[1] : null;
    };
    
    const userParticipant = participants.find(p => p.id === m.sender);
    const isUserAdmin = userParticipant?.admin === 'admin' || userParticipant?.admin === 'superadmin';
    
    // Storage keys
    const pollKey = `poll:${m.chat}`;
    const scheduleKey = `schedule:${m.chat}`;
    const linksKey = `links:${m.chat}`;
    const reminderKey = `reminder:${m.chat}`;
    const statsKey = `stats:${m.chat}`;
    
    // ==========================================
    // FITUR 1: POLLING/VOTING SYSTEM
    // ==========================================
    
    if (command === "buatpoll" || command === "createpoll") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      if (!text) {
        return m.reply(`❌ Format salah!

*Format:*
.buatpoll Pertanyaan | Opsi1 | Opsi2 | Opsi3

*Contoh:*
.buatpoll Meeting kapan? | Senin | Selasa | Rabu
.buatpoll Pizza topping? | Keju | Pepperoni | Vegetarian | Semua`);
      }
      
      try {
        const parts = text.split('|').map(p => p.trim());
        
        if (parts.length < 3) {
          return m.reply("❌ Minimal 1 pertanyaan dan 2 opsi!\n\nContoh:\n.buatpoll Makan dimana? | Restoran A | Restoran B");
        }
        
        const question = parts[0];
        const options = parts.slice(1);
        
        if (options.length > 10) {
          return m.reply("❌ Maksimal 10 opsi!");
        }
        
        const pollData = {
          active: true,
          question: question,
          options: options.map((opt, i) => ({
            id: i + 1,
            text: opt,
            votes: []
          })),
          createdBy: extractCleanNumber(m.sender),
          createdAt: new Date().toLocaleString('id-ID'),
          closedAt: null,
          allowMultiple: false
        };
        
        storageSet(pollKey, JSON.stringify(pollData));
        
        let msg = `📊 *POLLING DIBUKA*\n\n`;
        msg += `*${question}*\n\n`;
        msg += `Pilihan:\n`;
        options.forEach((opt, i) => {
          msg += `${i + 1}. ${opt}\n`;
        });
        msg += `\nVote dengan: .vote [nomor]\n`;
        msg += `Contoh: .vote 1\n\n`;
        msg += `_Dibuat oleh: @${extractCleanNumber(m.sender)}_`;
        
        m.reply(msg, null, { mentions: [m.sender] });
        
      } catch (e) {
        m.reply(`❌ Gagal membuat poll!\n\nError: ${e.message}`);
      }
    }
    
    else if (command === "vote" || command === "pilih") {
      if (!text || isNaN(text)) {
        return m.reply(`❌ Masukkan nomor pilihan!

*Contoh:*
.vote 1
.vote 3

Gunakan .cekpoll untuk melihat pilihan`);
      }
      
      try {
        let pollData = null;
        const result = storageGet(pollKey);
        if (result && result.value) {
          pollData = JSON.parse(result.value);
        }
        
        if (!pollData || !pollData.active) {
          return m.reply("❌ Tidak ada polling yang sedang aktif!\n\nAdmin dapat membuat dengan .buatpoll");
        }
        
        const voteNum = parseInt(text);
        
        if (voteNum < 1 || voteNum > pollData.options.length) {
          return m.reply(`❌ Nomor pilihan tidak valid! Pilihan: 1-${pollData.options.length}`);
        }
        
        const voterNumber = extractCleanNumber(m.sender);
        
        // Cek apakah sudah vote
        const hasVoted = pollData.options.some(opt => 
          opt.votes.some(v => v.number === voterNumber)
        );
        
        if (hasVoted) {
          // Hapus vote lama
          pollData.options.forEach(opt => {
            opt.votes = opt.votes.filter(v => v.number !== voterNumber);
          });
        }
        
        // Tambah vote baru
        pollData.options[voteNum - 1].votes.push({
          number: voterNumber,
          time: new Date().toLocaleString('id-ID')
        });
        
        storageSet(pollKey, JSON.stringify(pollData));
        
        const totalVotes = pollData.options.reduce((sum, opt) => sum + opt.votes.length, 0);
        
        m.reply(`✅ Vote berhasil dicatat!\n\nAnda memilih: *${pollData.options[voteNum - 1].text}*\n\nTotal vote: ${totalVotes}`);
        
      } catch (e) {
        m.reply(`❌ Gagal mencatat vote!\n\nError: ${e.message}`);
      }
    }
    
    else if (command === "cekpoll" || command === "hasilpoll") {
      try {
        let pollData = null;
        const result = storageGet(pollKey);
        if (result && result.value) {
          pollData = JSON.parse(result.value);
        }
        
        if (!pollData) {
          return m.reply("❌ Belum ada polling di grup ini!");
        }
        
        const totalVotes = pollData.options.reduce((sum, opt) => sum + opt.votes.length, 0);
        
        let msg = `📊 *HASIL POLLING*\n`;
        msg += `${pollData.active ? '🟢 Aktif' : '🔴 Ditutup'}\n\n`;
        msg += `*${pollData.question}*\n\n`;
        
        // Sort by votes
        const sorted = [...pollData.options].sort((a, b) => b.votes.length - a.votes.length);
        
        sorted.forEach((opt, i) => {
          const percentage = totalVotes > 0 ? ((opt.votes.length / totalVotes) * 100).toFixed(1) : 0;
          const bar = '█'.repeat(Math.floor(percentage / 5));
          
          msg += `${opt.id}. ${opt.text}\n`;
          msg += `   ${bar} ${percentage}% (${opt.votes.length} vote)\n\n`;
        });
        
        msg += `Total vote: ${totalVotes}\n`;
        msg += `Dibuat: ${pollData.createdAt}\n`;
        
        if (pollData.active) {
          msg += `\nVote dengan: .vote [nomor]`;
        }
        
        m.reply(msg);
        
      } catch (e) {
        m.reply(`❌ Gagal mengambil hasil poll!\n\nError: ${e.message}`);
      }
    }
    
    else if (command === "tutuppoll" || command === "closepoll") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      try {
        let pollData = null;
        const result = storageGet(pollKey);
        if (result && result.value) {
          pollData = JSON.parse(result.value);
        }
        
        if (!pollData || !pollData.active) {
          return m.reply("❌ Tidak ada polling yang sedang aktif!");
        }
        
        pollData.active = false;
        pollData.closedAt = new Date().toLocaleString('id-ID');
        
        storageSet(pollKey, JSON.stringify(pollData));
        
        const totalVotes = pollData.options.reduce((sum, opt) => sum + opt.votes.length, 0);
        const winner = [...pollData.options].sort((a, b) => b.votes.length - a.votes.length)[0];
        
        let msg = `📊 *POLLING DITUTUP*\n\n`;
        msg += `*${pollData.question}*\n\n`;
        msg += `🏆 *Pemenang:*\n`;
        msg += `${winner.text} (${winner.votes.length} vote)\n\n`;
        msg += `Total partisipan: ${totalVotes}\n`;
        msg += `Gunakan .cekpoll untuk detail lengkap`;
        
        m.reply(msg);
        
      } catch (e) {
        m.reply(`❌ Gagal menutup poll!\n\nError: ${e.message}`);
      }
    }
    
    // ==========================================
    // FITUR 2: JADWAL GRUP (SCHEDULE)
    // ==========================================
    
    else if (command === "addjadwal" || command === "tambahjadwal") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      if (!text) {
        return m.reply(`❌ Format salah!

*Format:*
.addjadwal Tanggal | Waktu | Acara | Lokasi

*Contoh:*
.addjadwal 25 Nov | 14:00 | Meeting | Zoom
.addjadwal 1 Des | 19:00 | Dinner | Restoran ABC
.addjadwal Senin | 09:00 | Kelas Online | Google Meet`);
      }
      
      try {
        const parts = text.split('|').map(p => p.trim());
        
        if (parts.length < 3) {
          return m.reply("❌ Minimal isi: Tanggal | Waktu | Acara");
        }
        
        let scheduleData = { schedules: [] };
        const result = storageGet(scheduleKey);
        if (result && result.value) {
          scheduleData = JSON.parse(result.value);
        }
        
        const newSchedule = {
          id: Date.now(),
          date: parts[0],
          time: parts[1],
          event: parts[2],
          location: parts[3] || "-",
          addedBy: extractCleanNumber(m.sender),
          addedAt: new Date().toLocaleString('id-ID'),
          reminded: false
        };
        
        scheduleData.schedules.push(newSchedule);
        scheduleData.schedules.sort((a, b) => a.id - b.id);
        
        storageSet(scheduleKey, JSON.stringify(scheduleData));
        
        let msg = `✅ Jadwal berhasil ditambahkan!\n\n`;
        msg += `📅 ${newSchedule.date}\n`;
        msg += `⏰ ${newSchedule.time}\n`;
        msg += `📍 ${newSchedule.event}\n`;
        msg += `📌 ${newSchedule.location}\n\n`;
        msg += `Total jadwal: ${scheduleData.schedules.length}`;
        
        m.reply(msg);
        
      } catch (e) {
        m.reply(`❌ Gagal menambahkan jadwal!\n\nError: ${e.message}`);
      }
    }
    
    else if (command === "jadwal" || command === "listjadwal" || command === "schedule") {
      try {
        let scheduleData = { schedules: [] };
        const result = storageGet(scheduleKey);
        if (result && result.value) {
          scheduleData = JSON.parse(result.value);
        }
        
        if (scheduleData.schedules.length === 0) {
          return m.reply("📅 Belum ada jadwal di grup ini.\n\nGunakan .addjadwal untuk menambahkan.");
        }
        
        let msg = `📅 *JADWAL GRUP*\n`;
        msg += `Total: ${scheduleData.schedules.length} jadwal\n\n`;
        
        scheduleData.schedules.forEach((sch, i) => {
          msg += `*${i + 1}. ${sch.event}*\n`;
          msg += `📅 ${sch.date} | ⏰ ${sch.time}\n`;
          msg += `📌 ${sch.location}\n`;
          msg += `_ditambahkan: ${sch.addedAt}_\n\n`;
        });
        
        msg += `*Kelola jadwal:*\n`;
        msg += `.addjadwal - Tambah jadwal\n`;
        msg += `.deljadwal [no] - Hapus jadwal\n`;
        msg += `.clearjadwal - Hapus semua`;
        
        m.reply(msg);
        
      } catch (e) {
        m.reply(`❌ Gagal mengambil jadwal!\n\nError: ${e.message}`);
      }
    }
    
    else if (command === "deljadwal" || command === "hapusjadwal") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      if (!text || isNaN(text)) {
        return m.reply(`❌ Masukkan nomor jadwal yang ingin dihapus!

*Contoh:*
.deljadwal 1
.deljadwal 3`);
      }
      
      try {
        const scheduleIndex = parseInt(text) - 1;
        let scheduleData = { schedules: [] };
        const result = storageGet(scheduleKey);
        if (result && result.value) {
          scheduleData = JSON.parse(result.value);
        }
        
        if (scheduleIndex < 0 || scheduleIndex >= scheduleData.schedules.length) {
          return m.reply(`❌ Nomor tidak valid! Total jadwal: ${scheduleData.schedules.length}`);
        }
        
        const deleted = scheduleData.schedules.splice(scheduleIndex, 1)[0];
        storageSet(scheduleKey, JSON.stringify(scheduleData));
        
        m.reply(`✅ Jadwal berhasil dihapus!\n\n_${deleted.event} - ${deleted.date}_`);
        
      } catch (e) {
        m.reply(`❌ Gagal menghapus jadwal!\n\nError: ${e.message}`);
      }
    }
    
    else if (command === "clearjadwal") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      try {
        storageDelete(scheduleKey);
        m.reply("✅ Semua jadwal berhasil dihapus!");
      } catch (e) {
        m.reply(`❌ Gagal menghapus jadwal!\n\nError: ${e.message}`);
      }
    }
    
    // ==========================================
    // FITUR 3: LINK MANAGER
    // ==========================================
    
    else if (command === "addlink" || command === "simpanlink") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      if (!text) {
        return m.reply(`❌ Format salah!

*Format:*
.addlink Judul | URL | Kategori

*Contoh:*
.addlink Materi Bab 1 | https://drive.google.com/xxx | Materi
.addlink Zoom Meeting | https://zoom.us/j/xxx | Meeting
.addlink GitHub Repo | https://github.com/xxx | Project`);
      }
      
      try {
        const parts = text.split('|').map(p => p.trim());
        
        if (parts.length < 2) {
          return m.reply("❌ Minimal isi: Judul | URL");
        }
        
        let linksData = { links: [] };
        const result = storageGet(linksKey);
        if (result && result.value) {
          linksData = JSON.parse(result.value);
        }
        
        const newLink = {
          id: Date.now(),
          title: parts[0],
          url: parts[1],
          category: parts[2] || "Umum",
          addedBy: extractCleanNumber(m.sender),
          addedAt: new Date().toLocaleString('id-ID'),
          clicks: 0
        };
        
        linksData.links.unshift(newLink);
        storageSet(linksKey, JSON.stringify(linksData));
        
        let msg = `✅ Link berhasil disimpan!\n\n`;
        msg += `📎 *${newLink.title}*\n`;
        msg += `🔗 ${newLink.url}\n`;
        msg += `🏷️ ${newLink.category}\n\n`;
        msg += `Total link: ${linksData.links.length}`;
        
        m.reply(msg);
        
      } catch (e) {
        m.reply(`❌ Gagal menyimpan link!\n\nError: ${e.message}`);
      }
    }
    
    else if (command === "links" || command === "listlink") {
      try {
        let linksData = { links: [] };
        const result = storageGet(linksKey);
        if (result && result.value) {
          linksData = JSON.parse(result.value);
        }
        
        if (linksData.links.length === 0) {
          return m.reply("🔗 Belum ada link tersimpan.\n\nGunakan .addlink untuk menyimpan link.");
        }
        
        // Group by category
        const byCategory = {};
        linksData.links.forEach(link => {
          if (!byCategory[link.category]) {
            byCategory[link.category] = [];
          }
          byCategory[link.category].push(link);
        });
        
        let msg = `🔗 *LINK GRUP*\n`;
        msg += `Total: ${linksData.links.length} link\n\n`;
        
        Object.keys(byCategory).forEach(category => {
          msg += `*📁 ${category}*\n`;
          byCategory[category].forEach((link, i) => {
            msg += `${i + 1}. ${link.title}\n`;
            msg += `   ${link.url}\n`;
            msg += `   _${link.clicks} klik | ${link.addedAt}_\n\n`;
          });
        });
        
        msg += `*Kelola link:*\n`;
        msg += `.addlink - Tambah link\n`;
        msg += `.dellink [no] - Hapus link\n`;
        msg += `.searchlink [kata] - Cari link`;
        
        m.reply(msg);
        
      } catch (e) {
        m.reply(`❌ Gagal mengambil link!\n\nError: ${e.message}`);
      }
    }
    
    else if (command === "dellink" || command === "hapuslink") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      if (!text || isNaN(text)) {
        return m.reply(`❌ Masukkan nomor link yang ingin dihapus!

Gunakan .links untuk melihat nomor link.`);
      }
      
      try {
        const linkIndex = parseInt(text) - 1;
        let linksData = { links: [] };
        const result = storageGet(linksKey);
        if (result && result.value) {
          linksData = JSON.parse(result.value);
        }
        
        if (linkIndex < 0 || linkIndex >= linksData.links.length) {
          return m.reply(`❌ Nomor tidak valid! Total link: ${linksData.links.length}`);
        }
        
        const deleted = linksData.links.splice(linkIndex, 1)[0];
        storageSet(linksKey, JSON.stringify(linksData));
        
        m.reply(`✅ Link berhasil dihapus!\n\n_${deleted.title}_`);
        
      } catch (e) {
        m.reply(`❌ Gagal menghapus link!\n\nError: ${e.message}`);
      }
    }
    
    else if (command === "searchlink" || command === "carilink") {
      if (!text) {
        return m.reply("❌ Masukkan kata kunci pencarian!");
      }
      
      try {
        let linksData = { links: [] };
        const result = storageGet(linksKey);
        if (result && result.value) {
          linksData = JSON.parse(result.value);
        }
        
        const keyword = text.toLowerCase();
        const found = linksData.links.filter(link => 
          link.title.toLowerCase().includes(keyword) ||
          link.category.toLowerCase().includes(keyword) ||
          link.url.toLowerCase().includes(keyword)
        );
        
        if (found.length === 0) {
          return m.reply(`🔍 Tidak ditemukan link dengan kata kunci: "${text}"`);
        }
        
        let msg = `🔍 *HASIL PENCARIAN*\n`;
        msg += `Kata kunci: "${text}"\n`;
        msg += `Ditemukan: ${found.length} link\n\n`;
        
        found.forEach((link, i) => {
          msg += `${i + 1}. *${link.title}*\n`;
          msg += `   ${link.url}\n`;
          msg += `   🏷️ ${link.category}\n\n`;
        });
        
        m.reply(msg);
        
      } catch (e) {
        m.reply(`❌ Gagal mencari link!\n\nError: ${e.message}`);
      }
    }
    
    // ==========================================
    // FITUR 4: STATISTIK GRUP
    // ==========================================
    
    else if (command === "grupstats" || command === "statistik") {
      try {
        // Get all data
        let notesCount = 0, warningsCount = 0, todosCount = 0;
        let linksCount = 0, schedulesCount = 0;
        
        const notesResult = storageGet(`notes:${m.chat}`);
        if (notesResult?.value) {
          const data = JSON.parse(notesResult.value);
          notesCount = data.notes?.length || 0;
        }
        
        const warningsResult = storageGet(`warnings:${m.chat}`);
        if (warningsResult?.value) {
          const data = JSON.parse(warningsResult.value);
          warningsCount = Object.values(data.warnings || {}).reduce((sum, arr) => sum + arr.length, 0);
        }
        
        const todosResult = storageGet(`todo:${m.chat}`);
        if (todosResult?.value) {
          const data = JSON.parse(todosResult.value);
          todosCount = data.todos?.length || 0;
        }
        
        const linksResult = storageGet(linksKey);
        if (linksResult?.value) {
          const data = JSON.parse(linksResult.value);
          linksCount = data.links?.length || 0;
        }
        
        const schedulesResult = storageGet(scheduleKey);
        if (schedulesResult?.value) {
          const data = JSON.parse(schedulesResult.value);
          schedulesCount = data.schedules?.length || 0;
        }
        
        const memberCount = participants.length;
        const adminCount = participants.filter(p => p.admin).length;
        
        let msg = `📊 *STATISTIK GRUP*\n\n`;
        msg += `*${groupMetadata.subject}*\n\n`;
        msg += `👥 Total Member: ${memberCount}\n`;
        msg += `👮 Admin: ${adminCount}\n\n`;
        msg += `*Data Tersimpan:*\n`;
        msg += `📝 Catatan: ${notesCount}\n`;
        msg += `⚠️ Warning: ${warningsCount}\n`;
        msg += `✅ Todo: ${todosCount}\n`;
        msg += `🔗 Link: ${linksCount}\n`;
        msg += `📅 Jadwal: ${schedulesCount}\n\n`;
        msg += `_Update: ${new Date().toLocaleString('id-ID')}_`;
        
        m.reply(msg);
        
      } catch (e) {
        m.reply(`❌ Gagal mengambil statistik!\n\nError: ${e.message}`);
      }
    }
    
    // ==========================================
    // FITUR 5: QUICK REMINDER
    // ==========================================
    
    else if (command === "ingatkan" || command === "remind") {
      if (!text) {
        return m.reply(`❌ Format salah!

*Format:*
.ingatkan [pesan]

*Contoh:*
.ingatkan Jangan lupa meeting jam 2 siang
.ingatkan Submit tugas hari ini`);
      }
      
      try {
        let reminderData = { reminders: [] };
        const result = storageGet(reminderKey);
        if (result && result.value) {
          reminderData = JSON.parse(result.value);
        }
        
        const newReminder = {
          id: Date.now(),
          message: text,
          createdBy: extractCleanNumber(m.sender),
          createdAt: new Date().toLocaleString('id-ID')
        };
        
        reminderData.reminders.push(newReminder);
        storageSet(reminderKey, JSON.stringify(reminderData));
        
        let msg = `⏰ *REMINDER DIBUAT*\n\n`;
        msg += `📌 ${text}\n\n`;
        msg += `Oleh: @${extractCleanNumber(m.sender)}\n`;
        msg += `Waktu: ${newReminder.createdAt}\n\n`;
        msg += `_Bot akan mention semua member_`;
        
        // Mention all members
        const allMembers = participants.map(p => p.id);
        
        setTimeout(() => {
          conn.sendMessage(m.chat, {
            text: `🔔 *REMINDER*\n\n${text}\n\n@everyone`,
            mentions: allMembers
          });
        }, 1000);
        
        m.reply(msg, null, { mentions: [m.sender] });
        
      } catch (e) {
        m.reply(`❌ Gagal membuat reminder!\n\nError: ${e.message}`);
      }
    }
    
  } catch (e) {
    console.error('Error:', e);
    m.reply(`❌ Terjadi kesalahan!\n\nError: ${e.message}`);
  }
};



handler.help = [
  "buatpoll [pertanyaan | opsi1 | opsi2] - Buat polling",
  "vote [nomor] - Vote pada polling",
  "cekpoll - Lihat hasil polling",
  "tutuppoll - Tutup polling (admin)",
  "addjadwal [tanggal | waktu | acara] - Tambah jadwal",
  "jadwal - Lihat semua jadwal",
  "deljadwal [nomor] - Hapus jadwal",
  "addlink [judul | url | kategori] - Simpan link",
  "links - Lihat semua link",
  "searchlink [kata] - Cari link",
  "dellink [nomor] - Hapus link (admin)",
  "grupstats - Lihat statistik grup",
  "ingatkan [pesan] - Buat reminder untuk semua"
];

handler.tags = ["group"];
handler.command = [
  "buatpoll", "createpoll",
  "vote", "pilih",
  "cekpoll", "hasilpoll",
  "tutuppoll", "closepoll",
  "addjadwal", "tambahjadwal",
  "jadwal", "listjadwal", "schedule",
  "deljadwal", "hapusjadwal",
  "clearjadwal",
  "addlink", "simpanlink",
  "links", "listlink",
  "dellink", "hapuslink",
  "searchlink", "carilink",
  "grupstats", "statistik",
  "ingatkan", "remind"
];

handler.group = true;

export default handler;