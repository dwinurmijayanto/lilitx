import fs from 'fs';
import path from 'path';

// ========== TEST TRACKER ==========

const DATA_DIR = './data/group_tracker';

function getGroupDataPath(groupId) {
  const sanitized = groupId.replace(/[^a-zA-Z0-9]/g, '_');
  return path.join(DATA_DIR, `${sanitized}.json`);
}

function formatTimestamp(timestamp) {
  const date = new Date(timestamp);
  const options = {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    timeZone: 'Asia/Jakarta'
  };
  return date.toLocaleString('id-ID', options);
}

let handler = async (m, { conn, command, args }) => {
  try {
    console.log(`[${command}] === TEST TRACKER START ===`);
    
    if (command === 'testtracker') {
      // Test apakah file tracker sudah terbuat
      const groupId = m.chat;
      const filePath = getGroupDataPath(groupId);
      
      let report = `🧪 *TEST TRACKER REPORT*\n\n`;
      
      // Check 1: Folder exists
      if (fs.existsSync(DATA_DIR)) {
        report += `✅ Folder data exists: ${DATA_DIR}\n`;
      } else {
        report += `❌ Folder data NOT exists: ${DATA_DIR}\n`;
      }
      
      // Check 2: Group data file exists
      if (fs.existsSync(filePath)) {
        report += `✅ Group data file exists\n`;
        
        // Read data
        try {
          const data = fs.readFileSync(filePath, 'utf8');
          const groupData = JSON.parse(data);
          
          report += `\n📊 *CURRENT STATS:*\n`;
          report += `➕ Total Joins: ${groupData.stats.totalJoins}\n`;
          report += `➖ Total Leaves: ${groupData.stats.totalLeaves}\n`;
          report += `📝 Total Events: ${groupData.events.length}\n`;
          report += `🕐 Last Update: ${formatTimestamp(groupData.stats.lastUpdate)}\n`;
          
          if (groupData.events.length > 0) {
            report += `\n📋 *LATEST EVENT:*\n`;
            const latest = groupData.events[0];
            report += `${latest.type === 'join' ? '➕' : '➖'} ${latest.type.toUpperCase()}\n`;
            report += `👤 ${latest.participantName}\n`;
            report += `📅 ${latest.formattedTime}\n`;
          }
          
        } catch (readError) {
          report += `❌ Error reading data: ${readError.message}\n`;
        }
      } else {
        report += `⚠️ Group data file NOT exists yet\n`;
        report += `_File akan dibuat saat ada event join/leave pertama_\n`;
      }
      
      // Check 3: Handler status
      report += `\n🔧 *HANDLER INFO:*\n`;
      report += `• handler.before: Active\n`;
      report += `• messageStubType detection: Active\n`;
      report += `• Listening for: 27 (add), 28/32 (remove/leave)\n`;
      
      return m.reply(report);
    }
    
    if (command === 'debugmsg') {
      // Debug message properties
      let debug = `🐛 *MESSAGE DEBUG INFO*\n\n`;
      debug += `📍 *Basic Info:*\n`;
      debug += `• isGroup: ${m.isGroup}\n`;
      debug += `• chat: ${m.chat}\n`;
      debug += `• sender: ${m.sender}\n`;
      debug += `• mtype: ${m.mtype}\n`;
      debug += `\n📨 *Message Properties:*\n`;
      debug += `• messageStubType: ${m.messageStubType || 'undefined'}\n`;
      debug += `• messageStubParameters: ${m.messageStubParameters ? JSON.stringify(m.messageStubParameters) : 'undefined'}\n`;
      debug += `\n🔑 *Available Keys:*\n`;
      debug += Object.keys(m).slice(0, 20).join(', ') + '...\n';
      
      return m.reply(debug);
    }
    
    if (command === 'simulatetracker') {
      // Simulasi manual tracking event
      const groupId = m.chat;
      const timestamp = Date.now();
      
      // Load atau buat data baru
      let groupData = {
        groupId: groupId,
        stats: {
          totalJoins: 0,
          totalLeaves: 0,
          lastUpdate: Date.now()
        },
        events: []
      };
      
      const filePath = getGroupDataPath(groupId);
      if (fs.existsSync(filePath)) {
        const data = fs.readFileSync(filePath, 'utf8');
        groupData = JSON.parse(data);
      }
      
      // Buat event simulasi
      const eventData = {
        id: `${timestamp}_simulated`,
        type: 'join',
        participantJid: 'simulated@s.whatsapp.net',
        participantName: 'Test User (Simulated)',
        timestamp: timestamp,
        formattedTime: formatTimestamp(timestamp),
        groupId: groupId
      };
      
      // Tambahkan event
      groupData.events.unshift(eventData);
      groupData.stats.totalJoins++;
      groupData.stats.lastUpdate = timestamp;
      
      // Simpan
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      fs.writeFileSync(filePath, JSON.stringify(groupData, null, 2), 'utf8');
      
      return m.reply(`✅ *Simulated Event Created*\n\n📊 Stats updated:\n➕ Total Joins: ${groupData.stats.totalJoins}\n📝 Total Events: ${groupData.events.length}`);
    }
    
  } catch (error) {
    console.error(`[${command}] Error:`, error);
    return m.reply(`❌ Error: ${error.message}`);
  }
};

handler.help = [
  "testtracker - Cek status tracker",
  "debugmsg - Debug message properties",
  "simulatetracker - Buat event simulasi"
];

handler.tags = ["group", "owner"];

handler.command = ["testtracker", "debugmsg", "simulatetracker"];

handler.group = true;

export default handler;