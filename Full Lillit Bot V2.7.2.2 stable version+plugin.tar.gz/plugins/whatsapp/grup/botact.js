import os from "os";

let handler = async (m, { conn, config, command, args, usedPrefix = '.' }) => {
  try {
    // Extract text dari args array
    let text = Array.isArray(args) ? args.join(' ') : '';
    
    // Fallback: coba extract dari message body
    if (!text && m.body) {
      const commandPrefix = usedPrefix + command;
      if (m.body.startsWith(commandPrefix)) {
        text = m.body.slice(commandPrefix.length).trim();
      }
    }
    
    console.log('=== BOTACT HANDLER DEBUG ===');
    console.log('Command:', command);
    console.log('Args array:', args);
    console.log('Extracted text:', text);
    console.log('Message body:', m.body);
    
    // Fungsi untuk extract invite code dari berbagai format link
    const extractInviteCode = (input) => {
      if (!input) return null;
      
      // Pattern untuk berbagai format link WhatsApp
      const patterns = [
        /chat\.whatsapp\.com\/([a-zA-Z0-9_-]+)/i,  // https://chat.whatsapp.com/CODE
        /wa\.me\/([a-zA-Z0-9_-]+)/i,                // https://wa.me/CODE
        /whatsapp\.com\/accept\?code=([a-zA-Z0-9_-]+)/i, // Old format
        /^([a-zA-Z0-9_-]{20,30})$/  // Direct code (biasanya 22-24 karakter)
      ];
      
      for (const pattern of patterns) {
        const match = input.match(pattern);
        if (match && match[1]) {
          console.log('Invite code extracted:', match[1]);
          return match[1];
        }
      }
      
      return null;
    };
    
    // COMMAND: JOIN GROUP
    if (command === "join" || command === "joingrup" || command === "joingroup") {
      
      if (!text) {
        return m.reply(`❌ Masukkan link invite grup!

*Format yang didukung:*
• https://chat.whatsapp.com/CODE
• https://wa.me/CODE
• CODE (kode langsung)

*Contoh penggunaan:*
• ${usedPrefix}join https://chat.whatsapp.com/ABC123xyz
• ${usedPrefix}join ABC123xyz

💡 *Cara mendapatkan link invite:*
1. Buka grup yang ingin diundang bot
2. Ketik .linkgrup untuk mendapatkan link
3. Kirim link tersebut ke bot dengan command ${usedPrefix}join`);
      }
      
      const inviteCode = extractInviteCode(text);
      
      if (!inviteCode) {
        return m.reply(`❌ Link invite tidak valid!

*Format yang benar:*
• https://chat.whatsapp.com/CODE
• CODE (22-24 karakter)

*Contoh:*
${usedPrefix}join https://chat.whatsapp.com/ABC123xyz`);
      }
      
      try {
        console.log('Attempting to join group with code:', inviteCode);
        
        // Coba join grup menggunakan invite code
        const response = await conn.groupAcceptInvite(inviteCode);
        
        console.log('✅ Successfully joined group:', response);
        
        // Kirim konfirmasi ke user yang mengundang
        m.reply(`✅ *Berhasil bergabung ke grup!*

📋 *Group ID:* ${response}

Bot sekarang sudah bergabung dan siap digunakan.

💡 *Tips:*
• Jadikan bot sebagai admin untuk fitur lengkap
• Ketik .infogrup untuk info grup
• Ketik .menu untuk list command`);
        
        // Kirim pesan intro ke grup yang baru dimasuki (optional)
        try {
          await conn.sendMessage(response, {
            text: `👋 *Halo, saya Bot WhatsApp!*

Terima kasih telah mengundang saya ke grup ini.

🤖 *Tentang Bot:*
• Bot multifungsi untuk manajemen grup
• Ketik .menu untuk melihat semua command
• Ketik .infogrup untuk info grup

⚙️ *Rekomendasi:*
• Jadikan saya admin untuk fitur lengkap
• Gunakan .help untuk panduan lengkap

Mari kita mulai! 🚀`
          });
        } catch (introError) {
          console.log('⚠️ Could not send intro message:', introError.message);
        }
        
      } catch (e) {
        console.error('❌ Error joining group:', e);
        
        // Error handling yang lebih detail
        let errorMessage = "❌ Gagal bergabung ke grup!\n\n";
        
        if (e.message?.includes('invite code expired') || e.message?.includes('expired')) {
          errorMessage += "⚠️ *Link invite sudah kadaluarsa!*\n\nMinta link invite baru dari admin grup.";
        } else if (e.message?.includes('not-authorized') || e.message?.includes('forbidden')) {
          errorMessage += "⚠️ *Bot tidak memiliki izin!*\n\nKemungkinan:\n• Link invite salah\n• Grup membatasi join otomatis\n• Bot di-banned dari grup tersebut";
        } else if (e.message?.includes('gone')) {
          errorMessage += "⚠️ *Grup tidak ditemukan!*\n\nKemungkinan grup sudah dihapus atau link tidak valid.";
        } else if (e.message?.includes('bad-request')) {
          errorMessage += "⚠️ *Format invite code salah!*\n\nPastikan kode yang dimasukkan benar.";
        } else {
          errorMessage += `⚠️ *Error:* ${e.message}\n\n💡 Coba gunakan link invite yang baru atau hubungi admin grup.`;
        }
        
        m.reply(errorMessage);
      }
    }
    
    // COMMAND: LEAVE GROUP (Bot keluar dari grup)
    else if (command === "leave" || command === "out") {
      // Cek apakah command ini dipanggil di grup
      const isGroup = m.isGroup;
      
      if (!isGroup) {
        return m.reply("❌ Command ini hanya bisa digunakan di grup!");
      }
      
      // Cek apakah yang menggunakan command adalah owner bot (optional security)
      // Uncomment line berikut jika ingin hanya owner yang bisa kick bot
      // const isOwner = config?.owners?.includes(m.sender);
      // if (!isOwner) {
      //   return m.reply("❌ Command ini hanya untuk owner bot!");
      // }
      
      try {
        // Ambil metadata grup untuk pesan perpisahan
        const groupMetadata = await conn.groupMetadata(m.chat);
        const groupName = groupMetadata.subject;
        
        // Kirim pesan perpisahan
        await m.reply(`👋 *Terima kasih telah menggunakan bot!*

Saya akan keluar dari grup *${groupName}*.

Sampai jumpa lagi! 🙏`);
        
        // Tunggu sebentar agar pesan terkirim
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Bot keluar dari grup
        await conn.groupLeave(m.chat);
        
        console.log(`✅ Bot left group: ${groupName} (${m.chat})`);
        
      } catch (e) {
        console.error('❌ Error leaving group:', e);
        m.reply("❌ Gagal keluar dari grup! Cek console untuk detail error.");
      }
    }
    
    // COMMAND: AUTO JOIN STATUS (Check if auto-join is enabled)
    else if (command === "autojoin" || command === "autojoininfo") {
      const msg = `⚙️ *Auto Join Group Info*

*Status:* ✅ Aktif

Bot dapat bergabung ke grup melalui link invite.

*Cara menggunakan:*
1. Dapatkan link invite grup
   • Di grup: ketik .linkgrup
   
2. Kirim link ke bot
   • Format: ${usedPrefix}join [link/code]
   • Contoh: ${usedPrefix}join https://chat.whatsapp.com/ABC123

3. Bot otomatis bergabung
   • Konfirmasi akan dikirim ke anda
   • Bot akan intro di grup baru

*Command terkait:*
• ${usedPrefix}join [link] - Join grup
• ${usedPrefix}leave - Keluar dari grup
• ${usedPrefix}out - Keluar dari grup
• ${usedPrefix}linkgrup - Dapatkan link grup

💡 *Tips:*
• Pastikan link valid dan tidak expired
• Jadikan bot admin untuk fitur penuh
• Gunakan ${usedPrefix}infogrup untuk cek status`;
      
      m.reply(msg);
    }
    
    // COMMAND: LIST ALL GROUPS (Bot list semua grup yang diikuti)
    else if (command === "listgrup" || command === "listgroup" || command === "gruplist") {
      try {
        // Ambil semua chats
        const chats = Object.values(await conn.groupFetchAllParticipating());
        
        if (chats.length === 0) {
          return m.reply("📋 Bot belum bergabung di grup manapun!");
        }
        
        let msg = `📋 *LIST GRUP BOT*\n\n`;
        msg += `Total: ${chats.length} grup\n\n`;
        
        chats.forEach((group, index) => {
          msg += `${index + 1}. *${group.subject}*\n`;
          msg += `   ID: ${group.id}\n`;
          msg += `   Members: ${group.participants?.length || 0}\n`;
          msg += `   Created: ${new Date(group.creation * 1000).toLocaleDateString('id-ID')}\n\n`;
        });
        
        msg += `\n💡 Gunakan ${usedPrefix}infogrup di grup untuk detail lengkap`;
        
        m.reply(msg);
        
      } catch (e) {
        console.error('❌ Error listing groups:', e);
        m.reply("❌ Gagal mendapatkan list grup! Cek console untuk detail error.");
      }
    }
    
    // COMMAND: JOIN WITH VERIFY (Join dengan konfirmasi admin grup dulu)
    else if (command === "joinverify" || command === "requestjoin") {
      if (!text) {
        return m.reply(`❌ Masukkan link invite grup!

*Contoh:*
${usedPrefix}joinverify https://chat.whatsapp.com/ABC123xyz

Fitur ini akan mengirim request join ke admin grup terlebih dahulu.`);
      }
      
      const inviteCode = extractInviteCode(text);
      
      if (!inviteCode) {
        return m.reply(`❌ Link invite tidak valid!`);
      }
      
      try {
        // Get group info dari invite code
        const groupInfo = await conn.groupGetInviteInfo(inviteCode);
        
        const msg = `🔍 *Informasi Grup*

*Nama:* ${groupInfo.subject}
*ID:* ${groupInfo.id}
*Members:* ${groupInfo.size || 'Unknown'}
*Deskripsi:* ${groupInfo.desc || 'Tidak ada'}

⚠️ Apakah Anda yakin ingin join grup ini?

Reply dengan "ya" untuk join atau "tidak" untuk batal.`;
        
        m.reply(msg);
        
        // Store state untuk konfirmasi (simplified version)
        // Di implementasi real, gunakan proper state management
        
      } catch (e) {
        console.error('❌ Error getting group info:', e);
        m.reply("❌ Gagal mendapatkan info grup! Link mungkin expired atau invalid.");
      }
    }
    
    // COMMAND: GROUP INFO FROM LINK (Cek info grup tanpa join)
    else if (command === "checkgrup" || command === "checkgroup" || command === "grupinfo") {
      if (!text) {
        return m.reply(`❌ Masukkan link invite grup!

*Contoh:*
${usedPrefix}checkgrup https://chat.whatsapp.com/ABC123xyz

Cek info grup tanpa harus join.`);
      }
      
      const inviteCode = extractInviteCode(text);
      
      if (!inviteCode) {
        return m.reply(`❌ Link invite tidak valid!`);
      }
      
      try {
        const groupInfo = await conn.groupGetInviteInfo(inviteCode);
        
        const msg = `🔍 *INFORMASI GRUP*

╔═══════════════════
║ *Nama:* ${groupInfo.subject}
║ *ID:* ${groupInfo.id}
║ *Ukuran:* ${groupInfo.size || 'Unknown'} members
║ *Restrict:* ${groupInfo.restrict ? 'Ya' : 'Tidak'}
║ *Announce:* ${groupInfo.announce ? 'Ya' : 'Tidak'}
╠═══════════════════
║ *Deskripsi:*
║ ${groupInfo.desc || 'Tidak ada deskripsi'}
╠═══════════════════
║ *Created:* ${groupInfo.creation ? new Date(groupInfo.creation * 1000).toLocaleDateString('id-ID') : 'Unknown'}
╚═══════════════════

💡 Gunakan ${usedPrefix}join [link] untuk bergabung ke grup ini.`;
        
        m.reply(msg);
        
      } catch (e) {
        console.error('❌ Error getting group info:', e);
        
        let errorMsg = "❌ Gagal mendapatkan info grup!\n\n";
        
        if (e.message?.includes('expired')) {
          errorMsg += "⚠️ Link invite sudah expired!";
        } else if (e.message?.includes('not-authorized')) {
          errorMsg += "⚠️ Bot tidak memiliki akses ke info grup!";
        } else {
          errorMsg += `⚠️ ${e.message}`;
        }
        
        m.reply(errorMsg);
      }
    }
    
    // COMMAND: LEAVE FROM SPECIFIC GROUP (Leave dari grup tertentu via ID)
    else if (command === "leavefrom" || command === "keluardari") {
      if (!text) {
        return m.reply(`❌ Masukkan Group ID!

*Contoh:*
${usedPrefix}leavefrom 1234567890@g.us

💡 Gunakan ${usedPrefix}listgrup untuk melihat semua Group ID`);
      }
      
      try {
        // Validasi format Group ID
        if (!text.includes('@g.us')) {
          return m.reply("❌ Format Group ID salah! Harus berakhiran @g.us");
        }
        
        // Ambil metadata grup
        const groupMetadata = await conn.groupMetadata(text);
        const groupName = groupMetadata.subject;
        
        // Konfirmasi
        m.reply(`⚠️ *Konfirmasi Leave Grup*

Anda akan mengeluarkan bot dari:
*${groupName}*
(${text})

Bot akan keluar dalam 5 detik...`);
        
        // Tunggu 5 detik
        await new Promise(resolve => setTimeout(resolve, 5000));
        
        // Kirim pesan perpisahan ke grup
        try {
          await conn.sendMessage(text, {
            text: `👋 *Selamat tinggal!*

Saya telah diperintahkan untuk keluar dari grup ini.

Terima kasih atas waktunya! 🙏`
          });
        } catch (sendError) {
          console.log('⚠️ Could not send goodbye message:', sendError.message);
        }
        
        // Tunggu sebentar
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Leave grup
        await conn.groupLeave(text);
        
        m.reply(`✅ Berhasil keluar dari grup *${groupName}*!`);
        
      } catch (e) {
        console.error('❌ Error leaving group:', e);
        m.reply(`❌ Gagal keluar dari grup!

Kemungkinan:
• Group ID tidak valid
• Bot sudah tidak ada di grup tersebut
• Bot tidak memiliki akses

Error: ${e.message}`);
      }
    }
    
    // COMMAND: BROADCAST TO ALL GROUPS
    else if (command === "bcgrup" || command === "bcgroup" || command === "broadcastgroup") {
      // Security: Hanya owner yang bisa broadcast
      // Uncomment jika ingin aktifkan
      // const isOwner = config?.owners?.includes(m.sender);
      // if (!isOwner) {
      //   return m.reply("❌ Command ini hanya untuk owner bot!");
      // }
      
      if (!text) {
        return m.reply(`❌ Masukkan pesan yang ingin di-broadcast!

*Contoh:*
${usedPrefix}bcgrup Halo semua! Ini adalah pengumuman penting.

⚠️ Pesan akan dikirim ke SEMUA grup yang diikuti bot!`);
      }
      
      try {
        const chats = Object.values(await conn.groupFetchAllParticipating());
        
        if (chats.length === 0) {
          return m.reply("📋 Bot belum bergabung di grup manapun!");
        }
        
        m.reply(`📢 Memulai broadcast ke ${chats.length} grup...\n\nMohon tunggu...`);
        
        let success = 0;
        let failed = 0;
        
        for (const group of chats) {
          try {
            const bcMessage = `📢 *BROADCAST MESSAGE*\n\n${text}\n\n_Pesan ini dikirim ke semua grup bot_`;
            
            await conn.sendMessage(group.id, {
              text: bcMessage
            });
            
            success++;
            
            // Delay agar tidak kena rate limit
            await new Promise(resolve => setTimeout(resolve, 1000));
            
          } catch (sendError) {
            console.error(`Failed to send to ${group.subject}:`, sendError);
            failed++;
          }
        }
        
        m.reply(`✅ *Broadcast Selesai!*

📊 *Statistik:*
• Total grup: ${chats.length}
• Berhasil: ${success}
• Gagal: ${failed}

${failed > 0 ? '⚠️ Beberapa grup gagal menerima pesan. Cek console untuk detail.' : '✅ Semua grup berhasil menerima pesan!'}`);
        
      } catch (e) {
        console.error('❌ Error broadcasting:', e);
        m.reply("❌ Gagal melakukan broadcast! Cek console untuk detail error.");
      }
    }
    
    // COMMAND: INVITE USER TO GROUP (Undang user ke grup tertentu)
    else if (command === "inviteto" || command === "undangke") {
      if (!m.isGroup) {
        return m.reply("❌ Command ini hanya bisa digunakan di grup!");
      }
      
      if (!text) {
        return m.reply(`❌ Tag user yang ingin diundang!

*Contoh:*
${usedPrefix}inviteto @user

User akan mendapatkan link invite grup ini.`);
      }
      
      try {
        // Extract user
        let targetUser = null;
        
        if (m.mentionedJid && m.mentionedJid.length > 0) {
          targetUser = m.mentionedJid[0];
        } else if (m.quoted) {
          targetUser = m.quoted.sender;
        }
        
        if (!targetUser) {
          return m.reply("❌ Tag atau reply user yang ingin diundang!");
        }
        
        // Dapatkan link grup
        const code = await conn.groupInviteCode(m.chat);
        const groupMetadata = await conn.groupMetadata(m.chat);
        const groupName = groupMetadata.subject;
        
        // Kirim invite ke user
        await conn.sendMessage(targetUser, {
          text: `📨 *UNDANGAN GRUP*

Anda diundang untuk bergabung ke grup:
*${groupName}*

🔗 *Link Invite:*
https://chat.whatsapp.com/${code}

Klik link di atas untuk bergabung!`
        });
        
        m.reply(`✅ Undangan berhasil dikirim ke @${targetUser.split('@')[0]}!`, null, {
          mentions: [targetUser]
        });
        
      } catch (e) {
        console.error('❌ Error sending invite:', e);
        m.reply("❌ Gagal mengirim undangan! Pastikan bot adalah admin grup.");
      }
    }
    
    // COMMAND: AUTO ACCEPT JOIN REQUEST (Terima semua request join otomatis)
    else if (command === "autoaccept" || command === "autojoinrequest") {
      if (!m.isGroup) {
        return m.reply("❌ Command ini hanya bisa digunakan di grup!");
      }
      
      const msg = `⚙️ *AUTO ACCEPT JOIN REQUEST*

Fitur ini akan membuat bot otomatis menerima semua request join grup.

*Status:* Coming Soon

*Note:* Fitur ini memerlukan event listener untuk join request. Implementasi tergantung pada library WhatsApp yang digunakan.

💡 Alternatif:
• Gunakan ${usedPrefix}add [nomor] untuk manual add
• Set grup ke "Semua orang bisa mengirim pesan"`;
      
      m.reply(msg);
    }
    
  } catch (e) {
    console.error('❌ BOTACT MAIN ERROR:', e);
    console.error('Stack trace:', e.stack);
    m.reply("❌ Terjadi kesalahan! Cek console untuk detail error.");
  }
};

handler.help = [
  "join [link/code] - Bot join ke grup via invite",
  "leave - Bot keluar dari grup (di grup)",
  "out - Bot keluar dari grup (di grup)",
  "autojoin - Info auto join status",
  "listgrup - List semua grup bot",
  "checkgrup [link] - Cek info grup tanpa join",
  "joinverify [link] - Join dengan konfirmasi",
  "leavefrom [groupID] - Leave dari grup tertentu",
  "bcgrup [pesan] - Broadcast ke semua grup",
  "inviteto @user - Kirim invite grup ke user",
  "autoaccept - Auto terima join request"
];

handler.tags = ["owner", "group"];

handler.command = [
  "join", "joingrup", "joingroup",
  "leave", "out",
  "autojoin", "autojoininfo",
  "listgrup", "listgroup", "gruplist",
  "checkgrup", "checkgroup", "grupinfo",
  "joinverify", "requestjoin",
  "leavefrom", "keluardari",
  "bcgrup", "bcgroup", "broadcastgroup",
  "inviteto", "undangke",
  "autoaccept", "autojoinrequest"
];

// Join bisa dipanggil di private atau grup
handler.group = false;

// Leave hanya di grup (dicek di dalam handler)
handler.admin = false;
handler.botAdmin = false;

// Uncomment jika ingin hanya owner yang bisa join/leave
// handler.owner = true;
handler.owner = false;

handler.mods = false;
handler.premium = false;

export default handler;