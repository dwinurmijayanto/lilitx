import fs from 'fs';
import path from 'path';

// ========== STORAGE HELPER ==========

const DATA_DIR = './data/group_tracker';

// Fungsi untuk mendapatkan path file data grup
function getGroupDataPath(groupId) {
  const sanitized = groupId.replace(/[^a-zA-Z0-9]/g, '_');
  return path.join(DATA_DIR, `${sanitized}.json`);
}

// Load data grup
function loadGroupData(groupId) {
  try {
    const filePath = getGroupDataPath(groupId);
    if (fs.existsSync(filePath)) {
      const data = fs.readFileSync(filePath, 'utf8');
      return JSON.parse(data);
    }
  } catch (error) {
    console.error('[Stats] Error loading data:', error);
  }
  
  return null;
}

// Save data grup
function saveGroupData(groupId, data) {
  try {
    const filePath = getGroupDataPath(groupId);
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (error) {
    console.error('[Stats] Error saving data:', error);
    return false;
  }
}

// ========== HELPER FUNCTIONS ==========

function formatTimestamp(timestamp) {
  const date = new Date(timestamp);
  const options = {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    timeZone: 'Asia/Jakarta'
  };
  return date.toLocaleString('id-ID', options);
}

function getRelativeTime(timestamp) {
  const now = Date.now();
  const diff = now - timestamp;
  
  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  const months = Math.floor(days / 30);
  
  if (months > 0) return `${months} bulan yang lalu`;
  if (days > 0) return `${days} hari yang lalu`;
  if (hours > 0) return `${hours} jam yang lalu`;
  if (minutes > 0) return `${minutes} menit yang lalu`;
  return `${seconds} detik yang lalu`;
}

// ========== COMMAND HANDLERS ==========

async function showStats(conn, m) {
  try {
    const groupId = m.chat;
    
    // React loading
    await conn.sendMessage(m.chat, {
      react: { text: "⏳", key: m.key }
    });
    
    // Load data
    const groupData = loadGroupData(groupId);
    
    if (!groupData) {
      await conn.sendMessage(m.chat, {
        react: { text: "❌", key: m.key }
      });
      return m.reply('📊 Belum ada data statistik untuk grup ini.');
    }
    
    const stats = groupData.stats;
    const message = `📊 *STATISTIK GRUP*

➕ Total Bergabung: *${stats.totalJoins}*
➖ Total Keluar: *${stats.totalLeaves}*
📈 Perubahan Bersih: *${stats.totalJoins - stats.totalLeaves}*

📅 Update Terakhir: ${formatTimestamp(stats.lastUpdate)}
⏰ ${getRelativeTime(stats.lastUpdate)}`;
    
    await conn.sendMessage(m.chat, {
      react: { text: "✅", key: m.key }
    });
    
    return m.reply(message);
    
  } catch (error) {
    console.error('[Stats] Error:', error);
    await conn.sendMessage(m.chat, {
      react: { text: "❌", key: m.key }
    });
    return m.reply('❌ Terjadi kesalahan saat mengambil statistik.');
  }
}

async function showHistory(conn, m, limit = 10, type = 'all') {
  try {
    const groupId = m.chat;
    
    // React loading
    await conn.sendMessage(m.chat, {
      react: { text: "⏳", key: m.key }
    });
    
    // Load data
    const groupData = loadGroupData(groupId);
    
    if (!groupData || groupData.events.length === 0) {
      await conn.sendMessage(m.chat, {
        react: { text: "❌", key: m.key }
      });
      return m.reply('📜 Belum ada riwayat aktivitas untuk grup ini.');
    }
    
    let events = groupData.events;
    
    // Filter by type jika diminta
    if (type === 'join') {
      events = events.filter(e => e.type === 'join');
    } else if (type === 'leave') {
      events = events.filter(e => e.type === 'leave');
    }
    
    // Batasi jumlah
    const displayEvents = events.slice(0, limit);
    
    let message = `📜 *RIWAYAT AKTIVITAS GRUP*\n`;
    message += `_Menampilkan ${displayEvents.length} dari ${events.length} event_\n\n`;
    
    displayEvents.forEach((event, index) => {
      const emoji = event.type === 'join' ? '➕' : '➖';
      const action = event.type === 'join' ? 'Bergabung' : 'Keluar';
      
      message += `${emoji} *${action}*\n`;
      message += `👤 ${event.participantName}\n`;
      message += `⏰ ${getRelativeTime(event.timestamp)}\n`;
      message += `📅 ${event.formattedTime}\n`;
      
      if (index < displayEvents.length - 1) {
        message += `\n`;
      }
    });
    
    if (events.length > limit) {
      message += `\n\n_Ketik *${m.usedPrefix || '.'}trackhistory ${limit + 10}* untuk melihat lebih banyak_`;
    }
    
    await conn.sendMessage(m.chat, {
      react: { text: "✅", key: m.key }
    });
    
    return m.reply(message);
    
  } catch (error) {
    console.error('[History] Error:', error);
    await conn.sendMessage(m.chat, {
      react: { text: "❌", key: m.key }
    });
    return m.reply('❌ Terjadi kesalahan saat mengambil riwayat.');
  }
}

async function resetTracking(conn, m) {
  try {
    const groupId = m.chat;
    
    // React loading
    await conn.sendMessage(m.chat, {
      react: { text: "⏳", key: m.key }
    });
    
    // Hapus file data
    try {
      const filePath = getGroupDataPath(groupId);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    } catch (err) {
      console.log('[Reset] Error deleting file:', err);
    }
    
    await conn.sendMessage(m.chat, {
      react: { text: "✅", key: m.key }
    });
    
    return m.reply('🗑️ *Data tracking berhasil direset!*\n\nSemua statistik dan riwayat telah dihapus.');
    
  } catch (error) {
    console.error('[Reset] Error:', error);
    await conn.sendMessage(m.chat, {
      react: { text: "❌", key: m.key }
    });
    return m.reply('❌ Terjadi kesalahan saat mereset data.');
  }
}

// ========== MAIN HANDLER ==========

let handler = async (m, { conn, command, args, usedPrefix = '.', isAdmin, isOwner }) => {
  try {
    console.log(`[${command}] Command dipanggil oleh: ${m.sender}`);
    console.log(`[${command}] Chat ID: ${m.chat}`);
    console.log(`[${command}] Args:`, args);
    
    // Routing command
    if (command === 'trackstats' || command === 'statsgrup') {
      return await showStats(conn, m);
    }
    
    if (command === 'trackhistory' || command === 'historygrup' || command === 'history') {
      const limit = parseInt(args[0]) || 10;
      const type = args[1] || 'all'; // all, join, leave
      return await showHistory(conn, m, limit, type);
    }
    
    if (command === 'trackreset' || command === 'resettrack') {
      // Hanya admin atau owner yang bisa reset
      if (!isAdmin && !isOwner) {
        return m.reply('⛔ Hanya admin grup yang dapat mereset data tracking.');
      }
      return await resetTracking(conn, m);
    }
    
    // Default: tampilkan help
    const helpMsg = `📊 *GROUP MEMBER TRACKER*

*Fitur:*
Bot akan otomatis mencatat setiap anggota yang masuk dan keluar dari grup.

*Command tersedia:*

*${usedPrefix}trackstats*
Menampilkan statistik grup (total join/leave)

*${usedPrefix}trackhistory [limit] [type]*
Menampilkan riwayat aktivitas
• limit: jumlah event (default 10)
• type: all/join/leave (default all)

Contoh:
${usedPrefix}trackhistory 20
${usedPrefix}trackhistory 15 join
${usedPrefix}trackhistory 10 leave

*${usedPrefix}trackreset* _(admin only)_
Mereset semua data tracking

*Catatan:*
• Bot akan otomatis mencatat tanpa perlu command
• Data disimpan di folder ./data/group_tracker
• Maksimal 500 event terakhir per grup`;

    return m.reply(helpMsg);
    
  } catch (error) {
    console.error(`[${command}] Error:`, error);
    console.error(`[${command}] Stack trace:`, error.stack);
    
    await conn.sendMessage(m.chat, {
      react: { text: "❌", key: m.key }
    });
    
    return m.reply(`❌ Terjadi kesalahan.\n\nError: ${error.message}`);
  }
};

// ========== HANDLER CONFIGURATION ==========

handler.help = [
  "tracker - Panduan group tracker",
  "trackstats - Lihat statistik grup",
  "trackhistory [limit] [type] - Lihat riwayat aktivitas",
  "trackreset - Reset data tracking (admin)"
];

handler.tags = ["group"];

handler.command = [
  "tracker",
  "track",
  "trackstats",
  "statsgrup",
  "trackhistory",
  "historygrup",
  "history",
  "trackreset",
  "resettrack"
];

handler.group = true;
handler.admin = false;
handler.botAdmin = false;

export default handler;