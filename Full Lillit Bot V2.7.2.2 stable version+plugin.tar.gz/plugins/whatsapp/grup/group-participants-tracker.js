import fs from 'fs';
import path from 'path';

// ========== STORAGE HELPER ==========

const DATA_DIR = './data/group_tracker';

// Pastikan folder data ada
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

function getGroupDataPath(groupId) {
  const sanitized = groupId.replace(/[^a-zA-Z0-9]/g, '_');
  return path.join(DATA_DIR, `${sanitized}.json`);
}

function loadGroupData(groupId) {
  try {
    const filePath = getGroupDataPath(groupId);
    if (fs.existsSync(filePath)) {
      const data = fs.readFileSync(filePath, 'utf8');
      return JSON.parse(data);
    }
  } catch (error) {
    console.error('[ParticipantTracker] Error loading data:', error);
  }
  
  return {
    groupId: groupId,
    stats: {
      totalJoins: 0,
      totalLeaves: 0,
      lastUpdate: Date.now()
    },
    events: []
  };
}

function saveGroupData(groupId, data) {
  try {
    const filePath = getGroupDataPath(groupId);
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (error) {
    console.error('[ParticipantTracker] Error saving data:', error);
    return false;
  }
}

function formatTimestamp(timestamp) {
  const date = new Date(timestamp);
  const options = {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    timeZone: 'Asia/Jakarta'
  };
  return date.toLocaleString('id-ID', options);
}

// ========== PARTICIPANT UPDATE HANDLER ==========

async function handleParticipantsUpdate(conn, { id, participants, action }) {
  try {
    console.log('[ParticipantTracker] === PARTICIPANTS UPDATE ===');
    console.log('[ParticipantTracker] Group ID:', id);
    console.log('[ParticipantTracker] Action:', action);
    console.log('[ParticipantTracker] Participants:', participants);
    
    const groupId = id;
    const timestamp = Date.now();
    
    // Deteksi action: add, remove, promote, demote
    if (!['add', 'remove'].includes(action)) {
      console.log('[ParticipantTracker] Skipped: Action is', action);
      return;
    }
    
    // Load data grup
    const groupData = loadGroupData(groupId);
    
    // Tentukan jenis event
    let eventType = action === 'add' ? 'join' : 'leave';
    let emoji = action === 'add' ? '➕' : '➖';
    
    // Proses setiap participant
    for (const participantJid of participants) {
      try {
        // Ambil info participant
        let participantName = participantJid;
        try {
          participantName = await conn.getName(participantJid) || participantJid.split('@')[0];
        } catch (err) {
          participantName = participantJid.split('@')[0];
        }
        
        // Buat event data
        const eventData = {
          id: `${timestamp}_${participantJid}`,
          type: eventType,
          participantJid: participantJid,
          participantName: participantName,
          timestamp: timestamp,
          formattedTime: formatTimestamp(timestamp),
          groupId: groupId
        };
        
        // Tambahkan event ke array (max 500)
        groupData.events.unshift(eventData);
        if (groupData.events.length > 500) {
          groupData.events = groupData.events.slice(0, 500);
        }
        
        // Update stats
        if (eventType === 'join') {
          groupData.stats.totalJoins++;
        } else {
          groupData.stats.totalLeaves++;
        }
        groupData.stats.lastUpdate = timestamp;
        
        // Simpan data
        saveGroupData(groupId, groupData);
        
        console.log('[ParticipantTracker] ✅ Event saved:', eventData);
        console.log('[ParticipantTracker] Stats:', groupData.stats);
        
        // Kirim notifikasi ke grup
        const message = eventType === 'join' 
          ? `${emoji} *Anggota Bergabung*\n\n👤 ${participantName}\n📅 ${formatTimestamp(timestamp)}\n\n📊 Total bergabung: ${groupData.stats.totalJoins}`
          : `${emoji} *Anggota Keluar*\n\n👤 ${participantName}\n📅 ${formatTimestamp(timestamp)}\n\n📊 Total keluar: ${groupData.stats.totalLeaves}`;
        
        await conn.sendMessage(groupId, { text: message });
        
      } catch (participantError) {
        console.error('[ParticipantTracker] Error processing participant:', participantError);
      }
    }
    
  } catch (error) {
    console.error('[ParticipantTracker] Error in handler:', error);
    console.error('[ParticipantTracker] Stack:', error.stack);
  }
}

// ========== MAIN HANDLER ==========

let handler = async (m, { conn }) => {
  // Dummy handler
  return;
};

// ========== HANDLER CONFIGURATION ==========

handler.help = [];
handler.tags = [];
handler.command = ["trackparticipants"]; // Dummy command yang tidak akan dipakai

// Event listener untuk group-participants.update
handler.group = true;

// Jika bot framework mendukung event listener
handler.participantsUpdate = async function ({ id, participants, action }, { conn }) {
  await handleParticipantsUpdate(conn, { id, participants, action });
};

export default handler;