// =========================================
// FILE: plugins/whatsapp/grup/antilink.js
// Plugin Anti-Link (mandiri, pola sama seperti group-welcome.js)
// Hanya handle command ON/OFF/STATUS
// Penghapusan link dilakukan oleh listener di index.js
// =========================================

import fs from 'fs';
import path from 'path';

const SETTINGS_DIR = './data/antilink';
if (!fs.existsSync(SETTINGS_DIR)) {
  fs.mkdirSync(SETTINGS_DIR, { recursive: true });
}

function getFilePath(groupId) {
  const sanitized = groupId.replace(/[^a-zA-Z0-9@.-]/g, '_');
  return path.join(SETTINGS_DIR, `${sanitized}.json`);
}

function loadAntiLinkSettings(groupId) {
  const filePath = getFilePath(groupId);
  if (fs.existsSync(filePath)) {
    try {
      return JSON.parse(fs.readFileSync(filePath, 'utf8'));
    } catch (err) {
      console.error('[AntiLink] Error parse settings:', err.message);
    }
  }
  return { enabled: false };
}

function saveAntiLinkSettings(groupId, settings) {
  try {
    const filePath = getFilePath(groupId);
    fs.writeFileSync(filePath, JSON.stringify(settings, null, 2), 'utf8');
    return true;
  } catch (err) {
    console.error('[AntiLink] Error saving settings:', err.message);
    return false;
  }
}

// Fungsi isAdmin mandiri (tidak bergantung welcome-bye-handler)
async function isAdmin(conn, groupId, userId) {
  try {
    const meta = await conn.groupMetadata(groupId);
    const participant = meta.participants.find(p => p.id === userId);
    return participant && (participant.admin === 'admin' || participant.admin === 'superadmin');
  } catch (err) {
    console.error('[AntiLink] Error checking admin:', err.message);
    return false;
  }
}

/**
 * MAIN HANDLER - Anti-Link System
 */
async function handler(m, { conn, text, command, isAdmin: isAdminCheck, args, usedPrefix }) {
  const groupId = m.chat;
  const sender = m.sender;

  if (!m.isGroup) {
    return m.reply('❌ Command ini hanya bisa digunakan di grup!');
  }

  // Gunakan isAdminCheck dari Baileys jika ada, atau cek manual
  const isAdminUser = isAdminCheck || await isAdmin(conn, groupId, sender);

  const adminCommands = [
    'antilinkon',
    'antilinkoff',
    'antilinkstatus',
    'cekantilink'
  ];

  if (adminCommands.includes(command) && !isAdminUser) {
    return m.reply('❌ Hanya admin yang bisa menggunakan command ini!');
  }

  const settings = loadAntiLinkSettings(groupId);

  // ========== ANTI-LINK COMMANDS ==========

  if (command === 'antilinkon') {
    settings.enabled = true;
    if (saveAntiLinkSettings(groupId, settings)) {
      return m.reply('✅ *Anti-Link berhasil diaktifkan!*\nSemua pesan berisi link akan dihapus otomatis (kecuali dari admin).');
    } else {
      return m.reply('❌ Gagal menyimpan pengaturan!');
    }
  }

  if (command === 'antilinkoff') {
    settings.enabled = false;
    if (saveAntiLinkSettings(groupId, settings)) {
      return m.reply('❌ *Anti-Link berhasil dinonaktifkan.*');
    } else {
      return m.reply('❌ Gagal menyimpan pengaturan!');
    }
  }

  if (command === 'antilinkstatus' || command === 'cekantilink') {
    const status = `╭─「 *ANTI-LINK SETTINGS* 」
│
│ *Status:* ${settings.enabled ? '✅ Aktif' : '❌ Nonaktif'}
│ *Perlindungan admin:* Ya (link dari admin aman)
│
╰────────────────
*Commands:*
• ${usedPrefix}antilinkon     - Aktifkan anti-link
• ${usedPrefix}antilinkoff    - Nonaktifkan anti-link
• ${usedPrefix}antilinkstatus - Cek status anti-link
• ${usedPrefix}cekantilink    - Cek status (alternatif)`;

    return m.reply(status);
  }
}

// Handler config (pola sama seperti group-welcome.js)
handler.help = [
  "antilinkon - Aktifkan anti-link",
  "antilinkoff - Nonaktifkan anti-link",
  "antilinkstatus - Cek status anti-link",
  "cekantilink - Cek status anti-link (alternatif)"
];

handler.tags = ["group"];

handler.command = [
  "antilinkon",
  "antilinkoff",
  "antilinkstatus",
  "cekantilink"
];

handler.group = true;

export default handler;