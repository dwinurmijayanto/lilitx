/**
 * ========================================
 * DELETE MESSAGE HANDLER
 * ========================================
 * Fitur hapus pesan untuk semua (delete for everyone)
 * dengan cara reply pesan yang ingin dihapus
 * 
 * Cara pakai:
 * 1. Reply pesan yang ingin dihapus
 * 2. Ketik .del atau .delete atau .hapus
 * 
 * Aturan:
 * - Member biasa: hanya bisa hapus pesan sendiri
 * - Admin grup: bisa hapus pesan siapa saja (tanpa perlu bot admin)
 * - Bot harus admin: hanya jika member biasa hapus pesan orang lain
 */

let handler = async (m, { conn, command, usedPrefix }) => {
  try {
    console.log('=== DELETE MESSAGE DEBUG ===');
    console.log('Command:', command);
    console.log('User:', m.sender);
    console.log('Chat:', m.chat);
    console.log('Is Group:', m.isGroup);
    
    // Cek apakah di grup atau private chat
    const isGroup = m.isGroup;
    
    if (!isGroup) {
      return m.reply("❌ Command ini hanya bisa digunakan di grup!");
    }
    
    // Ambil metadata grup untuk cek admin
    const groupMetadata = await conn.groupMetadata(m.chat);
    const participants = groupMetadata.participants;
    
    // Fungsi untuk extract nomor bersih dari JID
    const extractCleanNumber = (jid) => {
      if (!jid) return null;
      const match = jid.match(/^(\d+)/);
      return match ? match[1] : null;
    };
    
    // Cek apakah user adalah admin
    const userParticipant = participants.find(p => p.id === m.sender);
    const isUserAdmin = userParticipant?.admin === 'admin' || userParticipant?.admin === 'superadmin';
    
    console.log('Is User Admin:', isUserAdmin);
    
    // Cek apakah bot adalah admin
    let botNumber = conn.user?.id || conn.authState?.creds?.me?.id || 'Unknown';
    let botNumberClean = extractCleanNumber(botNumber);
    
    const botParticipant = participants.find(p => {
      const cleanP = extractCleanNumber(p.id);
      return cleanP === botNumberClean;
    });
    
    const isBotAdmin = botParticipant?.admin === 'admin' || botParticipant?.admin === 'superadmin';
    
    console.log('Is Bot Admin:', isBotAdmin);
    console.log('Has quoted message:', !!m.quoted);
    
    // ========== EXTRACT RAW MESSAGE & CONTEXT INFO (POLA DARI GROUP HANDLER) ==========
    let rawMessage = m.message;
    let contextInfo = null;
    let quotedMessage = null;
    
    console.log('Raw message keys:', Object.keys(rawMessage || {}));
    
    // Extract contextInfo berdasarkan tipe message
    if (rawMessage) {
      if (rawMessage.extendedTextMessage) {
        contextInfo = rawMessage.extendedTextMessage.contextInfo;
        console.log('Found contextInfo in extendedTextMessage');
      } else if (rawMessage.imageMessage) {
        contextInfo = rawMessage.imageMessage.contextInfo;
        console.log('Found contextInfo in imageMessage');
      } else if (rawMessage.videoMessage) {
        contextInfo = rawMessage.videoMessage.contextInfo;
        console.log('Found contextInfo in videoMessage');
      } else if (rawMessage.audioMessage) {
        contextInfo = rawMessage.audioMessage.contextInfo;
        console.log('Found contextInfo in audioMessage');
      } else if (rawMessage.documentMessage) {
        contextInfo = rawMessage.documentMessage.contextInfo;
        console.log('Found contextInfo in documentMessage');
      } else if (rawMessage.stickerMessage) {
        contextInfo = rawMessage.stickerMessage.contextInfo;
        console.log('Found contextInfo in stickerMessage');
      }
      
      if (contextInfo) {
        quotedMessage = contextInfo.quotedMessage;
        console.log('Has contextInfo:', true);
        console.log('contextInfo keys:', Object.keys(contextInfo));
        console.log('stanzaId:', contextInfo.stanzaId);
        console.log('participant:', contextInfo.participant);
      }
    }
    
    console.log('Has quotedMessage:', !!quotedMessage);
    console.log('m.quoted exists:', !!m.quoted);
    
    // Cek apakah ada pesan yang direply
    if (!m.quoted && !contextInfo) {
      return m.reply(`❌ *Tidak ada pesan yang direply!*

*📝 Cara pakai:*
1. Reply pesan yang ingin dihapus
2. Ketik: ${usedPrefix}del

*✅ Aturan:*
• Member biasa → Hanya bisa hapus pesan sendiri
• Admin grup → Bisa hapus pesan siapa saja
• Bot harus admin → Untuk member hapus pesan orang lain

*💡 Contoh:*
[Reply pesan target] → ${usedPrefix}del`);
    }
    
    // ========== EXTRACT QUOTED KEY DENGAN MULTIPLE METHOD ==========
    let quotedKey = null;
    let quotedSender = null;
    
    console.log('\n=== EXTRACTING QUOTED MESSAGE KEY ===');
    
    // Method 1: Dari m.quoted.key (jika ada)
    if (m.quoted?.key) {
      quotedKey = m.quoted.key;
      quotedSender = m.quoted.sender || m.quoted.participant;
      console.log('Method 1: Using m.quoted.key');
      console.log('Quoted key:', JSON.stringify(quotedKey, null, 2));
    }
    
    // Method 2: Build dari contextInfo.stanzaId (lebih reliable)
    if (contextInfo?.stanzaId) {
      quotedKey = {
        remoteJid: m.chat,
        fromMe: false,
        id: contextInfo.stanzaId,
        participant: contextInfo.participant
      };
      quotedSender = contextInfo.participant;
      console.log('Method 2: Built from contextInfo.stanzaId');
      console.log('Quoted key:', JSON.stringify(quotedKey, null, 2));
    }
    
    // Validasi key
    if (!quotedKey || !quotedKey.id) {
      console.error('❌ Cannot extract quoted message key!');
      console.error('m.quoted:', m.quoted);
      console.error('contextInfo:', contextInfo);
      
      return m.reply(`❌ *Gagal mendapatkan info pesan!*

*Kemungkinan penyebab:*
• Pesan terlalu lama
• Format pesan tidak didukung
• Error sistem WhatsApp

*Debug Info:*
• Has m.quoted: ${!!m.quoted}
• Has contextInfo: ${!!contextInfo}
• Has stanzaId: ${!!contextInfo?.stanzaId}

*Solusi:*
• Coba reply pesan yang lebih baru
• Restart bot dan coba lagi`);
    }
    
    const quotedFromMe = quotedKey?.fromMe || false;
    
    console.log('\n=== FINAL EXTRACTED INFO ===');
    console.log('Quoted Key:', JSON.stringify(quotedKey, null, 2));
    console.log('Quoted Sender:', quotedSender);
    console.log('Quoted From Me:', quotedFromMe);
    console.log('Message Sender:', m.sender);
    
    // Cek apakah pesan milik sendiri
    const isOwnMessage = quotedSender === m.sender || quotedFromMe;
    
    console.log('Is Own Message:', isOwnMessage);
    console.log('User is admin:', isUserAdmin);
    console.log('Bot is admin:', isBotAdmin);
    
    // Admin langsung bisa hapus, tidak perlu validasi
    // Bot admin tidak diperlukan jika user adalah admin
    
    // ========== HAPUS PESAN ==========
    try {
      console.log('\n=== ATTEMPTING TO DELETE MESSAGE ===');
      console.log('Using key:', JSON.stringify(quotedKey, null, 2));
      
      // Hapus pesan yang direply
      await conn.sendMessage(m.chat, { 
        delete: quotedKey 
      });
      
      console.log('✅ Message deleted successfully');
      
      // Kirim konfirmasi
      const confirmMsg = await m.reply("✅ Pesan berhasil dihapus untuk semua!");
      
      // Auto cleanup: hapus command delete dan konfirmasi setelah 3 detik
      setTimeout(async () => {
        try {
          await conn.sendMessage(m.chat, { delete: m.key });
          await conn.sendMessage(m.chat, { delete: confirmMsg.key });
          console.log('✅ Cleanup: Command and confirmation deleted');
        } catch (cleanupErr) {
          console.error('⚠️ Failed to cleanup messages:', cleanupErr.message);
        }
      }, 3000);
      
    } catch (error) {
      console.error('\n❌ ERROR DELETING MESSAGE');
      console.error('Error message:', error.message);
      console.error('Error name:', error.name);
      console.error('Error stack:', error.stack);
      
      // Error handling dengan pesan yang informatif
      let errorMsg = "❌ *Gagal menghapus pesan!*\n\n";
      
      if (error.message?.includes('not-authorized')) {
        errorMsg += `*Alasan:* Bot tidak punya izin\n\n`;
        errorMsg += `*Solusi:*\n`;
        errorMsg += `• Jadikan bot sebagai admin grup\n`;
        errorMsg += `• Pastikan bot punya akses penuh`;
      } else if (error.message?.includes('item-not-found')) {
        errorMsg += `*Alasan:* Pesan tidak ditemukan\n\n`;
        errorMsg += `*Kemungkinan:*\n`;
        errorMsg += `• Pesan sudah dihapus sebelumnya\n`;
        errorMsg += `• Pesan terlalu lama (>48 jam)\n`;
        errorMsg += `• Pesan tidak ada di database`;
      } else if (error.message?.includes('message-too-old')) {
        errorMsg += `*Alasan:* Pesan terlalu lama\n\n`;
        errorMsg += `*Info:*\n`;
        errorMsg += `• WhatsApp hanya izinkan hapus pesan <48 jam\n`;
        errorMsg += `• Pesan ini sudah melewati batas waktu`;
      } else if (error.message?.includes('forbidden')) {
        errorMsg += `*Alasan:* Akses ditolak\n\n`;
        errorMsg += `*Solusi:*\n`;
        errorMsg += `• Cek status admin bot\n`;
        errorMsg += `• Restart bot dan coba lagi`;
      } else {
        errorMsg += `*Error:* ${error.message}\n\n`;
        errorMsg += `*Debug Info:*\n`;
        errorMsg += `• Key ID: ${quotedKey?.id || 'null'}\n`;
        errorMsg += `• Has participant: ${!!quotedKey?.participant}\n`;
        errorMsg += `• User is admin: ${isUserAdmin}\n`;
        errorMsg += `• Bot is admin: ${isBotAdmin}\n\n`;
        errorMsg += `*Solusi:*\n`;
        errorMsg += `• Coba lagi dalam beberapa detik\n`;
        errorMsg += `• Jadikan bot admin jika belum\n`;
        errorMsg += `• Hubungi developer jika masih error`;
      }
      
      m.reply(errorMsg);
    }
    
  } catch (mainError) {
    console.error('\n❌ MAIN ERROR');
    console.error('Error:', mainError);
    console.error('Stack trace:', mainError.stack);
    
    m.reply(`❌ *Terjadi kesalahan sistem!*

*Error:* ${mainError.message}

*Solusi:*
• Coba lagi dalam beberapa detik
• Restart bot jika masih error
• Hubungi developer untuk bantuan

*Debug:* Cek console untuk detail lengkap`);
  }
};

// ========== HANDLER CONFIG ==========
handler.help = [
  "del - Hapus pesan (reply pesan yang ingin dihapus)",
  "delete - Hapus pesan untuk semua",
  "hapus - Hapus pesan yang direply"
];

handler.tags = ["group"];

handler.command = ["del", "delete", "hapus"];

handler.group = true; // Hanya bisa di grup
handler.admin = false; // Tidak harus admin (tergantung pesan)
handler.botAdmin = false; // Tidak harus bot admin (tergantung pesan)
handler.owner = false; // Tidak harus owner
handler.premium = false; // Tidak harus premium

export default handler;