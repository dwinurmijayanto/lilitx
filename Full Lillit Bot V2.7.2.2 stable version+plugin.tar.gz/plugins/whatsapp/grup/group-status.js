import * as baileys from "baileys";
import crypto from "node:crypto";

// ========== GROUP STATUS FUNCTION ==========
async function groupStatus(conn, jid, content) {
  const { backgroundColor } = content;
  delete content.backgroundColor;

  const inside = await baileys.generateWAMessageContent(content, {
    upload: conn.waUploadToServer,
    backgroundColor
  });

  const messageSecret = crypto.randomBytes(32);

  const m = baileys.generateWAMessageFromContent(
    jid,
    {
      messageContextInfo: { messageSecret },
      groupStatusMessageV2: {
        message: {
          ...inside,
          messageContextInfo: { messageSecret }
        }
      }
    },
    {}
  );

  await conn.relayMessage(jid, m.message, { messageId: m.key.id });
  return m;
}

// ========== HANDLER ==========
let handler = async (m, { conn, command, args, text, usedPrefix = '.', isOwner }) => {
  try {
    console.log(`[${command}] Command dipanggil oleh: ${m.sender}`);
    console.log(`[${command}] Chat ID: ${m.chat}`);
    
    // Validasi grup
    if (!m.isGroup) {
      return m.reply("❌ Command ini hanya bisa digunakan di grup!");
    }
    
    // ========== EXTRACT TEXT DENGAN MULTIPLE FALLBACK ==========
    let teks = "";
    
    // Priority 1: Parameter text
    if (text && text.trim()) {
      teks = text.trim();
      console.log(`[${command}] Text dari parameter 'text': "${teks}"`);
    }
    // Priority 2: Join args array
    else if (args && args.length > 0) {
      teks = args.join(" ").trim();
      console.log(`[${command}] Text dari args.join(): "${teks}"`);
    }
    // Priority 3: Extract dari m.body
    else if (m.body) {
      const commandPrefix = usedPrefix + command;
      if (m.body.startsWith(commandPrefix)) {
        teks = m.body.slice(commandPrefix.length).trim();
        console.log(`[${command}] Text dari m.body slice: "${teks}"`);
      }
    }
    // Priority 4: Dari m.text
    else if (m.text) {
      teks = m.text.trim();
      console.log(`[${command}] Text dari m.text: "${teks}"`);
    }
    
    console.log(`[${command}] ===== DEBUG INFO =====`);
    console.log(`[${command}] Parameter text:`, text);
    console.log(`[${command}] Parameter args:`, args);
    console.log(`[${command}] m.body:`, m.body);
    console.log(`[${command}] m.text:`, m.text);
    console.log(`[${command}] Final teks: "${teks}"`);
    console.log(`[${command}] ====================`);
    
    // ========== DETEKSI QUOTED & MIME ==========
    const isQuoted = !!m.quoted;
    const mimeType = isQuoted ? (m.quoted.mimetype || m.quoted.mtype) : null;
    
    console.log(`[${command}] isQuoted: ${isQuoted}`);
    console.log(`[${command}] mimeType: ${mimeType}`);
    
    let media;
    
    // Download media jika ada quoted message
    if (isQuoted) {
      console.log(`[${command}] Downloading media from quoted message...`);
      media = await m.quoted.download();
      console.log(`[${command}] Media downloaded:`, !!media);
    }
    
    // ========== PARSE TARGET GRUP (FITUR OWNER) ==========
    let targetGc = m.chat;
    let caption = teks;

    if (isOwner && teks.includes("|")) {
      const [idgc, ...rest] = teks.split("|");
      targetGc = idgc.trim();
      caption = rest.join("|").trim();
      console.log(`[${command}] Owner mode - Target: ${targetGc}, Caption: ${caption}`);
    }
    
    // ========== VALIDASI TARGET GRUP ==========
    if (!isOwner && m.chat !== targetGc) {
      return m.reply("⚠️ Hanya owner yang bisa kirim status ke grup lain!");
    }
    
    // ========== BUILD OPTIONS ==========
    let options = {};
    
    if (isQuoted) {
      if (/image/.test(mimeType)) {
        console.log(`[${command}] 📷 Memproses gambar dengan caption: "${caption}"`);
        options = { image: media, caption: caption };
      } else if (/video/.test(mimeType)) {
        console.log(`[${command}] 🎥 Memproses video dengan caption: "${caption}"`);
        options = { video: media, caption: caption };
      } else if (/audio/.test(mimeType)) {
        console.log(`[${command}] 🎵 Memproses audio...`);
        options = { audio: media, mimetype: "audio/mpeg", ptt: false };
      } else {
        console.log(`[${command}] ❌ Tipe media tidak didukung: ${mimeType}`);
        return m.reply("❌ Hanya bisa gambar, video, audio atau teks untuk status grup!");
      }
    } else if (caption) {
      // INI YANG PENTING: Jika ada caption tapi tidak ada quoted, kirim sebagai text
      console.log(`[${command}] 📝 Memproses teks: "${caption}"`);
      options = { text: caption };
    } else {
      // Tampilkan help jika benar-benar tidak ada input
      console.log(`[${command}] ℹ️ Tidak ada input, menampilkan help`);
      const helpMsg = `📤 *Upload Status Grup*

*Cara penggunaan:*

*1. Upload Text*
   ${usedPrefix}${command} Halo semua! 👋

*2. Upload Image*
   Reply gambar lalu ketik: ${usedPrefix}${command} Caption

*3. Upload Video*
   Reply video lalu ketik: ${usedPrefix}${command} Caption

*4. Upload Audio*
   Reply audio lalu ketik: ${usedPrefix}${command}

*Fitur Owner:*
   ${usedPrefix}${command} ID_GRUP | Caption
   (Kirim status ke grup lain)

*Contoh:*
${usedPrefix}${command} Selamat pagi semua! ☀️
${usedPrefix}${command} (reply foto) Pemandangan hari ini`;

      return m.reply(helpMsg);
    }
    
    console.log(`[${command}] Final options:`, JSON.stringify({ 
      ...options, 
      image: options.image ? '[Buffer]' : undefined, 
      video: options.video ? '[Buffer]' : undefined, 
      audio: options.audio ? '[Buffer]' : undefined 
    }));
    
    // React loading
    await conn.sendMessage(m.chat, {
      react: { text: "⏳", key: m.key }
    });

    // ========== KIRIM STATUS GRUP ==========
    console.log(`[${command}] 📤 Mengirim status grup ke: ${targetGc}`);
    await groupStatus(conn, targetGc, options);
    console.log(`[${command}] ✅ Status grup berhasil dikirim!`);

    // React success
    await conn.sendMessage(m.chat, {
      react: { text: "✅", key: m.key }
    });

  } catch (e) {
    console.error(`[${command}] ❌ ERROR:`, e);
    console.error(`[${command}] Stack trace:`, e.stack);
    
    await conn.sendMessage(m.chat, {
      react: { text: "❌", key: m.key }
    });

    await m.reply(
      `❌ Terjadi kesalahan saat mengirim status grup.\n\nError: ${e.message}`
    );
  }
};

// ========== HANDLER CONFIG ==========
handler.help = ["toswgc [text/reply media]"];
handler.tags = ["group"];
handler.command = ["toswgc"];
handler.group = true;
handler.admin = false;
handler.botAdmin = false;
handler.owner = false;

export default handler;