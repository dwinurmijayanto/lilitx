import os from "os";
import { downloadContentFromMessage } from 'baileys';

// ========== DOWNLOAD MEDIA FUNCTION ==========
/**
 * Download media dari Baileys message
 * @param {Object} message - Raw Baileys message object
 * @returns {Buffer|null} - Media buffer atau null jika gagal
 */
async function downloadMedia(message) {
    try {
        const mimeMap = {
            imageMessage: 'image',
            videoMessage: 'video',
            stickerMessage: 'sticker',
            documentMessage: 'document',
            audioMessage: 'audio'
        };

        const msgKeys = Object.keys(message || {});
        if (msgKeys.length === 0) return null;

        const type = msgKeys[0];
        if (!type) return null;

        const m = message[type];
        if (!m) return null;

        const mediaType = mimeMap[type];
        if (!mediaType) return null;

        // Download media menggunakan Baileys
        const stream = await downloadContentFromMessage(m, mediaType);
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        
        return Buffer.concat(chunks);
    } catch (error) {
        console.error('[Group Handler] Error downloading media:', error);
        return null;
    }
}

let handler = async (m, { conn, config, command, args, usedPrefix = '.' }) => {
  try {
    const thumbnailUrl = "https://upload.vbi1.my.id/uploads/2025/11/581730296_25054465594217355_89.jpg";
    
    // PENTING: Extract text dari args array
    let text = Array.isArray(args) ? args.join(' ') : '';
    
    // Fallback: coba extract dari message body
    if (!text && m.body) {
      const commandPrefix = usedPrefix + command;
      if (m.body.startsWith(commandPrefix)) {
        text = m.body.slice(commandPrefix.length).trim();
      }
    }
    
    console.log('=== HANDLER DEBUG ===');
    console.log('Command:', command);
    console.log('Args array:', args);
    console.log('Extracted text:', text);
    console.log('Message body:', m.body);
    
    // Cek apakah di grup atau private chat
    const isGroup = m.isGroup;
    
    if (!isGroup) {
      return m.reply("❌ Command ini hanya bisa digunakan di grup!");
    }
    
    // Ambil metadata grup
    const groupMetadata = await conn.groupMetadata(m.chat);
    const groupName = groupMetadata.subject;
    const groupDesc = groupMetadata.desc || "Tidak ada deskripsi";
    const groupOwner = groupMetadata.owner || "Tidak diketahui";
    const groupCreated = new Date(groupMetadata.creation * 1000).toLocaleDateString("id-ID");
    const totalMembers = groupMetadata.participants.length;
    const participants = groupMetadata.participants;
    
    // Hitung admin dan member
    const admins = participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin').length;
    const regularMembers = totalMembers - admins;
    
    // Fungsi untuk extract nomor bersih dari JID
    const extractCleanNumber = (jid) => {
      if (!jid) return null;
      const match = jid.match(/^(\d+)/);
      return match ? match[1] : null;
    };
    
    // Ambil bot number untuk display
    let botNumber = conn.user?.id || conn.authState?.creds?.me?.id || 'Unknown';
    let botNumberClean = extractCleanNumber(botNumber);
    
    // Cek apakah user adalah admin
    const userParticipant = participants.find(p => p.id === m.sender);
    const isUserAdmin = userParticipant?.admin === 'admin' || userParticipant?.admin === 'superadmin';
    
    // ===== DETEKSI BOT PARTICIPANT =====
    let botParticipant = null;
    let botJid = null;
    let detectionLog = [];
    
    detectionLog.push("=== BOT DETECTION DEBUG ===");
    detectionLog.push(`Bot User ID: ${conn.user?.id}`);
    detectionLog.push(`Bot Number Clean: ${botNumberClean}`);
    detectionLog.push(`Message From Me: ${m.key?.fromMe}`);
    detectionLog.push(`Message Sender: ${m.sender}`);
    detectionLog.push(`Message Participant: ${m.key?.participant || 'N/A'}`);
    detectionLog.push(`Total Participants: ${participants.length}`);
    
    // Method 1: Dari message key participant
    detectionLog.push("\n--- Method 1: Message Key Participant ---");
    if (m.key?.participant) {
      detectionLog.push(`Found participant in message key: ${m.key.participant}`);
      botJid = m.key.participant;
      botParticipant = participants.find(p => p.id === botJid);
      if (botParticipant) {
        detectionLog.push(`✅ SUCCESS: Bot found using message participant`);
        detectionLog.push(`Bot JID: ${botJid}`);
        detectionLog.push(`Bot Admin: ${botParticipant.admin || 'member'}`);
      } else {
        detectionLog.push(`❌ FAILED: Participant ${botJid} not in group members list`);
      }
    } else {
      detectionLog.push(`No participant in message key`);
    }
    
    // Method 2: Match by number
    if (!botParticipant) {
      detectionLog.push("\n--- Method 2: Match by Number ---");
      detectionLog.push(`Searching for number: ${botNumberClean}`);
      
      botParticipant = participants.find(p => {
        const cleanP = extractCleanNumber(p.id);
        const matches = cleanP === botNumberClean;
        if (matches) {
          detectionLog.push(`Found match: ${p.id} -> ${cleanP}`);
        }
        return matches;
      });
      
      if (botParticipant) {
        botJid = botParticipant.id;
        detectionLog.push(`✅ SUCCESS: Bot found by number matching`);
        detectionLog.push(`Bot JID: ${botJid}`);
      } else {
        detectionLog.push(`❌ FAILED: No participant matches bot number`);
      }
    }
    
    // Method 3: Send test message (WORKAROUND)
    if (!botParticipant && (command === "infogrup" || command === "infogroup" || command === "groupinfo" || command === "infogc" || command === "debugbot")) {
      detectionLog.push("\n--- Method 3: Test Message (Last Resort) ---");
      try {
        detectionLog.push(`Sending test message to capture bot JID...`);
        const tempMsg = await conn.sendMessage(m.chat, { 
          text: "🔍 Detecting bot..." 
        });
        
        if (tempMsg?.key?.participant) {
          botJid = tempMsg.key.participant;
          detectionLog.push(`Captured bot JID from test message: ${botJid}`);
          
          botParticipant = participants.find(p => p.id === botJid);
          if (botParticipant) {
            detectionLog.push(`✅ SUCCESS: Bot found using test message`);
          } else {
            detectionLog.push(`❌ FAILED: Test message JID not in participants`);
          }
          
          // Delete test message
          setTimeout(async () => {
            try {
              await conn.sendMessage(m.chat, { delete: tempMsg.key });
              detectionLog.push(`Test message deleted`);
            } catch (e) {
              detectionLog.push(`Failed to delete test message: ${e.message}`);
            }
          }, 1500);
        } else {
          detectionLog.push(`❌ No participant in test message key`);
        }
      } catch (e) {
        detectionLog.push(`ERROR sending test message: ${e.message}`);
      }
    }
    
    // Log all participants
    detectionLog.push("\n--- All Group Participants ---");
    participants.forEach((p, i) => {
      const cleanNum = extractCleanNumber(p.id);
      const isBotNum = cleanNum === botNumberClean;
      detectionLog.push(`${i + 1}. ${p.id} (admin: ${p.admin || 'member'}) ${isBotNum ? '← BOT' : ''}`);
    });
    
    // Final detection status
    detectionLog.push("\n=== DETECTION RESULT ===");
    if (botParticipant) {
      detectionLog.push(`✅ Bot Detected!`);
      detectionLog.push(`Bot JID: ${botJid}`);
      detectionLog.push(`Bot Admin Status: ${botParticipant.admin || 'member'}`);
    } else {
      detectionLog.push(`❌ Bot NOT Detected!`);
      detectionLog.push(`SOLUTION: Make bot send a message, then run .debugbot again`);
    }
    
    const isBotAdmin = botParticipant?.admin === 'admin' || botParticipant?.admin === 'superadmin';
    
    // ========== ENHANCED EXTRACT USER WITH IMAGE SUPPORT ==========
    const extractUser = () => {
      // ========== EXTRACT RAW MESSAGE & CONTEXT INFO ==========
      let rawMessage = m.message;
      let contextInfo = null;
      let quotedMessage = null;
      
      // Extract contextInfo berdasarkan tipe message
      if (rawMessage) {
        if (rawMessage.extendedTextMessage) {
          contextInfo = rawMessage.extendedTextMessage.contextInfo;
        } else if (rawMessage.imageMessage) {
          contextInfo = rawMessage.imageMessage.contextInfo;
        } else if (rawMessage.videoMessage) {
          contextInfo = rawMessage.videoMessage.contextInfo;
        }
        
        if (contextInfo) {
          quotedMessage = contextInfo.quotedMessage;
        }
      }
      
      // Priority 1: Mention dari text
      if (m.mentionedJid && m.mentionedJid.length > 0) {
        console.log('Extracted from mention:', m.mentionedJid[0]);
        return m.mentionedJid[0];
      }
      
      // Priority 2: Phone mention dari text (@628xxx)
      if (text) {
        const phoneMatch = text.match(/@(\d{10,15})/);
        if (phoneMatch) {
          const phone = phoneMatch[1];
          console.log('Extracted phone from text mention:', phone);
          return phone + '@s.whatsapp.net';
        }
      }
      
      // Priority 3: Reply message (dari raw quotedMessage)
      if (quotedMessage) {
        // Cek jika quoted message punya participant
        if (contextInfo.participant) {
          console.log('Extracted from quoted raw participant:', contextInfo.participant);
          return contextInfo.participant;
        }
      }
      
      // Priority 4: m.quoted fallback
      if (m.quoted) {
        if (m.quoted.participant) {
          console.log('Extracted from quoted participant:', m.quoted.participant);
          return m.quoted.participant;
        }
        if (m.quoted.sender) {
          console.log('Extracted from quoted sender:', m.quoted.sender);
          return m.quoted.sender;
        }
      }
      
      // Priority 5: Plain text nomor
      if (text) {
        let cleanText = text.trim();
        let match = cleanText.match(/^(\+?62\d+|0\d+)$/);
        if (match) {
          let number = match[0].replace(/[@+\s-]/g, '');
          if (number.startsWith('0')) {
            number = '62' + number.slice(1);
          }
          console.log('Extracted from text (phone):', number);
          return number + '@s.whatsapp.net';
        }
      }
      
      return null;
    };
    
    // Helper function untuk cari participant
    const findParticipantByNumber = (targetJid) => {
      if (!targetJid) return null;
      
      console.log('Finding participant for:', targetJid);
      
      let participant = participants.find(p => p.id === targetJid);
      if (participant) {
        console.log('Found by exact match:', participant.id);
        return participant;
      }
      
      let cleanTarget = extractCleanNumber(targetJid);
      if (cleanTarget) {
        console.log('Searching by clean number:', cleanTarget);
        
        participant = participants.find(p => {
          const cleanId = extractCleanNumber(p.id);
          if (cleanId === cleanTarget) {
            console.log('Match found:', p.id);
            return true;
          }
          
          if (p.phoneNumber) {
            const cleanPhone = extractCleanNumber(p.phoneNumber);
            if (cleanPhone === cleanTarget) {
              console.log('Match found in phoneNumber:', p.id);
              return true;
            }
          }
          
          return false;
        });
      }
      
      if (!participant) {
        console.log('No participant found');
      }
      
      return participant || null;
    };
    
    // COMMAND: DEBUG BOT
    if (command === "debugbot") {
      const debugMsg = `*🔍 BOT DETECTION DEBUG*

\`\`\`${detectionLog.join('\n')}\`\`\`

*Next Steps:*
${!botParticipant ? '1. Make bot send any message in group\n2. Run .debugbot again' : '✅ Bot detected successfully!'}

*Addressing Mode:* ${groupMetadata.addressingMode || 'unknown'}`;
      
      return m.reply(debugMsg);
    }
    
    // FITUR 1: INFO GRUP
    if (command === "infogrup" || command === "infogroup" || command === "groupinfo" || command === "infogc") {
      const debugSection = `
*🔍 Debug Info:*
Bot JID: ${botJid || 'NOT FOUND'}
Bot Number: ${botNumberClean}
Bot Detected: ${botParticipant ? 'YES' : 'NO'}
Bot Admin: ${isBotAdmin ? 'YES' : 'NO'}

${!botParticipant ? '⚠️ Bot tidak terdeteksi! Jalankan .debugbot' : ''}`;

      const msg = `╔═══════════════════
║ *📊 INFO GRUP WHATSAPP*
╠═══════════════════
║ *Nama Grup:* ${groupName}
║ *Dibuat:* ${groupCreated}
║ *Total Anggota:* ${totalMembers}
║ *Admin:* ${admins}
║ *Member:* ${regularMembers}
║ *Owner:* @${groupOwner.split("@")[0]}
║ *Bot Admin:* ${isBotAdmin ? "✅ Ya" : "❌ Tidak"}
║ *Anda Admin:* ${isUserAdmin ? "✅ Ya" : "❌ Tidak"}
╠═══════════════════
║ *Deskripsi:*
║ ${groupDesc.substring(0, 100)}${groupDesc.length > 100 ? "..." : ""}
╚═══════════════════

*🛡️ Fitur Penjagaan Grup:*
• .tutup - Tutup grup (admin)
• .buka - Buka grup (admin)
• .kick @user - Tendang member (admin)
• .promote @user - Jadikan admin (admin)
• .demote @admin - Turunkan admin (admin)
• .setname [nama] - Ubah nama grup (admin)
• .setdesc [desc] - Ubah deskripsi (admin)
• .setpp - Ubah foto grup (admin)
• .add [nomor] - Tambah member (admin)
• .tagall [pesan] - Tag semua member (admin)
• .tagadmin [pesan] - Tag semua admin
• .listadmin - List semua admin
• .linkgrup - Dapatkan link grup
• .resetlink - Reset link grup (admin)
• .autodelete [waktu] - Auto hapus pesan (admin)
• .debugbot - Debug deteksi bot

${debugSection}`;
      
      await conn.sendMessage(m.chat, {
        image: { url: thumbnailUrl },
        caption: msg,
        mentions: [groupOwner]
      });
    }
    
    // FITUR 2: TUTUP GRUP
    else if (command === "tutup" || command === "close") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      if (!isBotAdmin) {
        return m.reply("❌ Bot harus dijadikan admin terlebih dahulu!");
      }
      
      try {
        await conn.groupSettingUpdate(m.chat, 'announcement');
        m.reply("🔒 Grup telah ditutup! Hanya admin yang bisa mengirim pesan.");
      } catch (e) {
        console.error('❌ Error closing group:', e);
        m.reply("❌ Gagal menutup grup! Cek console untuk detail error.");
      }
    }
    
    // FITUR 3: BUKA GRUP
    else if (command === "buka" || command === "open") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      if (!isBotAdmin) {
        return m.reply("❌ Bot harus dijadikan admin terlebih dahulu!");
      }
      
      try {
        await conn.groupSettingUpdate(m.chat, 'not_announcement');
        m.reply("🔓 Grup telah dibuka! Semua member bisa mengirim pesan.");
      } catch (e) {
        console.error('❌ Error opening group:', e);
        m.reply("❌ Gagal membuka grup! Cek console untuk detail error.");
      }
    }
    

// FITUR 4: KICK MEMBER
else if (command === "kick" || command === "tendang") {
  if (!isUserAdmin) {
    return m.reply("❌ Command ini hanya untuk admin grup!");
  }
  
  if (!isBotAdmin) {
    return m.reply("❌ Bot harus dijadikan admin terlebih dahulu!");
  }
  
  let targetUser = extractUser();
  
  if (!targetUser) {
    return m.reply(`❌ Tag, reply, atau masukkan nomor member yang ingin ditendang!
*Contoh:*
- .kick @user
- .kick 628123456789
- Reply pesan user lalu ketik .kick`);
  }
  
  const targetParticipant = findParticipantByNumber(targetUser);
  
  if (!targetParticipant) {
    return m.reply("❌ User tidak ditemukan di grup!");
  }
  
  const targetIsAdmin = targetParticipant?.admin === 'admin' || targetParticipant?.admin === 'superadmin';
  
  try {
    // Jika target adalah admin, demote terlebih dahulu secara silent
    if (targetIsAdmin) {
      await conn.groupParticipantsUpdate(m.chat, [targetParticipant.id], 'demote');
      await new Promise(resolve => setTimeout(resolve, 1000)); // Delay 1 detik
    }
    
    // Lakukan kick
    await conn.groupParticipantsUpdate(m.chat, [targetParticipant.id], 'remove');
    
    // Kirim 1 pesan saja
    m.reply(`✅ Berhasil menendang @${extractCleanNumber(targetParticipant.id)} dari grup!`, null, {
      mentions: [targetParticipant.id]
    });
  } catch (e) {
    console.error('❌ Error kicking member:', e);
    m.reply("❌ Gagal menendang member! Cek console untuk detail error.");
  }
}

// FITUR 6: DEMOTE ADMIN JADI MEMBER
else if (command === "demote" || command === "unadmin") {
  if (!isUserAdmin) {
    return m.reply("❌ Command ini hanya untuk admin grup!");
  }
  
  if (!isBotAdmin) {
    return m.reply("❌ Bot harus dijadikan admin terlebih dahulu!");
  }
  
  let targetUser = extractUser();
  
  if (!targetUser) {
    return m.reply(`❌ Tag, reply, atau masukkan nomor admin yang ingin di-demote!
*Contoh:*
- .demote @admin
- .demote 628123456789
- Reply pesan admin lalu ketik .demote`);
  }
  
  const targetParticipant = findParticipantByNumber(targetUser);
  
  if (!targetParticipant) {
    return m.reply("❌ User tidak ditemukan di grup!");
  }
  
  const targetIsAdmin = targetParticipant?.admin === 'admin' || targetParticipant?.admin === 'superadmin';
  
  if (!targetIsAdmin) {
    return m.reply("❌ User tersebut bukan admin!");
  }
  
  try {
    await conn.groupParticipantsUpdate(m.chat, [targetParticipant.id], 'demote');
    m.reply(`✅ @${extractCleanNumber(targetParticipant.id)} telah diturunkan menjadi member!`, null, {
      mentions: [targetParticipant.id]
    });
  } catch (e) {
    console.error('❌ Error demoting admin:', e);
    m.reply("❌ Gagal demote admin! Cek console untuk detail error.");
  }
}
    
    // FITUR 5: PROMOTE MEMBER JADI ADMIN
    else if (command === "promote" || command === "admin") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      if (!isBotAdmin) {
        return m.reply("❌ Bot harus dijadikan admin terlebih dahulu!");
      }
      
      let targetUser = extractUser();
      
      if (!targetUser) {
        return m.reply(`❌ Tag, reply, atau masukkan nomor member yang ingin dijadikan admin!

*Contoh:*
• .promote @user
• .promote 628123456789
• Reply pesan user lalu ketik .promote`);
      }
      
      const targetParticipant = findParticipantByNumber(targetUser);
      
      if (!targetParticipant) {
        return m.reply("❌ User tidak ditemukan di grup!");
      }
      
      const targetIsAdmin = targetParticipant?.admin === 'admin' || targetParticipant?.admin === 'superadmin';
      
      if (targetIsAdmin) {
        return m.reply("❌ User tersebut sudah menjadi admin!");
      }
      
      try {
        await conn.groupParticipantsUpdate(m.chat, [targetParticipant.id], 'promote');
        m.reply(`✅ @${extractCleanNumber(targetParticipant.id)} telah dijadikan admin!`, null, {
          mentions: [targetParticipant.id]
        });
      } catch (e) {
        console.error('❌ Error promoting member:', e);
        m.reply("❌ Gagal promote member! Cek console untuk detail error.");
      }
    }
    
    // FITUR 6: DEMOTE ADMIN JADI MEMBER
    else if (command === "demote" || command === "unadmin") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      if (!isBotAdmin) {
        return m.reply("❌ Bot harus dijadikan admin terlebih dahulu!");
      }
      
      let targetUser = extractUser();
      
      if (!targetUser) {
        return m.reply(`❌ Tag, reply, atau masukkan nomor admin yang ingin di-demote!

*Contoh:*
• .demote @admin
• .demote 628123456789
• Reply pesan admin lalu ketik .demote`);
      }
      
      const targetParticipant = findParticipantByNumber(targetUser);
      
      if (!targetParticipant) {
        return m.reply("❌ User tidak ditemukan di grup!");
      }
      
      const targetIsAdmin = targetParticipant?.admin === 'admin' || targetParticipant?.admin === 'superadmin';
      
      if (!targetIsAdmin) {
        return m.reply("❌ User tersebut bukan admin!");
      }
      
      try {
        await conn.groupParticipantsUpdate(m.chat, [targetParticipant.id], 'demote');
        m.reply(`✅ @${extractCleanNumber(targetParticipant.id)} telah diturunkan menjadi member!`, null, {
          mentions: [targetParticipant.id]
        });
      } catch (e) {
        console.error('❌ Error demoting admin:', e);
        m.reply("❌ Gagal demote admin! Cek console untuk detail error.");
      }
    }
    
    // FITUR 7: UBAH NAMA GRUP
    else if (command === "setname" || command === "namagrup") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      if (!isBotAdmin) {
        return m.reply("❌ Bot harus dijadikan admin terlebih dahulu!");
      }
      
      if (!text) {
        return m.reply(`❌ Masukkan nama grup baru!\n\nContoh: .setname Nama Grup Baru`);
      }
      
      try {
        await conn.groupUpdateSubject(m.chat, text);
        m.reply(`✅ Nama grup berhasil diubah menjadi: *${text}*`);
      } catch (e) {
        console.error('❌ Error updating group name:', e);
        m.reply("❌ Gagal mengubah nama grup! Cek console untuk detail error.");
      }
    }
    
    // FITUR 8: UBAH DESKRIPSI GRUP
    else if (command === "setdesc" || command === "deskripsigrup") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      if (!isBotAdmin) {
        return m.reply("❌ Bot harus dijadikan admin terlebih dahulu!");
      }
      
      if (!text) {
        return m.reply(`❌ Masukkan deskripsi grup baru!\n\nContoh: .setdesc Ini adalah deskripsi baru`);
      }
      
      try {
        await conn.groupUpdateDescription(m.chat, text);
        m.reply(`✅ Deskripsi grup berhasil diubah!`);
      } catch (e) {
        console.error('❌ Error updating group description:', e);
        m.reply("❌ Gagal mengubah deskripsi! Cek console untuk detail error.");
      }
    }
    
    // FITUR 9: UBAH FOTO GRUP (ENHANCED WITH REPLY SUPPORT)
    else if (command === "setpp" || command === "setppgrup") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      if (!isBotAdmin) {
        return m.reply("❌ Bot harus dijadikan admin terlebih dahulu!");
      }
      
      let mediaBuffer = null;
      let mime = '';
      
      // ========== EXTRACT RAW MESSAGE & CONTEXT INFO ==========
      let rawMessage = m.message;
      let contextInfo = null;
      let quotedMessage = null;
      
      if (rawMessage) {
        if (rawMessage.extendedTextMessage) {
          contextInfo = rawMessage.extendedTextMessage.contextInfo;
        } else if (rawMessage.imageMessage) {
          contextInfo = rawMessage.imageMessage.contextInfo;
        }
        
        if (contextInfo) {
          quotedMessage = contextInfo.quotedMessage;
        }
      }
      
      // Check 1: Direct image message
      if (rawMessage?.imageMessage) {
        console.log('[Group Handler] Processing direct image for setpp');
        mime = rawMessage.imageMessage.mimetype || 'image/jpeg';
        mediaBuffer = await downloadMedia(rawMessage);
      }
      // Check 2: Quoted image (dari raw contextInfo)
      else if (quotedMessage?.imageMessage) {
        console.log('[Group Handler] Processing quoted image for setpp');
        mime = quotedMessage.imageMessage.mimetype || 'image/jpeg';
        mediaBuffer = await downloadMedia(quotedMessage);
      }
      // Check 3: Fallback ke m.quoted
      else if (m.quoted?.message?.imageMessage) {
        console.log('[Group Handler] Processing from m.quoted for setpp');
        mime = m.quoted.message.imageMessage.mimetype || 'image/jpeg';
        mediaBuffer = await downloadMedia(m.quoted.message);
      }
      
      if (!mediaBuffer || !mime) {
        return m.reply(`❌ Reply gambar dengan caption .setpp untuk mengubah foto grup!

*Cara pakai:*
• Kirim gambar dengan caption .setpp
• Reply gambar lalu ketik .setpp`);
      }
      
      // Validasi format gambar
      if (!/image\/(jpe?g|png)/.test(mime)) {
        return m.reply('⚠️ Format tidak didukung! Hanya jpg/png.');
      }
      
      try {
        await conn.updateProfilePicture(m.chat, mediaBuffer);
        m.reply("✅ Foto grup berhasil diubah!");
      } catch (e) {
        console.error('❌ Error updating group picture:', e);
        m.reply("❌ Gagal mengubah foto grup! Cek console untuk detail error.");
      }
    }
    
    // FITUR 10: TAG ALL MEMBERS
    else if (command === "tagall") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      const customMessage = text || "📢 Pengumuman untuk semua member!";
      
      const mentions = participants.map(p => p.id);
      const mentionText = mentions.map(id => `@${extractCleanNumber(id)}`).join(' ');
      const fullMessage = `${customMessage}\n\n${mentionText}`;
      
      try {
        await conn.sendMessage(m.chat, {
          text: fullMessage,
          mentions: mentions
        });
        
        console.log('✅ Tagall sent successfully');
        
        // Auto delete perintah tagall setelah berhasil
        try {
          await conn.sendMessage(m.chat, { delete: m.key });
          console.log('✅ Tagall command deleted');
        } catch (delErr) {
          console.error('⚠️ Failed to delete tagall command:', delErr);
        }
      } catch (e) {
        console.error('❌ Tagall error:', e);
        m.reply("❌ Gagal mengirim tagall! Cek console untuk detail error.");
      }
    }
    
// FITUR 10B: HIDETAG
else if (command === "hidetag" || command === "h") {
  if (!isUserAdmin) {
    return m.reply("❌ Command ini hanya untuk admin grup!");
  }
  
  const message = text || "📢 Pengumuman untuk semua member!";
  const mentions = participants.map(p => p.id);
  
  try {
    await conn.sendMessage(m.chat, {
      text: message,
      mentions: mentions
    });
    
    console.log('✅ Hidetag sent successfully');
    
    // Auto delete perintah hidetag setelah berhasil
    try {
      await conn.sendMessage(m.chat, { delete: m.key });
      console.log('✅ Hidetag command deleted');
    } catch (delErr) {
      console.error('⚠️ Failed to delete hidetag command:', delErr);
    }
  } catch (e) {
    console.error('❌ Hidetag error:', e);
    m.reply("❌ Gagal mengirim hidetag! Cek console untuk detail error.");
  }
}
    
    // FITUR 10C: TAG ADMIN
    else if (command === "tagadmin" || command === "adminonly") {
      const customMessage = text || "🔔 Panggilan untuk semua admin!";
      
      const adminParticipants = participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin');
      const adminMentions = adminParticipants.map(p => p.id);
      
      if (adminMentions.length === 0) {
        return m.reply("❌ Tidak ada admin di grup ini!");
      }
      
      const mentionText = adminMentions.map(id => `@${extractCleanNumber(id)}`).join(' ');
      const fullMessage = `${customMessage}\n\n👥 *Admin yang dipanggil:*\n${mentionText}`;
      
      try {
        await conn.sendMessage(m.chat, {
          text: fullMessage,
          mentions: adminMentions
        });
        
        console.log('✅ Tagadmin sent successfully');
      } catch (e) {
        console.error('❌ Tagadmin error:', e);
        m.reply("❌ Gagal mengirim tagadmin! Cek console untuk detail error.");
      }
    }
    
    // FITUR 11: LIST ADMIN
    else if (command === "listadmin" || command === "adminlist") {
      const adminList = participants
        .filter(p => p.admin === 'admin' || p.admin === 'superadmin')
        .map((p, i) => `${i + 1}. @${extractCleanNumber(p.id)}`)
        .join('\n');
      
      const msg = `*👥 List Admin Grup*\n\n${adminList}\n\n*Total: ${admins} admin*`;
      
      await conn.sendMessage(m.chat, {
        text: msg,
        mentions: participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin').map(p => p.id)
      });
    }
    
    // FITUR 12: ADD MEMBER
    else if (command === "add" || command === "invite") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      if (!isBotAdmin) {
        return m.reply("❌ Bot harus dijadikan admin terlebih dahulu!");
      }
      
      if (!text) {
        return m.reply(`❌ Masukkan nomor yang ingin ditambahkan!

*Contoh:*
• .add 628123456789
• .add 08123456789`);
      }
      
      try {
        let number = text.replace(/[^0-9]/g, '');
        
        if (number.startsWith('0')) {
          number = '62' + number.slice(1);
        }
        
        if (!number.startsWith('62')) {
          number = '62' + number;
        }
        
        const jid = number + '@s.whatsapp.net';
        
        const isAlreadyMember = participants.some(p => {
          if (p.phoneNumber) {
            let cleanP = extractCleanNumber(p.phoneNumber);
            return cleanP === number;
          }
          return false;
        });
        
        if (isAlreadyMember) {
          return m.reply(`❌ @${number} sudah menjadi member grup!`, null, {
            mentions: [jid]
          });
        }
        
        await conn.groupParticipantsUpdate(m.chat, [jid], 'add');
        m.reply(`✅ Berhasil menambahkan @${number} ke grup!`, null, {
          mentions: [jid]
        });
      } catch (e) {
        console.error('❌ Error adding member:', e);
        m.reply(`❌ Gagal menambahkan member!

💡 Kemungkinan penyebab:
• Nomor salah/tidak terdaftar
• Privacy setting user tidak mengizinkan
• Bot bukan admin

Cek console untuk detail error.`);
      }
    }
    
    // FITUR 13: LINK GRUP
    else if (command === "linkgrup" || command === "linkgroup" || command === "link") {
      try {
        const code = await conn.groupInviteCode(m.chat);
        m.reply(`🔗 *Link Grup*\n\nhttps://chat.whatsapp.com/${code}\n\n_Link ini bisa digunakan untuk mengundang member baru._`);
      } catch (e) {
        console.error('❌ Error getting group link:', e);
        if (!isBotAdmin) {
          return m.reply("❌ Bot harus dijadikan admin terlebih dahulu!");
        }
        m.reply("❌ Gagal mendapatkan link grup! Cek console untuk detail error.");
      }
    }
    
    // FITUR 14: RESET LINK GRUP
    else if (command === "resetlink" || command === "revoke") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      if (!isBotAdmin) {
        return m.reply("❌ Bot harus dijadikan admin terlebih dahulu!");
      }
      
      try {
        await conn.groupRevokeInvite(m.chat);
        const newCode = await conn.groupInviteCode(m.chat);
        m.reply(`✅ Link grup berhasil direset!\n\n🔗 Link baru:\nhttps://chat.whatsapp.com/${newCode}`);
      } catch (e) {
        console.error('❌ Error resetting group link:', e);
        m.reply("❌ Gagal reset link grup! Cek console untuk detail error.");
      }
    }
    
    // FITUR 15: AUTO DELETE PESAN
    else if (command === "autodelete" || command === "ephemeral") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      if (!isBotAdmin) {
        return m.reply("❌ Bot harus dijadikan admin terlebih dahulu!");
      }
      
      if (!text) {
        return m.reply(`⚙️ *Auto Delete Pesan*

Aktifkan auto delete untuk menghapus pesan otomatis setelah waktu tertentu.

*Contoh:*
• .autodelete 24h - Hapus setelah 24 jam
• .autodelete 7d - Hapus setelah 7 hari
• .autodelete 90d - Hapus setelah 90 hari
• .autodelete off - Matikan auto delete

*Pilihan waktu:*
24h, 7d, 90d, off`);
      }
      
      try {
        let ephemeral;
        
        switch(text.toLowerCase()) {
          case '24h':
          case '1d':
          case '24':
            ephemeral = 86400;
            break;
          case '7d':
          case '7':
            ephemeral = 604800;
            break;
          case '90d':
          case '90':
            ephemeral = 7776000;
            break;
          case 'off':
          case 'disable':
          case 'nonaktif':
            ephemeral = 0;
            break;
          default:
            return m.reply(`❌ Pilihan tidak valid!

*Pilihan yang tersedia:*
• 24h atau 1d
• 7d atau 7
• 90d atau 90
• off (untuk menonaktifkan)`);
        }
        
        await conn.groupToggleEphemeral(m.chat, ephemeral);
        
        if (ephemeral === 0) {
          m.reply("✅ Auto delete pesan telah dinonaktifkan!");
        } else {
          const timeText = ephemeral === 86400 ? '24 jam' : ephemeral === 604800 ? '7 hari' : '90 hari';
          m.reply(`✅ Auto delete pesan telah diaktifkan!\n\n⏱️ Pesan akan otomatis terhapus setelah *${timeText}*`);
        }
      } catch (e) {
        console.error('❌ Error setting auto delete:', e);
        m.reply("❌ Gagal mengatur auto delete! Cek console untuk detail error.");
      }
    }
    
  } catch (e) {
    console.error('❌ MAIN ERROR:', e);
    console.error('Stack trace:', e.stack);
    m.reply("❌ Terjadi kesalahan! Cek console untuk detail error.");
  }
};

handler.help = [
  "infogrup - Info lengkap grup",
  "debugbot - Debug deteksi bot",
  "tutup - Tutup grup (admin)",
  "buka - Buka grup (admin)",
  "kick @user/nomor - Tendang member (admin)",
  "promote @user/nomor - Jadikan admin (admin)",
  "demote @admin/nomor - Turunkan admin (admin)",
  "setname [nama] - Ubah nama grup (admin)",
  "setdesc [desc] - Ubah deskripsi (admin)",
  "setpp - Ubah foto grup (admin)",
  "add [nomor] - Tambah member (admin)",
  "linkgrup - Dapatkan link grup",
  "resetlink - Reset link grup (admin)",
  "tagall [pesan] - Tag semua member (admin)",
  "hidetag [pesan] - Tag tersembunyi (admin)",
  "tagadmin [pesan] - Tag semua admin",
  "listadmin - List semua admin",
  "autodelete [waktu] - Auto hapus pesan (admin)"
];

handler.tags = ["group"];

handler.command = [
  "groupinfo", "infogroup", "infogrup", "infogc",
  "debugbot",
  "tutup", "close",
  "buka", "open",
  "kick", "tendang",
  "promote", "admin",
  "demote", "unadmin",
  "setname", "namagrup",
  "setdesc", "deskripsigrup",
  "setpp", "setppgrup",
  "add", "invite",
  "linkgrup", "linkgroup", "link",
  "resetlink", "revoke",
  "tagall", "hidetag", "tagadmin", "adminonly","h",
  "listadmin", "adminlist",
  "autodelete", "ephemeral"
];

handler.group = true;
handler.admin = false;
handler.botAdmin = false;
handler.owner = false;
handler.mods = false;
handler.premium = false;

export default handler;