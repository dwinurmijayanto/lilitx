import fs from 'fs';
import path from 'path';
import { downloadContentFromMessage } from 'baileys';

let handler = async (m, { conn, args, usedPrefix = '.' }) => {
  try {
    // Deteksi mode berdasarkan command atau argument
    const mode = args[0]?.toLowerCase();
    
    // ===== UTILITY FUNCTIONS =====
    
    // Extract media type dari quoted message
    const getMediaType = (quoted) => {
      if (!quoted) return null;
      if (quoted.imageMessage) return 'image';
      if (quoted.videoMessage) return 'video';
      if (quoted.audioMessage) return 'audio';
      if (quoted.documentMessage) return 'document';
      return null;
    };
    
    // Get file extension berdasarkan media type
    const getFileExtension = (mediaType, mimetype = '') => {
      const extensions = {
        'image': 'jpg',
        'video': 'mp4',
        'audio': 'mp3',
        'document': 'pdf'
      };
      
      // Cek dari mimetype jika ada
      if (mimetype) {
        if (mimetype.includes('png')) return 'png';
        if (mimetype.includes('gif')) return 'gif';
        if (mimetype.includes('webp')) return 'webp';
        if (mimetype.includes('mp4')) return 'mp4';
        if (mimetype.includes('mpeg')) return 'mpeg';
        if (mimetype.includes('ogg')) return 'ogg';
      }
      
      return extensions[mediaType] || 'bin';
    };
    
    // Format file size
    const formatFileSize = (bytes) => {
      if (bytes === 0) return '0 Bytes';
      const k = 1024;
      const sizes = ['Bytes', 'KB', 'MB', 'GB'];
      const i = Math.floor(Math.log(bytes) / Math.log(k));
      return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
    };
    
    // Get status info
    const getStatusInfo = (quoted) => {
      const mediaType = getMediaType(quoted);
      if (!mediaType) return null;
      
      const mediaMsg = quoted[`${mediaType}Message`];
      return {
        type: mediaType,
        caption: mediaMsg?.caption || '',
        mimetype: mediaMsg?.mimetype || '',
        fileLength: mediaMsg?.fileLength || 0,
        seconds: mediaMsg?.seconds || 0,
        width: mediaMsg?.width || 0,
        height: mediaMsg?.height || 0
      };
    };
    
    // Ensure downloads directory exists
    const ensureDownloadDir = () => {
      const downloadDir = path.join(process.cwd(), 'downloads');
      if (!fs.existsSync(downloadDir)) {
        fs.mkdirSync(downloadDir, { recursive: true });
      }
      return downloadDir;
    };
    
    // ===== MODE 1: DOWNLOAD STATUS (DEFAULT) =====
    if (!mode || mode === 'download' || mode === 'dl') {
      // Cek apakah reply ke status/message
      if (!m.quoted) {
        let text = `❌ *Cara Menggunakan:*\n\n`;
        text += `Reply/balas status WhatsApp dengan command:\n`;
        text += `• \`${usedPrefix}statusdown\` - Download status\n`;
        text += `• \`${usedPrefix}statusdown info\` - Info status\n`;
        text += `• \`${usedPrefix}statusdown help\` - Bantuan lengkap\n\n`;
        text += `_Note: Status harus visible/terlihat oleh bot_`;
        return m.reply(text);
      }
      
      // Ambil quoted message
      const quoted = m.quoted;
      const mediaType = getMediaType(quoted);
      
      // Validasi media type
      if (!mediaType) {
        return m.reply(`⚠️ *Pesan yang direply bukan media status!*\n\nMedia yang didukung:\n• 📷 Gambar/Foto\n• 🎥 Video\n• 🎵 Audio\n• 📄 Dokumen`);
      }
      
      // Kirim status loading
      await m.reply(`⏳ *Mengunduh ${mediaType}...*\n\n_Mohon tunggu sebentar_`);
      
      try {
        // Download content
        const stream = await downloadContentFromMessage(
          quoted.message[`${mediaType}Message`], 
          mediaType
        );
        
        // Collect chunks
        const chunks = [];
        for await (const chunk of stream) {
          chunks.push(chunk);
        }
        
        // Combine buffer
        const buffer = Buffer.concat(chunks);
        
        // Get file info
        const statusInfo = getStatusInfo(quoted);
        const ext = getFileExtension(mediaType, statusInfo.mimetype);
        const fileName = `status_${Date.now()}.${ext}`;
        const downloadDir = ensureDownloadDir();
        const filePath = path.join(downloadDir, fileName);
        
        // Save file
        fs.writeFileSync(filePath, buffer);
        
        // Prepare response
        let text = `✅ *Status Berhasil Diunduh!*\n\n`;
        text += `📁 *Info File:*\n`;
        text += `• Tipe: ${mediaType.toUpperCase()}\n`;
        text += `• Ukuran: ${formatFileSize(buffer.length)}\n`;
        text += `• Format: ${ext.toUpperCase()}\n`;
        text += `• Lokasi: downloads/${fileName}\n`;
        
        if (statusInfo.caption) {
          text += `\n💬 *Caption:*\n${statusInfo.caption}`;
        }
        
        if (statusInfo.seconds) {
          text += `\n⏱️ Durasi: ${Math.floor(statusInfo.seconds)}s`;
        }
        
        if (statusInfo.width && statusInfo.height) {
          text += `\n📐 Dimensi: ${statusInfo.width}x${statusInfo.height}`;
        }
        
        // Kirim file kembali ke user
        await conn.sendFile(m.chat, buffer, fileName, text, m);
        
      } catch (downloadError) {
        console.error('Download Error:', downloadError);
        return m.reply(`❌ *Gagal mengunduh status!*\n\n_Error: ${downloadError.message}_\n\n*Kemungkinan penyebab:*\n• Status sudah dihapus\n• Koneksi bermasalah\n• Format tidak didukung`);
      }
      
      return;
    }
    
    // ===== MODE 2: INFO STATUS =====
    if (mode === 'info' || mode === 'detail') {
      if (!m.quoted) {
        return m.reply(`❌ Reply status terlebih dahulu!\n\nContoh: Reply status lalu ketik \`${usedPrefix}statusdown info\``);
      }
      
      const quoted = m.quoted;
      const mediaType = getMediaType(quoted);
      
      if (!mediaType) {
        return m.reply(`⚠️ Pesan yang direply bukan media status!`);
      }
      
      const statusInfo = getStatusInfo(quoted);
      
      let text = `╭━━━『 *STATUS INFO* 』━━━╮\n`;
      text += `│\n`;
      text += `│ 📊 *Detail Status*\n`;
      text += `│ • Tipe Media: ${mediaType.toUpperCase()}\n`;
      text += `│ • Format: ${statusInfo.mimetype || 'N/A'}\n`;
      text += `│ • Ukuran: ${formatFileSize(statusInfo.fileLength)}\n`;
      
      if (statusInfo.seconds) {
        text += `│ • Durasi: ${Math.floor(statusInfo.seconds)} detik\n`;
      }
      
      if (statusInfo.width && statusInfo.height) {
        text += `│ • Resolusi: ${statusInfo.width}x${statusInfo.height}px\n`;
      }
      
      text += `│\n`;
      
      // Info sender
      text += `│ 👤 *Pengirim*\n`;
      text += `│ • Nama: ${m.quoted.pushName || 'Unknown'}\n`;
      text += `│ • Nomor: ${m.quoted.sender.split('@')[0]}\n`;
      text += `│\n`;
      
      // Info timestamp
      if (m.quoted.messageTimestamp) {
        const date = new Date(m.quoted.messageTimestamp * 1000);
        text += `│ 🕒 *Waktu*\n`;
        text += `│ • Dikirim: ${date.toLocaleString('id-ID')}\n`;
        text += `│\n`;
      }
      
      // Caption
      if (statusInfo.caption) {
        text += `│ 💬 *Caption*\n`;
        text += `│ ${statusInfo.caption.split('\n').join('\n│ ')}\n`;
        text += `│\n`;
      }
      
      text += `│ 📥 *Download*\n`;
      text += `│ Gunakan: \`${usedPrefix}statusdown\`\n`;
      text += `│\n`;
      text += `╰━━━━━━━━━━━━━━━━╯`;
      
      return m.reply(text);
    }
    
    // ===== MODE 3: BATCH DOWNLOAD =====
    if (mode === 'batch' || mode === 'all') {
      return m.reply(`🚧 *Fitur Batch Download*\n\n_Fitur ini sedang dalam pengembangan._\n\nFitur akan memungkinkan download multiple status sekaligus.`);
    }
    
    // ===== MODE 4: LIST DOWNLOADED =====
    if (mode === 'list' || mode === 'history') {
      const downloadDir = path.join(process.cwd(), 'downloads');
      
      if (!fs.existsSync(downloadDir)) {
        return m.reply(`📁 *Folder downloads kosong*\n\n_Belum ada status yang diunduh_`);
      }
      
      const files = fs.readdirSync(downloadDir).filter(f => f.startsWith('status_'));
      
      if (files.length === 0) {
        return m.reply(`📁 *Tidak ada riwayat download*\n\n_Folder downloads kosong_`);
      }
      
      let text = `╭━━━『 *DOWNLOAD HISTORY* 』━━━╮\n`;
      text += `│\n`;
      text += `│ 📂 Total Files: ${files.length}\n`;
      text += `│\n`;
      
      // Ambil 10 file terbaru
      const recentFiles = files.slice(-10).reverse();
      
      recentFiles.forEach((file, i) => {
        const filePath = path.join(downloadDir, file);
        const stats = fs.statSync(filePath);
        const ext = path.extname(file).toUpperCase();
        
        text += `│ ${i + 1}. ${file}\n`;
        text += `│    📊 ${formatFileSize(stats.size)} | ${ext}\n`;
        text += `│    🕒 ${new Date(stats.mtime).toLocaleDateString('id-ID')}\n`;
        if (i < recentFiles.length - 1) text += `│\n`;
      });
      
      text += `│\n`;
      text += `│ 🗑️ Hapus: \`${usedPrefix}statusdown clear\`\n`;
      text += `│\n`;
      text += `╰━━━━━━━━━━━━━━━━╯`;
      
      return m.reply(text);
    }
    
    // ===== MODE 5: CLEAR/DELETE =====
    if (mode === 'clear' || mode === 'delete' || mode === 'clean') {
      const downloadDir = path.join(process.cwd(), 'downloads');
      
      if (!fs.existsSync(downloadDir)) {
        return m.reply(`✅ Folder downloads sudah bersih`);
      }
      
      const files = fs.readdirSync(downloadDir).filter(f => f.startsWith('status_'));
      
      if (files.length === 0) {
        return m.reply(`✅ Tidak ada file yang perlu dihapus`);
      }
      
      // Confirm delete
      if (!args[1] || args[1] !== 'confirm') {
        let text = `⚠️ *Konfirmasi Hapus*\n\n`;
        text += `Akan menghapus ${files.length} file status.\n`;
        text += `Total ukuran: ${formatFileSize(
          files.reduce((acc, f) => {
            const stats = fs.statSync(path.join(downloadDir, f));
            return acc + stats.size;
          }, 0)
        )}\n\n`;
        text += `Ketik: \`${usedPrefix}statusdown clear confirm\``;
        return m.reply(text);
      }
      
      // Delete files
      let deletedCount = 0;
      files.forEach(file => {
        try {
          fs.unlinkSync(path.join(downloadDir, file));
          deletedCount++;
        } catch (e) {
          console.error(`Failed to delete ${file}:`, e);
        }
      });
      
      return m.reply(`✅ *Berhasil dihapus!*\n\n${deletedCount} file status telah dihapus dari folder downloads.`);
    }
    
    // ===== MODE 6: STATS =====
    if (mode === 'stats') {
      const downloadDir = path.join(process.cwd(), 'downloads');
      
      if (!fs.existsSync(downloadDir)) {
        return m.reply(`📊 *Statistik: Kosong*\n\n_Belum ada aktivitas download_`);
      }
      
      const files = fs.readdirSync(downloadDir).filter(f => f.startsWith('status_'));
      
      // Hitung statistik
      let totalSize = 0;
      const types = {};
      
      files.forEach(file => {
        const filePath = path.join(downloadDir, file);
        const stats = fs.statSync(filePath);
        const ext = path.extname(file).slice(1);
        
        totalSize += stats.size;
        types[ext] = (types[ext] || 0) + 1;
      });
      
      let text = `╭━━━『 *DOWNLOAD STATS* 』━━━╮\n`;
      text += `│\n`;
      text += `│ 📊 *Overview*\n`;
      text += `│ • Total Files: ${files.length}\n`;
      text += `│ • Total Size: ${formatFileSize(totalSize)}\n`;
      text += `│ • Avg Size: ${formatFileSize(totalSize / files.length)}\n`;
      text += `│\n`;
      text += `│ 📁 *By Type*\n`;
      
      Object.entries(types).forEach(([ext, count]) => {
        text += `│ • ${ext.toUpperCase()}: ${count} file(s)\n`;
      });
      
      text += `│\n`;
      text += `╰━━━━━━━━━━━━━━━━╯`;
      
      return m.reply(text);
    }
    
    // ===== MODE 7: HELP =====
    if (mode === 'help' || mode === 'menu') {
      let text = `╭━━━『 *STATUS DOWNLOADER* 』━━━╮\n`;
      text += `│\n`;
      text += `│ 📖 *Available Commands:*\n`;
      text += `│\n`;
      text += `│ • \`${usedPrefix}statusdown\`\n`;
      text += `│   Download status (reply status)\n`;
      text += `│\n`;
      text += `│ • \`${usedPrefix}statusdown info\`\n`;
      text += `│   Lihat info status detail\n`;
      text += `│\n`;
      text += `│ • \`${usedPrefix}statusdown list\`\n`;
      text += `│   Riwayat download\n`;
      text += `│\n`;
      text += `│ • \`${usedPrefix}statusdown stats\`\n`;
      text += `│   Statistik download\n`;
      text += `│\n`;
      text += `│ • \`${usedPrefix}statusdown clear\`\n`;
      text += `│   Hapus semua file\n`;
      text += `│\n`;
      text += `│ 📝 *Cara Pakai:*\n`;
      text += `│ 1. Buka status WhatsApp\n`;
      text += `│ 2. Reply/balas status\n`;
      text += `│ 3. Ketik command download\n`;
      text += `│ 4. File akan dikirim ke chat\n`;
      text += `│\n`;
      text += `│ 📦 *Supported Media:*\n`;
      text += `│ • Gambar (JPG, PNG, GIF, WEBP)\n`;
      text += `│ • Video (MP4, MPEG)\n`;
      text += `│ • Audio (MP3, OGG)\n`;
      text += `│ • Dokumen (PDF, etc)\n`;
      text += `│\n`;
      text += `│ ⚠️ *Catatan:*\n`;
      text += `│ • Status harus visible\n`;
      text += `│ • Tidak untuk status private\n`;
      text += `│ • Gunakan dengan bijak\n`;
      text += `│\n`;
      text += `╰━━━━━━━━━━━━━━━━╯`;
      
      return m.reply(text);
    }
    
    // Mode tidak dikenali
    m.reply(`❌ Mode tidak valid: *${mode}*\n\nGunakan \`${usedPrefix}statusdown help\` untuk bantuan.`);
    
  } catch (e) {
    console.error('StatusDown Error:', e);
    m.reply(`❌ *Error!*\n\n${e.message}\n\n_Stack: ${e.stack?.split('\n')[0]}_`);
  }
};

handler.help = [
  "statusdown [mode]",
  "Modes: download, info, list, stats, clear, help"
];
handler.tags = ["downloader", "tools"];
handler.command = ["statusdown", "statusdl", "sdl"];

export default handler;