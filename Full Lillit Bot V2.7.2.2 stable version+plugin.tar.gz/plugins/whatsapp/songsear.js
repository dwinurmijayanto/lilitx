import fetch from 'node-fetch';
import * as cheerio from 'cheerio';

const cache = new Map();
const CACHE_TTL = 10 * 60 * 1000; // 10 menit

function getCachedData(key) {
    const cached = cache.get(key);
    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
        console.log('[FindSong] Cache hit:', key);
        return cached.data;
    }
    if (cached) cache.delete(key);
    return null;
}

function setCachedData(key, data) {
    cache.set(key, { data, timestamp: Date.now() });
    if (cache.size > 50) {
        const firstKey = cache.keys().next().value;
        cache.delete(firstKey);
    }
}

async function findSongs(text) {
    try {
        const cacheKey = `song_${text.toLowerCase().trim()}`;
        const cached = getCachedData(cacheKey);
        if (cached) return cached;
        
        console.log('[FindSong] Searching:', text);
        
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 15000);
        
        const response = await fetch(
            'https://songsear.ch/q/' + encodeURIComponent(text),
            {
                signal: controller.signal,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            }
        );
        
        clearTimeout(timeout);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        
        const html = await response.text();
        const $ = cheerio.load(html);
        
        const title = $('div.results > div:nth-child(1) > .head > h3 > b').text();
        const artist = $('div.results > div:nth-child(1) > .head > h2 > a').text();
        const album = $('div.results > div:nth-child(1) > .head > p').text();
        const songUrl = $('div.results > div:nth-child(1) > .head > a').attr('href');
        const thumb = $('div.results > div:nth-child(1) > .head > a > img').attr('src');
        
        if (!title || !artist || !songUrl) {
            throw new Error('Song not found');
        }
        
        const songNumber = songUrl.split('/')[4];
        
        console.log('[FindSong] Found song, fetching lyrics...');
        
        const lyricsController = new AbortController();
        const lyricsTimeout = setTimeout(() => lyricsController.abort(), 10000);
        
        const lyricsResponse = await fetch(
            `https://songsear.ch/api/song/${songNumber}?text_only=true`,
            {
                signal: lyricsController.signal,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            }
        );
        
        clearTimeout(lyricsTimeout);
        
        if (!lyricsResponse.ok) {
            throw new Error(`HTTP ${lyricsResponse.status} - Lyrics API`);
        }
        
        const lyricData = await lyricsResponse.json();
        
        const lyrics = lyricData.song.text_html
            .replace(/<br\/>/g, '\n')
            .replace(/&#x27;/g, "'")
            .replace(/&quot;/g, '"')
            .replace(/&amp;/g, '&')
            .replace(/<[^>]*>/g, '');
        
        const result = {
            status: true,
            title: `${title} - ${artist}`,
            album: album || 'Unknown Album',
            thumb: thumb || null,
            lyrics: lyrics,
            songNumber: songNumber
        };
        
        setCachedData(cacheKey, result);
        
        console.log('[FindSong] Success:', result.title);
        return result;
        
    } catch (error) {
        console.error('[FindSong] Error:', error.message);
        return {
            status: false,
            error: error.message
        };
    }
}

let processingUsers = new Set();

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    const userId = m.sender;
    let prefix = usedPrefix || '.';
    const cmd = command || 'findsong2';
    
    if (processingUsers.has(userId)) {
        return m.reply('⏳ Tunggu pencarian sebelumnya...');
    }
    
    // Get query from text or args
    let query = '';
    if (text) {
        query = text.trim();
    } else if (args && args.length > 0) {
        query = args.join(' ').trim();
    }
    
    if (!query) {
        return m.reply(`*🎵 Find Song*

Cari lirik lagu dengan kata kunci:
${prefix}${cmd} <kata kunci>

Contoh:
${prefix}${cmd} bohemian rhapsody
${prefix}${cmd} imagine john lennon
${prefix}${cmd} hotel california`);
    }
    
    processingUsers.add(userId);
    
    try {
        await conn.sendMessage(m.chat, {
            react: { text: '🔍', key: m.key }
        });
        
        const result = await findSongs(query);
        
        if (!result.status) {
            await conn.sendMessage(m.chat, {
                react: { text: '❌', key: m.key }
            });
            return m.reply(`❌ *Pencarian Gagal*

Error: ${result.error}

💡 Tips:
• Coba kata kunci lain
• Gunakan judul + artis
• Pastikan ejaan benar`);
        }
        
        // Truncate lyrics jika terlalu panjang (max 3000 char untuk WhatsApp)
        let lyricsText = result.lyrics;
        if (lyricsText.length > 3000) {
            lyricsText = lyricsText.substring(0, 2997) + '...';
        }
        
        const message = `*🎵 ${result.title}*

📀 Album: ${result.album}

*Lyrics:*
${lyricsText}`;
        
        if (result.thumb) {
            try {
                await conn.sendMessage(m.chat, {
                    image: { url: result.thumb },
                    caption: message
                }, { quoted: m });
            } catch (imgError) {
                console.error('[FindSong] Failed to send image:', imgError.message);
                await m.reply(message);
            }
        } else {
            await m.reply(message);
        }
        
        await conn.sendMessage(m.chat, {
            react: { text: '✅', key: m.key }
        });
        
    } catch (error) {
        console.error('[FindSong] Handler error:', error);
        
        await conn.sendMessage(m.chat, {
            react: { text: '❌', key: m.key }
        });
        
        m.reply(`❌ Error: ${error.message}`);
    } finally {
        processingUsers.delete(userId);
    }
};

handler.help = ["findsong2"];
handler.tags = ["tools"];
handler.command = ["findsong2", "lirik2", "lyrics2"];
handler.limit = true;
handler.register = false;

export default handler;