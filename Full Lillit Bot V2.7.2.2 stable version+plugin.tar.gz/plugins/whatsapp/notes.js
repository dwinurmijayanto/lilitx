import fs from "fs";
import path from "path";

// ========== LID TO JID CONVERTER ==========
const isLID = (id) => {
  if (!id || typeof id !== 'string') return false;
  return id.endsWith('@lid');
};

const isJID = (id) => {
  if (!id || typeof id !== 'string') return false;
  return id.includes('@s.whatsapp.net') || id.includes('@g.us') || id.includes('@broadcast');
};

const extractNumber = (id) => {
  if (!id) return '';
  if (/^\d+$/.test(id)) return id;
  return id.split('@')[0].replace(/[^\d]/g, '');
};

const toDisplayFormat = (id, messageContext = null) => {
  if (!id) return '';
  
  const participantAlt = messageContext?.key?.participantAlt || 
                         messageContext?.participantAlt;
  
  if (participantAlt) {
    const altNumber = extractNumber(participantAlt);
    if (altNumber) {
      return `${altNumber}@s.whatsapp.net`;
    }
  }
  
  if (isLID(id)) {
    const number = id.split('@')[0];
    return `${number}@s.whatsapp.net`;
  }
  
  return id;
};

const getCorrectNumber = (message) => {
  const alt = message?.key?.participantAlt || message?.participantAlt;
  if (alt) {
    const num = extractNumber(alt);
    if (num) return num;
  }
  
  const participant = message?.key?.participant || message?.participant || message?.sender;
  if (participant) {
    return extractNumber(participant);
  }
  
  return '';
};

// Helper untuk baca/tulis storage
const storageDir = './data/group-storage';

// Pastikan folder storage ada
if (!fs.existsSync(storageDir)) {
  fs.mkdirSync(storageDir, { recursive: true });
}

const getStoragePath = (key) => {
  const safeName = key.replace(/[^a-z0-9_-]/gi, '_');
  return path.join(storageDir, `${safeName}.json`);
};

const storageGet = (key) => {
  try {
    const filePath = getStoragePath(key);
    if (fs.existsSync(filePath)) {
      const data = fs.readFileSync(filePath, 'utf8');
      return { key, value: data };
    }
    return null;
  } catch (e) {
    console.error('Storage get error:', e);
    return null;
  }
};

const storageSet = (key, value) => {
  try {
    const filePath = getStoragePath(key);
    fs.writeFileSync(filePath, value, 'utf8');
    return { key, value };
  } catch (e) {
    console.error('Storage set error:', e);
    return null;
  }
};

const storageDelete = (key) => {
  try {
    const filePath = getStoragePath(key);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      return { key, deleted: true };
    }
    return { key, deleted: false };
  } catch (e) {
    console.error('Storage delete error:', e);
    return null;
  }
};

let handler = async (m, { conn, config, command, args, usedPrefix = '.' }) => {
  try {
    // Extract text dari args
    let text = Array.isArray(args) ? args.join(' ') : '';
    
    if (!text && m.body) {
      const commandPrefix = usedPrefix + command;
      if (m.body.startsWith(commandPrefix)) {
        text = m.body.slice(commandPrefix.length).trim();
      }
    }
    
    // Cek apakah di grup
    const isGroup = m.isGroup;
    
    if (!isGroup) {
      return m.reply("❌ Command ini hanya bisa digunakan di grup!");
    }
    
    // Ambil metadata grup
    const groupMetadata = await conn.groupMetadata(m.chat);
    const participants = groupMetadata.participants;
    
    // ========== HELPER FUNCTIONS ==========
    
    // Helper untuk extract nomor dari berbagai format
    const extractCleanNumber = (jid) => {
      if (!jid) return null;
      return extractNumber(jid);
    };
    
    // Helper untuk convert ke JID format yang benar untuk mention
    const toJidFormat = (jid) => {
      if (!jid) return null;
      
      // Jika sudah JID format, return as-is
      if (isJID(jid)) return jid;
      
      // Jika LID, cari participant yang sesuai
      if (isLID(jid)) {
        const participant = participants.find(p => p.id === jid);
        
        // Priority 1: Cek participantAlt (nomor yang benar)
        if (participant?.participantAlt) {
          const altNum = extractNumber(participant.participantAlt);
          if (altNum) {
            return `${altNum}@s.whatsapp.net`;
          }
        }
        
        // Priority 2: Cek phoneNumber
        if (participant?.phoneNumber) {
          const phoneNum = extractNumber(participant.phoneNumber);
          if (phoneNum) {
            return `${phoneNum}@s.whatsapp.net`;
          }
        }
        
        // Priority 3: Fallback convert manual
        const number = jid.split('@')[0];
        return `${number}@s.whatsapp.net`;
      }
      
      return jid;
    };
    
    // Helper untuk cari participant dengan matching number
    const findParticipantByJid = (targetJid) => {
      if (!targetJid) return null;
      
      // Exact match
      let participant = participants.find(p => p.id === targetJid);
      if (participant) return participant;
      
      // Match by clean number
      const cleanTarget = extractCleanNumber(targetJid);
      if (cleanTarget) {
        participant = participants.find(p => {
          const cleanId = extractCleanNumber(p.id);
          if (cleanId === cleanTarget) return true;
          
          if (p.phoneNumber) {
            const cleanPhone = extractCleanNumber(p.phoneNumber);
            if (cleanPhone === cleanTarget) return true;
          }
          
          if (p.participantAlt) {
            const cleanAlt = extractCleanNumber(p.participantAlt);
            if (cleanAlt === cleanTarget) return true;
          }
          
          return false;
        });
      }
      
      return participant || null;
    };
    
    // Helper: Get user name from contact or default to number
    const getUserName = async (jid) => {
      try {
        const number = extractCleanNumber(jid);
        // Try to get push name or contact name
        if (m.sender === jid) {
          return m.pushName || number;
        }
        // Try from group metadata
        const participant = participants.find(p => p.id === jid);
        if (participant && participant.notify) {
          return participant.notify;
        }
        return number;
      } catch (e) {
        return extractCleanNumber(jid);
      }
    };
    
    // Helper: Extract user dari mention/quoted/text
    const extractUser = () => {
      if (m.mentionedJid && m.mentionedJid.length > 0) {
        return m.mentionedJid[0];
      }
      
      if (text) {
        const phoneMatch = text.match(/@(\d{10,15})/);
        if (phoneMatch) {
          return phoneMatch[1] + '@s.whatsapp.net';
        }
      }
      
      if (m.quoted) {
        return m.quoted.participant || m.quoted.sender;
      }
      
      if (text) {
        let cleanText = text.trim();
        let match = cleanText.match(/^(\+?62\d+|0\d+)$/);
        if (match) {
          let number = match[0].replace(/[@+\s-]/g, '');
          if (number.startsWith('0')) {
            number = '62' + number.slice(1);
          }
          return number + '@s.whatsapp.net';
        }
      }
      
      return null;
    };
    
    // Cek admin status
    const userParticipant = participants.find(p => p.id === m.sender);
    const isUserAdmin = userParticipant?.admin === 'admin' || userParticipant?.admin === 'superadmin';
    
    // Storage keys
    const notesKey = `notes:${m.chat}`;
    const warningsKey = `warnings:${m.chat}`;
    const attendanceKey = `attendance:${m.chat}`;
    const todoKey = `todo:${m.chat}`;
    
    // ==========================================
    // FITUR 1: CATATAN GRUP (NOTES)
    // ==========================================
    
    if (command === "addnote" || command === "tambahcatatan") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      if (!text) {
        return m.reply(`❌ Masukkan catatan yang ingin disimpan!

*Contoh:*
.addnote Link materi: https://example.com
.addnote Jadwal meeting: Senin 10:00 WIB`);
      }
      
      try {
        let notesData = { notes: [] };
        const result = storageGet(notesKey);
        if (result && result.value) {
          notesData = JSON.parse(result.value);
        }
        
        const userName = await getUserName(m.sender);
        const newNote = {
          id: Date.now(),
          text: text,
          author: extractCleanNumber(m.sender),
          authorName: userName,
          date: new Date().toLocaleString('id-ID')
        };
        
        notesData.notes.unshift(newNote);
        storageSet(notesKey, JSON.stringify(notesData));
        
        m.reply(`✅ Catatan berhasil ditambahkan!\n\n📝 *${text}*\n\n_Oleh: ${userName}_\n_Total catatan: ${notesData.notes.length}_`);
        
      } catch (e) {
        m.reply(`❌ Gagal menyimpan catatan!\n\nError: ${e.message}`);
      }
    }
    
    else if (command === "listnote" || command === "notes" || command === "catatan") {
      try {
        let notesData = { notes: [] };
        const result = storageGet(notesKey);
        if (result && result.value) {
          notesData = JSON.parse(result.value);
        }
        
        if (notesData.notes.length === 0) {
          return m.reply("📝 Belum ada catatan di grup ini.\n\nGunakan .addnote untuk menambahkan catatan.");
        }
        
        let msg = `📝 *CATATAN GRUP*\n`;
        msg += `Total: ${notesData.notes.length} catatan\n\n`;
        
        notesData.notes.slice(0, 20).forEach((note, i) => {
          msg += `*${i + 1}.* ${note.text}\n`;
          msg += `   _oleh: ${note.authorName || note.author} | ${note.date}_\n\n`;
        });
        
        if (notesData.notes.length > 20) {
          msg += `_...dan ${notesData.notes.length - 20} catatan lainnya_\n`;
        }
        
        msg += `\n*Kelola catatan:*\n`;
        msg += `.addnote [text] - Tambah catatan\n`;
        msg += `.delnote [nomor] - Hapus catatan\n`;
        msg += `.clearnotes - Hapus semua catatan`;
        
        m.reply(msg);
        
      } catch (e) {
        m.reply(`❌ Gagal mengambil catatan!\n\nError: ${e.message}`);
      }
    }
    
    else if (command === "delnote" || command === "hapuscatatan") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      if (!text || isNaN(text)) {
        return m.reply(`❌ Masukkan nomor catatan yang ingin dihapus!

*Contoh:*
.delnote 1
.delnote 3

Gunakan .notes untuk melihat nomor catatan.`);
      }
      
      try {
        const noteIndex = parseInt(text) - 1;
        let notesData = { notes: [] };
        const result = storageGet(notesKey);
        if (result && result.value) {
          notesData = JSON.parse(result.value);
        }
        
        if (noteIndex < 0 || noteIndex >= notesData.notes.length) {
          return m.reply(`❌ Nomor catatan tidak valid! Total catatan: ${notesData.notes.length}`);
        }
        
        const deletedNote = notesData.notes.splice(noteIndex, 1)[0];
        storageSet(notesKey, JSON.stringify(notesData));
        
        m.reply(`✅ Catatan berhasil dihapus!\n\n📝 _"${deletedNote.text}"_`);
        
      } catch (e) {
        m.reply(`❌ Gagal menghapus catatan!\n\nError: ${e.message}`);
      }
    }
    
    else if (command === "clearnotes" || command === "hapussemuacatatan") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      try {
        storageDelete(notesKey);
        m.reply("✅ Semua catatan berhasil dihapus!");
      } catch (e) {
        m.reply(`❌ Gagal menghapus catatan!\n\nError: ${e.message}`);
      }
    }
    
    // ==========================================
    // FITUR 2: WARNING SYSTEM
    // ==========================================
    
    else if (command === "warn" || command === "warning") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      let targetUser = extractUser();
      
      if (!targetUser) {
        return m.reply(`❌ Tag atau reply user yang ingin diberi warning!

*Contoh:*
.warn @user alasan warning
.warn @user spam
Reply pesan user: .warn melanggar rules`);
      }
      
      let reason = text.replace(/@\d+/g, '').trim() || "Tidak ada alasan";
      
      try {
        let warningsData = { warnings: {} };
        const result = storageGet(warningsKey);
        if (result && result.value) {
          warningsData = JSON.parse(result.value);
        }
        
        const targetNumber = extractCleanNumber(targetUser);
        
        if (!warningsData.warnings[targetNumber]) {
          warningsData.warnings[targetNumber] = [];
        }
        
        const newWarning = {
          id: Date.now(),
          reason: reason,
          by: extractCleanNumber(m.sender),
          date: new Date().toLocaleString('id-ID')
        };
        
        warningsData.warnings[targetNumber].push(newWarning);
        const totalWarns = warningsData.warnings[targetNumber].length;
        storageSet(warningsKey, JSON.stringify(warningsData));
        
        let msg = `⚠️ *WARNING DIBERIKAN*\n\n`;
        msg += `User: @${targetNumber}\n`;
        msg += `Alasan: ${reason}\n`;
        msg += `Oleh: @${extractCleanNumber(m.sender)}\n\n`;
        msg += `Total warning: ${totalWarns}/3\n\n`;
        
        if (totalWarns >= 3) {
          msg += `🚨 User mencapai 3 warning!\n`;
          msg += `Admin dapat menendang user dengan .kick @user`;
        } else {
          msg += `⚠️ Sisa ${3 - totalWarns} warning sebelum tindakan!`;
        }
        
        m.reply(msg, null, {
          mentions: [targetUser, m.sender]
        });
        
      } catch (e) {
        m.reply(`❌ Gagal memberikan warning!\n\nError: ${e.message}`);
      }
    }
    
    else if (command === "warnings" || command === "cekwarn") {
      let targetUser = extractUser();
      
      if (!targetUser) {
        targetUser = m.sender;
      }
      
      try {
        let warningsData = { warnings: {} };
        const result = storageGet(warningsKey);
        if (result && result.value) {
          warningsData = JSON.parse(result.value);
        }
        
        const targetNumber = extractCleanNumber(targetUser);
        const userWarnings = warningsData.warnings[targetNumber] || [];
        
        if (userWarnings.length === 0) {
          return m.reply(`✅ @${targetNumber} tidak memiliki warning.`, null, {
            mentions: [targetUser]
          });
        }
        
        let msg = `⚠️ *WARNING LIST*\n\n`;
        msg += `User: @${targetNumber}\n`;
        msg += `Total: ${userWarnings.length}/3\n\n`;
        
        userWarnings.forEach((warn, i) => {
          msg += `*${i + 1}.* ${warn.reason}\n`;
          msg += `   _oleh: @${warn.by} | ${warn.date}_\n\n`;
        });
        
        const mentions = [targetUser, ...userWarnings.map(w => `${w.by}@s.whatsapp.net`)];
        m.reply(msg, null, { mentions });
        
      } catch (e) {
        m.reply(`❌ Gagal mengecek warning!\n\nError: ${e.message}`);
      }
    }
    
    else if (command === "unwarn" || command === "delwarn") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      let targetUser = extractUser();
      
      if (!targetUser) {
        return m.reply(`❌ Tag atau reply user yang ingin dihapus warningnya!

*Contoh:*
.unwarn @user
Reply pesan user: .unwarn`);
      }
      
      try {
        let warningsData = { warnings: {} };
        const result = storageGet(warningsKey);
        if (result && result.value) {
          warningsData = JSON.parse(result.value);
        }
        
        const targetNumber = extractCleanNumber(targetUser);
        
        if (!warningsData.warnings[targetNumber] || warningsData.warnings[targetNumber].length === 0) {
          return m.reply(`ℹ️ @${targetNumber} tidak memiliki warning.`, null, {
            mentions: [targetUser]
          });
        }
        
        warningsData.warnings[targetNumber].pop();
        
        if (warningsData.warnings[targetNumber].length === 0) {
          delete warningsData.warnings[targetNumber];
        }
        
        storageSet(warningsKey, JSON.stringify(warningsData));
        
        const remaining = warningsData.warnings[targetNumber]?.length || 0;
        
        m.reply(`✅ Warning berhasil dihapus!\n\n@${targetNumber}\nSisa warning: ${remaining}/3`, null, {
          mentions: [targetUser]
        });
        
      } catch (e) {
        m.reply(`❌ Gagal menghapus warning!\n\nError: ${e.message}`);
      }
    }
    
    // ==========================================
    // FITUR 3: ABSENSI (ATTENDANCE) - ENHANCED
    // ==========================================
    
    else if (command === "bukaabsen" || command === "openattendance") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      if (!text) {
        return m.reply(`❌ Masukkan judul absensi!

*Contoh:*
.bukaabsen Meeting Mingguan
.bukaabsen Kelas Zoom - 28 Oktober`);
      }
      
      try {
        const userName = await getUserName(m.sender);
        let attendanceData = {
          active: true,
          title: text,
          openedBy: extractCleanNumber(m.sender),
          openedByName: userName,
          openedAt: new Date().toLocaleString('id-ID'),
          participants: []
        };
        
        storageSet(attendanceKey, JSON.stringify(attendanceData));
        
        let msg = `📋 *ABSENSI DIBUKA*\n\n`;
        msg += `*${text}*\n\n`;
        msg += `Dibuka oleh: ${userName}\n`;
        msg += `Waktu: ${attendanceData.openedAt}\n\n`;
        msg += `Ketik *.hadir* untuk absen!\n`;
        msg += `Admin: ketik *.tutupabsen* untuk menutup`;
        
        m.reply(msg);
        
      } catch (e) {
        m.reply(`❌ Gagal membuka absensi!\n\nError: ${e.message}`);
      }
    }
    
    else if (command === "hadir" || command === "absen" || command === "present") {
      try {
        let attendanceData = null;
        const result = storageGet(attendanceKey);
        if (result && result.value) {
          attendanceData = JSON.parse(result.value);
        }
        
        if (!attendanceData || !attendanceData.active) {
          return m.reply("❌ Tidak ada absensi yang sedang dibuka!\n\nAdmin dapat membuka dengan .bukaabsen");
        }
        
        const userNumber = extractCleanNumber(m.sender);
        const alreadyPresent = attendanceData.participants.some(p => p.number === userNumber);
        
        if (alreadyPresent) {
          return m.reply("✅ Anda sudah tercatat hadir!");
        }
        
        const userName = await getUserName(m.sender);
        const note = text || "-";
        
        // Cari participant untuk mendapatkan JID yang benar
        const participant = findParticipantByJid(m.sender);
        let correctJid = m.sender;
        let storedId = m.sender; // ID asli untuk reference
        
        // Priority 1: participantAlt (nomor yang benar!)
        if (participant?.participantAlt) {
          const altNum = extractNumber(participant.participantAlt);
          if (altNum) {
            correctJid = `${altNum}@s.whatsapp.net`;
          }
        }
        // Priority 2: phoneNumber
        else if (participant?.phoneNumber) {
          const phoneNum = extractNumber(participant.phoneNumber);
          if (phoneNum) {
            correctJid = `${phoneNum}@s.whatsapp.net`;
          }
        }
        // Priority 3: Convert dari LID
        else if (isLID(m.sender)) {
          correctJid = toJidFormat(m.sender);
        }
        
        attendanceData.participants.push({
          number: userNumber,
          id: storedId, // ID asli (LID/JID)
          jid: correctJid, // JID yang sudah di-convert dengan benar untuk mention
          name: userName,
          time: new Date().toLocaleString('id-ID'),
          note: note
        });
        
        storageSet(attendanceKey, JSON.stringify(attendanceData));
        
        // Generate list peserta
        let participantList = attendanceData.participants.map((p, i) => 
          `${i + 1}. ${p.name}`
        ).join('\n');
        
        m.reply(`✅ Terima kasih, ${userName}!\n\nAnda tercatat hadir untuk:\n*${attendanceData.title}*\n\n*Daftar Hadir (${attendanceData.participants.length} orang):*\n${participantList}`);
        
      } catch (e) {
        m.reply(`❌ Gagal mencatat kehadiran!\n\nError: ${e.message}`);
      }
    }
    
    else if (command === "tutupabsen" || command === "closeattendance") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      try {
        let attendanceData = null;
        const result = storageGet(attendanceKey);
        if (result && result.value) {
          attendanceData = JSON.parse(result.value);
        }
        
        if (!attendanceData || !attendanceData.active) {
          return m.reply("❌ Tidak ada absensi yang sedang dibuka!");
        }
        
        const userName = await getUserName(m.sender);
        attendanceData.active = false;
        attendanceData.closedBy = extractCleanNumber(m.sender);
        attendanceData.closedByName = userName;
        attendanceData.closedAt = new Date().toLocaleString('id-ID');
        
        storageSet(attendanceKey, JSON.stringify(attendanceData));
        
        let msg = `📋 *ABSENSI DITUTUP*\n\n`;
        msg += `*${attendanceData.title}*\n\n`;
        msg += `Total hadir: ${attendanceData.participants.length} orang\n\n`;
        msg += `*Daftar Hadir:*\n`;
        
        // Build daftar hadir dengan mention nama
        const mentions = [];
        attendanceData.participants.forEach((p, i) => {
          const jid = p.jid || p.id || `${p.number}@s.whatsapp.net`;
          mentions.push(jid);
          
          msg += `${i + 1}. ${p.name} @${extractCleanNumber(jid)} - ${p.time}\n`;
          if (p.note !== "-") {
            msg += `   _${p.note}_\n`;
          }
        });
        
        msg += `\nDitutup oleh: ${userName}`;
        
        console.log('=== TUTUP ABSEN DEBUG ===');
        console.log('Total participants:', attendanceData.participants.length);
        console.log('Mentions array:', mentions);
        attendanceData.participants.forEach((p, i) => {
          console.log(`${i + 1}. Name: ${p.name}, JID: ${p.jid}, ID: ${p.id}, Number: ${p.number}`);
        });
        
        m.reply(msg, null, { mentions });
        
      } catch (e) {
        m.reply(`❌ Gagal menutup absensi!\n\nError: ${e.message}`);
      }
    }
    
    else if (command === "cekabsen" || command === "listabsen") {
      try {
        let attendanceData = null;
        const result = storageGet(attendanceKey);
        if (result && result.value) {
          attendanceData = JSON.parse(result.value);
        }
        
        if (!attendanceData) {
          return m.reply("❌ Belum ada data absensi!");
        }
        
        let msg = `📋 *DATA ABSENSI*\n\n`;
        msg += `*${attendanceData.title}*\n`;
        msg += `Status: ${attendanceData.active ? '🟢 Dibuka' : '🔴 Ditutup'}\n`;
        msg += `Dibuka: ${attendanceData.openedAt}\n`;
        if (!attendanceData.active) {
          msg += `Ditutup: ${attendanceData.closedAt}\n`;
        }
        msg += `\nTotal hadir: ${attendanceData.participants.length} orang\n\n`;
        
        if (attendanceData.participants.length > 0) {
          msg += `*Daftar Hadir:*\n`;
          attendanceData.participants.forEach((p, i) => {
            msg += `${i + 1}. ${p.name}\n`;
            msg += `   ${p.time}`;
            if (p.note !== "-") {
              msg += ` - ${p.note}`;
            }
            msg += `\n`;
          });
        }
        
        m.reply(msg);
        
      } catch (e) {
        m.reply(`❌ Gagal mengambil data absensi!\n\nError: ${e.message}`);
      }
    }
    
    // ==========================================
    // FITUR 4: TODO LIST GRUP
    // ==========================================
    
    else if (command === "addtodo" || command === "tambahtodo") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      if (!text) {
        return m.reply(`❌ Masukkan tugas yang ingin ditambahkan!

*Contoh:*
.addtodo Siapkan materi presentasi
.addtodo Upload dokumentasi project`);
      }
      
      try {
        let todoData = { todos: [] };
        const result = storageGet(todoKey);
        if (result && result.value) {
          todoData = JSON.parse(result.value);
        }
        
        const newTodo = {
          id: Date.now(),
          text: text,
          done: false,
          addedBy: extractCleanNumber(m.sender),
          addedAt: new Date().toLocaleString('id-ID'),
          doneBy: null,
          doneAt: null
        };
        
        todoData.todos.push(newTodo);
        storageSet(todoKey, JSON.stringify(todoData));
        
        m.reply(`✅ Tugas berhasil ditambahkan!\n\n📌 *${text}*\n\nTotal tugas aktif: ${todoData.todos.filter(t => !t.done).length}`);
        
      } catch (e) {
        m.reply(`❌ Gagal menambahkan tugas!\n\nError: ${e.message}`);
      }
    }
    
    else if (command === "todo" || command === "listtodo") {
      try {
        let todoData = { todos: [] };
        const result = storageGet(todoKey);
        if (result && result.value) {
          todoData = JSON.parse(result.value);
        }
        
        if (todoData.todos.length === 0) {
          return m.reply("📝 Belum ada tugas di grup ini.\n\nGunakan .addtodo untuk menambahkan tugas.");
        }
        
        const activeTodos = todoData.todos.filter(t => !t.done);
        const doneTodos = todoData.todos.filter(t => t.done);
        
        let msg = `📋 *TODO LIST GRUP*\n\n`;
        
        if (activeTodos.length > 0) {
          msg += `*🔴 Tugas Aktif (${activeTodos.length})*\n`;
          activeTodos.forEach((todo, i) => {
            msg += `${i + 1}. ${todo.text}\n`;
            msg += `   _ditambahkan: ${todo.addedAt}_\n\n`;
          });
        }
        
        if (doneTodos.length > 0) {
          msg += `\n*✅ Selesai (${doneTodos.length})*\n`;
          doneTodos.slice(0, 5).forEach((todo, i) => {
            msg += `${i + 1}. ~${todo.text}~\n`;
            msg += `   _selesai: ${todo.doneAt}_\n\n`;
          });
        }
        
        msg += `\n*Kelola tugas:*\n`;
        msg += `.addtodo [task] - Tambah tugas\n`;
        msg += `.donetodo [nomor] - Tandai selesai\n`;
        msg += `.deltodo [nomor] - Hapus tugas`;
        
        m.reply(msg);
        
      } catch (e) {
        m.reply(`❌ Gagal mengambil todo list!\n\nError: ${e.message}`);
      }
    }
    
    else if (command === "donetodo" || command === "selesaitodo") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      if (!text || isNaN(text)) {
        return m.reply(`❌ Masukkan nomor tugas yang sudah selesai!

*Contoh:*
.donetodo 1
.donetodo 3`);
      }
      
      try {
        const todoIndex = parseInt(text) - 1;
        let todoData = { todos: [] };
        const result = storageGet(todoKey);
        if (result && result.value) {
          todoData = JSON.parse(result.value);
        }
        
        const activeTodos = todoData.todos.filter(t => !t.done);
        
        if (todoIndex < 0 || todoIndex >= activeTodos.length) {
          return m.reply(`❌ Nomor tugas tidak valid! Total tugas aktif: ${activeTodos.length}`);
        }
        
        const todo = activeTodos[todoIndex];
        todo.done = true;
        todo.doneBy = extractCleanNumber(m.sender);
        todo.doneAt = new Date().toLocaleString('id-ID');
        
        storageSet(todoKey, JSON.stringify(todoData));
        
        m.reply(`✅ Tugas selesai!\n\n~${todo.text}~\n\nDiselesaikan oleh: @${extractCleanNumber(m.sender)}`, null, {
          mentions: [m.sender]
        });
        
      } catch (e) {
        m.reply(`❌ Gagal menandai tugas selesai!\n\nError: ${e.message}`);
      }
    }
    
    else if (command === "deltodo" || command === "hapustodo") {
      if (!isUserAdmin) {
        return m.reply("❌ Command ini hanya untuk admin grup!");
      }
      
      if (!text || isNaN(text)) {
        return m.reply(`❌ Masukkan nomor tugas yang ingin dihapus!

*Contoh:*
.deltodo 1`);
      }
      
      try {
        const todoIndex = parseInt(text) - 1;
        let todoData = { todos: [] };
        const result = storageGet(todoKey);
        if (result && result.value) {
          todoData = JSON.parse(result.value);
        }
        
        const activeTodos = todoData.todos.filter(t => !t.done);
        
        if (todoIndex < 0 || todoIndex >= activeTodos.length) {
          return m.reply(`❌ Nomor tugas tidak valid! Total tugas aktif: ${activeTodos.length}`);
        }
        
        const todoToDelete = activeTodos[todoIndex];
        todoData.todos = todoData.todos.filter(t => t.id !== todoToDelete.id);
        
        storageSet(todoKey, JSON.stringify(todoData));
        
        m.reply(`✅ Tugas berhasil dihapus!\n\n_"${todoToDelete.text}"_`);
        
      } catch (e) {
        m.reply(`❌ Gagal menghapus tugas!\n\nError: ${e.message}`);
      }
    }
    
  } catch (e) {
    console.error('Error:', e);
    m.reply(`❌ Terjadi kesalahan!\n\nError: ${e.message}`);
  }
};

handler.help = [
  "addnote [text] - Tambah catatan grup",
  "notes - Lihat semua catatan",
  "delnote [nomor] - Hapus catatan",
  "clearnotes - Hapus semua catatan",
  "warn @user [alasan] - Beri warning",
  "warnings [@user] - Cek warning",
  "unwarn @user - Hapus 1 warning",
  "bukaabsen [judul] - Buka absensi",
  "hadir [keterangan] - Absen hadir",
  "tutupabsen - Tutup absensi",
  "cekabsen - Lihat data absensi",
  "addtodo [task] - Tambah tugas",
  "todo - Lihat todo list",
  "donetodo [nomor] - Tandai selesai",
  "deltodo [nomor] - Hapus tugas"
];

handler.tags = ["group"];
handler.command = [
  "addnote", "tambahcatatan",
  "listnote", "notes", "catatan",
  "delnote", "hapuscatatan",
  "clearnotes", "hapussemuacatatan",
  "warn", "warning",
  "warnings", "cekwarn",
  "unwarn", "delwarn",
  "bukaabsen", "openattendance",
  "hadir", "absen", "present",
  "tutupabsen", "closeattendance",
  "cekabsen", "listabsen",
  "addtodo", "tambahtodo",
  "todo", "listtodo",
  "donetodo", "selesaitodo",
  "deltodo", "hapustodo"
];

handler.group = true;

export default handler;