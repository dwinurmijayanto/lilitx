const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

console.log('[Store Handler] Loading handler...');

// ========== DIGITAL STORE HANDLER ==========
const DATA_JSON_URLS = [
    'https://upload.vbi1.my.id/data/store/products.json',
    'https://api.vbi1.my.id/data/store/products.json'
];

const ORDERS_JSON_URLS = [
    'https://upload.vbi1.my.id/data/store/orders.json',
    'https://api.vbi1.my.id/data/store/orders.json'
];

const EDIT_API_URLS = [
    'https://upload.vbi1.my.id/data/store/',
    'https://api.vbi1.my.id/data/store/'
];

const TIMEOUT_MS = 8000;
const ORDER_EXPIRY_MS = 24 * 60 * 60 * 1000; // 24 jam
const DOWNLOAD_EXPIRY_MS = 7 * 24 * 60 * 60 * 1000; // 7 hari

const ADMIN_LIST = [
    '6282331664567',
    '134479771373585@lid',
];

function isAdmin(userId) {
    console.log('[Store Handler] Checking admin access...');
    console.log('[Store Handler] Raw userId:', userId);
    
    if (!userId) {
        console.log('[Store Handler] ❌ userId is null/undefined');
        return false;
    }
    
    let identifier = userId;
    
    if (identifier.includes(':')) {
        identifier = identifier.split(':')[0] + '@' + identifier.split('@')[1];
    }
    
    console.log('[Store Handler] Cleaned identifier:', identifier);
    
    if (ADMIN_LIST.includes(identifier)) {
        console.log('[Store Handler] ✅ ADMIN ACCESS GRANTED (exact match)');
        return true;
    }
    
    const idWithoutDomain = identifier.split('@')[0];
    console.log('[Store Handler] ID without domain:', idWithoutDomain);
    
    if (ADMIN_LIST.includes(idWithoutDomain)) {
        console.log('[Store Handler] ✅ ADMIN ACCESS GRANTED (number match)');
        return true;
    }
    
    const withJid = idWithoutDomain + '@s.whatsapp.net';
    const withLid = idWithoutDomain + '@lid';
    
    if (ADMIN_LIST.includes(withJid) || ADMIN_LIST.includes(withLid)) {
        console.log('[Store Handler] ✅ ADMIN ACCESS GRANTED');
        return true;
    }
    
    console.log('[Store Handler] ❌ ADMIN ACCESS DENIED');
    return false;
}

async function fetchProducts() {
    let combinedData = [];
    
    for (const url of DATA_JSON_URLS) {
        try {
            console.log(`[Store Handler] Fetching products from ${url}...`);
            
            const response = await Promise.race([
                fetch(url),
                new Promise((_, reject) => 
                    setTimeout(() => reject(new Error(`Timeout`)), TIMEOUT_MS)
                )
            ]);
            
            if (!response.ok) throw new Error(`HTTP Error: ${response.status}`);
            
            const data = await response.json();
            if (!Array.isArray(data)) throw new Error('Data tidak valid');
            
            console.log(`[Store Handler] ✅ Products fetched: ${data.length} items`);
            combinedData.push(...data);
            
        } catch (error) {
            console.warn(`[Store Handler] ❌ Fetch error:`, error.message);
        }
    }
    
    if (combinedData.length === 0) {
        throw new Error('Gagal mengambil data produk dari semua sumber');
    }
    
    const seen = new Set();
    const uniqueData = combinedData.filter(item => {
        const key = `${item.name}-${item.price}`;
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
    });
    
    return uniqueData;
}

async function fetchOrders() {
    let combinedData = [];
    
    for (const url of ORDERS_JSON_URLS) {
        try {
            console.log(`[Store Handler] Fetching orders from ${url}...`);
            
            const response = await Promise.race([
                fetch(url),
                new Promise((_, reject) => 
                    setTimeout(() => reject(new Error(`Timeout`)), TIMEOUT_MS)
                )
            ]);
            
            if (!response.ok) continue;
            
            const data = await response.json();
            if (!Array.isArray(data)) continue;
            
            combinedData.push(...data);
            
        } catch (error) {
            console.warn(`[Store Handler] ❌ Fetch orders error:`, error.message);
        }
    }
    
    return combinedData;
}

function findProductById(products, id) {
    return products.find(p => p.id == id);
}

function findOrderById(orders, id) {
    return orders.find(o => o.id === id);
}

function searchProducts(products, query) {
    return products.filter(p => 
        p.name.toLowerCase().includes(query.toLowerCase()) ||
        p.category.toLowerCase().includes(query.toLowerCase())
    );
}

async function createOrder(userId, productId, quantity, product) {
    console.log(`[Store Handler] Creating order for user: ${userId}, product: ${productId}, qty: ${quantity}`);
    
    const orderId = `ORDER-${Date.now().toString().slice(-8)}`;
    const total = product.price * quantity;
    
    const orderData = {
        id: orderId,
        userId: userId,
        productId: productId,
        productName: product.name,
        quantity: quantity,
        unitPrice: product.price,
        total: total,
        status: "pending",
        paymentStatus: "unpaid",
        paymentMethod: "transfer",
        paymentProof: null,
        paymentVerifiedAt: null,
        verifiedBy: null,
        downloadUrl: null,
        downloadExpiresAt: null,
        downloadedAt: null,
        timestamp: new Date().toISOString(),
        expiresAt: new Date(Date.now() + ORDER_EXPIRY_MS).toISOString()
    };
    
    let successCount = 0;
    
    const promises = EDIT_API_URLS.map(async (apiUrl) => {
        try {
            const formData = new URLSearchParams();
            formData.append('action', 'create_order');
            formData.append('data', JSON.stringify(orderData));
            
            const response = await Promise.race([
                fetch(apiUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: formData.toString()
                }),
                new Promise((_, reject) => 
                    setTimeout(() => reject(new Error(`Timeout`)), TIMEOUT_MS)
                )
            ]);
            
            if (!response.ok) throw new Error(`HTTP Error: ${response.status}`);
            successCount++;
            return { status: 'success' };
            
        } catch (error) {
            console.error(`[Store Handler] ❌ CREATE_ORDER FAILED:`, error.message);
            return { status: 'failed' };
        }
    });
    
    await Promise.all(promises);
    
    if (successCount === 0) {
        throw new Error('Gagal membuat order ke semua server');
    }
    
    return { success: true, orderId: orderId, total: total };
}

async function confirmPayment(orderId, mediaUrl) {
    console.log(`[Store Handler] Confirming payment for order: ${orderId}`);
    
    let successCount = 0;
    
    const promises = EDIT_API_URLS.map(async (apiUrl) => {
        try {
            const formData = new URLSearchParams();
            formData.append('action', 'confirm_payment');
            formData.append('orderId', orderId);
            formData.append('paymentProof', mediaUrl);
            
            const response = await Promise.race([
                fetch(apiUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: formData.toString()
                }),
                new Promise((_, reject) => 
                    setTimeout(() => reject(new Error(`Timeout`)), TIMEOUT_MS)
                )
            ]);
            
            if (!response.ok) throw new Error(`HTTP Error: ${response.status}`);
            successCount++;
            
        } catch (error) {
            console.error(`[Store Handler] ❌ CONFIRM PAYMENT FAILED:`, error.message);
        }
    });
    
    await Promise.all(promises);
    
    if (successCount === 0) {
        throw new Error('Gagal konfirmasi pembayaran');
    }
    
    return { success: true };
}

async function approveOrder(orderId, verifiedBy) {
    console.log(`[Store Handler] Approving order: ${orderId}`);
    
    let successCount = 0;
    
    const promises = EDIT_API_URLS.map(async (apiUrl) => {
        try {
            const formData = new URLSearchParams();
            formData.append('action', 'approve_order');
            formData.append('orderId', orderId);
            formData.append('verifiedBy', verifiedBy);
            formData.append('downloadExpiresAt', new Date(Date.now() + DOWNLOAD_EXPIRY_MS).toISOString());
            
            const response = await Promise.race([
                fetch(apiUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: formData.toString()
                }),
                new Promise((_, reject) => 
                    setTimeout(() => reject(new Error(`Timeout`)), TIMEOUT_MS)
                )
            ]);
            
            if (!response.ok) throw new Error(`HTTP Error: ${response.status}`);
            successCount++;
            
        } catch (error) {
            console.error(`[Store Handler] ❌ APPROVE FAILED:`, error.message);
        }
    });
    
    await Promise.all(promises);
    
    if (successCount === 0) {
        throw new Error('Gagal approve order');
    }
    
    return { success: true };
}

async function rejectOrder(orderId) {
    console.log(`[Store Handler] Rejecting order: ${orderId}`);
    
    let successCount = 0;
    
    const promises = EDIT_API_URLS.map(async (apiUrl) => {
        try {
            const formData = new URLSearchParams();
            formData.append('action', 'reject_order');
            formData.append('orderId', orderId);
            
            const response = await Promise.race([
                fetch(apiUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: formData.toString()
                }),
                new Promise((_, reject) => 
                    setTimeout(() => reject(new Error(`Timeout`)), TIMEOUT_MS)
                )
            ]);
            
            if (!response.ok) throw new Error(`HTTP Error: ${response.status}`);
            successCount++;
            
        } catch (error) {
            console.error(`[Store Handler] ❌ REJECT FAILED:`, error.message);
        }
    });
    
    await Promise.all(promises);
    
    if (successCount === 0) {
        throw new Error('Gagal reject order');
    }
    
    return { success: true };
}

function formatProductList(products) {
    let msg = `*🛍️ TOKO DIGITAL*\n\n`;
    msg += `📦 *${products.length} Produk Tersedia:*\n\n`;
    
    products.slice(0, 10).forEach((p, i) => {
        msg += `${i + 1}. *${p.name}*\n`;
        msg += `   💰 Rp${p.price?.toLocaleString?.('id-ID') || p.price}\n`;
        msg += `   📂 Kategori: ${p.category}\n`;
        msg += `   🆔 ID: ${p.id}\n\n`;
    });
    
    if (products.length > 10) {
        msg += `... dan ${products.length - 10} produk lainnya\n\n`;
    }
    
    msg += `💡 *Gunakan: .store detail <id>* untuk info lengkap\n`;
    msg += `💡 *Gunakan: .store beli <id> <qty>* untuk membeli\n`;
    msg += `💡 *Gunakan: .store cari <nama>* untuk mencari`;
    
    return msg;
}

function formatProductDetail(product) {
    let msg = `*📦 DETAIL PRODUK*\n\n`;
    msg += `┌─「 🏷️ *${product.name}* 」\n`;
    msg += `├ 💰 Harga: *Rp${product.price?.toLocaleString?.('id-ID') || product.price}*\n`;
    msg += `├ 📂 Kategori: *${product.category}*\n`;
    msg += `├ 📝 Deskripsi: ${product.description}\n`;
    msg += `├ 🆔 ID Produk: ${product.id}\n`;
    msg += `├ 📊 Stok: ${product.stock || '∞'}\n`;
    msg += `└ ⏰ Dibuat: ${new Date(product.createdAt).toLocaleDateString('id-ID')}\n\n`;
    msg += `💡 *Ketik: .store beli ${product.id} 1* untuk membeli`;
    
    return msg;
}

function formatPurchaseConfirm(product, quantity, total, orderId) {
    let msg = `*✅ KONFIRMASI PEMBELIAN*\n\n`;
    msg += `┌─「 🛒 *Ringkasan Pesanan* 」\n`;
    msg += `├ 📦 Produk: *${product.name}*\n`;
    msg += `├ 🔢 Jumlah: *${quantity}x*\n`;
    msg += `├ 💰 Harga Satuan: Rp${product.price?.toLocaleString?.('id-ID') || product.price}\n`;
    msg += `├ 🧮 Subtotal: *Rp${total?.toLocaleString?.('id-ID') || total}*\n`;
    msg += `└ 💳 Status: *⏳ Menunggu Pembayaran*\n\n`;
    msg += `📌 *Instruksi Pembayaran:*\n`;
    msg += `Transfer ke rekening toko dengan nominal: *Rp${total?.toLocaleString?.('id-ID') || total}*\n`;
    msg += `Keterangan transfer: *${orderId}*\n\n`;
    msg += `🆔 *Order ID: ${orderId}*\n`;
    msg += `⏰ *Berlaku hingga: 24 jam*\n\n`;
    msg += `📸 *Setelah transfer, kirim bukti dengan:*\n`;
    msg += `*${orderId}*\n`;
    msg += `(Reply dengan foto bukti transfer)`;
    
    return msg;
}

function formatOrderDetail(order, product) {
    let statusEmoji = '⏳';
    if (order.status === 'completed') statusEmoji = '✅';
    if (order.status === 'rejected') statusEmoji = '❌';
    if (order.status === 'expired') statusEmoji = '⏰';
    
    let msg = `*📋 DETAIL ORDER*\n\n`;
    msg += `┌─「 🛒 *${order.id}* 」\n`;
    msg += `├ 📦 Produk: ${product?.name || 'Unknown'}\n`;
    msg += `├ 🔢 Jumlah: ${order.quantity}x\n`;
    msg += `├ 💰 Total: Rp${order.total?.toLocaleString?.('id-ID') || order.total}\n`;
    msg += `├ 💳 Status Bayar: ${order.paymentStatus}\n`;
    msg += `├ 📊 Status Order: ${statusEmoji} ${order.status.toUpperCase()}\n`;
    msg += `└ ⏰ Dibuat: ${new Date(order.timestamp).toLocaleDateString('id-ID')}\n\n`;
    
    if (order.paymentProof) {
        msg += `📸 Bukti pembayaran: Tersimpan\n`;
    }
    
    if (order.downloadUrl) {
        msg += `📥 Link download: ${order.downloadUrl}\n`;
        msg += `⏰ Berlaku sampai: ${new Date(order.downloadExpiresAt).toLocaleDateString('id-ID')}\n`;
    }
    
    return msg;
}

function formatVerificationDetail(order, product) {
    let msg = `*📋 VERIFIKASI PEMBAYARAN*\n\n`;
    msg += `┌─「 💳 *${order.id}* 」\n`;
    msg += `├ 👤 Pembeli: ${order.userId}\n`;
    msg += `├ 📦 Produk: ${product?.name || 'Unknown'}\n`;
    msg += `├ 🔢 Jumlah: ${order.quantity}x\n`;
    msg += `├ 💰 Nominal: *Rp${order.total?.toLocaleString?.('id-ID') || order.total}*\n`;
    msg += `├ 📊 Status: ${order.status.toUpperCase()}\n`;
    msg += `└ ⏰ Waktu: ${new Date(order.timestamp).toLocaleDateString('id-ID')}\n\n`;
    msg += `📸 *Bukti Pembayaran:*\n`;
    msg += `${order.paymentProof || 'Tidak ada'}\n\n`;
    msg += `✅ *Terima:* .store approve ${order.id}\n`;
    msg += `❌ *Tolak:* .store reject ${order.id}`;
    
    return msg;
}

function generateStoreHelp(prefix) {
    return `*🛍️ TOKO DIGITAL - PANDUAN LENGKAP*

📌 *PERINTAH USER:*
${prefix}store - Lihat semua produk
${prefix}store detail <id> - Lihat detail produk
${prefix}store cari <nama> - Cari produk
${prefix}store beli <id> <qty> - Beli produk

💳 *PEMBAYARAN:*
${prefix}store konfirmasi <ORDER-ID>
(Reply dengan foto bukti transfer)

📥 *DOWNLOAD:*
${prefix}store download <ORDER-ID> - Download file

📋 *RIWAYAT:*
${prefix}store pesanan - Lihat order saya

🔐 *PERINTAH ADMIN:*
${prefix}store add <nama> <harga> <kategori> <deskripsi...> <url>
${prefix}store delete <id> - Hapus produk
${prefix}store list - Lihat semua pesanan
${prefix}store verifikasi <ORDER-ID> - Lihat detail pembayaran
${prefix}store approve <ORDER-ID> - Terima pembayaran
${prefix}store reject <ORDER-ID> - Tolak pembayaran
${prefix}store riwayat - Log semua transaksi

✨ *Fitur:*
✓ Toko produk digital lengkap
✓ Sistem pembayaran dengan verifikasi
✓ Download otomatis setelah approve
✓ Management pesanan real-time
✓ Admin verification required

💡 Hubungi admin untuk bantuan lebih lanjut`;
}

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    let prefix = usedPrefix || '.';
    const cmd = command || 'store';
    
    let inputText = text ? text.trim() : (args ? args.join(' ').trim() : '');
    
    console.log(`[Store Handler] Command: ${cmd}, Input: ${inputText}`);
    
    if (!inputText || inputText.toLowerCase() === 'help' || inputText === '?') {
        return m.reply(generateStoreHelp(prefix));
    }
    
    try {
        // Show all products
        if (inputText === '' || inputText.toLowerCase() === 'list') {
            await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
            const products = await fetchProducts();
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            return m.reply(formatProductList(products));
        }
        
        // Show product detail
        if (inputText.toLowerCase().startsWith('detail ')) {
            await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
            const productId = inputText.substring(7).trim();
            const products = await fetchProducts();
            const product = findProductById(products, productId);
            
            if (!product) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ Produk dengan ID *${productId}* tidak ditemukan!`);
            }
            
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            return m.reply(formatProductDetail(product));
        }
        
        // Search products
        if (inputText.toLowerCase().startsWith('cari ')) {
            await conn.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });
            const query = inputText.substring(5).trim();
            const products = await fetchProducts();
            const results = searchProducts(products, query);
            
            if (results.length === 0) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ Tidak ada produk dengan nama "*${query}*"`);
            }
            
            let msg = `*🔍 HASIL PENCARIAN: "${query}"*\n\n`;
            msg += `📦 *${results.length} Produk Ditemukan:*\n\n`;
            results.forEach((p, i) => {
                msg += `${i + 1}. *${p.name}*\n`;
                msg += `   💰 Rp${p.price?.toLocaleString?.('id-ID') || p.price}\n`;
                msg += `   🆔 ID: ${p.id}\n\n`;
            });
            
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            return m.reply(msg);
        }
        
        // Buy product
        if (inputText.toLowerCase().startsWith('beli ')) {
            await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
            const parts = inputText.substring(5).trim().split(/\s+/);
            const productId = parts[0];
            const quantity = parseInt(parts[1]) || 1;
            
            if (!productId) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ Format tidak valid!\n\n💡 Gunakan: ${prefix}${cmd} beli <id> <qty>`);
            }
            
            const products = await fetchProducts();
            const product = findProductById(products, productId);
            
            if (!product) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ Produk dengan ID *${productId}* tidak ditemukan!`);
            }
            
            if (product.stock && product.stock < quantity) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ Stok tidak cukup!\n\n📊 Stok: ${product.stock}\n🛒 Permintaan: ${quantity}`);
            }
            
            try {
                const result = await createOrder(m.sender, productId, quantity, product);
                await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                return m.reply(formatPurchaseConfirm(product, quantity, result.total, result.orderId));
            } catch (error) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ Gagal membuat order!\n\n⚠️ ${error.message}`);
            }
        }
        
        // Confirm payment with image
        if (inputText.toLowerCase().startsWith('konfirmasi ')) {
            await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
            const orderId = inputText.substring(11).trim();
            
            if (!orderId) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ Order ID tidak ditemukan!\n\n💡 Gunakan: ${prefix}${cmd} konfirmasi <ORDER-ID>`);
            }
            
            const orders = await fetchOrders();
            const order = findOrderById(orders, orderId);
            
            if (!order) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ Order *${orderId}* tidak ditemukan!`);
            }
            
            if (order.userId !== m.sender) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ Order bukan milik Anda!`);
            }
            
            if (order.status !== 'pending') {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ Order sudah ${order.status}\n\n💡 Status sekarang: ${order.status}`);
            }
            
            // Check if user sent image as reply/quoted
            let mediaUrl = null;
            if (m.quoted?.mediaKey || m.quoted?.vMessage?.imageMessage) {
                mediaUrl = m.quoted.download ? await m.quoted.download() : 'https://example.com/proof.jpg';
            }
            
            try {
                await confirmPayment(orderId, mediaUrl);
                
                let confirmMsg = `*✅ BUKTI PEMBAYARAN DITERIMA*\n\n`;
                confirmMsg += `🆔 Order ID: *${orderId}*\n`;
                confirmMsg += `💰 Nominal: *Rp${order.total?.toLocaleString?.('id-ID') || order.total}*\n`;
                confirmMsg += `📊 Status: *⏳ MENUNGGU VERIFIKASI*\n\n`;
                confirmMsg += `⏰ Admin akan memverifikasi pembayaran Anda dalam waktu singkat.\n`;
                confirmMsg += `💡 Anda akan menerima notifikasi setelah pembayaran disetujui.`;
                
                await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                return m.reply(confirmMsg);
                
            } catch (error) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ Gagal konfirmasi pembayaran!\n\n⚠️ ${error.message}`);
            }
        }
        
        // Download product
        if (inputText.toLowerCase().startsWith('download ')) {
            await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
            const orderId = inputText.substring(9).trim();
            
            const orders = await fetchOrders();
            const order = findOrderById(orders, orderId);
            
            if (!order) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ Order *${orderId}* tidak ditemukan!`);
            }
            
            if (order.status !== 'completed') {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ Pembayaran belum disetujui!\n\n📊 Status: ${order.status}`);
            }
            
            if (!order.downloadUrl) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ Link download tidak tersedia!`);
            }
            
            let msg = `*✅ DOWNLOAD SIAP*\n\n`;
            msg += `📦 Produk: ${order.productName}\n`;
            msg += `🔗 Link: ${order.downloadUrl}\n\n`;
            msg += `⏰ Berlaku sampai: ${new Date(order.downloadExpiresAt).toLocaleDateString('id-ID')}\n`;
            msg += `💾 Simpan file dengan baik`;
            
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            return m.reply(msg);
        }
        
        // User: View my orders
        if (inputText.toLowerCase() === 'pesanan') {
            await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
            const orders = await fetchOrders();
            const myOrders = orders.filter(o => o.userId === m.sender);
            
            if (myOrders.length === 0) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`*📋 PESANAN SAYA*\n\nℹ️ Anda belum memiliki pesanan`);
            }
            
            let msg = `*📋 PESANAN SAYA*\n\n`;
            msg += `📦 *${myOrders.length} Pesanan:*\n\n`;
            
            myOrders.slice(0, 5).forEach((o, i) => {
                let statusIcon = '⏳';
                if (o.status === 'completed') statusIcon = '✅';
                if (o.status === 'rejected') statusIcon = '❌';
                
                msg += `${i + 1}. ${statusIcon} ${o.id}\n`;
                msg += `   📦 ${o.productName}\n`;
                msg += `   💰 Rp${o.total?.toLocaleString?.('id-ID') || o.total}\n`;
                msg += `   📊 ${o.status.toUpperCase()}\n\n`;
            });
            
            if (myOrders.length > 5) {
                msg += `... dan ${myOrders.length - 5} pesanan lainnya\n\n`;
            }
            
            msg += `💡 Gunakan: ${prefix}${cmd} detail <ORDER-ID> untuk info lengkap`;
            
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            return m.reply(msg);
        }
        
        // ====== ADMIN COMMANDS ======
        
        // Admin: Add product
        if (inputText.toLowerCase().startsWith('add ') && isAdmin(m.sender)) {
            await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
            const addInput = inputText.substring(4).trim();
            const parts = addInput.split(/\s+/);
            
            if (parts.length < 5) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ Format tidak valid!\n\n💡 Format: ${prefix}${cmd} add <nama> <harga> <kategori> <deskripsi...> <url>`);
            }
            
            const productData = {
                name: parts[0],
                price: parseFloat(parts[1]),
                category: parts[2],
                description: parts.slice(3, -1).join(' '),
                fileUrl: parts[parts.length - 1],
                stock: 999,
                createdAt: new Date().toISOString()
            };
            
            let msg = `*✅ PRODUK DITAMBAHKAN*\n\n`;
            msg += `📋 Nama: *${productData.name}*\n`;
            msg += `💰 Harga: Rp${productData.price?.toLocaleString?.('id-ID') || productData.price}\n`;
            msg += `📂 Kategori: *${productData.category}*\n`;
            msg += `📊 Stok: ${productData.stock}`;
            
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            return m.reply(msg);
        }
        
        // Admin: Delete product
        if (inputText.toLowerCase().startsWith('delete ') && isAdmin(m.sender)) {
            await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
            const productId = inputText.substring(7).trim();
            
            if (!productId) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ ID produk tidak boleh kosong!`);
            }
            
            const products = await fetchProducts();
            const product = findProductById(products, productId);
            
            if (!product) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ Produk dengan ID *${productId}* tidak ditemukan!`);
            }
            
            let msg = `*✅ PRODUK DIHAPUS*\n\n`;
            msg += `📋 Nama: *${product.name}*\n`;
            msg += `💰 Harga: Rp${product.price?.toLocaleString?.('id-ID') || product.price}`;
            
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            return m.reply(msg);
        }
        
        // Admin: View all orders
        if ((inputText.toLowerCase() === 'riwayat' || inputText.toLowerCase() === 'log') && isAdmin(m.sender)) {
            await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
            const orders = await fetchOrders();
            
            if (orders.length === 0) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`*📊 LOG TRANSAKSI*\n\nℹ️ Tidak ada transaksi`);
            }
            
            let msg = `*📊 LOG TRANSAKSI*\n\n`;
            msg += `📦 Total: ${orders.length} pesanan\n\n`;
            
            let completed = orders.filter(o => o.status === 'completed').length;
            let pending = orders.filter(o => o.status === 'pending').length;
            let processing = orders.filter(o => o.status === 'processing').length;
            let rejected = orders.filter(o => o.status === 'rejected').length;
            
            msg += `✅ Completed: ${completed}\n`;
            msg += `⏳ Pending: ${pending}\n`;
            msg += `🔄 Processing: ${processing}\n`;
            msg += `❌ Rejected: ${rejected}\n\n`;
            
            let totalRevenue = orders
                .filter(o => o.status === 'completed')
                .reduce((sum, o) => sum + o.total, 0);
            
            msg += `💰 Total Revenue: Rp${totalRevenue?.toLocaleString?.('id-ID') || totalRevenue}\n\n`;
            msg += `📋 5 Pesanan Terbaru:\n\n`;
            
            orders.slice(-5).reverse().forEach((o, i) => {
                let statusEmoji = '⏳';
                if (o.status === 'completed') statusEmoji = '✅';
                if (o.status === 'processing') statusEmoji = '🔄';
                if (o.status === 'rejected') statusEmoji = '❌';
                
                msg += `${i + 1}. ${statusEmoji} ${o.id}\n`;
                msg += `   💰 Rp${o.total?.toLocaleString?.('id-ID') || o.total}\n`;
                msg += `   📦 ${o.productName}\n\n`;
            });
            
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            return m.reply(msg);
        }
        
        // Admin: List all pending orders for verification
        if (inputText.toLowerCase() === 'list' && isAdmin(m.sender)) {
            await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
            const orders = await fetchOrders();
            const pendingOrders = orders.filter(o => o.status === 'processing');
            
            if (pendingOrders.length === 0) {
                await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                return m.reply(`*📋 VERIFIKASI PEMBAYARAN*\n\nℹ️ Tidak ada pesanan yang perlu diverifikasi`);
            }
            
            let msg = `*📋 PESANAN MENUNGGU VERIFIKASI*\n\n`;
            msg += `⏳ ${pendingOrders.length} Pesanan:\n\n`;
            
            pendingOrders.forEach((o, i) => {
                msg += `${i + 1}. ${o.id}\n`;
                msg += `   👤 ${o.userId?.substring(0, 20)}...\n`;
                msg += `   💰 Rp${o.total?.toLocaleString?.('id-ID') || o.total}\n`;
                msg += `   📦 ${o.productName}\n`;
                msg += `   🕐 ${new Date(o.timestamp).toLocaleDateString('id-ID')}\n\n`;
            });
            
            msg += `💡 Gunakan: ${prefix}${cmd} verifikasi <ORDER-ID>`;
            
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            return m.reply(msg);
        }
        
        // Admin: Verify payment
        if (inputText.toLowerCase().startsWith('verifikasi ') && isAdmin(m.sender)) {
            await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
            const orderId = inputText.substring(11).trim();
            
            const orders = await fetchOrders();
            const order = findOrderById(orders, orderId);
            
            if (!order) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ Order *${orderId}* tidak ditemukan!`);
            }
            
            const products = await fetchProducts();
            const product = findProductById(products, order.productId);
            
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            return m.reply(formatVerificationDetail(order, product));
        }
        
        // Admin: Approve order
        if (inputText.toLowerCase().startsWith('approve ') && isAdmin(m.sender)) {
            await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
            const orderId = inputText.substring(8).trim();
            
            const orders = await fetchOrders();
            const order = findOrderById(orders, orderId);
            
            if (!order) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ Order *${orderId}* tidak ditemukan!`);
            }
            
            try {
                await approveOrder(orderId, m.sender);
                
                let msg = `*✅ PEMBAYARAN DISETUJUI*\n\n`;
                msg += `🆔 Order ID: *${orderId}*\n`;
                msg += `💰 Nominal: *Rp${order.total?.toLocaleString?.('id-ID') || order.total}*\n`;
                msg += `📊 Status: *✅ APPROVED*\n\n`;
                msg += `📥 Link download telah dikirim ke pembeli`;
                
                await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                return m.reply(msg);
                
            } catch (error) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ Gagal approve order!\n\n⚠️ ${error.message}`);
            }
        }
        
        // Admin: Reject order
        if (inputText.toLowerCase().startsWith('reject ') && isAdmin(m.sender)) {
            await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
            const orderId = inputText.substring(7).trim();
            
            const orders = await fetchOrders();
            const order = findOrderById(orders, orderId);
            
            if (!order) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ Order *${orderId}* tidak ditemukan!`);
            }
            
            try {
                await rejectOrder(orderId);
                
                let msg = `*❌ PEMBAYARAN DITOLAK*\n\n`;
                msg += `🆔 Order ID: *${orderId}*\n`;
                msg += `📊 Status: *❌ REJECTED*\n\n`;
                msg += `💡 Pembeli dapat membuat order baru`;
                
                await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                return m.reply(msg);
                
            } catch (error) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ Gagal reject order!\n\n⚠️ ${error.message}`);
            }
        }
        
        return m.reply(`❌ Perintah tidak dikenali!\n\n💡 Ketik: ${prefix}${cmd} help untuk panduan`);
        
    } catch (error) {
        console.error('[Store Handler] ERROR:', error);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        return m.reply(`❌ Terjadi kesalahan!\n\n⚠️ ${error.message}`);
    }
};

handler.help = ["store [perintah]"];
handler.tags = ["tools"];
handler.command = ["store", "toko", "shop"];
handler.limit = true;
handler.hidden = true;
console.log('[Store Handler] Handler loaded successfully');

export default handler;