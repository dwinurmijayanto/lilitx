import fetch from 'node-fetch';
import FormData from 'form-data';
import fs from 'fs';
import { promisify } from 'util';
import { tmpdir } from 'os';
import { join } from 'path';

const writeFile = promisify(fs.writeFile);
const unlink = promisify(fs.unlink);

console.log('[Ai-Image Handler] Loading handler...');

// ========== CONFIGURATION ==========
const AI_LABS_CONFIG = {
    base: 'https://text2video.aritek.app',
    endpoints: {
        text2img: '/text2img'
    },
    cipher: 'hbMcgZLlzvghRlLbPcTbCpfcQKM0PcU0zhPcTlOFMxBZ1oLmruzlVp9remPgi0QWP0QW',
    shiftValue: 3
};

const UPLOAD_SERVICES = [
    {
        name: 'Panzlync',
        url: 'https://panzlync.biz.id/upload',
        timeout: 120000,
        maxSize: 100 * 1024 * 1024,
        handler: async (filePath, filename) => {
            const form = new FormData();
            form.append('file', fs.createReadStream(filePath), filename);
            form.append('expire_unit', 'unlimited');
            form.append('expire_value', '10');
            form.append('max_downloads_option', 'unlimited');
            form.append('max_downloads', '1');

            const response = await fetch('https://panzlync.biz.id/upload', {
                method: 'POST',
                body: form,
                headers: {
                    ...form.getHeaders(),
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                },
                redirect: 'follow' // ikuti redirect ke /success?file=<id>
            });

            // response.url = https://panzlync.biz.id/success?file=21970c.jpg
            const match = response.url.match(/[?&]file=([^&]+)/);
            if (!match) throw new Error('File ID tidak ditemukan di URL Panzlync: ' + response.url);
            const fileId = decodeURIComponent(match[1]);
            return { url: `https://panzlync.biz.id/f/${fileId}` };
        }
    },
    {
        name: 'Tmpfiles',
        url: 'https://tmpfiles.org/api/v1/upload',
        timeout: 120000,
        maxSize: 100 * 1024 * 1024,
        handler: async (filePath, filename) => {
            const form = new FormData();
            form.append('file', fs.createReadStream(filePath), filename);

            const response = await fetch('https://tmpfiles.org/api/v1/upload', {
                method: 'POST',
                body: form,
                headers: {
                    ...form.getHeaders(),
                    'Accept': 'application/json',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });

            if (!response.ok) throw new Error(`HTTP ${response.status}`);

            const result = await response.json();
            if (result.status !== 'success') throw new Error('Upload failed');

            const parts = result.data.url.split('/');
            const fileId = parts[parts.length - 2];
            const fileName = parts[parts.length - 1];
            return { url: `https://tmpfiles.org/dl/${fileId}/${fileName}` };
        }
    },
    {
        name: 'Ikky HF',
        url: 'https://ikyy-upload-file.hf.space/upload',
        timeout: 120000,
        maxSize: 100 * 1024 * 1024,
        handler: async (filePath, filename) => {
            const form = new FormData();
            form.append('file', fs.createReadStream(filePath), filename);

            const response = await fetch('https://ikyy-upload-file.hf.space/upload', {
                method: 'POST',
                body: form,
                headers: {
                    ...form.getHeaders(),
                    'Accept': 'application/json',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });

            if (!response.ok) throw new Error(`HTTP ${response.status}`);

            const result = await response.json();
            if (!result.fileUrl) throw new Error('Invalid response');

            return { url: result.fileUrl };
        }
    }
];

const state = { token: null };

// ========== UTILITY FUNCTIONS ==========
function decryptCaesar(text, shift) {
    return [...text].map(c =>
        /[a-z]/.test(c)
            ? String.fromCharCode((c.charCodeAt(0) - 97 - shift + 26) % 26 + 97)
            : /[A-Z]/.test(c)
            ? String.fromCharCode((c.charCodeAt(0) - 65 - shift + 26) % 26 + 65)
            : c
    ).join('');
}

async function getAuthToken() {
    if (state.token) return state.token;
    state.token = decryptCaesar(AI_LABS_CONFIG.cipher, AI_LABS_CONFIG.shiftValue);
    return state.token;
}

function createHeaders(token) {
    return {
        'user-agent': 'NB Android/1.0.0',
        'accept-encoding': 'gzip',
        'content-type': 'application/json',
        'authorization': token
    };
}

function formatFileSize(bytes) {
    if (bytes >= 1024 * 1024 * 1024) return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
    if (bytes >= 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
    if (bytes >= 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return bytes + ' B';
}

// ========== DOWNLOAD & UPLOAD FUNCTIONS ==========
async function downloadFromUrl(url) {
    try {
        console.log('[Ai-Image Handler] Downloading from URL:', url);
        const response = await fetch(url, {
            method: 'GET',
            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
        });
        if (!response.ok) throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        return Buffer.from(await response.arrayBuffer());
    } catch (error) {
        console.error('[Ai-Image Handler] Download error:', error.message);
        throw error;
    }
}

async function uploadWithFallback(filePath, filename) {
    const fileSize = fs.statSync(filePath).size;
    console.log('[Ai-Image Handler] File size:', formatFileSize(fileSize));

    const eligible = UPLOAD_SERVICES.filter(s => fileSize <= s.maxSize);
    if (eligible.length === 0) return { success: false, message: 'File too large for all upload services' };

    const MAX_RETRIES = 2;
    let lastErrors = [];

    const raceUpload = () => new Promise((resolve) => {
        let settled = false;
        let failCount = 0;
        const errors = [];

        eligible.forEach(service => {
            const timer = setTimeout(() => {
                if (!settled) {
                    failCount++;
                    errors.push(`${service.name}: timeout`);
                    console.error(`[Ai-Image Handler] ${service.name} timed out`);
                    if (failCount === eligible.length) { settled = true; resolve({ success: false, errors }); }
                }
            }, service.timeout);

            service.handler(filePath, filename)
                .then(res => {
                    clearTimeout(timer);
                    if (res?.url && !settled) {
                        settled = true;
                        console.log(`[Ai-Image Handler] Fastest upload via ${service.name}`);
                        resolve({ success: true, url: res.url, service: service.name, metadata: { size: fileSize, filename } });
                    } else if (!settled) {
                        failCount++;
                        errors.push(`${service.name}: invalid response`);
                        if (failCount === eligible.length) { settled = true; resolve({ success: false, errors }); }
                    }
                })
                .catch(err => {
                    clearTimeout(timer);
                    console.error(`[Ai-Image Handler] ${service.name} failed:`, err.message);
                    if (!settled) {
                        failCount++;
                        errors.push(`${service.name}: ${err.message}`);
                        if (failCount === eligible.length) { settled = true; resolve({ success: false, errors }); }
                    }
                });
        });
    });

    for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
        if (attempt > 0) {
            console.log(`[Ai-Image Handler] Retrying upload (attempt ${attempt}/${MAX_RETRIES})...`);
            await new Promise(r => setTimeout(r, 1500 * attempt));
        }

        console.log(`[Ai-Image Handler] Running ${eligible.length} upload(s) in parallel (attempt ${attempt + 1})...`);
        const result = await raceUpload();

        if (result.success) {
            if (attempt > 0) console.log(`[Ai-Image Handler] Upload succeeded on retry ${attempt}`);
            return result;
        }

        lastErrors = result.errors;
        console.error(`[Ai-Image Handler] All services failed (attempt ${attempt + 1}):`, lastErrors.join('; '));
    }

    return { success: false, message: `All upload services failed after ${MAX_RETRIES + 1} attempts. Errors: ${lastErrors.join('; ')}` };
}

async function downloadAndUpload(sourceUrl, filename) {
    let tmpFile = null;
    try {
        const buffer = await downloadFromUrl(sourceUrl);
        tmpFile = join(tmpdir(), `ai_image_${Date.now()}.jpg`);
        await writeFile(tmpFile, buffer);

        const uploadResult = await uploadWithFallback(tmpFile, filename);

        try { await unlink(tmpFile); } catch (e) { /* silent */ }

        if (uploadResult.success) {
            return { success: true, url: uploadResult.url, service: uploadResult.service, metadata: uploadResult.metadata, originalUrl: sourceUrl };
        }
        throw new Error(uploadResult.message || 'Upload failed');
    } catch (error) {
        if (tmpFile) try { await unlink(tmpFile); } catch (e) { /* silent */ }
        return { success: false, message: error.message, originalUrl: sourceUrl };
    }
}

// ========== AI GENERATION FUNCTION ==========
async function generateImage(prompt) {
    try {
        console.log('[Ai-Image Handler] Generating image:', prompt);

        const token = await getAuthToken();
        const formData = new FormData();
        formData.append('prompt', prompt);
        formData.append('token', token);

        const response = await fetch(AI_LABS_CONFIG.base + AI_LABS_CONFIG.endpoints.text2img, {
            method: 'POST',
            body: formData,
            headers: { ...createHeaders(token), ...formData.getHeaders() }
        });

        if (!response.ok) throw new Error(`HTTP Error: ${response.status} ${response.statusText}`);

        const result = await response.json();

        if (result.code === 0 && result.url) {
            console.log('[Ai-Image Handler] Image generation success');
            return { success: true, url: result.url.trim(), prompt };
        }
        throw new Error('Image generation failed - invalid response');
    } catch (error) {
        console.error('[Ai-Image Handler] Image generation error:', error.message);
        return { success: false, message: error.message };
    }
}

// ========== VALIDATION ==========
function validatePrompt(prompt) {
    if (!prompt?.trim()) return { valid: false, message: '❌ Prompt tidak boleh kosong!' };
    if (!/^[a-zA-Z0-9\s.,!?'-]+$/.test(prompt)) {
        return { valid: false, message: '❌ Prompt mengandung karakter tidak valid!\n\n💡 Hanya boleh huruf, angka, dan tanda baca dasar' };
    }
    return { valid: true };
}

// ========== FORMAT FUNCTIONS ==========
function formatImageResult(result, prompt, uploadResult = null) {
    let msg = `*🎨 AI IMAGE GENERATION*\n\n`;

    if (result.success && uploadResult?.success) {
        msg += `┌─「 ✨ *Success* 」\n`;
        msg += `├ 📝 Prompt: ${prompt}\n`;
        msg += `├ ✅ Status: *BERHASIL*\n`;
        msg += `├ 📦 Uploaded: *Yes*\n`;
        msg += `├ 🌐 Service: *${uploadResult.service}*\n`;
        if (uploadResult.metadata?.size) msg += `├ 📊 Size: ${formatFileSize(uploadResult.metadata.size)}\n`;
        msg += `├ 🔗 URL:\n│    ${uploadResult.url}\n`;
        msg += `└─────────────\n\n🎉 *Gambar berhasil dibuat dan diupload!*`;
    } else if (result.success && !uploadResult?.success) {
        msg += `┌─「 ⚠️ *Partial Success* 」\n`;
        msg += `├ 📝 Prompt: ${prompt}\n`;
        msg += `├ ✅ Generate: *BERHASIL*\n`;
        msg += `├ ❌ Upload: *GAGAL*\n`;
        msg += `├ ⚠️ Error: ${uploadResult?.message || 'Unknown error'}\n`;
        msg += `├ 🔗 Original URL:\n│    ${result.url}\n`;
        msg += `└─────────────\n\n⚠️ *Gambar berhasil dibuat tapi gagal upload*`;
    } else {
        msg += `┌─「 ❌ *Failed* 」\n`;
        msg += `├ 📝 Prompt: ${prompt}\n`;
        msg += `├ ❌ Status: *GAGAL*\n`;
        msg += `├ ⚠️ Error: ${result.message || 'Unknown error'}\n`;
        msg += `└─────────────\n\n❌ *Gagal membuat gambar, silakan coba lagi*`;
    }

    return msg;
}

function generateUsageHelp(prefix, cmd) {
    return `*🎨 AI IMAGE GENERATION*

📌 *Cara Penggunaan:*
${prefix}${cmd} <prompt>

*Contoh:*
${prefix}${cmd} a beautiful sunset over the ocean
${prefix}${cmd} cat playing with ball

📋 *Ketentuan Prompt:*
- Gunakan bahasa Inggris
- Hanya huruf, angka, dan tanda baca: . , ! ? ' -
- Deskripsikan dengan jelas apa yang ingin dibuat

💡 *Tips:*
- Semakin detail prompt, semakin baik hasil
- Gunakan kata kunci yang spesifik

⚡ *Fitur:*
✅ Generate image dari text prompt
✅ Auto upload dengan multiple services
✅ Parallel upload, gunakan yang tercepat
✅ Auto retry jika semua gagal (maks 2x)
✅ High quality output

🌐 *Upload Services (Race Parallel):*
• Panzlync (Primary)
• Tmpfiles.org
• Ikky HF
`;
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    const prefix = usedPrefix || '.';
    const cmd = command || 'aiimage';

    try {
        let inputText = (text || args?.join(' ') || '').trim();

        if (!inputText || inputText.toLowerCase() === 'help' || inputText === '?') {
            return m.reply(generateUsageHelp(prefix, cmd));
        }

        const validation = validatePrompt(inputText);
        if (!validation.valid) {
            return m.reply(`${validation.message}\n\n💡 Ketik ${prefix}${cmd} help untuk panduan lengkap`);
        }

        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        const result = await generateImage(inputText);

        let uploadResult = null;
        if (result.success && result.url) {
            uploadResult = await downloadAndUpload(result.url, `ai_image_${Date.now()}.jpg`);
            if (!uploadResult.success) console.error('[Ai-Image Handler] Upload failed:', uploadResult.message);
        }

        const resultMessage = formatImageResult(result, inputText, uploadResult);

        if (result.success) {
            const finalUrl = uploadResult?.success ? uploadResult.url : result.url;
            await conn.sendMessage(m.chat, { image: { url: finalUrl }, caption: resultMessage }, { quoted: m });
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } else {
            await conn.sendMessage(m.chat, { text: resultMessage }, { quoted: m });
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        }

    } catch (error) {
        console.error('[Ai-Image Handler] CRITICAL ERROR:', error.message);
        console.error('[Ai-Image Handler] Stack:', error.stack);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        return m.reply(`❌ Terjadi kesalahan saat generate.\n💡 Coba lagi atau ketik ${prefix}${cmd} help`);
    }
};

handler.help = ["aiimage <prompt>"];
handler.tags = ["ai"];
handler.command = ["aiimage"];
handler.limit = true;

console.log('[Ai-Image Handler] Handler loaded successfully');

export default handler;