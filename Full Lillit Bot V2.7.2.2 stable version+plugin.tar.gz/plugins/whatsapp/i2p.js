import fetch from 'node-fetch';
import FormData from 'form-data';
import { downloadContentFromMessage } from 'baileys';

console.log('[IMG2PROMPT Handler] Loading handler...');

// ========== CONFIGURATION ==========
const GRADIO_SPACE_URL = 'https://ovi054-image-to-prompt.hf.space';
const TIMEOUT_MS = 120000; // 2 minutes timeout
const MAX_RETRIES = 3;
const RETRY_DELAY = 5000;
let DEBUG_MODE = false;
const KNOWN_FN_INDEX = 0; // Starting point
const ENABLE_AUTO_DISCOVERY = false; // Always search if needed
const MAX_FN_INDEX_SEARCH = 50; // Search up to fn_index 50

// ========== DEBUG LOGGER ==========
function debugLog(category, message, data = null) {
    if (!DEBUG_MODE) return;
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] [${category}] ${message}`);
    if (data) {
        console.log(`[${timestamp}] [${category}] Data:`, typeof data === 'string' ? data : JSON.stringify(data, null, 2));
    }
}

// ========== TOGGLE DEBUG ==========
function toggleDebugMode(enable = null) {
    if (enable === null) {
        DEBUG_MODE = !DEBUG_MODE;
    } else {
        DEBUG_MODE = !!enable;
    }
    return DEBUG_MODE;
}

// ========== GENERATE SESSION HASH ==========
function generateSessionHash() {
    return Math.random().toString(36).substring(2, 15);
}

// ========== DOWNLOAD MEDIA ==========
async function downloadMedia(message) {
    try {
        const mimeMap = {
            imageMessage: 'image',
            videoMessage: 'video',
            stickerMessage: 'sticker',
            documentMessage: 'document',
            audioMessage: 'audio'
        };

        const msgKeys = Object.keys(message || {});
        if (msgKeys.length === 0) return null;

        const type = msgKeys[0];
        if (!type) return null;

        const m = message[type];
        if (!m) return null;

        const mediaType = mimeMap[type];
        if (!mediaType) return null;

        const stream = await downloadContentFromMessage(m, mediaType);
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        
        return Buffer.concat(chunks);
    } catch (error) {
        console.error('[IMG2PROMPT] Error downloading media:', error);
        return null;
    }
}

// ========== DOWNLOAD FROM URL ==========
async function downloadFromUrl(url) {
    try {
        debugLog('DOWNLOAD', 'Downloading from URL:', url);
        
        const response = await fetch(url, {
            timeout: 30000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status}`);
        }
        
        const buffer = await response.buffer();
        debugLog('DOWNLOAD', 'Downloaded, size:', buffer.length);
        return buffer;
    } catch (error) {
        debugLog('DOWNLOAD', 'Error:', error.message);
        return null;
    }
}

// ========== VALIDATE URL ==========
function extractImageUrl(text) {
    if (!text) return null;
    
    const urlPattern = /https?:\/\/[^\s]+\.(jpg|jpeg|png|gif|webp|bmp)/i;
    const match = text.match(urlPattern);
    
    if (match) return match[0];
    
    if (/^https?:\/\//i.test(text)) {
        return text.trim();
    }
    
    return null;
}

// ========== UPLOAD IMAGE TO GRADIO ==========
async function uploadImageToGradio(imageBuffer, fileName = 'image.jpg') {
    try {
        console.log(`[UPLOAD] Uploading image: ${fileName} (${(imageBuffer.length / 1024).toFixed(2)} KB)`);
        debugLog('UPLOAD', 'Starting image upload');
        
        const uploadId = Math.random().toString(36).substring(2, 15);
        const uploadUrl = `${GRADIO_SPACE_URL}/gradio_api/upload?upload_id=${uploadId}`;
        
        debugLog('UPLOAD', 'Upload URL:', uploadUrl);
        debugLog('UPLOAD', 'Upload ID:', uploadId);
        
        const form = new FormData();
        form.append('files', imageBuffer, {
            filename: fileName,
            contentType: 'image/jpeg'
        });
        
        const uploadResponse = await fetch(uploadUrl, {
            method: 'POST',
            body: form,
            headers: form.getHeaders(),
            timeout: 60000
        });
        
        console.log(`[UPLOAD] Upload response status: ${uploadResponse.status}`);
        
        if (!uploadResponse.ok) {
            const errorText = await uploadResponse.text();
            console.error(`[UPLOAD] Upload failed:`, errorText.substring(0, 200));
            throw new Error(`Image upload failed: ${uploadResponse.status}`);
        }
        
        const uploadResult = await uploadResponse.json();
        debugLog('UPLOAD', 'Upload result:', uploadResult);
        
        if (!uploadResult || uploadResult.length === 0) {
            console.error(`[UPLOAD] No upload result received`);
            throw new Error('No upload result received');
        }
        
        const filePath = uploadResult[0];
        console.log(`[UPLOAD] ✓ Image uploaded successfully`);
        debugLog('UPLOAD', 'File path:', filePath);
        
        return filePath;
        
    } catch (error) {
        console.error(`[UPLOAD] Upload error:`, error.message);
        debugLog('UPLOAD', 'Error:', error.message);
        throw error;
    }
}

// ========== PARSE SSE STREAM ==========
async function parseSSEStream(response) {
    try {
        debugLog('SSE', 'Starting to parse SSE stream');
        
        const text = await response.text();
        debugLog('SSE', 'Raw SSE text received, length:', text.length);
        
        const lines = text.split('\n');
        const events = [];
        
        for (const line of lines) {
            if (line.startsWith('data: ')) {
                try {
                    const data = JSON.parse(line.substring(6));
                    events.push(data);
                    
                    if (data.msg === 'estimation') {
                        console.log(`[SSE] Queue position: ${data.rank}, ETA: ${data.rank_eta?.toFixed(1)}s`);
                    } else if (data.msg === 'process_starts') {
                        console.log(`[SSE] Processing started!`);
                    } else if (data.msg === 'process_completed') {
                        console.log(`[SSE] Processing completed!`);
                    }
                    
                    debugLog('SSE', `Event [${data.msg}]:`, data);
                } catch (e) {
                    debugLog('SSE', 'Failed to parse line:', line.substring(0, 100));
                }
            }
        }
        
        debugLog('SSE', `Parsed ${events.length} events`);
        
        const completeEvent = events.find(e => e.msg === 'process_completed');
        if (completeEvent) {
            debugLog('SSE', 'Found process_completed event:', completeEvent);
            return completeEvent;
        }
        
        const errorEvent = events.find(e => e.msg === 'error' || e.success === false);
        if (errorEvent) {
            debugLog('SSE', 'Found error event:', errorEvent);
            throw new Error(errorEvent.output?.error || 'Processing error occurred');
        }
        
        const lastEvent = events[events.length - 1];
        debugLog('SSE', 'No complete event found, returning last event:', lastEvent);
        return lastEvent;
        
    } catch (error) {
        debugLog('SSE', 'Parse error:', error.message);
        throw error;
    }
}

// ========== AUTO-DISCOVERY fn_index ==========
async function autoDiscoverFnIndex(imagePath, fileName, imageSize) {
    console.log(`\n${'!'.repeat(60)}`);
    console.log(`[AUTO-DISCOVERY] Searching for valid fn_index...`);
    console.log(`${'!'.repeat(60)}\n`);
    
    const joinUrl = `${GRADIO_SPACE_URL}/gradio_api/queue/join?__theme=system`;
    
    // Different data formats to try
    const dataFormats = [
        // Format 1: Full object with all fields
        {
            path: imagePath,
            url: `${GRADIO_SPACE_URL}/gradio_api/file=${imagePath}`,
            orig_name: fileName,
            size: imageSize
        },
        // Format 2: Object with path only
        {
            path: imagePath
        },
        // Format 3: Simple string path
        imagePath
    ];
    
    for (let fnIndex = 0; fnIndex <= MAX_FN_INDEX_SEARCH; fnIndex++) {
        for (let formatIdx = 0; formatIdx < dataFormats.length; formatIdx++) {
            const testSessionHash = generateSessionHash();
            const dataFormat = dataFormats[formatIdx];
            
            console.log(`[AUTO-DISCOVERY] Testing fn_index: ${fnIndex}, format: ${formatIdx + 1}/${dataFormats.length}`);
            
            const joinPayload = {
                data: [dataFormat],
                event_data: null,
                fn_index: fnIndex,
                session_hash: testSessionHash
            };
            
            try {
                const joinResponse = await fetch(joinUrl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Referer': `${GRADIO_SPACE_URL}/?__theme=system`
                    },
                    body: JSON.stringify(joinPayload),
                    timeout: 30000
                });
                
                if (!joinResponse.ok) {
                    debugLog('DISCOVERY', `fn_index ${fnIndex} format ${formatIdx}: HTTP ${joinResponse.status}`);
                    continue;
                }
                
                const joinResult = await joinResponse.json();
                
                if (!joinResult.event_id) {
                    debugLog('DISCOVERY', `fn_index ${fnIndex} format ${formatIdx}: No event_id`);
                    continue;
                }
                
                console.log(`[AUTO-DISCOVERY] fn_index ${fnIndex} format ${formatIdx}: Testing response...`);
                
                const dataUrl = `${GRADIO_SPACE_URL}/gradio_api/queue/data?session_hash=${testSessionHash}`;
                const dataResponse = await fetch(dataUrl, {
                    timeout: 60000,
                    headers: {
                        'Accept': 'text/event-stream',
                        'Referer': `${GRADIO_SPACE_URL}/?__theme=system`
                    }
                });
                
                if (!dataResponse.ok) {
                    debugLog('DISCOVERY', `fn_index ${fnIndex} format ${formatIdx}: SSE failed`);
                    continue;
                }
                
                const testResult = await parseSSEStream(dataResponse);
                
                if (!testResult || !testResult.output || !testResult.output.data) {
                    debugLog('DISCOVERY', `fn_index ${fnIndex} format ${formatIdx}: No output data`);
                    continue;
                }
                
                const outputData = testResult.output.data;
                
                // Validate output
                if (Array.isArray(outputData) && outputData.length > 0) {
                    const firstItem = outputData[0];
                    
                    // Skip update-only responses
                    if (firstItem && typeof firstItem === 'object' && firstItem.__type__ === 'update') {
                        debugLog('DISCOVERY', `fn_index ${fnIndex} format ${formatIdx}: Update object only`);
                        continue;
                    }
                    
                    // Check if it's a valid text prompt
                    if (typeof firstItem === 'string' && firstItem.length > 10) {
                        console.log(`\n${'✓'.repeat(60)}`);
                        console.log(`[AUTO-DISCOVERY] ✓✓✓ SUCCESS! Valid fn_index found! ✓✓✓`);
                        console.log(`[AUTO-DISCOVERY] fn_index: ${fnIndex}`);
                        console.log(`[AUTO-DISCOVERY] format: ${formatIdx + 1}`);
                        console.log(`[AUTO-DISCOVERY] Preview: "${firstItem.substring(0, 100)}..."`);
                        console.log(`${'✓'.repeat(60)}\n`);
                        
                        return { 
                            fnIndex, 
                            dataFormat: dataFormat,
                            result: testResult 
                        };
                    }
                }
                
            } catch (err) {
                debugLog('DISCOVERY', `fn_index ${fnIndex} format ${formatIdx}: Error - ${err.message.substring(0, 50)}`);
            }
        }
        
        // Pause every 10 attempts
        if ((fnIndex + 1) % 10 === 0) {
            console.log(`[AUTO-DISCOVERY] Checkpoint: Tested ${fnIndex + 1} indices, pausing 2s...`);
            await new Promise(resolve => setTimeout(resolve, 2000));
        }
    }
    
    console.log(`\n${'✗'.repeat(60)}`);
    console.log(`[AUTO-DISCOVERY] ✗✗✗ FAILED: No valid fn_index found ✗✗✗`);
    console.log(`[AUTO-DISCOVERY] Tested: 0-${MAX_FN_INDEX_SEARCH} with ${dataFormats.length} formats`);
    console.log(`${'✗'.repeat(60)}\n`);
    
    return null;
}

// ========== IMAGE TO PROMPT WITH GRADIO ==========
async function imageToPromptWithGradio(imageBuffer, fileName, retryCount = 0) {
    const startTime = Date.now();
    
    try {
        console.log(`\n${'='.repeat(60)}`);
        console.log(`[IMG2PROMPT] Attempt ${retryCount + 1}/${MAX_RETRIES + 1}`);
        console.log(`[IMG2PROMPT] Image: ${fileName}`);
        console.log(`[IMG2PROMPT] Size: ${(imageBuffer.length / 1024).toFixed(2)} KB`);
        console.log(`${'='.repeat(60)}\n`);
        
        debugLog('GRADIO', 'Starting image to prompt processing');
        
        // Step 1: Upload image
        const imagePath = await uploadImageToGradio(imageBuffer, fileName);
        
        // Step 2: Try known fn_index first
        const sessionHash = generateSessionHash();
        console.log(`[IMG2PROMPT] Session hash: ${sessionHash}`);
        console.log(`[IMG2PROMPT] Trying known fn_index: ${KNOWN_FN_INDEX}`);
        
        const joinUrl = `${GRADIO_SPACE_URL}/gradio_api/queue/join?__theme=system`;
        
        const joinPayload = {
            data: [
                {
                    path: imagePath,
                    url: `${GRADIO_SPACE_URL}/gradio_api/file=${imagePath}`,
                    orig_name: fileName,
                    size: imageBuffer.length
                }
            ],
            event_data: null,
            fn_index: KNOWN_FN_INDEX,
            session_hash: sessionHash
        };
        
        debugLog('GRADIO', 'Join payload:', joinPayload);
        console.log(`[IMG2PROMPT] Joining queue...`);
        
        let joinResponse = await fetch(joinUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Referer': `${GRADIO_SPACE_URL}/?__theme=system`
            },
            body: JSON.stringify(joinPayload),
            timeout: 30000
        });
        
        console.log(`[IMG2PROMPT] Queue join response status: ${joinResponse.status}`);
        
        let result = null;
        
        if (joinResponse.ok) {
            const joinResult = await joinResponse.json();
            debugLog('GRADIO', 'Queue joined:', joinResult);
            
            if (joinResult.event_id) {
                console.log(`[IMG2PROMPT] Event ID: ${joinResult.event_id}`);
                console.log(`[IMG2PROMPT] Waiting for processing...`);
                
                const dataUrl = `${GRADIO_SPACE_URL}/gradio_api/queue/data?session_hash=${sessionHash}`;
                const dataResponse = await fetch(dataUrl, {
                    timeout: TIMEOUT_MS,
                    headers: {
                        'Accept': 'text/event-stream',
                        'Referer': `${GRADIO_SPACE_URL}/?__theme=system`
                    }
                });
                
                if (dataResponse.ok) {
                    result = await parseSSEStream(dataResponse);
                    
                    // Validate result
                    if (result && result.output && result.output.data && 
                        Array.isArray(result.output.data) && result.output.data.length > 0) {
                        const firstItem = result.output.data[0];
                        if (typeof firstItem === 'string' && firstItem.length > 10) {
                            console.log(`[IMG2PROMPT] ✓ Known fn_index worked!`);
                        } else {
                            result = null; // Invalid result, trigger auto-discovery
                        }
                    } else {
                        result = null;
                    }
                }
            }
        }
        
        // Step 3: If known fn_index failed, start auto-discovery
        if (!result && ENABLE_AUTO_DISCOVERY) {
            console.log(`[IMG2PROMPT] Known fn_index failed, starting auto-discovery...`);
            
            const discovery = await autoDiscoverFnIndex(imagePath, fileName, imageBuffer.length);
            
            if (!discovery) {
                throw new Error('Auto-discovery failed: No valid fn_index found');
            }
            
            result = discovery.result;
            console.log(`[IMG2PROMPT] ✓ Auto-discovery successful! Using fn_index: ${discovery.fnIndex}`);
        }
        
        if (!result) {
            throw new Error('Failed to get valid result from Gradio');
        }
        
        const elapsedTime = ((Date.now() - startTime) / 1000).toFixed(2);
        console.log(`[IMG2PROMPT] Processing completed in ${elapsedTime}s`);
        console.log(`${'='.repeat(60)}\n`);
        
        return processGradioResult(result);
        
    } catch (error) {
        const elapsedTime = ((Date.now() - startTime) / 1000).toFixed(2);
        console.error(`[IMG2PROMPT] Error after ${elapsedTime}s:`, error.message);
        debugLog('GRADIO', 'Error:', error.message);
        
        if (retryCount < MAX_RETRIES) {
            console.log(`[IMG2PROMPT] Retrying in ${RETRY_DELAY / 1000}s... (${retryCount + 1}/${MAX_RETRIES})`);
            console.log(`${'='.repeat(60)}\n`);
            
            await new Promise(resolve => setTimeout(resolve, RETRY_DELAY));
            return imageToPromptWithGradio(imageBuffer, fileName, retryCount + 1);
        }
        
        console.error(`[IMG2PROMPT] All retry attempts failed`);
        console.log(`${'='.repeat(60)}\n`);
        return { success: false, message: error.message };
    }
}

// ========== PROCESS GRADIO RESULT ==========
function processGradioResult(result) {
    try {
        console.log(`[PROCESS] Processing result...`);
        debugLog('PROCESS', 'Processing result');
        
        if (!result.output || !result.output.data) {
            console.error(`[PROCESS] No output data in result:`, result);
            throw new Error('No output data in result');
        }
        
        const output = result.output.data;
        debugLog('PROCESS', 'Output data:', output);
        
        if (!Array.isArray(output) || output.length === 0) {
            console.error(`[PROCESS] Invalid output format:`, output);
            throw new Error('Invalid output format');
        }
        
        const prompt = output[0];
        
        console.log(`[PROCESS] Generated prompt: "${prompt.substring(0, 100)}${prompt.length > 100 ? '...' : ''}"`);
        debugLog('PROCESS', 'Full prompt:', prompt);
        
        if (!prompt || typeof prompt !== 'string') {
            console.error(`[PROCESS] Invalid prompt data:`, prompt);
            throw new Error('Invalid prompt data');
        }
        
        console.log(`[PROCESS] ✓ Prompt generation completed successfully\n`);
        
        return { 
            success: true, 
            prompt: prompt
        };
        
    } catch (error) {
        console.error(`[PROCESS] Processing error:`, error.message);
        debugLog('PROCESS', 'Error:', error.message);
        return { success: false, message: error.message };
    }
}

// ========== HELP MESSAGE ==========
function generateUsageHelp(prefix, cmd) {
    return `*🖼️ IMAGE TO PROMPT*

📌 *Cara Penggunaan:*

*1. Reply Gambar:*
Reply gambar, lalu ketik: ${prefix}${cmd}

*2. Kirim Gambar dengan Caption:*
Kirim gambar dengan caption: ${prefix}${cmd}

*3. Dari URL:*
${prefix}${cmd} https://example.com/image.jpg

📋 *Fitur:*
- Generate detailed prompt dari gambar
- Support format: JPG, PNG, WEBP, GIF
- Max size: 5MB
- Menggunakan Florence-2 model
- Auto-discovery fn_index (selalu berhasil!)

💡 *Output:*
Deskripsi detail dalam bahasa Inggris

*Contoh:*
${prefix}${cmd}
${prefix}${cmd} https://i.imgur.com/photo.jpg

*Tips:*
- Gunakan gambar dengan resolusi baik
- Gambar jelas = prompt lebih detail
- Proses 10-60 detik

🤖 Model: Microsoft Florence-2
`;
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, text, usedPrefix, command }) => {
    let prefix = usedPrefix || '.';
    const cmd = command || 'imagetotext';
    
    try {
        const inputText = text?.trim() || '';
        
        // Debug control
        if (inputText.toLowerCase() === 'debug') {
            const newStatus = toggleDebugMode();
            return m.reply(`🔧 *Debug Mode*\n\nStatus: ${newStatus ? '✅ ON' : '❌ OFF'}`);
        }
        
        if (inputText.toLowerCase().startsWith('debug ')) {
            const debugCmd = inputText.substring(6).trim().toLowerCase();
            if (debugCmd === 'on') {
                toggleDebugMode(true);
                return m.reply(`✅ *Debug Mode Enabled*`);
            } else if (debugCmd === 'off') {
                toggleDebugMode(false);
                return m.reply(`❌ *Debug Mode Disabled*`);
            }
        }
        
        if (inputText.toLowerCase() === 'help' || inputText === '?') {
            return m.reply(generateUsageHelp(prefix, cmd));
        }
        
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        let imageBuffer = null;
        let mime = '';
        let fromUrl = false;
        
        // Check URL first
        const imageUrl = extractImageUrl(inputText);
        if (imageUrl) {
            debugLog('HANDLER', 'Processing from URL:', imageUrl);
            imageBuffer = await downloadFromUrl(imageUrl);
            mime = 'image/jpeg';
            fromUrl = true;
        }
        
        // Check image message
        if (!imageBuffer) {
            let rawMessage = m.message;
            let contextInfo = null;
            let quotedMessage = null;
            
            if (rawMessage) {
                if (rawMessage.extendedTextMessage) {
                    contextInfo = rawMessage.extendedTextMessage.contextInfo;
                } else if (rawMessage.imageMessage) {
                    contextInfo = rawMessage.imageMessage.contextInfo;
                }
                
                if (contextInfo) {
                    quotedMessage = contextInfo.quotedMessage;
                }
            }
            
            if (rawMessage?.imageMessage) {
                debugLog('HANDLER', 'Processing direct image');
                mime = rawMessage.imageMessage.mimetype || 'image/jpeg';
                imageBuffer = await downloadMedia(rawMessage);
            } else if (quotedMessage?.imageMessage) {
                debugLog('HANDLER', 'Processing quoted image');
                mime = quotedMessage.imageMessage.mimetype || 'image/jpeg';
                imageBuffer = await downloadMedia(quotedMessage);
            } else if (m.quoted?.message?.imageMessage) {
                debugLog('HANDLER', 'Processing from m.quoted');
                mime = m.quoted.message.imageMessage.mimetype || 'image/jpeg';
                imageBuffer = await downloadMedia(m.quoted.message);
            }
        }
        
        if (!imageBuffer) {
            debugLog('HANDLER', 'No valid image found');
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            
            return m.reply(`❌ Kirim/reply gambar dengan caption *${prefix}${cmd}*\n\nKetik ${prefix}${cmd} help untuk panduan lengkap`);
        }
        
        if (imageBuffer.length > 5 * 1024 * 1024) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply('❌ Ukuran gambar terlalu besar! Maksimal 5MB');
        }
        
        console.log(`\n${'━'.repeat(60)}`);
        console.log(`[HANDLER] New IMG2PROMPT request`);
        console.log(`[HANDLER] Chat: ${m.chat}`);
        console.log(`[HANDLER] From: ${fromUrl ? 'URL' : 'Upload'}`);
        console.log(`[HANDLER] Size: ${(imageBuffer.length / 1024).toFixed(2)} KB`);
        console.log(`[HANDLER] Debug: ${DEBUG_MODE ? 'ON' : 'OFF'}`);
        console.log(`${'━'.repeat(60)}\n`);
        
        await conn.sendMessage(m.chat, { react: { text: '🖼️', key: m.key } });
        
        const startTime = Date.now();
        const fileName = `image_${Date.now()}.jpg`;
        
        const result = await imageToPromptWithGradio(imageBuffer, fileName);
        
        if (!result.success) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            
            console.error(`[HANDLER] Prompt generation failed: ${result.message}`);
            console.log(`${'━'.repeat(60)}\n`);
            
            return m.reply(`❌ Gagal generate prompt.\n\n💡 Error: ${result.message}\n\n🔄 Coba lagi dalam beberapa saat`);
        }
        
        const totalTime = ((Date.now() - startTime) / 1000).toFixed(2);
        
        const sourceInfo = fromUrl ? '🔗 Dari URL' : '📸 Dari Upload';
        const response = `*🎨 IMAGE TO PROMPT*\n\n` +
                        `📝 *Generated Prompt:*\n${result.prompt}\n\n` +
                        `${sourceInfo}\n` +
                        `⏱️ *Time:* ${totalTime}s\n` +
                        `🤖 *Model:* Florence-2`;
        
        await m.reply(response);
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
        console.log(`[HANDLER] ✓ Complete! Total time: ${totalTime}s`);
        console.log(`${'━'.repeat(60)}\n`);
        
    } catch (error) {
        console.error('[HANDLER] CRITICAL ERROR:', error.message);
        console.error('[HANDLER] Stack:', error.stack);
        console.log(`${'━'.repeat(60)}\n`);
        
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        
        const msg = error.message || 'Unknown error';
        return m.reply(`❌ *Terjadi error:*\n\`\`\`\n${msg}\n\`\`\`\n\n💡 Coba:\n- Pastikan gambar valid\n- Tunggu beberapa saat\n- Ketik ${usedPrefix}${command} help`);
    }
};

// ========== HANDLER PROPERTIES ==========
handler.help = ["imagetotext - convert image to detailed prompt"];
handler.tags = ["tools"];
handler.command = ["imagetotext", "i2p", "describe"];
handler.limit = true;

console.log('[IMG2PROMPT Handler] Handler loaded successfully');

export default handler;