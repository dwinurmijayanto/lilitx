import { exec } from "child_process";
import util from "util";

const execPromise = util.promisify(exec);

const handler = async (m, { conn, command, args, usedPrefix = '.' }) => {
  // PENTING: Extract text dari args array
  let text = Array.isArray(args) ? args.join(' ') : '';
  
  // Fallback: coba extract dari message body
  if (!text && m.body) {
    const commandPrefix = usedPrefix + command;
    if (m.body.startsWith(commandPrefix)) {
      text = m.body.slice(commandPrefix.length).trim();
    }
  }
  
  console.log("=== EXEC HANDLER DEBUG ===");
  console.log("Command:", command);
  console.log("Args array:", args);
  console.log("Extracted text:", text);
  console.log("========================");
  
  if (!text) {
    return m.reply("Masukkan perintah terminal-nya.");
  }
  
  await m.reply("execute...");
  
  try {
    const { stdout, stderr } = await execPromise(text, { timeout: 30000 });
    let output = "";
    
    if (stdout) {
      output += `*STDOUT:*\n\`\`\`\n${stdout.trim()}\n\`\`\``;
    }
    
    if (stderr) {
      output += `\n\n*STDERR:*\n\`\`\`\n${stderr.trim()}\n\`\`\``;
    }
    
    if (!stdout && !stderr) {
      output = "Perintah selesai (tanpa output).";
    }
    
    await m.reply(output.trim());
  } catch (e) {
    console.error("EXEC Error:", e);
    await m.reply(`*Error Eksekusi:*\n\`\`\`\n${e.message || util.inspect(e)}\n\`\`\``);
  }
};

handler.command = ["exec", "$"];
handler.tags = ["owner"];
handler.help = ["exec <cmd>", "$ <cmd>"];
handler.description = "Menjalankan perintah terminal (Owner Only).";

export default handler;