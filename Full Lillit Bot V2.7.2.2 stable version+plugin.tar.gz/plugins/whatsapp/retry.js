// ========================================
// HANDLER: Repeat/Retry Command with URL Auto-Detection
// Mengulang perintah dari pesan yang di-reply dengan deteksi URL otomatis
// ========================================

const handler = async (m, { conn, usedPrefix = '.' }) => {
  console.log("\n==============================================");
  console.log("[RE] Repeat handler dipanggil");
  console.log("[RE] Chat ID:", m.chat);
  console.log("[RE] Sender:", m.sender);
  console.log("==============================================\n");

  try {
    // ========================================
    // STEP 1: Validasi quoted message
    // ========================================
    if (!m.quoted) {
      console.log("[RE] Tidak ada pesan yang di-reply");
      return m.reply(
        `❌ *Cara penggunaan salah!*\n\n` +
        `Reply pesan yang berisi perintah bot atau URL, lalu ketik *${usedPrefix}re*\n\n` +
        `*Contoh:*\n` +
        `1. Reply pesan dengan command: "yt https://youtube.com/watch?v=xxxxx"\n` +
        `2. Reply pesan dengan URL: "https://youtube.com/watch?v=xxxxx"\n` +
        `3. Ketik: ${usedPrefix}re\n` +
        `4. Bot akan otomatis mendeteksi dan menjalankan perintah yang sesuai`
      );
    }

    // ========================================
    // STEP 2: Extract text dari quoted message
    // ========================================
    let quotedText = '';
    
    // Extract from raw message structure
    let rawMessage = m.message;
    let contextInfo = null;
    let quotedMessage = null;
    
    if (rawMessage) {
      if (rawMessage.extendedTextMessage) {
        contextInfo = rawMessage.extendedTextMessage.contextInfo;
      } else if (rawMessage.imageMessage) {
        contextInfo = rawMessage.imageMessage.contextInfo;
      } else if (rawMessage.videoMessage) {
        contextInfo = rawMessage.videoMessage.contextInfo;
      } else if (rawMessage.documentMessage) {
        contextInfo = rawMessage.documentMessage.contextInfo;
      } else if (rawMessage.audioMessage) {
        contextInfo = rawMessage.audioMessage.contextInfo;
      }
      
      if (contextInfo) {
        quotedMessage = contextInfo.quotedMessage;
      }
    }
    
    // Extract text
    if (quotedMessage?.conversation) {
      quotedText = quotedMessage.conversation;
      console.log("[RE] Text dari quotedMessage.conversation:", quotedText);
    } else if (quotedMessage?.extendedTextMessage?.text) {
      quotedText = quotedMessage.extendedTextMessage.text;
      console.log("[RE] Text dari quotedMessage.extendedTextMessage:", quotedText);
    } else if (quotedMessage?.imageMessage?.caption) {
      quotedText = quotedMessage.imageMessage.caption;
      console.log("[RE] Text dari quotedMessage.imageMessage.caption:", quotedText);
    } else if (quotedMessage?.videoMessage?.caption) {
      quotedText = quotedMessage.videoMessage.caption;
      console.log("[RE] Text dari quotedMessage.videoMessage.caption:", quotedText);
    }
    
    // Fallback to m.quoted
    if (!quotedText && m.quoted) {
      if (m.quoted.text) {
        quotedText = m.quoted.text;
      } else if (m.quoted.caption) {
        quotedText = m.quoted.caption;
      } else if (m.quoted.body) {
        quotedText = m.quoted.body;
      }
      console.log("[RE] Text dari m.quoted:", quotedText);
    }
    
    quotedText = quotedText.trim();

    if (!quotedText) {
      console.log("[RE] Quoted message tidak memiliki text");
      return m.reply(
        `❌ *Pesan yang di-reply tidak berisi teks!*\n\n` +
        `Pastikan pesan yang di-reply adalah pesan yang berisi perintah bot atau URL.`
      );
    }

    // ========================================
    // STEP 3: URL Detection & Auto-Command
    // ========================================
    
    /**
     * Fungsi untuk mendeteksi URL dan mengembalikan command yang sesuai
     * @param {string} text - Text yang akan dicek
     * @returns {object|null} - {command: string, url: string} atau null
     */
    const detectURLCommand = (text) => {
      // Regex untuk mendeteksi URL
      const urlRegex = /(https?:\/\/[^\s]+)/gi;
      const urls = text.match(urlRegex);
      
      if (!urls || urls.length === 0) {
        return null;
      }
      
      const url = urls[0]; // Ambil URL pertama
      console.log("[RE] URL detected:", url);
      
      // Mapping domain ke command
      const urlMappings = [
        // YouTube
        {
          patterns: [
            /youtube\.com\/watch/i,
            /youtu\.be\//i,
            /youtube\.com\/shorts/i,
            /youtube\.com\/live/i,
            /m\.youtube\.com/i
          ],
          command: 'yt',
          name: 'YouTube'
        },
        // TikTok
        {
          patterns: [
            /tiktok\.com/i,
            /vt\.tiktok\.com/i,
            /vm\.tiktok\.com/i
          ],
          command: 'tt',
          name: 'TikTok'
        },
        // Facebook
        {
          patterns: [
            /facebook\.com/i,
            /fb\.watch/i,
            /fb\.com/i,
            /m\.facebook\.com/i
          ],
          command: 'fb',
          name: 'Facebook'
        },
        // Instagram
        {
          patterns: [
            /instagram\.com/i,
            /instagr\.am/i
          ],
          command: 'ig',
          name: 'Instagram'
        },
        // Twitter/X
        {
          patterns: [
            /twitter\.com/i,
            /x\.com/i,
            /t\.co/i
          ],
          command: 'twitter',
          name: 'Twitter/X'
        },
        // Threads
        {
          patterns: [
            /threads\.net/i
          ],
          command: 'threads',
          name: 'Threads'
        },
        // Pinterest
        {
          patterns: [
            /pinterest\.com/i,
            /pin\.it/i
          ],
          command: 'pin',
          name: 'Pinterest'
        },
        // Spotify
        {
          patterns: [
            /spotify\.com/i,
            /spotify\.link/i
          ],
          command: 'spotify',
          name: 'Spotify'
        },
        // SoundCloud
        {
          patterns: [
            /soundcloud\.com/i
          ],
          command: 'soundcloud',
          name: 'SoundCloud'
        },
        // MediaFire
        {
          patterns: [
            /mediafire\.com/i
          ],
          command: 'mediafire',
          name: 'MediaFire'
        },
        // Google Drive
        {
          patterns: [
            /drive\.google\.com/i
          ],
          command: 'gdrive',
          name: 'Google Drive'
        },
        // Twitch
        {
          patterns: [
            /twitch\.tv/i
          ],
          command: 'twitch',
          name: 'Twitch'
        }
      ];
      
      // Cek setiap mapping
      for (const mapping of urlMappings) {
        for (const pattern of mapping.patterns) {
          if (pattern.test(url)) {
            console.log(`[RE] ✅ Detected ${mapping.name} URL`);
            return {
              command: mapping.command,
              url: url,
              platform: mapping.name
            };
          }
        }
      }
      
      console.log("[RE] ⚠️ URL detected but no matching command");
      return null;
    };

    // ========================================
    // STEP 4: Parse command atau detect URL
    // ========================================
    
    let commandText = quotedText;
    let detectedPrefix = usedPrefix;
    let command = '';
    let args = [];
    let autoDetected = false;
    let detectedPlatform = '';
    
    const commonPrefixes = ['.', '!', '/', '#', '$', '>', '<'];
    
    // Cek apakah sudah ada prefix (perintah langsung)
    let hasPrefix = commonPrefixes.some(p => quotedText.startsWith(p));
    
    if (!hasPrefix) {
      // Tidak ada prefix, coba deteksi URL
      const urlDetection = detectURLCommand(quotedText);
      
      if (urlDetection) {
        // URL terdeteksi, gunakan command otomatis
        command = urlDetection.command;
        args = [urlDetection.url];
        commandText = `${detectedPrefix}${command} ${urlDetection.url}`;
        autoDetected = true;
        detectedPlatform = urlDetection.platform;
        
        console.log("[RE] 🤖 Auto-detected command:", command);
        console.log("[RE] 🤖 Platform:", detectedPlatform);
        console.log("[RE] 🤖 URL:", urlDetection.url);
      } else {
        // Tidak ada URL, tambahkan prefix default
        commandText = detectedPrefix + quotedText;
        console.log("[RE] Tidak ada prefix/URL, ditambahkan prefix:", detectedPrefix);
      }
    }
    
    // Jika belum di-parse (tidak auto-detect), parse manual
    if (!autoDetected) {
      // Deteksi prefix yang digunakan
      for (const prefix of commonPrefixes) {
        if (quotedText.startsWith(prefix)) {
          detectedPrefix = prefix;
          break;
        }
      }
      
      const withoutPrefix = commandText.slice(detectedPrefix.length).trim();
      const parts = withoutPrefix.split(/\s+/);
      command = parts[0].toLowerCase();
      args = parts.slice(1);
    }

    console.log("[RE] Command text final:", commandText);
    console.log("[RE] Detected prefix:", detectedPrefix);
    console.log("[RE] Command:", command);
    console.log("[RE] Arguments:", args);

    if (!command) {
      return m.reply(
        `❌ *Tidak dapat mendeteksi perintah atau URL!*\n\n` +
        `Pesan yang di-reply: "${quotedText}"\n\n` +
        `💡 Pastikan pesan berisi command bot atau URL yang didukung.`
      );
    }

    // ========================================
    // STEP 5: Send message as user (bot will auto-process)
    // ========================================
    
    console.log("[RE] Sending message to trigger bot handler...");

    try {
      // Kirim notifikasi processing
      let notificationText = `🔄 *Menjalankan ulang perintah...*\n\n`;
      
      if (autoDetected) {
        notificationText += `🤖 *Auto-detected:* ${detectedPlatform}\n`;
        notificationText += `📝 Command: *${detectedPrefix}${command}*\n`;
        notificationText += `🔗 URL: ${args[0]}`;
      } else {
        notificationText += `📝 Command: *${detectedPrefix}${command}*\n`;
        notificationText += `📋 Arguments: ${args.length > 0 ? args.join(' ') : '_(tidak ada)_'}`;
      }
      
      const processingMsg = await m.reply(notificationText);
      
      // Tunggu sebentar agar notifikasi terkirim
      await new Promise(resolve => setTimeout(resolve, 500));

      // Construct message object yang akan di-inject
      const fakeRawMessage = {
        key: {
          remoteJid: m.chat,
          fromMe: false,
          id: 'RE_' + Date.now(),
          participant: m.sender
        },
        message: {
          conversation: commandText
        },
        messageTimestamp: Math.floor(Date.now() / 1000),
        pushName: m.pushName || 'User'
      };

      console.log("[RE] Fake message object:", JSON.stringify(fakeRawMessage, null, 2));

      // Cari handler function di conn
      let handlerExecuted = false;

      // Method 1: conn.handler (most common)
      if (typeof conn.handler === 'function') {
        console.log("[RE] Trying Method 1: conn.handler");
        try {
          await conn.handler.call(conn, { 
            messages: [fakeRawMessage], 
            type: 'notify' 
          });
          handlerExecuted = true;
          console.log("[RE] ✅ Executed via conn.handler");
        } catch (e) {
          console.log("[RE] Method 1 failed:", e.message);
        }
      }

      // Method 2: conn.ev.emit (event-based)
      if (!handlerExecuted && conn.ev && typeof conn.ev.emit === 'function') {
        console.log("[RE] Trying Method 2: conn.ev.emit");
        try {
          conn.ev.emit('messages.upsert', { 
            messages: [fakeRawMessage], 
            type: 'notify' 
          });
          handlerExecuted = true;
          console.log("[RE] ✅ Emitted via conn.ev");
        } catch (e) {
          console.log("[RE] Method 2 failed:", e.message);
        }
      }

      // Method 3: Send actual message (fallback)
      if (!handlerExecuted) {
        console.log("[RE] Trying Method 3: sendMessage (fallback)");
        try {
          await conn.sendMessage(m.chat, { 
            text: commandText 
          }, {
            quoted: m.quoted
          });
          handlerExecuted = true;
          console.log("[RE] ✅ Message sent via sendMessage");
        } catch (e) {
          console.log("[RE] Method 3 failed:", e.message);
        }
      }

      if (!handlerExecuted) {
        throw new Error("Tidak ada handler method yang tersedia");
      }

      // Wait for command to process
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Delete processing notification
      try {
        await conn.sendMessage(m.chat, { delete: processingMsg.key });
        console.log("[RE] Processing notification deleted");
      } catch (e) {
        console.log("[RE] Failed to delete notification:", e.message);
      }

      console.log("[RE] ✅ Command execution completed");

    } catch (execError) {
      console.error("[RE] ❌ Execution error:", execError.message);
      console.error("[RE] Stack:", execError.stack);
      
      return m.reply(
        `❌ *Gagal menjalankan command!*\n\n` +
        `Command: *${command}*\n` +
        `Error: ${execError.message}\n\n` +
        `💡 Coba jalankan manual: ${commandText}`
      );
    }

  } catch (e) {
    console.error("\n[RE ERROR] ==========================================");
    console.error("[RE ERROR] Unhandled error:", e.message);
    console.error("[RE ERROR] Stack:", e.stack);
    console.error("[RE ERROR] ==========================================\n");
    
    m.reply(
      `❌ *Terjadi kesalahan sistem*\n\n` +
      `${e.message}\n\n` +
      `Silakan coba lagi atau hubungi admin bot.`
    );
  }
};

// ========================================
// HANDLER METADATA
// ========================================
handler.help = ["re", "repeat", "retry"];
handler.command = ["re", "repeat", "retry"];
handler.tags = ["tools"];
handler.description = "Mengulangi perintah dari pesan yang di-reply dengan auto-deteksi URL";
handler.limit = false;

export default handler;