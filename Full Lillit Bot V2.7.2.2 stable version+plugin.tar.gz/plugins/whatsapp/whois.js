// whois.js - Plugin Whois Lookup untuk bot WhatsApp (ESM-safe)

import { createRequire } from 'module';
const require = createRequire(import.meta.url);

class AntiDoubleActivity {
    constructor() {
        this.activities = new Map();
    }

    checkAndMark(userId, commandName) {
        const key = `${userId}_${commandName}`;
        if (this.activities.has(key)) return false;
        this.activities.set(key, true);
        return true;
    }

    markAsComplete(userId, commandName) {
        const key = `${userId}_${commandName}`;
        this.activities.delete(key);
    }
}

const antiDoubleActivity = new AntiDoubleActivity();

function extractQuotedText(m) {
    try {
        if (m.quoted?.text) return m.quoted.text.trim();

        const msg = m.message;
        let contextInfo = null;

        if (msg?.extendedTextMessage) contextInfo = msg.extendedTextMessage.contextInfo;
        else if (msg?.imageMessage)     contextInfo = msg.imageMessage.contextInfo;
        else if (msg?.videoMessage)     contextInfo = msg.videoMessage.contextInfo;

        if (contextInfo?.quotedMessage) {
            return contextInfo.quotedMessage.conversation?.trim() ||
                   contextInfo.quotedMessage.extendedTextMessage?.text?.trim() ||
                   null;
        }
        return null;
    } catch {
        return null;
    }
}

async function simpleWhoisLookup(domain) {
    domain = domain.trim().toLowerCase()
        .replace(/^https?:\/\//i, '')
        .split(/[/?#]/)[0];

    if (!/^[a-z0-9][a-z0-9.-]*\.[a-z]{2,}$/.test(domain)) {
        throw new Error('Format domain tidak valid');
    }

    let whoisServer = 'whois.iana.org';
    let data = '';

    try {
        const ianaData = await whoisQuery(whoisServer, domain);
        const match = ianaData.match(/whois:\s+([^\s\r\n]+)/i);
        if (match) whoisServer = match[1].trim();
    } catch {}

    try {
        data = await whoisQuery(whoisServer, domain);
    } catch (err) {
        throw new Error(`Gagal koneksi ke server WHOIS: ${err.message}`);
    }

    const result = {
        domain: domain.toUpperCase(),
        success: data.length > 40,
        registered: null,
        expires: null,
        registrar: null,
        nameservers: [],
        note: null,
        raw: data.trim()
    };

    const lines = data.split('\n').map(l => l.trim()).filter(Boolean);

    for (const line of lines) {
        if (line.startsWith('>>>') || line.includes('TERMS OF USE')) continue;

        const [keyPart, ...valueParts] = line.split(':');
        const key = keyPart.trim().toLowerCase();
        const value = valueParts.join(':').trim();

        if (key.includes('domain name')) result.domain = value;
        else if (key.includes('creation date') || key.includes('created')) result.registered = value;
        else if (key.includes('registry expiry') || key.includes('expires')) result.expires = value;
        else if (key.includes('registrar') && !result.registrar) {
            result.registrar = value.replace(/\s+operations,\s*UAB/i, ' (UAB)');
        }
        else if (key.includes('name server')) {
            let ns = value.toLowerCase().replace(/\.$/, '');
            if (ns && !result.nameservers.includes(ns)) result.nameservers.push(ns);
        }
    }

    if (result.expires) {
        try {
            const expDate = new Date(result.expires);
            const now = new Date();
            const daysLeft = Math.floor((expDate - now) / (1000 * 60 * 60 * 24));
            result.daysLeft = daysLeft;
            result.note = daysLeft < 0 ? 'Domain sudah kadaluarsa' : `Sisa ${daysLeft} hari`;
        } catch {}
    }

    return result;
}

function whoisQuery(server, query) {
    return new Promise((resolve, reject) => {
        const net = require('net');  // Sekarang aman karena pakai createRequire
        const client = net.connect({ host: server, port: 43 }, () => {
            client.write(query + '\r\n');
        });

        let buffer = '';
        client.on('data', chunk => buffer += chunk);
        client.on('end', () => resolve(buffer));
        client.on('error', reject);
        client.setTimeout(12000, () => {
            client.destroy();
            reject(new Error('Timeout koneksi'));
        });
    });
}

function formatWhoisResult(result, prefix) {
    let text = `🌐 *WHOIS LOOKUP*\n\n📛 Domain: *${result.domain}*\n`;

    if (!result.success) {
        text += `❌ Gagal mendapatkan data lengkap\n`;
        if (result.raw) text += `\n${result.raw.slice(0, 300)}...\n`;
        text += `\n\nCoba lagi: ${prefix}whois <domain>`;
        return text;
    }

    if (result.registered) text += `📅 Registered : ${result.registered}\n`;
    if (result.expires)    text += `⏳ Expires    : ${result.expires}\n`;
    if (result.daysLeft != null) {
        text += `⏱ Status     : ${result.daysLeft < 0 ? 'Kadaluarsa' : `Sisa ${result.daysLeft} hari`}\n`;
    }
    if (result.registrar)  text += `🏢 Registrar  : ${result.registrar}\n`;

    if (result.nameservers.length > 0) {
        text += `\n📡 Nameserver:\n${result.nameservers.map(ns => `• ${ns}`).join('\n')}\n`;
    }

    if (result.note) text += `\nℹ️ *Catatan*: ${result.note}\n`;

    text += `\n\nGunakan: ${prefix}whois <domain> atau reply pesan`;

    return text;
}

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    const userId = m.sender;
    const commandName = 'whois';

    if (!antiDoubleActivity.checkAndMark(userId, commandName)) {
        return m.reply('⚠️ Sedang memproses whois lain. Mohon tunggu sebentar...');
    }

    try {
        let query = (text || '').trim();
        if (!query && args?.length) query = args.join(' ').trim();

        if (!query) {
            const quoted = extractQuotedText(m);
            if (quoted) query = quoted.trim();
        }

        const pref = usedPrefix || '.';

        if (!query) {
            antiDoubleActivity.markAsComplete(userId, commandName);
            return m.reply(
                `*🌐 WHOIS LOOKUP*\n\n`
              + `Cara Penggunaan:\n`
              + `• ${pref}whois google.com\n`
              + `• ${pref}whois detik.com\n`
              + `• Reply pesan berisi domain → ${pref}whois\n\n`
              + `Contoh:\n`
              + `${pref}whois example.com\n\n`
              + `Fitur:\n`
              + `• Info registrar, tanggal kadaluarsa, nameserver\n`
              + `• Anti spam (satu proses per user)\n`
              + `• Output mudah dibaca`
            );
        }

        if (query.toLowerCase() === 'help' || query === '?') {
            antiDoubleActivity.markAsComplete(userId, commandName);
            return m.reply(/* teks help sama seperti di atas */);
        }

        await conn.sendMessage(m.chat, { react: { text: '🔍', key: m.key } });

        const whoisData = await simpleWhoisLookup(query);
        const formatted = formatWhoisResult(whoisData, pref);

        await m.reply(formatted);

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (err) {
        console.error('[WHOIS ERROR]', err.message, err.stack);
        await m.reply(`❌ Gagal: ${err.message || 'terjadi kesalahan'}`);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    } finally {
        antiDoubleActivity.markAsComplete(userId, commandName);
    }
};

handler.help = ["whois <domain>", "whois"];
handler.tags = ["tools", "info"];
handler.command = ["whois"];
handler.limit = true;

export default handler;