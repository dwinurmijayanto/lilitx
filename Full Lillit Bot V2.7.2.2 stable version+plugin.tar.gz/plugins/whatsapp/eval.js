import util from "util";
import vm from "vm";
import { createRequire } from "module";

// Create require function for ES modules
const require = createRequire(import.meta.url);

const handler = async (m, { conn, command, args, config, usedPrefix = '.' }) => {
  // PENTING: Extract text dari args array
  let text = Array.isArray(args) ? args.join(' ') : '';
  
  // Fallback: coba extract dari message body
  if (!text && m.body) {
    const commandPrefix = usedPrefix + command;
    if (m.body.startsWith(commandPrefix)) {
      text = m.body.slice(commandPrefix.length).trim();
    }
  }
  
  console.log("=== EVAL HANDLER DEBUG ===");
  console.log("Command:", command);
  console.log("Args array:", args);
  console.log("Extracted text:", text);
  console.log("========================");
  
  if (!text) {
    return m.reply("Masukkan kode JavaScript-nya.");
  }
  
  let logs = [];
  let result, error;
  
  try {
    const sandbox = {
      ...global,
      m,
      conn,
      args,
      config,
      require,
      process,
      Buffer,
      setTimeout, 
      clearTimeout, 
      setInterval, 
      clearInterval,
      console: { 
        log: (...a) => logs.push(a.map(x => util.inspect(x, { depth: 1 })).join(" ")),
        error: (...a) => logs.push("[ERR] " + a.map(x => util.inspect(x, { depth: 1 })).join(" ")),
      },
    };
    
    const context = vm.createContext(sandbox);
    
    const wrapped = /^\s*\((.*)\)\s*=>|^async\s+|\bawait\b/.test(text)
      ? `(async()=>{ return (${text}); })()`
      : `(async()=>{ ${text} })()`;
    
    result = await vm.runInContext(wrapped, context, { timeout: 10000 });
  } catch (e) {
    error = e;
  }
  
  const block = (s) => "```\n" + String(s).slice(0, 1900) + "\n```";
  
  const out = 
    (logs.length ? `*Console:*\n${block(logs.join("\n"))}\n` : "") +
    (error ? `*Error:*\n${block(error)}`
           : `*Result:*\n${block(util.inspect(result, { depth: 2 }))}`);
  
  await m.reply(out);
};

handler.command = ["eval", "=>"];
handler.tags = ["owner"];
handler.help = ["eval <code>", "=> <code>"];
handler.description = "Evaluate JavaScript code (Owner Only).";

export default handler;