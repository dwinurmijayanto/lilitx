const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

async function fetchGempaData() {
    const apiUrl = 'https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json';
    
    try {
        const response = await fetch(apiUrl, {
            timeout: 10000 // 10 detik timeout
        });
        
        if (!response.ok) {
            throw new Error(`API Error: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (!data.Infogempa || !data.Infogempa.gempa) {
            throw new Error('API tidak mengembalikan data yang valid');
        }
        
        return { success: true, data: data.Infogempa.gempa };
    } catch (error) {
        throw new Error(`Gagal mengambil data gempa: ${error.message}`);
    }
}

// Fungsi untuk mendapatkan emoji berdasarkan magnitudo
function getMagnitudeEmoji(magnitude) {
    const mag = parseFloat(magnitude);
    if (mag >= 7.0) return '🔴'; // Sangat Kuat
    if (mag >= 6.0) return '🟠'; // Kuat
    if (mag >= 5.0) return '🟡'; // Sedang
    return '🟢'; // Ringan
}

// Fungsi untuk mendapatkan kategori gempa
function getMagnitudeCategory(magnitude) {
    const mag = parseFloat(magnitude);
    if (mag >= 7.0) return 'Sangat Kuat';
    if (mag >= 6.0) return 'Kuat';
    if (mag >= 5.0) return 'Sedang';
    return 'Ringan';
}

// Fungsi untuk mengecek potensi tsunami
function hasTsunamiPotential(potensi) {
    const lower = potensi.toLowerCase();
    return lower.includes('tsunami') && !lower.includes('tidak berpotensi tsunami');
}

// Fungsi untuk menghitung waktu relatif
function getRelativeTime(dateTimeString) {
    try {
        const gempaTime = new Date(dateTimeString);
        const now = new Date();
        const diffMs = now - gempaTime;
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMs / 3600000);
        const diffDays = Math.floor(diffMs / 86400000);
        
        if (diffMins < 1) return 'Baru saja';
        if (diffMins < 60) return `${diffMins} menit yang lalu`;
        if (diffHours < 24) return `${diffHours} jam yang lalu`;
        if (diffDays < 7) return `${diffDays} hari yang lalu`;
        return gempaTime.toLocaleDateString('id-ID');
    } catch (error) {
        return 'Waktu tidak tersedia';
    }
}

function formatGempaData(gempa) {
    const {
        Tanggal,
        Jam,
        DateTime,
        Coordinates,
        Lintang,
        Bujur,
        Magnitude,
        Kedalaman,
        Wilayah,
        Potensi,
        Dirasakan,
        Shakemap
    } = gempa;
    
    // Format shakemap URL
    const shakemapUrl = `https://static.bmkg.go.id/${Shakemap}`;
    
    // Parse koordinat untuk format yang lebih rapi
    const [lat, lon] = Coordinates.split(',');
    
    // Dapatkan emoji dan kategori magnitudo
    const magEmoji = getMagnitudeEmoji(Magnitude);
    const magCategory = getMagnitudeCategory(Magnitude);
    
    // Cek potensi tsunami
    const tsunamiAlert = hasTsunamiPotential(Potensi);
    const tsunamiEmoji = tsunamiAlert ? '🌊⚠️' : '✅';
    
    // Waktu relatif
    const relativeTime = getRelativeTime(DateTime);
    
    let output = `╔═══════════════════════\n`;
    output += `║ 🌍 *INFO GEMPA TERKINI*\n`;
    output += `╚═══════════════════════\n\n`;
    
    // Header dengan highlight
    output += `${magEmoji} *Gempa ${magCategory}* - M${Magnitude}\n`;
    output += `📍 ${Wilayah}\n`;
    output += `⏱️ _${relativeTime}_\n\n`;
    
    output += `┏━━━━━━━━━━━━━━━━━━━━┓\n`;
    output += `┃  📊 DETAIL GEMPA  ┃\n`;
    output += `┗━━━━━━━━━━━━━━━━━━━━┛\n\n`;
    
    // Informasi Waktu
    output += `⏰ *Waktu Kejadian*\n`;
    output += `├ 📅 ${Tanggal}\n`;
    output += `├ 🕐 ${Jam}\n`;
    output += `└ 🌐 ${DateTime}\n\n`;
    
    // Informasi Kekuatan & Lokasi
    output += `💥 *Kekuatan & Lokasi*\n`;
    output += `├ ${magEmoji} Magnitudo: *${Magnitude} SR*\n`;
    output += `├ 📏 Kedalaman: ${Kedalaman}\n`;
    output += `├ 🧭 ${Lintang}\n`;
    output += `├ 🧭 ${Bujur}\n`;
    output += `└ 📌 ${lat}°, ${lon}°\n\n`;
    
    // Status Tsunami
    output += `${tsunamiEmoji} *Status Tsunami*\n`;
    output += `${Potensi}\n\n`;
    
    // Area yang merasakan (jika ada)
    if (Dirasakan) {
        output += `👥 *Wilayah Terdampak (MMI)*\n`;
        const wilayahList = Dirasakan.split(',').map(w => w.trim());
        wilayahList.forEach((wilayah, index) => {
            const prefix = index === wilayahList.length - 1 ? '└' : '├';
            output += `${prefix} ${wilayah}\n`;
        });
        output += `\n`;
    }
    
    output += `━━━━━━━━━━━━━━━━━━━━━━\n`;
    output += `📡 Sumber: BMKG Indonesia\n`;
    output += `🔄 Diperbarui: ${new Date().toLocaleString('id-ID', { 
        timeZone: 'Asia/Jakarta',
        hour: '2-digit',
        minute: '2-digit'
    })} WIB`;
    
    return { 
        text: output, 
        imageUrl: shakemapUrl, 
        magnitude: Magnitude, 
        hasTsunami: tsunamiAlert,
        shakemapLink: shakemapUrl  // Tambahan untuk keperluan fallback
    };
}

function generateUsageHelp(prefix, cmd) {
    return `*🌍 INFO GEMPA BMKG*

📌 *Cara Penggunaan:*
${prefix}${cmd} → Cek gempa terkini

✨ *Informasi yang ditampilkan:*
• Tanggal & Waktu (WIB & UTC)
• Magnitudo (kekuatan gempa)
• Kedalaman episenter
• Koordinat lokasi (Lintang & Bujur)
• Wilayah terdekat dengan pusat gempa
• Potensi tsunami
• Daerah yang merasakan gempa (skala MMI)
• Peta guncangan (Shakemap)

📊 *Sumber Data:*
BMKG (Badan Meteorologi, Klimatologi, dan Geofisika)
_Data real-time dari sistem monitoring BMKG_

⚠️ *Catatan:*
• Data yang ditampilkan adalah gempa terkini yang tercatat
• Informasi ini bersifat resmi dari BMKG
• Selalu ikuti arahan dari pihak berwenang saat terjadi gempa

💡 *Tips Keselamatan:*
• Tetap tenang dan jangan panik
• Lindungi kepala dari benda jatuh
• Jauhi bangunan, pohon, dan tiang listrik
• Jika di pantai dan gempa kuat, segera ke tempat tinggi`;
}

let handler = async (m, { conn, args, usedPrefix, command }) => {
    // Deteksi prefix
    let prefix = usedPrefix;
    if (!prefix && m.text) {
        const match = m.text.match(/^([.!#/])/);
        prefix = match ? match[1] : '.';
    }
    prefix = prefix || '.';
    
    const cmd = command || 'gempa';
    
    // Cek apakah user minta help
    if (args && args.length > 0 && (args[0].toLowerCase() === 'help' || args[0] === '?')) {
        return m.reply(generateUsageHelp(prefix, cmd));
    }
    
    try {
        // React dengan emoji untuk menunjukkan proses
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        const { success, data } = await fetchGempaData();
        
        if (!success || !data) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply('❌ Gagal mendapatkan data gempa dari BMKG. Silakan coba lagi.');
        }
        
        // Format data gempa
        const { text: message, imageUrl, magnitude, hasTsunami, shakemapLink } = formatGempaData(data);
        
        // Tentukan emoji react berdasarkan kondisi
        let reactEmoji = '✅';
        if (hasTsunami) {
            reactEmoji = '🌊'; // Tsunami warning
        } else if (parseFloat(magnitude) >= 6.0) {
            reactEmoji = '⚠️'; // Gempa kuat
        }
        
        // Kirim pesan dengan gambar shakemap
        try {
            await conn.sendMessage(m.chat, {
                image: { url: imageUrl },
                caption: message
            }, { quoted: m });
            
            // Tambahan peringatan jika ada potensi tsunami
            if (hasTsunami) {
                await conn.sendMessage(m.chat, {
                    text: `⚠️ *PERINGATAN TSUNAMI* ⚠️\n\nSegera lakukan evakuasi ke tempat yang lebih tinggi!\nJauhi area pantai dan ikuti arahan petugas berwenang.`
                }, { quoted: m });
            }
        } catch (imgError) {
            // Jika gagal kirim gambar, kirim text dengan link gambar
            console.error('Gagal mengirim gambar:', imgError);
            const fallbackMessage = message + 
                `\n\n🗺️ *Peta Guncangan:*\n${shakemapLink}\n\n` +
                `⚠️ _Gambar gagal dimuat, gunakan link di atas_`;
            
            await conn.sendMessage(m.chat, {
                text: fallbackMessage
            }, { quoted: m });
            
            // Tetap kirim peringatan tsunami jika ada
            if (hasTsunami) {
                await conn.sendMessage(m.chat, {
                    text: `⚠️ *PERINGATAN TSUNAMI* ⚠️\n\nSegera lakukan evakuasi ke tempat yang lebih tinggi!\nJauhi area pantai dan ikuti arahan petugas berwenang.`
                }, { quoted: m });
            }
        }
        
        // React dengan emoji sesuai kondisi
        await conn.sendMessage(m.chat, { react: { text: reactEmoji, key: m.key } });
        
    } catch (error) {
        console.error('Error fetching gempa data:', error);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        m.reply('❌ Terjadi kesalahan saat mengambil data gempa. Silakan coba lagi.\n\n' + 
                '💡 Tip: Pastikan koneksi internet stabil\n' +
                `📋 Error: ${error.message}`);
    }
};

handler.help = ["gempa"];
handler.tags = ["info"];
handler.command = ["gempa", "earthquake", "infogempa", "gempabumi"];

export default handler;