import fetch from 'node-fetch';
import FormData from 'form-data';
import fs from 'fs';
import { promisify } from 'util';
import { tmpdir } from 'os';
import { join } from 'path';

const writeFile = promisify(fs.writeFile);
const unlink = promisify(fs.unlink);

console.log('[Khodam Handler] Loading handler...');

// ========== KHODAM CONFIGURATION ==========
const KHODAM_API_URL = 'https://cek-khodam.com/api/check';
const KHODAM_STATS_URL = 'https://cek-khodam.com/api/stats';
const TIMEOUT_MS = 8000;

// Daftar khodam yang mungkin muncul
const KHODAM_LIST = [
    'Macan Putih', 'Naga Hitam', 'Elang Jawa', 'Harimau Sumatera',
    'Singa Emas', 'Gajah Putih', 'Burung Phoenix', 'Kuda Sembrani',
    'Ular Naga', 'Kucing Oren', 'Ayam Geprek', 'Tikus Got',
    'Bebek Peking', 'Sapi Perah', 'Kambing Guling', 'Monyet Sakti',
    'Buaya Darat', 'Kelelawar Hitam', 'Serigala Abu-abu', 'Rubah Merah',
    'Ratu Adil', 'Jin Ifrit', 'Bidadari Surga', 'Malaikat Pelindung',
    'Pocong Lompat', 'Kuntilanak Merah', 'Genderuwo Hutan', 'Tuyul Kaya',
    'Wewe Gombel', 'Leak Bali', 'Sundel Bolong', 'Buto Ijo',
    'Kosong (Tidak Ada Khodam)', 'Semut Merah', 'Cicak Dinding',
    'Sendal Jepit', 'Kardus Bekas', 'Tutup Botol', 'Batu Akik Palsu'
];

// ========== AI IMAGE CONFIGURATION ==========
const AI_LABS_CONFIG = {
    base: 'https://text2video.aritek.app',
    endpoints: {
        text2img: '/text2img'
    },
    cipher: 'hbMcgZLlzvghRlLbPcTbCpfcQKM0PcU0zhPcTlOFMxBZ1oLmruzlVp9remPgi0QWP0QW',
    shiftValue: 3,
    timeout: 15000
};

const UPLOAD_CONFIG = {
    url: 'https://badan-tools-web.onrender.com/upload',
    timeout: 120000,
    maxFileSize: 500 * 1024 * 1024
};

// State management
const state = {
    token: null
};

// ========== UTILITY FUNCTIONS ==========
function decryptCaesar(text, shift) {
    return [...text].map(c =>
        /[a-z]/.test(c)
            ? String.fromCharCode((c.charCodeAt(0) - 97 - shift + 26) % 26 + 97)
            : /[A-Z]/.test(c)
            ? String.fromCharCode((c.charCodeAt(0) - 65 - shift + 26) % 26 + 65)
            : c
    ).join('');
}

async function getAuthToken() {
    if (state.token) return state.token;
    const decrypted = decryptCaesar(AI_LABS_CONFIG.cipher, AI_LABS_CONFIG.shiftValue);
    state.token = decrypted;
    return decrypted;
}

function createHeaders(token) {
    return {
        'user-agent': 'NB Android/1.0.0',
        'accept-encoding': 'gzip',
        'content-type': 'application/json',
        'authorization': token
    };
}

function formatFileSize(bytes) {
    if (bytes >= 1024 * 1024 * 1024) {
        return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
    } else if (bytes >= 1024 * 1024) {
        return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
    } else if (bytes >= 1024) {
        return (bytes / 1024).toFixed(2) + ' KB';
    }
    return bytes + ' B';
}

// ========== KHODAM FUNCTIONS ==========
function generateKhodam(nama) {
    if (!nama || nama.trim() === '') {
        return null;
    }
    
    let hash = 0;
    const cleanNama = nama.toLowerCase().trim();
    
    for (let i = 0; i < cleanNama.length; i++) {
        const char = cleanNama.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash;
    }
    
    const index = Math.abs(hash) % KHODAM_LIST.length;
    return KHODAM_LIST[index];
}

async function checkKhodamAPI(nama) {
    try {
        console.log(`[Khodam Handler] Checking khodam for: ${nama}`);
        
        const fetchPromise = fetch(KHODAM_API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ name: nama })
        });
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error(`Timeout setelah ${TIMEOUT_MS}ms`)), TIMEOUT_MS)
        );
        
        const response = await Promise.race([fetchPromise, timeoutPromise]);
        
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status}`);
        }
        
        const data = await response.json();
        console.log('[Khodam Handler] ✅ API response received');
        
        return {
            success: true,
            khodam: data.khodam || data.result || generateKhodam(nama),
            source: 'api'
        };
        
    } catch (error) {
        console.warn(`[Khodam Handler] ⚠️ API failed: ${error.message}, using fallback`);
        return {
            success: true,
            khodam: generateKhodam(nama),
            source: 'fallback'
        };
    }
}

async function getKhodamStats() {
    try {
        console.log('[Khodam Handler] Fetching khodam statistics...');
        
        const fetchPromise = fetch(KHODAM_STATS_URL);
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error(`Timeout setelah ${TIMEOUT_MS}ms`)), TIMEOUT_MS)
        );
        
        const response = await Promise.race([fetchPromise, timeoutPromise]);
        
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status}`);
        }
        
        const data = await response.json();
        console.log('[Khodam Handler] ✅ Stats received');
        
        return {
            success: true,
            stats: data,
            source: 'api'
        };
        
    } catch (error) {
        console.warn(`[Khodam Handler] ⚠️ Stats API failed: ${error.message}`);
        return {
            success: false,
            error: error.message
        };
    }
}

// ========== AI IMAGE GENERATION FUNCTIONS ==========
async function generateKhodamImage(khodamName) {
    try {
        console.log('[Khodam Handler] Generating AI image for khodam:', khodamName);
        
        // Create descriptive prompt for the khodam
        const prompt = `mystical spirit guardian ${khodamName}, indonesian mythology, magical aura, ethereal, fantasy art, detailed, vibrant colors`;
        
        const token = await getAuthToken();
        const formData = new FormData();
        formData.append('prompt', prompt);
        formData.append('token', token);
        
        const url = AI_LABS_CONFIG.base + AI_LABS_CONFIG.endpoints.text2img;
        const response = await fetch(url, {
            method: 'POST',
            body: formData,
            headers: {
                ...createHeaders(token),
                ...formData.getHeaders()
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status} ${response.statusText}`);
        }
        
        const result = await response.json();
        
        if (result.code === 0 && result.url) {
            console.log('[Khodam Handler] AI image generation success');
            return { 
                success: true, 
                url: result.url.trim(),
                prompt: prompt
            };
        } else {
            throw new Error('AI image generation failed - invalid response');
        }
    } catch (error) {
        console.error('[Khodam Handler] AI image generation error:', error.message);
        return { 
            success: false, 
            message: error.message 
        };
    }
}

async function downloadFromUrl(url) {
    try {
        console.log('[Khodam Handler] Downloading from URL:', url);
        
        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const contentLength = response.headers.get('content-length');
        if (contentLength) {
            const size = parseInt(contentLength);
            if (size > UPLOAD_CONFIG.maxFileSize) {
                throw new Error(`File terlalu besar (${formatFileSize(size)}). Maksimal 500MB`);
            }
        }
        
        const arrayBuffer = await response.arrayBuffer();
        return Buffer.from(arrayBuffer);
    } catch (error) {
        console.error('[Khodam Handler] Download error:', error.message);
        throw error;
    }
}

async function uploadToBadanTools(filePath, filename) {
    try {
        console.log('[Khodam Handler] Uploading to Badan Tools:', filename);
        
        const form = new FormData();
        form.append('uploadedFile', fs.createReadStream(filePath), filename);
        
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), UPLOAD_CONFIG.timeout);
        
        const response = await fetch(UPLOAD_CONFIG.url, {
            method: 'POST',
            signal: controller.signal,
            headers: {
                ...form.getHeaders(),
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36'
            },
            body: form
        });
        
        clearTimeout(timeout);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const result = await response.json();
        
        if (result.success && result.url) {
            console.log('[Khodam Handler] Upload success:', result.url);
            return {
                success: true,
                url: result.url,
                metadata: result.metadata || {}
            };
        } else {
            throw new Error(result.message || 'Upload failed');
        }
        
    } catch (error) {
        console.error('[Khodam Handler] Upload error:', error.message);
        return { 
            success: false, 
            message: error.message 
        };
    }
}

async function downloadAndUpload(sourceUrl, filename) {
    let tmpFile = null;
    
    try {
        console.log('[Khodam Handler] Starting download and upload process');
        
        const buffer = await downloadFromUrl(sourceUrl);
        
        if (buffer.length > UPLOAD_CONFIG.maxFileSize) {
            throw new Error(`File terlalu besar (${formatFileSize(buffer.length)}). Maksimal 500MB`);
        }
        
        tmpFile = join(tmpdir(), `khodam_${Date.now()}.jpg`);
        await writeFile(tmpFile, buffer);
        
        console.log('[Khodam Handler] File saved to temp:', tmpFile);
        
        const uploadResult = await uploadToBadanTools(tmpFile, filename);
        
        try {
            await unlink(tmpFile);
            console.log('[Khodam Handler] Temp file cleaned up');
        } catch (e) {
            // Silent fail
        }
        
        if (uploadResult.success) {
            return {
                success: true,
                url: uploadResult.url,
                metadata: uploadResult.metadata,
                originalUrl: sourceUrl
            };
        } else {
            throw new Error(uploadResult.message || 'Upload failed');
        }
        
    } catch (error) {
        if (tmpFile) {
            try {
                await unlink(tmpFile);
            } catch (e) {
                // Silent fail
            }
        }
        
        return {
            success: false,
            message: error.message,
            originalUrl: sourceUrl
        };
    }
}

// ========== FORMAT FUNCTIONS ==========
function formatKhodamMessage(nama, khodam, source, hasImage = false) {
    let message = `*🔮 CEK KHODAM*\n\n`;
    message += `┌─「 👤 *Info Pengecekan* 」\n`;
    message += `├ 📝 Nama: *${nama}*\n`;
    message += `└ 🎭 Khodam: *${khodam}*\n\n`;
    
    // Tambahkan deskripsi berdasarkan jenis khodam
    if (khodam.toLowerCase().includes('kosong') || khodam.toLowerCase().includes('tidak ada')) {
        message += `*💭 Penjelasan:*\n`;
        message += `Kamu tidak memiliki khodam pendamping. Ini bukan hal buruk! Kamu adalah pribadi yang mandiri dan tidak bergantung pada kekuatan gaib.\n\n`;
    } else if (khodam.toLowerCase().includes('macan') || khodam.toLowerCase().includes('harimau') || khodam.toLowerCase().includes('singa')) {
        message += `*🦁 Penjelasan:*\n`;
        message += `Khodam kamu adalah makhluk yang perkasa dan gagah berani! Kamu memiliki jiwa kepemimpinan yang kuat dan keberanian luar biasa.\n\n`;
    } else if (khodam.toLowerCase().includes('naga') || khodam.toLowerCase().includes('ular')) {
        message += `*🐉 Penjelasan:*\n`;
        message += `Khodam kamu penuh misteri dan kearifan! Kamu memiliki intuisi tajam dan kemampuan untuk melihat hal-hal yang tersembunyi.\n\n`;
    } else if (khodam.toLowerCase().includes('burung') || khodam.toLowerCase().includes('elang') || khodam.toLowerCase().includes('phoenix')) {
        message += `*🦅 Penjelasan:*\n`;
        message += `Khodam kamu melambangkan kebebasan dan visi yang tinggi! Kamu memiliki perspektif luas dan mampu melihat gambaran besar.\n\n`;
    } else if (khodam.toLowerCase().includes('jin') || khodam.toLowerCase().includes('malaikat') || khodam.toLowerCase().includes('bidadari')) {
        message += `*✨ Penjelasan:*\n`;
        message += `Khodam kamu adalah makhluk spiritual yang mulia! Kamu memiliki koneksi spiritual yang kuat dan aura positif.\n\n`;
    } else if (khodam.toLowerCase().includes('pocong') || khodam.toLowerCase().includes('kuntilanak') || khodam.toLowerCase().includes('genderuwo')) {
        message += `*👻 Penjelasan:*\n`;
        message += `Khodam kamu adalah makhluk halus lokal! Ini menunjukkan kamu memiliki daya tarik mistis dan kepribadian yang unik.\n\n`;
    } else if (khodam.toLowerCase().includes('sendal') || khodam.toLowerCase().includes('kardus') || khodam.toLowerCase().includes('tutup')) {
        message += `*😄 Penjelasan:*\n`;
        message += `Khodam kamu adalah benda sehari-hari! Ini menunjukkan kamu adalah pribadi yang sederhana, down to earth, dan mudah bergaul.\n\n`;
    } else {
        message += `*🌟 Penjelasan:*\n`;
        message += `Khodam kamu memiliki energi unik tersendiri! Setiap khodam membawa keberuntungan dan perlindungan dengan caranya sendiri.\n\n`;
    }
    
    if (hasImage) {
    //    message += `🎨 _Gambar khodam dibuat menggunakan AI Image Generation_\n\n`;
    }
    
    message += `💡 _Hasil ini hanya untuk hiburan. Jangan terlalu serius ya!_ 😊`;
    
    return message;
}

function formatStatsMessage(stats) {
    let message = `*📊 STATISTIK KHODAM*\n\n`;
    
    if (stats.popular && stats.popular.length > 0) {
        message += `*🏆 KHODAM PALING POPULER:*\n\n`;
        stats.popular.slice(0, 5).forEach((item, index) => {
            const emoji = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : '🏅';
            message += `${emoji} *${item.name}*\n`;
            message += `   └ ${item.count} kali muncul\n\n`;
        });
    }
    
    if (stats.rare && stats.rare.length > 0) {
        message += `*💎 KHODAM PALING LANGKA:*\n\n`;
        stats.rare.slice(0, 5).forEach((item, index) => {
            message += `💎 *${item.name}*\n`;
            message += `   └ ${item.count} kali muncul\n\n`;
        });
    }
    
    if (stats.total_checks) {
        message += `*📈 TOTAL PENGECEKAN:*\n`;
        message += `${stats.total_checks.toLocaleString()} kali\n\n`;
    }
    
    message += `🔗 *Sumber:* cek-khodam.com\n`;
    message += `⏰ *Update:* ${new Date().toLocaleString('id-ID')}`;
    
    return message;
}

function generateUsageHelp(prefix, cmd) {
    return `*🔮 CEK KHODAM*

📌 *Cara Penggunaan:*
${prefix}${cmd} <nama>

📋 *Contoh:*
${prefix}${cmd} Budi
${prefix}${cmd} Siti Nurhaliza
${prefix}${cmd} Ahmad Dhani

✨ *Fitur:*
• Cek khodam berdasarkan nama
• Hasil konsisten untuk nama yang sama
• Penjelasan karakteristik khodam
• Support nama panjang
• Gambar AI Generated dari khodam
• Auto upload ke Badan Tools Web

📊 *Statistik:*
${prefix}${cmd} stats
Lihat khodam paling populer dan langka

🎭 *Apa itu Khodam?*
Khodam adalah makhluk gaib yang dipercaya mendampingi seseorang dan memberikan perlindungan atau keberuntungan tertentu.

⚠️ *Disclaimer:*
Fitur ini hanya untuk hiburan dan tidak memiliki dasar ilmiah. Jangan dijadikan patokan serius ya! 😊

💡 _Ketik ${prefix}${cmd} help untuk melihat panduan ini lagi_`;
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    console.log('[Khodam Handler] ========================================');
    console.log('[Khodam Handler] Handler function called!');
    
    let prefix = usedPrefix;
    if (!prefix && m.text) {
        const match = m.text.match(/^([.!#/])/);
        prefix = match ? match[1] : '.';
    }
    prefix = prefix || '.';
    
    const cmd = command || 'khodam';
    
    let inputText = '';
    if (text) {
        inputText = text.trim();
    } else if (args && args.length > 0) {
        inputText = args.join(' ').trim();
    }
    
    console.log(`[Khodam Handler] Parsed data - prefix: ${prefix}, cmd: ${cmd}, inputText: "${inputText}"`);
    
    // Check for help
    if (!inputText || inputText.toLowerCase() === 'help' || inputText === '?') {
        console.log('[Khodam Handler] Help requested');
        return m.reply(generateUsageHelp(prefix, cmd));
    }
    
    // Check for stats
    if (inputText.toLowerCase() === 'stats' || inputText.toLowerCase() === 'statistik') {
        try {
            await conn.sendMessage(m.chat, { react: { text: '📊', key: m.key } });
            
            console.log('[Khodam Handler] Stats requested');
            const result = await getKhodamStats();
            
            if (result.success) {
                const message = formatStatsMessage(result.stats);
                await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                return m.reply(message);
            } else {
                await conn.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } });
                return m.reply(`⚠️ Statistik tidak tersedia saat ini\n\n💡 Coba lagi nanti atau gunakan:\n${prefix}${cmd} <nama> untuk cek khodam`);
            }
            
        } catch (error) {
            console.error('[Khodam Handler] Stats ERROR:', error);
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
            return m.reply(`❌ Gagal mengambil statistik!\n\n⚠️ Error: ${error.message}`);
        }
    }
    
    // Validate nama
    const nama = inputText.trim();
    
    if (nama.length < 2) {
        return m.reply(`❌ Nama terlalu pendek!\n\n💡 Masukkan nama yang valid (minimal 2 karakter)\n\n📋 Contoh:\n${prefix}${cmd} Budi`);
    }
    
    if (nama.length > 50) {
        return m.reply(`❌ Nama terlalu panjang!\n\n💡 Maksimal 50 karakter\n\n📋 Contoh:\n${prefix}${cmd} Budi Santoso`);
    }
    
    try {
        await conn.sendMessage(m.chat, { react: { text: '🔮', key: m.key } });
        
        console.log(`[Khodam Handler] Checking khodam for: ${nama}`);
        const result = await checkKhodamAPI(nama);
        
        if (result.success) {
            // Generate AI image for khodam
            console.log('[Khodam Handler] Generating AI image...');
            await m.reply('🎨 *Membuat visualisasi khodam...*\n⏳ Mohon tunggu sebentar...');
            
            const imageResult = await generateKhodamImage(result.khodam);
            let finalImageUrl = null;
            
            if (imageResult.success && imageResult.url) {
                console.log('[Khodam Handler] Uploading image to Badan Tools');
                const filename = `khodam_${nama.replace(/\s+/g, '_')}_${Date.now()}.jpg`;
                const uploadResult = await downloadAndUpload(imageResult.url, filename);
                
                if (uploadResult.success) {
                    finalImageUrl = uploadResult.url;
                    console.log('[Khodam Handler] ✅ Image uploaded successfully');
                } else {
                    // Fallback to original URL
                    finalImageUrl = imageResult.url;
                    console.warn('[Khodam Handler] ⚠️ Upload failed, using original URL');
                }
            }
            
            const message = formatKhodamMessage(nama, result.khodam, result.source, !!finalImageUrl);
            
            if (finalImageUrl) {
                // Send with image
                try {
                    await conn.sendMessage(m.chat, {
                        image: { url: finalImageUrl },
                        caption: message
                    }, { quoted: m });
                    
                    console.log('[Khodam Handler] ✅ Message sent with image');
                } catch (imgError) {
                    console.warn('[Khodam Handler] ⚠️ Failed to send image, sending text only:', imgError.message);
                    await conn.sendMessage(m.chat, {
                        text: message
                    }, { quoted: m });
                }
            } else {
                // Send text only
                await conn.sendMessage(m.chat, {
                    text: message
                }, { quoted: m });
                
                console.log('[Khodam Handler] ✅ Message sent (text only)');
            }
            
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            
            console.log(`[Khodam Handler] ✅ Khodam result: ${result.khodam}`);
        } else {
            throw new Error('Failed to get khodam result');
        }
        
    } catch (error) {
        console.error('[Khodam Handler] ERROR:', error);
        console.error('[Khodam Handler] Stack:', error.stack);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        
        let errorMsg = '❌ Terjadi kesalahan saat mengecek khodam.\n\n';
        
        if (error.message.includes('Timeout')) {
            errorMsg += `⚠️ Timeout: Server tidak merespons dalam ${TIMEOUT_MS}ms\n💡 Coba lagi dalam beberapa saat`;
        } else {
            errorMsg += `⚠️ Error: ${error.message}\n💡 Coba lagi atau ketik ${prefix}${cmd} help`;
        }
        
        return m.reply(errorMsg);
    }
};

handler.help = ["khodam <nama>"];
handler.tags = ["fun"];
handler.command = ["khodam", "cekkhodam", "cekhodam"];
handler.limit = true;

console.log('[Khodam Handler] Handler loaded successfully');

export default handler;