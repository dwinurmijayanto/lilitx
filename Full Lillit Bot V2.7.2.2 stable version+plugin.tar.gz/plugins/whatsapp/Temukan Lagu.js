import axios from 'axios';
import FormData from 'form-data';
import fs from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';
import { downloadContentFromMessage } from 'baileys';

/**
 * Download media from WhatsApp message
 */
async function downloadMedia(message) {
  try {
    const mimeMap = {
      imageMessage: 'image',
      videoMessage: 'video',
      stickerMessage: 'sticker',
      documentMessage: 'document',
      audioMessage: 'audio'
    };

    const msgKeys = Object.keys(message || {});
    if (msgKeys.length === 0) return null;

    const type = msgKeys[0];
    if (!type) return null;

    const m = message[type];
    if (!m) return null;

    const mediaType = mimeMap[type];
    if (!mediaType) return null;

    const stream = await downloadContentFromMessage(m, mediaType);
    const chunks = [];
    for await (const chunk of stream) {
      chunks.push(chunk);
    }
    
    return Buffer.concat(chunks);
  } catch (error) {
    console.error('[FindSong] Error downloading media:', error);
    return null;
  }
}

/**
 * Detect media from message
 */
function detectMediaFromMessage(m) {
  console.log('[FindSong] Detecting media from message...');
  
  let mediaBuffer = null;
  let mime = '';
  let filename = '';
  let mediaSource = null;
  
  const rawMessage = m.message;
  
  if (!rawMessage) {
    console.log('[FindSong] No raw message found');
    return { mediaBuffer, mime, filename, mediaSource };
  }
  
  console.log('[FindSong] Raw message keys:', Object.keys(rawMessage));
  
  // Check for direct media in message
  if (rawMessage.audioMessage) {
    console.log('[FindSong] Found audioMessage');
    mime = rawMessage.audioMessage.mimetype || 'audio/mpeg';
    filename = rawMessage.audioMessage.fileName || `audio_${Date.now()}.mp3`;
    mediaSource = rawMessage;
  } else if (rawMessage.videoMessage) {
    console.log('[FindSong] Found videoMessage');
    mime = rawMessage.videoMessage.mimetype || 'video/mp4';
    filename = rawMessage.videoMessage.fileName || `video_${Date.now()}.mp4`;
    mediaSource = rawMessage;
  } else if (rawMessage.documentMessage) {
    console.log('[FindSong] Found documentMessage');
    mime = rawMessage.documentMessage.mimetype || 'application/octet-stream';
    filename = rawMessage.documentMessage.fileName || `document_${Date.now()}.mp3`;
    mediaSource = rawMessage;
  } else if (rawMessage.extendedTextMessage) {
    console.log('[FindSong] Found extendedTextMessage, checking for quoted media');
    const contextInfo = rawMessage.extendedTextMessage.contextInfo;
    const quotedMessage = contextInfo?.quotedMessage;
    
    if (quotedMessage) {
      console.log('[FindSong] Quoted message keys:', Object.keys(quotedMessage));
      
      if (quotedMessage.audioMessage) {
        console.log('[FindSong] Found quoted audioMessage');
        mime = quotedMessage.audioMessage.mimetype || 'audio/mpeg';
        filename = quotedMessage.audioMessage.fileName || `audio_${Date.now()}.mp3`;
        mediaSource = quotedMessage;
      } else if (quotedMessage.videoMessage) {
        console.log('[FindSong] Found quoted videoMessage');
        mime = quotedMessage.videoMessage.mimetype || 'video/mp4';
        filename = quotedMessage.videoMessage.fileName || `video_${Date.now()}.mp4`;
        mediaSource = quotedMessage;
      } else if (quotedMessage.documentMessage) {
        console.log('[FindSong] Found quoted documentMessage');
        mime = quotedMessage.documentMessage.mimetype || 'application/octet-stream';
        filename = quotedMessage.documentMessage.fileName || `document_${Date.now()}.mp3`;
        mediaSource = quotedMessage;
      }
    }
  }
  
  // Try m.quoted as fallback
  if (!mediaSource && m.quoted?.message) {
    console.log('[FindSong] Trying m.quoted.message');
    const quotedMsg = m.quoted.message;
    console.log('[FindSong] m.quoted.message keys:', Object.keys(quotedMsg));
    
    if (quotedMsg.audioMessage) {
      console.log('[FindSong] Found m.quoted audioMessage');
      mime = quotedMsg.audioMessage.mimetype || 'audio/mpeg';
      filename = quotedMsg.audioMessage.fileName || `audio_${Date.now()}.mp3`;
      mediaSource = m.quoted.message;
    } else if (quotedMsg.videoMessage) {
      console.log('[FindSong] Found m.quoted videoMessage');
      mime = quotedMsg.videoMessage.mimetype || 'video/mp4';
      filename = quotedMsg.videoMessage.fileName || `video_${Date.now()}.mp4`;
      mediaSource = m.quoted.message;
    } else if (quotedMsg.documentMessage) {
      console.log('[FindSong] Found m.quoted documentMessage');
      mime = quotedMsg.documentMessage.mimetype || 'application/octet-stream';
      filename = quotedMsg.documentMessage.fileName || `document_${Date.now()}.mp3`;
      mediaSource = m.quoted.message;
    }
  }
  
  console.log('[FindSong] Media detection result:', {
    found: !!mediaSource,
    mime: mime,
    filename: filename
  });
  
  return { mediaBuffer, mime, filename, mediaSource };
}

/**
 * Identifies a song from an audio file using the Aha-Music (doreso.com) API.
 */
async function aha_music(path) {
  const form = new FormData();
  form.append('file', fs.createReadStream(path));
  form.append('sample_size', 118784);

  const { data } = await axios.post(
    'https://api.doreso.com/humming',
    form,
    {
      headers: {
        ...form.getHeaders(),
        'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
        'accept': 'application/json, text/plain, */*',
        'origin': 'https://www.aha-music.com',
        'referer': 'https://www.aha-music.com/'
      },
      maxBodyLength: Infinity,
      maxContentLength: Infinity
    }
  );

  return data;
}

let handler = async (m, { conn, usedPrefix, command }) => {
  try {
    // Detect media from message or quoted message
    const detection = detectMediaFromMessage(m);
    
    if (!detection.mediaSource) {
      return m.reply(`❌ Reply audio atau video untuk mencari judul lagu!

*Cara Pakai:*
1. Reply pesan audio/voice note/video
2. Ketik: ${usedPrefix}${command}

📌 Bot akan mengidentifikasi lagu dari audio yang Anda reply.

*Supported:*
• Audio (MP3, WAV, OGG)
• Voice Note WhatsApp
• Video (akan diextract audionya)`);
    }

    const mime = detection.mime;
    
    // Validasi apakah pesan adalah audio atau video
    if (!/audio|video/.test(mime)) {
      return m.reply(`❌ Media harus berupa audio atau video!

*Format yang didukung:*
• Audio: MP3, WAV, OGG, FLAC
• Voice Note WhatsApp
• Video: MP4, MKV, AVI (audio akan diekstrak)

*Cara pakai:*
Reply audio/video dengan: ${usedPrefix}${command}`);
    }

    // React dengan emoji music untuk indikasi proses
    await conn.sendMessage(m.chat, { react: { text: '🎶', key: m.key } });
    
    let tmpPath;
    try {
      // Download media
      console.log('[FindSong] Downloading media...');
      const mediaBuffer = await downloadMedia(detection.mediaSource);
      
      if (!mediaBuffer) {
        throw new Error('Failed to download media buffer');
      }
      
      console.log('[FindSong] Media downloaded successfully:', {
        size: mediaBuffer.length,
        mime: mime,
        filename: detection.filename
      });
      
      tmpPath = join(tmpdir(), `findsong_${Date.now()}.mp3`);
      await fs.promises.writeFile(tmpPath, mediaBuffer);

      // Kirim pesan loading
      const loadingMsg = await m.reply('🔍 Sedang mengidentifikasi lagu...\n_Mohon tunggu sebentar_');
      
      // Proses identifikasi lagu
      const result = await aha_music(tmpPath);

      // Parse hasil
      if (result && result.data && result.data.title) {
        const song = result.data;
        
        let msg = `🎵 *LAGU DITEMUKAN!*\n\n`;
        msg += `📌 *Judul:* ${song.title}\n`;
        msg += `🎤 *Artist:* ${song.artists || 'Unknown'}\n`;
        
        if (song.album) {
          msg += `💿 *Album:* ${song.album}\n`;
        }
        
        if (song.release_date) {
          msg += `📅 *Rilis:* ${song.release_date}\n`;
        }
        
        if (song.spotify_url) {
          msg += `🎧 *Spotify:* ${song.spotify_url}\n`;
        }
        
        if (song.youtube_url) {
          msg += `▶️ *YouTube:* ${song.youtube_url}\n`;
        }
        
        if (song.apple_music_url) {
          msg += `🍎 *Apple Music:* ${song.apple_music_url}\n`;
        }
        
        msg += `\n_Powered by Aha-Music_`;
        
        // Edit pesan loading menjadi hasil
        await conn.sendMessage(m.chat, {
          text: msg,
          edit: loadingMsg.key
        });
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
      } else if (result && result.data && result.data.length > 0) {
        // Jika ada beberapa hasil potensial
        let msg = `🎵 *HASIL PENCARIAN*\n\n`;
        msg += `Ditemukan ${result.data.length} lagu yang mirip:\n\n`;
        
        result.data.slice(0, 3).forEach((song, i) => {
          msg += `*${i + 1}. ${song.title}*\n`;
          msg += `   Artist: ${song.artists || 'Unknown'}\n`;
          if (song.album) {
            msg += `   Album: ${song.album}\n`;
          }
          msg += `\n`;
        });
        
        msg += `_Gunakan audio yang lebih jelas untuk hasil yang lebih akurat_`;
        
        // Edit pesan loading menjadi hasil
        await conn.sendMessage(m.chat, {
          text: msg,
          edit: loadingMsg.key
        });
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
      } else {
        let msg = `❓ *Lagu tidak ditemukan*

Kemungkinan penyebab:
• Audio terlalu pendek (minimal 5-10 detik)
• Kualitas audio kurang jelas
• Lagu tidak ada di database
• Audio terlalu banyak noise

💡 *Tips:*
• Gunakan audio yang lebih panjang
• Pastikan audio jernih (tidak berisik)
• Coba dengan bagian chorus/reff lagu`;

        // Edit pesan loading menjadi hasil
        await conn.sendMessage(m.chat, {
          text: msg,
          edit: loadingMsg.key
        });
        await conn.sendMessage(m.chat, { react: { text: '❓', key: m.key } });
      }
      
    } catch (apiError) {
      console.error('[FindSong] API Error:', apiError);
      
      let errorMsg = '';
      
      if (apiError.response) {
        // Error dari API
        errorMsg = `❌ Gagal mengidentifikasi lagu!

*Error:* ${apiError.response.status} - ${apiError.response.statusText}

Silakan coba lagi dalam beberapa saat.`;
      } else if (apiError.request) {
        // Network error
        errorMsg = `❌ Tidak dapat terhubung ke server!

Periksa koneksi internet Anda dan coba lagi.`;
      } else {
        // Error lainnya
        errorMsg = `❌ Terjadi kesalahan saat memproses audio!

Error: ${apiError.message}`;
      }
      
      // Edit pesan loading menjadi error (jika ada)
      if (typeof loadingMsg !== 'undefined' && loadingMsg?.key) {
        await conn.sendMessage(m.chat, {
          text: errorMsg,
          edit: loadingMsg.key
        }).catch(() => m.reply(errorMsg));
      } else {
        await m.reply(errorMsg);
      }
      
      await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      
    } finally {
      // Clean up temporary file
      if (tmpPath && fs.existsSync(tmpPath)) {
        try {
          fs.unlinkSync(tmpPath);
          console.log('[FindSong] Temp file cleaned up:', tmpPath);
        } catch (cleanupError) {
          console.error('[FindSong] Cleanup error:', cleanupError);
        }
      }
    }
    
  } catch (e) {
    console.error('[FindSong] Handler Error:', e);
    await m.reply(`❌ Terjadi kesalahan!\n\nError: ${e.message}`);
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
  }
};

handler.help = [
  "findsong - Cari judul lagu dari audio",
  "whatsong - Identifikasi lagu",
  "shazam - Cari info lagu (reply audio)"
];

handler.tags = ["tools"];

handler.command = [
  "findsong",
  "whatsong", 
  "shazam",
  "carilagu",
  "identifylagu"
];

handler.description = "Identifikasi judul lagu dengan reply audio/voice note/video";

console.log('[FindSong] Handler loaded successfully with improved media detection');

export default handler;