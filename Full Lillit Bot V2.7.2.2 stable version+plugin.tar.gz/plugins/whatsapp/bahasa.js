import fetch from 'node-fetch';

console.log('[Translate Handler] Loading handler...');

// ========== CONFIGURATION ==========
const TRANSLATE_JAWA_API = 'https://api.translatejawa.id/translate';
const AKSARA_JAWA_API = 'https://aksarajawa.id/api/translate';
const SUNDA_API = 'https://lingvanex.com/translation/translate';

// ========== TRANSLATION FUNCTIONS ==========

/**
 * Translate Indonesia ke Bahasa Jawa (Krama/Ngoko/Lugu)
 * @param {string} text - Text to translate
 * @param {Object} options - Translation options
 * @returns {Promise<string>} - Translated text
 */
async function translateJawa(text, { from = 'indo', to = 'krama-alus' } = {}) {
    try {
        if (!text) throw new Error('Text is required.');
        
        const languageMap = {
            indo: 'id',
            jawa: 'jw',
            'krama-lugu': 'kl',
            'krama-alus': 'ka',
            ngoko: 'ng'
        };
        
        const fromCode = languageMap[from];
        const toCode = languageMap[to];
        
        if (!fromCode) throw new Error(`Invalid 'from' language: ${from}.`);
        if (!toCode) throw new Error(`Invalid 'to' language: ${to}.`);
        if (fromCode === 'id' && toCode === 'id') throw new Error('Cannot translate from indo to indo.');
        if (fromCode === 'jw' && toCode !== 'id') throw new Error('When translating from jawa, target must be indo.');
        
        console.log(`[Translate Handler] Translating: ${from} -> ${to}`);
        
        const response = await fetch(TRANSLATE_JAWA_API, {
            method: 'POST',
            headers: {
                'content-type': 'application/json',
                'referer': 'https://translatejawa.id/',
                'user-agent': 'Mozilla/5.0'
            },
            body: JSON.stringify({
                text: text.trim(),
                from: fromCode,
                to: toCode
            })
        });
        
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status}`);
        }
        
        const data = await response.json();
        return data.result;
    } catch (error) {
        console.error('[Translate Handler] Translation error:', error.message);
        throw new Error(error.message);
    }
}

/**
 * Convert text ke Aksara Jawa atau sebaliknya
 * @param {string} text - Text to convert
 * @param {Object} options - Conversion options
 * @returns {Promise<string>} - Converted text
 */
async function convertAksara(text, { direction = 'toJavanese', withSpace = true, withMurda = true } = {}) {
    try {
        if (!text) throw new Error('Text is required.');
        
        const validDirections = ['toJavanese', 'toLatin'];
        if (!validDirections.includes(direction)) throw new Error(`Invalid 'direction': ${direction}.`);
        
        console.log(`[Translate Handler] Converting to aksara: ${direction}`);
        
        const response = await fetch(AKSARA_JAWA_API, {
            method: 'POST',
            headers: {
                'content-type': 'application/json',
                'referer': 'https://aksarajawa.id/',
                'user-agent': 'Mozilla/5.0'
            },
            body: JSON.stringify({
                text: text.trim(),
                direction: direction,
                options: {
                    withSpace: withSpace,
                    withMurda: withMurda,
                    typeMode: true
                }
            })
        });
        
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status}`);
        }
        
        const data = await response.json();
        return data.result;
    } catch (error) {
        console.error('[Translate Handler] Aksara error:', error.message);
        throw new Error(error.message);
    }
}

/**
 * Translate Indonesia ke Bahasa Sunda
 * @param {string} text - Text to translate
 * @returns {Promise<string>} - Translated text
 */
async function translateSunda(text) {
    try {
        if (!text) throw new Error('Text is required.');
        
        console.log('[Translate Handler] Translating to Sunda');
        
        const params = new URLSearchParams({
            from_lang: 'id_ID',
            to: 'su_ID',
            text: text.trim(),
            platform: 'dp'
        });
        
        const response = await fetch(SUNDA_API, {
            method: 'POST',
            headers: {
                'Host': 'lingvanex.com',
                'User-Agent': 'Mozilla/5.0',
                'Accept': 'application/json, text/javascript, */*; q=0.01',
                'Accept-Language': 'id,en-US;q=0.7,en;q=0.3',
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'X-Requested-With': 'XMLHttpRequest',
                'Origin': 'https://lingvanex.com',
                'Referer': 'https://lingvanex.com/translation/indonesia-ke-bahasa-sunda',
                'Connection': 'keep-alive'
            },
            body: params.toString()
        });
        
        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status}`);
        }
        
        const data = await response.json();
        return data.result;
    } catch (error) {
        console.error('[Translate Handler] Sunda error:', error.message);
        throw new Error(error.message);
    }
}

// ========== FORMAT FUNCTIONS ==========

/**
 * Generate help message
 * @param {string} prefix - Command prefix
 * @returns {string} - Help message
 */
function generateUsageHelp(prefix) {
    return `*🌏 TRANSLATE JAWA & SUNDA*

📌 *Available Commands:*

*1. Krama Alus (Halus):*
${prefix}krama <text>
Atau reply pesan: ${prefix}krama

*2. Krama Lugu (Madya):*
${prefix}lugu <text>
Atau reply pesan: ${prefix}lugu

*3. Ngoko (Kasar):*
${prefix}ngoko <text>
Atau reply pesan: ${prefix}ngoko

*4. Aksara Jawa:*
${prefix}aksara <text>
Atau reply pesan: ${prefix}aksara

*5. Bahasa Sunda:*
${prefix}sunda <text>
Atau reply pesan: ${prefix}sunda

💡 *Cara Pakai Reply:*
Reply sebuah pesan lalu ketik command
Contoh: Reply "Selamat pagi" → ketik .krama

📝 *Contoh Langsung:*
${prefix}krama Selamat pagi, apa kabar?
${prefix}aksara Sugeng enjing
${prefix}sunda Selamat pagi semua

💡 *Tips:*
- Krama Alus: Bahasa paling sopan
- Krama Lugu: Bahasa sopan standar
- Ngoko: Bahasa sehari-hari
- Aksara: Latin → Aksara Jawa
- Sunda: Indonesia → Sunda
`;
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, command, args, usedPrefix }) => {
    let prefix = usedPrefix || '.';
    
    try {
        // Get text from args
        let text = args.join(' ').trim();
        
        // ========== EXTRACT TEXT FROM REPLY ==========
        // Extract raw message & context
        let rawMessage = m.message;
        let contextInfo = null;
        let quotedMessage = null;
        
        if (rawMessage) {
            if (rawMessage.extendedTextMessage) {
                contextInfo = rawMessage.extendedTextMessage.contextInfo;
            } else if (rawMessage.imageMessage) {
                contextInfo = rawMessage.imageMessage.contextInfo;
            } else if (rawMessage.videoMessage) {
                contextInfo = rawMessage.videoMessage.contextInfo;
            }
            
            if (contextInfo) {
                quotedMessage = contextInfo.quotedMessage;
            }
        }
        
        // Check if replying to a message and extract text
        if (!text) {
            // Check 1: From quoted message in contextInfo
            if (quotedMessage?.conversation) {
                text = quotedMessage.conversation;
            } else if (quotedMessage?.extendedTextMessage?.text) {
                text = quotedMessage.extendedTextMessage.text;
            }
            // Check 2: Fallback to m.quoted
            else if (m.quoted?.text) {
                text = m.quoted.text;
            }
        }
        
        // Cek help command
        if (!text || text.toLowerCase() === 'help' || text === '?') {
            return m.reply(generateUsageHelp(prefix));
        }
        
        // React dengan emoji loading
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        let result;
        let emoji;
        let label;
        
        console.log(`[Translate Handler] Processing command: ${command}`);
        
        switch (command) {
            case 'krama':
                result = await translateJawa(text, { to: 'krama-alus' });
                emoji = '🎭';
                label = 'Krama Alus';
                break;
                
            case 'lugu':
                result = await translateJawa(text, { to: 'krama-lugu' });
                emoji = '📝';
                label = 'Krama Lugu';
                break;
                
            case 'ngoko':
                result = await translateJawa(text, { to: 'ngoko' });
                emoji = '💬';
                label = 'Ngoko';
                break;
                
            case 'aksara':
                result = await convertAksara(text);
                emoji = '✍️';
                label = 'Aksara Jawa';
                break;
                
            case 'sunda':
                result = await translateSunda(text);
                emoji = '🏔️';
                label = 'Bahasa Sunda';
                break;
                
            default:
                result = await translateJawa(text);
                emoji = '🎭';
                label = 'Krama Alus';
                break;
        }
        
        // Send result (langsung result saja tanpa format)
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        return m.reply(result);
        
    } catch (error) {
        console.error('[Translate Handler] CRITICAL ERROR:', error.message);
        console.error('[Translate Handler] Stack:', error.stack);
        
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        
        const msg = error.message || 'Unknown error';
        return m.reply(`❌ *Terjadi error:*\n\`\`\`\n${msg}\n\`\`\`\n\n💡 Ketik ${usedPrefix || '.'}${command} help untuk bantuan`);
    }
};

// ========== HANDLER PROPERTIES ==========
handler.help = ['krama', 'lugu', 'ngoko', 'aksara', 'sunda'];
handler.tags = ['tools'];
handler.command = ['krama', 'lugu', 'ngoko', 'aksara', 'sunda'];
handler.limit = false;

console.log('[Translate Handler] Handler loaded successfully');

export default handler;