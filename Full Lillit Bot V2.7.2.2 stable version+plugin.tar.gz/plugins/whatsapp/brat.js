import { downloadContentFromMessage } from 'baileys';
import sharp from 'sharp';
import fetch from 'node-fetch';
import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const execPromise = promisify(exec);

console.log('[Brat Handler] Loading handler...');

// ========== CONFIGURATION ==========
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const TEMP_DIR = path.join(__dirname, '../tmp');
const TIMEOUT_MS = 60000; // 60 detik timeout
const DEFAULT_WIDTH = 1080;
const DEFAULT_HEIGHT = 1350;
const API_BASE_URL = 'https://api.deline.web.id';
const API_FALLBACK_URL = 'https://akunv53-brat.hf.space';
const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
const STICKER_TIMEOUT_MS = 45000; // 45 detik untuk konversi sticker

// Pastikan temp directory ada
if (!fs.existsSync(TEMP_DIR)) {
    fs.mkdirSync(TEMP_DIR, { recursive: true });
}

// Brat color palettes (untuk mode lokal)
const BRAT_PALETTES = {
    default: {
        bg: '#000000',
        textColor: '#00ff00',
        strokeColor: '#000000',
        name: 'Classic Brat'
    },
    dark: {
        bg: '#0a0a0a',
        textColor: '#00ff00',
        strokeColor: '#00ff00',
        name: 'Dark Mode'
    },
    light: {
        bg: '#ffffff',
        textColor: '#00ff00',
        strokeColor: '#000000',
        name: 'Light Mode'
    },
    pink: {
        bg: '#1a0a1a',
        textColor: '#ff00ff',
        strokeColor: '#ff00ff',
        name: 'Pink Brat'
    },
    purple: {
        bg: '#0a0a1a',
        textColor: '#00ffff',
        strokeColor: '#ff00ff',
        name: 'Purple Neon'
    },
    retro: {
        bg: '#2a2a2a',
        textColor: '#ffff00',
        strokeColor: '#000000',
        name: 'Retro 80s'
    }
};

/**
 * Generate random colorful gradient background
 * @returns {string} - SVG gradient definition
 */
function generateRandomGradient() {
    const colors = [
        ['#FF0080', '#7928CA', '#0070F3'],
        ['#F213A4', '#5551FF', '#00D4FF'],
        ['#FF416C', '#FF4B2B', '#FFD700'],
        ['#8E2DE2', '#4A00E0', '#00F5FF'],
        ['#FF00CC', '#333399', '#00FFFF'],
        ['#E100FF', '#7F00FF', '#00FFE0'],
        ['#FF0099', '#493240', '#00D9FF'],
        ['#FC466B', '#3F5EFB', '#00FFA3'],
        ['#FE0000', '#FF6B00', '#FFD700'],
        ['#00F260', '#0575E6', '#8E2DE2']
    ];
    
    const randomColors = colors[Math.floor(Math.random() * colors.length)];
    const rotation = Math.floor(Math.random() * 360);
    
    return {
        colors: randomColors,
        rotation: rotation
    };
}

// ========== STICKER CONVERSION FUNCTION ==========
/**
 * Convert image/video buffer to sticker
 * @param {Buffer} mediaBuffer - Media buffer to convert
 * @param {Object} options - Conversion options
 * @returns {Object} - {success: boolean, buffer: Buffer, size: number, message: string}
 */
async function convertToSticker(mediaBuffer, options = {}) {
    const {
        packname = 'Brat Aesthetic',
        author = 'Bot',
        isVideo = false
    } = options;

    const tempInputPath = path.join(TEMP_DIR, `brat_input_${Date.now()}.${isVideo ? 'mp4' : 'png'}`);
    const tempOutputPath = path.join(TEMP_DIR, `brat_sticker_${Date.now()}.webp`);
    
    try {
        if (mediaBuffer.length > MAX_FILE_SIZE) {
            throw new Error('File terlalu besar! Max ' + (MAX_FILE_SIZE / 1024 / 1024) + 'MB');
        }
        
        console.log('[Brat Handler] Converting to sticker...');
        fs.writeFileSync(tempInputPath, mediaBuffer);
        
        let ffmpegCmd;
        
        if (isVideo) {
            // Video ke Sticker Animasi (Meningkatkan Kualitas Animasi: quality 85, fps 15)
            ffmpegCmd = `ffmpeg -i "${tempInputPath}" -t 10 -vf "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000,setsar=1,format=rgba" -c:v libwebp -lossless 0 -qscale:v 85 -preset default -r 15 -loop 0 -an -vsync 0 -y "${tempOutputPath}"`;
        } else {
            // Gambar ke Sticker Diam (Meningkatkan Kualitas: lossless 1 / qscale 100)
            ffmpegCmd = `ffmpeg -i "${tempInputPath}" -vf "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000,format=rgba" -c:v libwebp -lossless 1 -qscale:v 100 -preset picture -y "${tempOutputPath}"`;
        }
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Timeout setelah ' + STICKER_TIMEOUT_MS + 'ms')), STICKER_TIMEOUT_MS)
        );
        
        const conversionPromise = execPromise(ffmpegCmd);
        
        await Promise.race([conversionPromise, timeoutPromise]);
        
        console.log('[Brat Handler] Sticker conversion complete');
        
        if (!fs.existsSync(tempOutputPath)) {
            throw new Error('File sticker tidak ditemukan setelah konversi');
        }
        
        const stickerBuffer = fs.readFileSync(tempOutputPath);
        const stickerSize = stickerBuffer.length;
        
        console.log('[Brat Handler] Sticker created, size: ' + stickerSize + ' bytes');
        
        // Cleanup
        try {
            fs.unlinkSync(tempInputPath);
            fs.unlinkSync(tempOutputPath);
        } catch (e) {
            console.error('[Brat Handler] Cleanup error:', e.message);
        }
        
        return {
            success: true,
            buffer: stickerBuffer,
            size: stickerSize
        };
        
    } catch (error) {
        console.error('[Brat Handler] Sticker conversion failed:', error.message);
        
        // Cleanup on error
        try {
            if (fs.existsSync(tempInputPath)) fs.unlinkSync(tempInputPath);
            if (fs.existsSync(tempOutputPath)) fs.unlinkSync(tempOutputPath);
        } catch (e) {
            console.error('[Brat Handler] Cleanup error:', e.message);
        }
        
        return {
            success: false,
            message: error.message
        };
    }
}

// ========== API FUNCTIONS ==========
/**
 * Generate brat image menggunakan API
 * @param {string} text - Text untuk brat image
 * @param {boolean} useFallback - Use fallback API if true
 * @returns {Object|null} - {success: boolean, url: string, buffer: Buffer}
 */
async function generateBratAPI(text, useFallback = false) {
    try {
        const baseUrl = useFallback ? API_FALLBACK_URL : API_BASE_URL;
        console.log('[Brat API] Generating brat image:', text, '| API:', baseUrl);
        
        const encodedText = encodeURIComponent(text);
        const apiUrl = `${baseUrl}/maker/brat?text=${encodedText}`;
        
        const response = await fetch(apiUrl, {
            method: 'GET',
            timeout: TIMEOUT_MS
        });
        
        if (!response.ok) {
            throw new Error(`API returned ${response.status}`);
        }
        
        const contentType = response.headers.get('content-type');
        
        // Check if response is JSON or direct image
        if (contentType && contentType.includes('application/json')) {
            const data = await response.json();
            
            if (data.status === 'success' && data.image_url) {
                console.log('[Brat API] Image URL received:', data.image_url);
                
                // Download image
                const imageResponse = await fetch(data.image_url, { timeout: TIMEOUT_MS });
                if (!imageResponse.ok) {
                    throw new Error('Failed to download image');
                }
                
                const buffer = await imageResponse.buffer();
                
                return {
                    success: true,
                    url: data.image_url,
                    buffer: buffer
                };
            } else {
                throw new Error('Invalid API response');
            }
        } else {
            // Direct image response
            console.log('[Brat API] Direct image response received');
            const buffer = await response.buffer();
            
            return {
                success: true,
                url: apiUrl,
                buffer: buffer
            };
        }
        
    } catch (error) {
        console.error('[Brat API] Error:', error.message);
        
        // Try fallback API if not already using it
        if (!useFallback) {
            console.log('[Brat API] Trying fallback API...');
            return await generateBratAPI(text, true);
        }
        
        return null;
    }
}

/**
 * Generate brat video menggunakan API
 * @param {string} text - Text untuk brat video
 * @param {boolean} useFallback - Use fallback API if true
 * @returns {Object|null} - {success: boolean, url: string, buffer: Buffer}
 */
async function generateBratVidAPI(text, useFallback = false) {
    try {
        const baseUrl = useFallback ? API_FALLBACK_URL : API_BASE_URL;
        console.log('[Brat API] Generating brat video:', text, '| API:', baseUrl);
        
        const encodedText = encodeURIComponent(text);
        const apiUrl = `${baseUrl}/maker/bratvid?text=${encodedText}`;
        
        const response = await fetch(apiUrl, {
            method: 'GET',
            timeout: TIMEOUT_MS
        });
        
        if (!response.ok) {
            throw new Error(`API returned ${response.status}`);
        }
        
        const contentType = response.headers.get('content-type');
        
        // Check if response is JSON or direct video
        if (contentType && contentType.includes('application/json')) {
            const data = await response.json();
            
            if (data.status === 'success' && data.video_url) {
                console.log('[Brat API] Video URL received:', data.video_url);
                
                // Download video
                const videoResponse = await fetch(data.video_url, { timeout: TIMEOUT_MS });
                if (!videoResponse.ok) {
                    throw new Error('Failed to download video');
                }
                
                const buffer = await videoResponse.buffer();
                
                return {
                    success: true,
                    url: data.video_url,
                    buffer: buffer
                };
            } else {
                throw new Error('Invalid API response');
            }
        } else {
            // Direct video response
            console.log('[Brat API] Direct video response received');
            const buffer = await response.buffer();
            
            return {
                success: true,
                url: apiUrl,
                buffer: buffer
            };
        }
        
    } catch (error) {
        console.error('[Brat API] Error:', error.message);
        
        // Try fallback API if not already using it
        if (!useFallback) {
            console.log('[Brat API] Trying fallback API...');
            return await generateBratVidAPI(text, true);
        }
        
        return null;
    }
}

/**
 * Generate brat cewek image menggunakan API
 * @param {string} text - Text untuk brat cewek image
 * @returns {Object|null} - {success: boolean, url: string, buffer: Buffer}
 */
async function generateBratCewekAPI(text) {
    try {
        console.log('[Brat API] Generating brat cewek image:', text);
        
        const encodedText = encodeURIComponent(text);
        const apiUrl = `${API_BASE_URL}/maker/cewekbrat?text=${encodedText}`;
        
        const response = await fetch(apiUrl, {
            method: 'GET',
            timeout: TIMEOUT_MS
        });
        
        if (!response.ok) {
            throw new Error(`API returned ${response.status}`);
        }
        
        const contentType = response.headers.get('content-type');
        
        // Check if response is JSON or direct image
        if (contentType && contentType.includes('application/json')) {
            const data = await response.json();
            
            if (data.status === 'success' && data.image_url) {
                console.log('[Brat API] Cewek Image URL received:', data.image_url);
                
                // Download image
                const imageResponse = await fetch(data.image_url, { timeout: TIMEOUT_MS });
                if (!imageResponse.ok) {
                    throw new Error('Failed to download image');
                }
                
                const buffer = await imageResponse.buffer();
                
                return {
                    success: true,
                    url: data.image_url,
                    buffer: buffer
                };
            } else {
                throw new Error('Invalid API response');
            }
        } else {
            // Direct image response
            console.log('[Brat API] Direct cewek image response received');
            const buffer = await response.buffer();
            
            return {
                success: true,
                url: apiUrl,
                buffer: buffer
            };
        }
        
    } catch (error) {
        console.error('[Brat API] Cewek Error:', error.message);
        return null;
    }
}

// ========== DOWNLOAD MEDIA FUNCTION ==========
/**
 * Download media dari Baileys message
 * @param {Object} message - Raw Baileys message object
 * @returns {Buffer|null} - Media buffer atau null jika gagal
 */
async function downloadMedia(message) {
    try {
        const mimeMap = {
            imageMessage: 'image',
            videoMessage: 'video',
            stickerMessage: 'sticker',
            documentMessage: 'document',
            audioMessage: 'audio'
        };

        const msgKeys = Object.keys(message || {});
        if (msgKeys.length === 0) return null;

        const type = msgKeys[0];
        if (!type) return null;

        const m = message[type];
        if (!m) return null;

        const mediaType = mimeMap[type];
        if (!mediaType) return null;

        const stream = await downloadContentFromMessage(m, mediaType);
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        
        return Buffer.concat(chunks);
    } catch (error) {
        console.error('[Brat Handler] Error downloading media:', error);
        return null;
    }
}

// ========== BRAT FILTER FUNCTION (LOCAL) ==========
/**
 * Apply brat filter effect ke gambar (mode lokal)
 * @param {Buffer} imageBuffer - Image buffer
 * @returns {Buffer|null} - Filtered image buffer
 */
async function applyBratFilter(imageBuffer) {
    try {
        console.log('[Brat Handler] Applying brat filter to image');
        
        // Generate random gradient overlay
        const gradient = generateRandomGradient();
        const metadata = await sharp(imageBuffer).metadata();
        const width = metadata.width;
        const height = metadata.height;
        
        // Create gradient SVG overlay
        const gradientSvg = `
        <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
            <defs>
                <linearGradient id="randomGrad" x1="0%" y1="0%" x2="100%" y2="100%" gradientTransform="rotate(${gradient.rotation})">
                    <stop offset="0%" style="stop-color:${gradient.colors[0]};stop-opacity:0.15" />
                    <stop offset="50%" style="stop-color:${gradient.colors[1]};stop-opacity:0.15" />
                    <stop offset="100%" style="stop-color:${gradient.colors[2]};stop-opacity:0.15" />
                </linearGradient>
            </defs>
            <rect width="${width}" height="${height}" fill="url(#randomGrad)"/>
        </svg>`;
        
        const processedImage = await sharp(imageBuffer)
            .modulate({
                saturation: 1.8,
                brightness: 1.1,
                hue: 120
            })
            .clahe({
                width: 8,
                height: 8,
                maxValue: 255
            })
            .linear(1.3, 5)
            .composite([
                {
                    input: Buffer.from(gradientSvg),
                    blend: 'overlay'
                }
            ])
            .toBuffer();
        
        console.log('[Brat Handler] Brat filter applied successfully');
        return processedImage;
    } catch (error) {
        console.error('[Brat Handler] Error applying filter:', error);
        return null;
    }
}

// ========== BRAT FILTER WITH CUSTOM TEXT (LOCAL) ==========
/**
 * Apply brat filter dengan custom text overlay (mode lokal)
 * @param {Buffer} imageBuffer - Image buffer
 * @param {string} customText - Custom text untuk overlay
 * @param {string} paletteType - Color palette type
 * @returns {Buffer|null} - Filtered image dengan text
 */
async function applyBratFilterWithCustomText(imageBuffer, customText = 'BRAT', paletteType = 'default') {
    try {
        console.log('[Brat Handler] Applying brat filter with custom text:', customText, 'palette:', paletteType);
        
        const palette = BRAT_PALETTES[paletteType] || BRAT_PALETTES['default'];
        const metadata = await sharp(imageBuffer).metadata();
        const width = metadata.width;
        const height = metadata.height;
        
        // Generate random gradient
        const gradient = generateRandomGradient();
        
        const escapedText = customText
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
        
        const fontSize = Math.max(60, Math.floor(width / 8));
        
        const textSvg = `
        <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
            <defs>
                <linearGradient id="randomGrad" x1="0%" y1="0%" x2="100%" y2="100%" gradientTransform="rotate(${gradient.rotation})">
                    <stop offset="0%" style="stop-color:${gradient.colors[0]};stop-opacity:0.2" />
                    <stop offset="50%" style="stop-color:${gradient.colors[1]};stop-opacity:0.2" />
                    <stop offset="100%" style="stop-color:${gradient.colors[2]};stop-opacity:0.2" />
                </linearGradient>
                <filter id="glow">
                    <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
                    <feMerge>
                        <feMergeNode in="coloredBlur"/>
                        <feMergeNode in="SourceGraphic"/>
                    </feMerge>
                </filter>
            </defs>
            <rect width="${width}" height="${height}" fill="url(#randomGrad)"/>
            <text x="50%" y="50%" font-size="${fontSize}" font-weight="900" 
                  text-anchor="middle" dominant-baseline="middle"
                  fill="${palette.textColor}" stroke="${palette.strokeColor}" stroke-width="3"
                  font-family="Arial, sans-serif" filter="url(#glow)"
                  opacity="0.8">
                ${escapedText}
            </text>
        </svg>`;
        
        const processedImage = await sharp(imageBuffer)
            .modulate({
                saturation: 1.8,
                brightness: 1.1,
                hue: 120
            })
            .clahe({
                width: 8,
                height: 8,
                maxValue: 255
            })
            .linear(1.3, 5)
            .composite([
                {
                    input: Buffer.from(textSvg),
                    blend: 'overlay'
                }
            ])
            .toBuffer();
        
        console.log('[Brat Handler] Brat filter with custom text applied successfully');
        return processedImage;
    } catch (error) {
        console.error('[Brat Handler] Error applying filter with custom text:', error);
        return null;
    }
}

// ========== FORMAT FUNCTIONS ==========
/**
 * Generate help message
 * @param {string} prefix - Command prefix
 * @param {string} cmd - Command name
 * @returns {string} - Help message
 */
function generateUsageHelp(prefix, cmd) {
    const paletteList = Object.entries(BRAT_PALETTES)
        .map(([key, val]) => `- ${key}: ${val.name}`)
        .join('\n');
    
    return `*🟢 BRAT AESTHETIC GENERATOR*

📌 *Cara Penggunaan:*

*1. Generate Brat Text Sticker (API):*
${prefix}${cmd} HALO DUNIA
${prefix}${cmd} NAMA KAMU
• Output: **Sticker langsung** 🎨

*2. Generate Brat Animated Sticker (API):*
${prefix}bratvid HALO DUNIA
${prefix}bratvid AESTHETIC
• Output: **Animated Sticker** 🎬

*3. Generate Brat Cewek Sticker (API):*
${prefix}bratcewek NARUTO
${prefix}bratcewek KAWAII GIRL
• Output: **Sticker dengan style cewek** 💕

*4. Filter Gambar → Sticker (Local - Basic):*
Reply gambar → ${prefix}${cmd} basic
• Output: **Sticker dengan filter** 🎨

*5. Filter Gambar + Custom Text → Sticker (Local):*
Reply gambar → ${prefix}${cmd} local NAMA KAMU
Reply gambar → ${prefix}${cmd} local TEXT pink
• Output: **Sticker dengan text custom** 🎨

🎨 *Available Palettes (Local Mode):*
${paletteList}

💡 *Fitur:*
- 🌐 API-based brat text generator → **Auto Sticker** ✨
- 🎬 API-based brat video generator → **Animated Sticker** ✨
- 💕 API-based brat cewek generator → **Auto Sticker** ✨
- 🖼️ Local image filter with custom text → **Auto Sticker** ✨
- 🎨 Multiple color palettes (local)
- ⚡ Fast & responsive
- 🔄 Auto fallback API jika primary API down

*Contoh:*
${prefix}${cmd} AESTHETIC
${prefix}bratvid HELLO WORLD
${prefix}bratcewek KAWAII
${prefix}${cmd} local BRAT pink (reply gambar)

*Note:*
- Mode default menggunakan API (tanpa gambar) → hasil **STICKER**
- Mode local filter gambar → hasil **STICKER**
- BratVid menggunakan API → hasil **ANIMATED STICKER**
- BratCewek menggunakan API → hasil **STICKER**
- Semua output adalah STICKER! 🎉
`;
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    let prefix = usedPrefix || '.';
    const cmd = command || 'brat';
    
    try {
        let inputText = '';
        if (text) {
            inputText = text.trim();
        } else if (args && args.length > 0) {
            inputText = args.join(' ').trim();
        }
        
        if (inputText.toLowerCase() === 'help' || inputText === '?') {
            return m.reply(generateUsageHelp(prefix, cmd));
        }
        
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        // ========== BRATCEWEK MODE (API) → STICKER ==========
        if (cmd === 'bratcewek' || cmd === 'bratc' || cmd === 'cewekbrat') {
            console.log('[Brat Handler] BratCewek mode activated → Sticker');
            
            if (!inputText || inputText.length === 0) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                console.error('[Brat Handler] BratCewek error: Text tidak boleh kosong');
                return;
            }
            
            if (inputText.length > 100) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                console.error('[Brat Handler] BratCewek error: Text terlalu panjang (max 100 chars)');
                return;
            }
            
            await conn.sendMessage(m.chat, { react: { text: '💕', key: m.key } });
            const result = await generateBratCewekAPI(inputText);
            
            if (!result || !result.success) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                console.error('[Brat Handler] BratCewek error: Gagal generate image dari API');
                return;
            }
            
            // ========== CONVERT IMAGE TO STICKER ==========
            console.log('[Brat Handler] Converting cewek image to sticker...');
            const stickerResult = await convertToSticker(result.buffer, {
                packname: 'Brat Cewek',
                author: 'Bot',
                isVideo: false
            });
            
            if (!stickerResult.success) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                console.error('[Brat Handler] BratCewek error: Gagal convert ke sticker -', stickerResult.message);
                return;
            }
            
            await conn.sendMessage(m.chat, {
                sticker: stickerResult.buffer,
                mimetype: 'image/webp'
            }, { quoted: m });
            
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            return;
        }
        
        // ========== BRATVID MODE (API) → ANIMATED STICKER ==========
        if (cmd === 'bratvid' || cmd === 'bratv') {
            console.log('[Brat Handler] BratVid mode activated → Animated Sticker');
            
            if (!inputText || inputText.length === 0) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                console.error('[Brat Handler] BratVid error: Text tidak boleh kosong');
                return;
            }
            
            if (inputText.length > 100) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                console.error('[Brat Handler] BratVid error: Text terlalu panjang (max 100 chars)');
                return;
            }
            
            await conn.sendMessage(m.chat, { react: { text: '🎬', key: m.key } });
            const result = await generateBratVidAPI(inputText);
            
            if (!result || !result.success) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                console.error('[Brat Handler] BratVid error: Gagal generate video dari API');
                return;
            }
            
            // ========== CONVERT VIDEO TO ANIMATED STICKER ==========
            console.log('[Brat Handler] Converting video to animated sticker...');
            const stickerResult = await convertToSticker(result.buffer, {
                packname: 'Brat Aesthetic',
                author: 'Bot',
                isVideo: true
            });
            
            if (!stickerResult.success) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                console.error('[Brat Handler] BratVid error: Gagal convert ke animated sticker -', stickerResult.message);
                return;
            }
            
            await conn.sendMessage(m.chat, {
                sticker: stickerResult.buffer,
                mimetype: 'image/webp'
            }, { quoted: m });
            
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            return;
        }
        
        // ========== CHECK IF LOCAL MODE ==========
        const isLocalMode = inputText.toLowerCase().startsWith('local ');
        if (isLocalMode) {
            inputText = inputText.substring(6).trim();
        }
        
        // ========== CHECK IF QUOTED IMAGE (LOCAL FILTER MODE) ==========
        let hasQuotedImage = false;
        let rawMessage = m.message;
        let contextInfo = null;
        let quotedMessage = null;
        
        if (rawMessage) {
            if (rawMessage.extendedTextMessage) {
                contextInfo = rawMessage.extendedTextMessage.contextInfo;
            } else if (rawMessage.imageMessage) {
                hasQuotedImage = true;
            } else if (rawMessage.videoMessage) {
                contextInfo = rawMessage.videoMessage.contextInfo;
            }
            
            if (contextInfo) {
                quotedMessage = contextInfo.quotedMessage;
                if (quotedMessage?.imageMessage) {
                    hasQuotedImage = true;
                }
            }
        }
        
        if (m.quoted?.message?.imageMessage) {
            hasQuotedImage = true;
        }
        
        // ========== LOCAL FILTER MODE (WITH IMAGE) → STICKER ==========
        if (isLocalMode || hasQuotedImage) {
            console.log('[Brat Handler] Local filter mode → Sticker');
            
            let mediaBuffer = null;
            let mime = '';
            
            if (rawMessage?.imageMessage) {
                console.log('[Brat Handler] Processing direct image');
                mime = rawMessage.imageMessage.mimetype || 'image/jpeg';
                mediaBuffer = await downloadMedia(rawMessage);
            } else if (quotedMessage?.imageMessage) {
                console.log('[Brat Handler] Processing quoted image');
                mime = quotedMessage.imageMessage.mimetype || 'image/jpeg';
                mediaBuffer = await downloadMedia(quotedMessage);
            } else if (m.quoted?.message?.imageMessage) {
                console.log('[Brat Handler] Processing from m.quoted');
                mime = m.quoted.message.imageMessage.mimetype || 'image/jpeg';
                mediaBuffer = await downloadMedia(m.quoted.message);
            }
            
            if (!mediaBuffer || !mime) {
                console.error('[Brat Handler] Local mode error: No valid image found');
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return;
            }
            
            if (!/image\/(jpe?g|png|gif|webp)/.test(mime)) {
                console.error('[Brat Handler] Local mode error: Unsupported format -', mime);
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return;
            }
            
            // Parse input
            let filterType = 'text';
            let customText = 'BRAT';
            let paletteType = 'default';
            
            const parts = inputText.split(' ');
            const validPalettes = Object.keys(BRAT_PALETTES);
            const lastPart = parts[parts.length - 1].toLowerCase();
            
            if (validPalettes.includes(lastPart)) {
                paletteType = lastPart;
                inputText = parts.slice(0, -1).join(' ');
            }
            
            const inputLower = inputText.toLowerCase();
            if (inputLower === 'basic') {
                filterType = 'basic';
            } else if (inputText && inputText.length > 0) {
                customText = inputText.toUpperCase();
                filterType = 'text';
            }
            
            await conn.sendMessage(m.chat, { react: { text: '🎨', key: m.key } });
            
            let filteredBuffer;
            
            console.log(`[Brat Handler] Applying ${filterType} filter with palette ${paletteType}`);
            
            if (filterType === 'basic') {
                filteredBuffer = await applyBratFilter(mediaBuffer);
            } else {
                filteredBuffer = await applyBratFilterWithCustomText(mediaBuffer, customText, paletteType);
            }
            
            if (!filteredBuffer) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                console.error('[Brat Handler] Local mode error: Gagal apply brat filter');
                return;
            }
            
            // ========== CONVERT TO STICKER ==========
            console.log('[Brat Handler] Converting filtered image to sticker...');
            const stickerResult = await convertToSticker(filteredBuffer, {
                packname: 'Brat Aesthetic',
                author: 'Bot'
            });
            
            if (!stickerResult.success) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                console.error('[Brat Handler] Local mode error: Gagal convert ke sticker -', stickerResult.message);
                return;
            }
            
            await conn.sendMessage(m.chat, {
                sticker: stickerResult.buffer,
                mimetype: 'image/webp'
            }, { quoted: m });
            
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            return;
        }
        
        // ========== API MODE (DEFAULT - TEXT ONLY) → STICKER ==========
        console.log('[Brat Handler] API mode - generating text image → Sticker');
        
        if (!inputText || inputText.length === 0) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            console.error('[Brat Handler] API mode error: Text tidak boleh kosong');
            return;
        }
        
        if (inputText.length > 100) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            console.error('[Brat Handler] API mode error: Text terlalu panjang (max 100 chars)');
            return;
        }
        
        await conn.sendMessage(m.chat, { react: { text: '🎨', key: m.key } });
        const result = await generateBratAPI(inputText);
        
        if (!result || !result.success) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            console.error('[Brat Handler] API mode error: Gagal generate brat image dari API');
            return;
        }
        
        // ========== CONVERT TO STICKER ==========
        console.log('[Brat Handler] Converting API result to sticker...');
        const stickerResult = await convertToSticker(result.buffer, {
            packname: 'Brat Aesthetic',
            author: 'Bot'
        });
        
        if (!stickerResult.success) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            console.error('[Brat Handler] API mode error: Gagal convert ke sticker -', stickerResult.message);
            return;
        }
        
        await conn.sendMessage(m.chat, {
            sticker: stickerResult.buffer,
            mimetype: 'image/webp'
        }, { quoted: m });
        
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        
    } catch (error) {
        console.error('[Brat Handler] CRITICAL ERROR:', error.message);
        console.error('[Brat Handler] Stack:', error.stack);
        
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
    }
};

// ========== HANDLER PROPERTIES ==========
handler.help = [
    "brat <text> - generate brat sticker via API",
    "brat local <text> - apply brat filter to quoted image → sticker",
    "bratvid <text> - generate animated brat sticker via API",
    "bratcewek <text> - generate brat cewek sticker via API"
];
handler.tags = ["tools"];
handler.command = ["brat", "bratfilter", "brattxt", "bratvid", "bratv", "bratcewek", "bratc", "cewekbrat"];
handler.limit = true;

console.log('[Brat Handler] Handler loaded successfully with full sticker integration');

export default handler;