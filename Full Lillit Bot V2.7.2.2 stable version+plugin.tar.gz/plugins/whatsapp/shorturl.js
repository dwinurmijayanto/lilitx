import fetch from 'node-fetch';

// ========== CONFIGURATION ==========
const CONFIG = {
    zeink: {
        api: 'https://zeinklab.com/api/create',
        baseUrl: 'http://zeink.cc',
        timeout: 15000
    },
    mono: {
        api: 'https://monojson.com/api/short-link',
        timeout: 15000
    }
};

// ========== URL VALIDATION ==========
function isValidUrl(string) {
    try {
        const url = new URL(string);
        return url.protocol === 'http:' || url.protocol === 'https:';
    } catch (_) {
        return false;
    }
}

function extractUrl(text) {
    // Find URL with protocol
    const urlRegex = /(https?:\/\/[^\s|]+)/gi;
    const match = text.match(urlRegex);
    if (match) return match[0].trim();
    
    // Find domain without protocol
    const domainRegex = /([a-zA-Z0-9-]+\.[a-zA-Z]{2,}[^\s|]*)/gi;
    const domainMatch = text.match(domainRegex);
    if (domainMatch) return 'https://' + domainMatch[0].trim();
    
    return null;
}

// ========== PARSE OPTIONS ==========
function parseOptions(text) {
    const options = { service: 'zeink' }; // default service
    const parts = text.split('|').map(p => p.trim());
    
    if (parts.length > 1) {
        if (!parts[1].includes('=')) {
            options.custom_code = parts[1];
        }
        
        parts.forEach((part, idx) => {
            if (idx === 0) return;
            
            const lower = part.toLowerCase();
            
            // Service selection
            if (lower === 'mono' || lower === 'monojson') {
                options.service = 'mono';
            } else if (lower === 'zeink' || lower === 'zeinklab') {
                options.service = 'zeink';
            }
            
            // Zeink options
            if (lower === 'int' || lower === 'intermediate') {
                options.enable_intermediate = true;
            }
            
            if (part.includes('=')) {
                const [key, value] = part.split('=').map(s => s.trim());
                const lowerKey = key.toLowerCase();
                
                if (lowerKey === 'code' || lowerKey === 'custom') {
                    options.custom_code = value;
                } else if (lowerKey === 'delay' || lowerKey === 'redirect') {
                    options.redirect_delay = parseInt(value) || 0;
                } else if (lowerKey === 'pass' || lowerKey === 'password') {
                    options.link_password = value;
                } else if (lowerKey === 'exp' || lowerKey === 'expiration') {
                    options.expiration = value;
                } else if (lowerKey === 'service' || lowerKey === 's') {
                    options.service = value.toLowerCase() === 'mono' ? 'mono' : 'zeink';
                }
            }
        });
    }
    
    return options;
}

// ========== CREATE SHORT URL - MONOJSON ==========
async function createMonoShortUrl(longUrl) {
    try {
        if (!isValidUrl(longUrl)) {
            throw new Error('URL tidak valid');
        }

        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), CONFIG.mono.timeout);

        const response = await fetch(CONFIG.mono.api, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'User-Agent': 'Mozilla/5.0'
            },
            body: JSON.stringify({ url: longUrl }),
            signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        const result = await response.json();

        if (result.shortUrl) {
            return { 
                success: true, 
                url: result.shortUrl,
                slug: result.slug,
                service: 'monojson'
            };
        }
        
        throw new Error('Gagal membuat short URL');

    } catch (error) {
        if (error.name === 'AbortError') {
            return { success: false, message: 'Timeout' };
        }
        return { success: false, message: error.message };
    }
}

// ========== CREATE SHORT URL - ZEINKLAB ==========
async function createZeinkShortUrl(longUrl, options = {}) {
    try {
        if (!isValidUrl(longUrl)) {
            throw new Error('URL tidak valid');
        }

        const payload = { url: longUrl, ...options };
        // Remove service key from payload
        delete payload.service;
        
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), CONFIG.zeink.timeout);

        const response = await fetch(CONFIG.zeink.api, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'User-Agent': 'Mozilla/5.0',
                'Origin': 'https://zeinklab.com',
                'Referer': 'https://zeinklab.com/create'
            },
            body: JSON.stringify(payload),
            signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        let responseText = await response.text();
        
        // Strip PHP warnings
        const jsonMatch = responseText.match(/(\{[\s\S]*\})/);
        if (jsonMatch) {
            responseText = jsonMatch[1];
        }
        
        const result = JSON.parse(responseText);

        if (result.success && result.short_url) {
            let url = result.short_url;
            if (url.startsWith('/')) {
                url = CONFIG.zeink.baseUrl + url;
            } else if (!url.startsWith('http')) {
                url = CONFIG.zeink.baseUrl + '/' + url;
            }
            
            return { 
                success: true, 
                url,
                service: 'zeinklab'
            };
        }
        
        throw new Error(result.message || 'Gagal membuat short URL');

    } catch (error) {
        if (error.name === 'AbortError') {
            return { success: false, message: 'Timeout' };
        }
        return { success: false, message: error.message };
    }
}

// ========== UNIFIED CREATE FUNCTION ==========
async function createShortUrl(longUrl, options = {}) {
    const service = options.service || 'zeink';
    
    if (service === 'mono') {
        return await createMonoShortUrl(longUrl);
    } else {
        return await createZeinkShortUrl(longUrl, options);
    }
}

// ========== HELP MESSAGE ==========
function showHelp(prefix, cmd) {
    return `*🔗 SHORT URL*

*Cara Penggunaan:*
${prefix}${cmd} <url>
${prefix}${cmd} <url> | <code>
${prefix}${cmd} <url> | mono
${prefix}${cmd} <url> | code=<custom> | int | delay=<N>

*Contoh:*
${prefix}${cmd} https://google.com
${prefix}${cmd} github.com | mono
${prefix}${cmd} github.com | repo
${prefix}${cmd} example.com | code=promo | int

*Services:*
• zeink/zeinklab - Default (dengan custom options)
• mono/monojson - Simple & fast

*Options (Zeink only):*
• code - Custom code
• int - Intermediate page
• delay - Redirect delay (detik)
• pass - Password
• exp - Expiration (YYYY-MM-DD)`;
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    try {
        let input = text || (args && args.length > 0 ? args.join(' ') : '');
        input = input.trim();
        
        if (!input || input === 'help' || input === '?') {
            return m.reply(showHelp(usedPrefix || '.', command || 'short'));
        }
        
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        const url = extractUrl(input);
        
        if (!url || !isValidUrl(url)) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ URL tidak valid!\n\nContoh: ${usedPrefix}${command} https://google.com`);
        }
        
        const options = parseOptions(input);
        
        // Create short URL from both services
        const zeinkPromise = createZeinkShortUrl(url, options);
        const monoPromise = createMonoShortUrl(url);
        
        const [zeinkResult, monoResult] = await Promise.allSettled([zeinkPromise, monoPromise]);
        
        let urls = [];
        
        // Zeinklab result
        if (zeinkResult.status === 'fulfilled' && zeinkResult.value.success) {
            urls.push(zeinkResult.value.url);
        }
        
        // Monojson result
        if (monoResult.status === 'fulfilled' && monoResult.value.success) {
            urls.push(monoResult.value.url);
        }
        
        if (urls.length > 0) {
            let message = `✅ Short URL dibuat!\n`;
            urls.forEach(url => {
                message += `🔗 ${url}\n`;
            });
            
            await conn.sendMessage(m.chat, { text: message.trim() }, { quoted: m });
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } else {
            let errorMsg = '❌ Gagal membuat short URL\n';
            if (zeinkResult.status === 'fulfilled' && !zeinkResult.value.success) {
                errorMsg += `Zeink: ${zeinkResult.value.message}\n`;
            }
            if (monoResult.status === 'fulfilled' && !monoResult.value.success) {
                errorMsg += `Mono: ${monoResult.value.message}`;
            }
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(errorMsg.trim());
        }
        
    } catch (error) {
        console.error('[ShortURL] Error:', error.message);
        try {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        } catch {}
        return m.reply(`❌ Error: ${error.message}`);
    }
};

handler.help = ["short <url> - Buat short URL (zeink/mono)"];
handler.tags = ["tools"];
handler.command = ["shorturl", "short", "shortlink", "sl"];
handler.limit = true;

export default handler;