import fetch from 'node-fetch';
import FormData from 'form-data';
import { Readable } from 'stream';
import { downloadContentFromMessage } from 'baileys';

// ========== DOWNLOAD MEDIA FUNCTION ==========
/**
 * Download media dari Baileys message
 * @param {Object} message - Raw Baileys message object
 * @returns {Buffer|null} - Media buffer atau null jika gagal
 */
async function downloadMedia(message) {
    try {
        const mimeMap = {
            imageMessage: 'image',
            videoMessage: 'video',
            stickerMessage: 'sticker',
            documentMessage: 'document',
            audioMessage: 'audio'
        };

        const msgKeys = Object.keys(message || {});
        if (msgKeys.length === 0) return null;

        const type = msgKeys[0];
        if (!type) return null;

        const m = message[type];
        if (!m) return null;

        const mediaType = mimeMap[type];
        if (!mediaType) return null;

        // Download media menggunakan Baileys
        const stream = await downloadContentFromMessage(m, mediaType);
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        
        return Buffer.concat(chunks);
    } catch (error) {
        console.error('[Vocal Remover] Error downloading media:', error);
        return null;
    }
}

/**
 * Upload audio file untuk diproses
 * @param {Buffer} audioBuffer - Buffer audio file
 * @param {string} filename - Nama file
 * @returns {Promise<Object>} Response data
 */
async function uploadAudio(audioBuffer, filename) {
    try {
        const form = new FormData();
        
        // Convert buffer ke stream
        const stream = Readable.from(audioBuffer);
        form.append('fileName', stream, { filename: filename });

        const response = await fetch('https://aivocalremover.com/api/v2/FileUpload', {
            method: 'POST',
            headers: {
                ...form.getHeaders(),
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36'
            },
            body: form,
            timeout: 60000 // 60 detik timeout untuk upload
        });

        if (!response.ok) {
            throw new Error(`Upload Error: ${response.status}`);
        }

        const data = await response.json();

        if (!data.file_name) {
            throw new Error('Upload gagal: file_name tidak ditemukan');
        }

        return { success: true, fileName: data.file_name };
    } catch (error) {
        throw new Error(`Gagal upload audio: ${error.message}`);
    }
}

/**
 * Proses pemisahan vocal dan instrumental
 * @param {string} fileName - Nama file yang sudah diupload
 * @returns {Promise<Object>} URL hasil pemisahan
 */
async function processVocalRemoval(fileName) {
    try {
        const body = new URLSearchParams({
            file_name: fileName,
            action: 'watermark_video',
            key: 'X9QXlU9PaCqGWpnP1Q4IzgXoKinMsKvMuMn3RYXnKHFqju8VfScRmLnIGQsJBnbZFdcKyzeCDOcnJ3StBmtT9nDEXJn',
            web: 'web'
        });

        const response = await fetch('https://aivocalremover.com/api/v2/ProcessFile', {
            method: 'POST',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
                'Content-Type': 'application/x-www-form-urlencoded',
                'Origin': 'https://aivocalremover.com',
                'Referer': 'https://aivocalremover.com/'
            },
            body: body,
            timeout: 120000 // 120 detik timeout untuk processing
        });

        if (!response.ok) {
            throw new Error(`Process Error: ${response.status}`);
        }

        const data = await response.json();

        if (!data.instrumental_path && !data.vocal_path) {
            throw new Error('Proses gagal: hasil tidak ditemukan');
        }

        return {
            success: true,
            instrumental: data.instrumental_path || null,
            vocal: data.vocal_path || null
        };
    } catch (error) {
        throw new Error(`Gagal memproses audio: ${error.message}`);
    }
}

/**
 * Download file dari URL
 * @param {string} url - URL file
 * @returns {Promise<Buffer>} Buffer file
 */
async function downloadFile(url) {
    try {
        const response = await fetch(url, {
            timeout: 60000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36'
            }
        });

        if (!response.ok) {
            throw new Error(`Download Error: ${response.status}`);
        }

        return await response.buffer();
    } catch (error) {
        throw new Error(`Gagal download file: ${error.message}`);
    }
}

// Fungsi untuk format waktu sesuai zona Jakarta
function formatJakartaTime(date) {
    return date.toLocaleString('id-ID', { 
        timeZone: 'Asia/Jakarta',
        dateStyle: 'medium',
        timeStyle: 'short'
    });
}

/**
 * Format file size
 * @param {number} bytes - Ukuran dalam bytes
 * @returns {string} Formatted size
 */
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
}

/**
 * Generate help message
 * @param {string} prefix - Prefix command
 * @param {string} cmd - Command name
 * @returns {string} Help message
 */
function generateUsageHelp(prefix, cmd) {
    return `*🎵 VOCAL REMOVER*

📌 *Cara Penggunaan:*

*1. Kirim Audio dengan Caption:*
Kirim file audio/video dengan caption:
${prefix}${cmd}

*2. Reply Audio/Video:*
Reply pesan yang berisi audio/video, lalu ketik:
${prefix}${cmd}

✨ *Fitur:*
• Pisahkan vocal dan musik instrumental
• Support berbagai format audio (mp3, wav, m4a, dll)
• Support video (akan diambil audionya)
• Hasil berkualitas tinggi
• Proses otomatis dengan AI

📝 *Format yang Didukung:*
• Audio: MP3, WAV, M4A, OGG, FLAC
• Video: MP4, MKV, AVI (audio akan diekstrak)

⚙️ *Hasil Output:*
• 🎹 Instrumental (musik tanpa vocal)
• 🎤 Vocal (suara vocal saja)

⏱️ *Waktu Proses:*
• Tergantung durasi audio (1-5 menit)
• Maksimal durasi: 10 menit

⚠️ *Catatan:*
• File maksimal 20MB
• Kualitas hasil tergantung kualitas input
• Proses memerlukan waktu, mohon tunggu
• Gunakan untuk tujuan pribadi/edukasi

💡 *Tips:*
• Gunakan audio dengan kualitas baik
• Hindari audio yang terlalu berisik
• Format MP3 320kbps memberikan hasil terbaik
`;
}

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    // Deteksi prefix
    let prefix = usedPrefix;
    if (!prefix && m.text) {
        const match = m.text.match(/^([.!#/])/);
        prefix = match ? match[1] : '.';
    }
    prefix = prefix || '.';
    
    const cmd = command || 'vocalremover';
    
    try {
        // ========== CEK HELP ==========
        if (text && (text.toLowerCase() === 'help' || text === '?')) {
            return m.reply(generateUsageHelp(prefix, cmd));
        }
        
        // ========== CEK MEDIA ==========
        let mediaBuffer = null;
        let mediaType = null;
        let filename = null;
        let mime = '';
        
        // ========== EXTRACT RAW MESSAGE & CONTEXT INFO ==========
        let rawMessage = m.message;
        let contextInfo = null;
        let quotedMessage = null;
        
        console.log('[Vocal Remover] Extracting media...');
        console.log('[Vocal Remover] Raw message keys:', Object.keys(rawMessage || {}));
        
        // Extract contextInfo berdasarkan tipe message
        if (rawMessage) {
            if (rawMessage.extendedTextMessage) {
                contextInfo = rawMessage.extendedTextMessage.contextInfo;
                console.log('[Vocal Remover] Found extendedTextMessage contextInfo');
            } else if (rawMessage.audioMessage) {
                console.log('[Vocal Remover] Found direct audioMessage');
            } else if (rawMessage.videoMessage) {
                console.log('[Vocal Remover] Found direct videoMessage');
            } else if (rawMessage.documentMessage) {
                console.log('[Vocal Remover] Found direct documentMessage');
            }
            
            // Extract quoted message dari contextInfo
            if (contextInfo) {
                quotedMessage = contextInfo.quotedMessage;
                console.log('[Vocal Remover] Quoted message keys:', Object.keys(quotedMessage || {}));
            }
        }
        
        // Check 1: Direct audio message
        if (rawMessage?.audioMessage) {
            console.log('[Vocal Remover] Processing direct audio');
            mediaType = 'audio';
            mime = rawMessage.audioMessage.mimetype || 'audio/mpeg';
            filename = rawMessage.audioMessage.fileName || `audio_${Date.now()}.mp3`;
            mediaBuffer = await downloadMedia(rawMessage);
        }
        // Check 2: Direct video message
        else if (rawMessage?.videoMessage) {
            console.log('[Vocal Remover] Processing direct video');
            mediaType = 'video';
            mime = rawMessage.videoMessage.mimetype || 'video/mp4';
            filename = rawMessage.videoMessage.fileName || `video_${Date.now()}.mp4`;
            mediaBuffer = await downloadMedia(rawMessage);
        }
        // Check 3: Direct document (audio/video)
        else if (rawMessage?.documentMessage && 
                 (rawMessage.documentMessage.mimetype?.includes('audio') || 
                  rawMessage.documentMessage.mimetype?.includes('video'))) {
            console.log('[Vocal Remover] Processing direct document');
            mediaType = rawMessage.documentMessage.mimetype.includes('audio') ? 'audio' : 'video';
            mime = rawMessage.documentMessage.mimetype;
            filename = rawMessage.documentMessage.fileName || `media_${Date.now()}`;
            mediaBuffer = await downloadMedia(rawMessage);
        }
        // Check 4: Quoted audio (dari raw contextInfo)
        else if (quotedMessage?.audioMessage) {
            console.log('[Vocal Remover] Processing quoted audio');
            mediaType = 'audio';
            mime = quotedMessage.audioMessage.mimetype || 'audio/mpeg';
            filename = quotedMessage.audioMessage.fileName || `audio_${Date.now()}.mp3`;
            mediaBuffer = await downloadMedia(quotedMessage);
        }
        // Check 5: Quoted video (dari raw contextInfo)
        else if (quotedMessage?.videoMessage) {
            console.log('[Vocal Remover] Processing quoted video');
            mediaType = 'video';
            mime = quotedMessage.videoMessage.mimetype || 'video/mp4';
            filename = quotedMessage.videoMessage.fileName || `video_${Date.now()}.mp4`;
            mediaBuffer = await downloadMedia(quotedMessage);
        }
        // Check 6: Quoted document (dari raw contextInfo)
        else if (quotedMessage?.documentMessage && 
                 (quotedMessage.documentMessage.mimetype?.includes('audio') || 
                  quotedMessage.documentMessage.mimetype?.includes('video'))) {
            console.log('[Vocal Remover] Processing quoted document');
            mediaType = quotedMessage.documentMessage.mimetype.includes('audio') ? 'audio' : 'video';
            mime = quotedMessage.documentMessage.mimetype;
            filename = quotedMessage.documentMessage.fileName || `media_${Date.now()}`;
            mediaBuffer = await downloadMedia(quotedMessage);
        }
        // Check 7: Fallback ke m.quoted
        else if (m.quoted?.message?.audioMessage) {
            console.log('[Vocal Remover] Processing from m.quoted audio');
            mediaType = 'audio';
            mime = m.quoted.message.audioMessage.mimetype || 'audio/mpeg';
            filename = m.quoted.message.audioMessage.fileName || `audio_${Date.now()}.mp3`;
            mediaBuffer = await downloadMedia(m.quoted.message);
        }
        else if (m.quoted?.message?.videoMessage) {
            console.log('[Vocal Remover] Processing from m.quoted video');
            mediaType = 'video';
            mime = m.quoted.message.videoMessage.mimetype || 'video/mp4';
            filename = m.quoted.message.videoMessage.fileName || `video_${Date.now()}.mp4`;
            mediaBuffer = await downloadMedia(m.quoted.message);
        }
        else if (m.quoted?.message?.documentMessage && 
                 (m.quoted.message.documentMessage.mimetype?.includes('audio') || 
                  m.quoted.message.documentMessage.mimetype?.includes('video'))) {
            console.log('[Vocal Remover] Processing from m.quoted document');
            mediaType = m.quoted.message.documentMessage.mimetype.includes('audio') ? 'audio' : 'video';
            mime = m.quoted.message.documentMessage.mimetype;
            filename = m.quoted.message.documentMessage.fileName || `media_${Date.now()}`;
            mediaBuffer = await downloadMedia(m.quoted.message);
        }
        
        console.log('[Vocal Remover] Media detection result:');
        console.log('- Media Type:', mediaType);
        console.log('- MIME:', mime);
        console.log('- Filename:', filename);
        console.log('- Buffer size:', mediaBuffer ? mediaBuffer.length : 0);
        
        // Jika tidak ada media, tampilkan help
        if (!mediaType || !mediaBuffer) {
            return m.reply(`❌ Tidak ada audio/video yang terdeteksi!

💡 Cara penggunaan:

*Kirim audio/video dengan caption:*
${prefix}${cmd}

*Atau reply audio/video, lalu ketik:*
${prefix}${cmd}

Ketik ${prefix}${cmd} help untuk info lengkap.`);
        }
        
        // ========== VALIDASI MEDIA ==========
        if (!mediaBuffer || mediaBuffer.length === 0) {
            console.error('[Vocal Remover] Media buffer is empty');
            return m.reply('❌ Gagal mendownload media. Silakan coba lagi.');
        }
        
        // Cek ukuran file (maksimal 20MB)
        const maxSize = 20 * 1024 * 1024; // 20MB
        if (mediaBuffer.length > maxSize) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply(`❌ File terlalu besar!

📊 Ukuran: ${formatFileSize(mediaBuffer.length)}
📊 Maksimal: ${formatFileSize(maxSize)}

💡 Gunakan file yang lebih kecil atau potong durasinya.`);
        }
        
        console.log(`[Vocal Remover] Downloaded ${mediaType}: ${formatFileSize(mediaBuffer.length)}`);
        
        // ========== UPLOAD DAN PROSES ==========
        try {
            await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
            
            // Kirim satu pesan progress saja
            const progressMsg = await m.reply(`⏳ *MEMPROSES VOCAL REMOVER*

📁 File: ${filename}
📊 Ukuran: ${formatFileSize(mediaBuffer.length)}

_Sedang mengupload dan memproses..._
_Mohon tunggu 1-5 menit._`);
            
            // Upload audio
            const { success: uploadSuccess, fileName } = await uploadAudio(mediaBuffer, filename);
            
            if (!uploadSuccess || !fileName) {
                throw new Error('Upload gagal');
            }
            
            console.log(`[Vocal Remover] Uploaded: ${fileName}`);
            
            // Proses pemisahan vocal
            await conn.sendMessage(m.chat, { react: { text: '🎵', key: m.key } });
            
            const { success: processSuccess, instrumental, vocal } = await processVocalRemoval(fileName);
            
            if (!processSuccess) {
                throw new Error('Proses gagal');
            }
            
            console.log(`[Vocal Remover] Processed:`, { instrumental, vocal });
            
            // ========== KIRIM HASIL ==========
            await conn.sendMessage(m.chat, { react: { text: '📤', key: m.key } });
            
            // Download dan kirim instrumental
            if (instrumental) {
                try {
                    const instrumentalBuffer = await downloadFile(instrumental);
                    
                    await conn.sendMessage(m.chat, {
                        audio: instrumentalBuffer,
                        mimetype: 'audio/mpeg',
                        fileName: `instrumental_${filename}`,
                        caption: `🎹 *Instrumental* (Musik tanpa vocal)

⏰ _${formatJakartaTime(new Date())}_`
                    }, { quoted: m });
                    
                    console.log(`[Vocal Remover] Sent instrumental: ${formatFileSize(instrumentalBuffer.length)}`);
                } catch (error) {
                    console.error('[Vocal Remover] Error sending instrumental:', error);
                    m.reply(`❌ Gagal mengirim instrumental.\n📥 Download: ${instrumental}`);
                }
            }
            
            // Download dan kirim vocal
            if (vocal) {
                try {
                    const vocalBuffer = await downloadFile(vocal);
                    
                    await conn.sendMessage(m.chat, {
                        audio: vocalBuffer,
                        mimetype: 'audio/mpeg',
                        fileName: `vocal_${filename}`,
                        caption: `🎤 *Vocal* (Suara vocal saja)

⏰ _${formatJakartaTime(new Date())}_`
                    }, { quoted: m });
                    
                    console.log(`[Vocal Remover] Sent vocal: ${formatFileSize(vocalBuffer.length)}`);
                } catch (error) {
                    console.error('[Vocal Remover] Error sending vocal:', error);
                    m.reply(`❌ Gagal mengirim vocal.\n📥 Download: ${vocal}`);
                }
            }
            
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            
        } catch (error) {
            console.error('[Vocal Remover] Error processing:', error);
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            
            let errorMsg = `❌ Terjadi kesalahan saat memproses audio.

📋 Error: ${error.message}

💡 Kemungkinan penyebab:
• Server sedang sibuk, coba lagi nanti
• Format audio tidak didukung
• Durasi audio terlalu panjang (maks 10 menit)
• Koneksi internet tidak stabil

Silakan coba lagi dengan file yang berbeda.`;
            
            m.reply(errorMsg);
        }
        
    } catch (error) {
        console.error('[Vocal Remover] CRITICAL ERROR:', error.message);
        console.error('[Vocal Remover] Stack:', error.stack);
        
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        
        return m.reply(`❌ Terjadi kesalahan sistem.
💡 Ketik ${prefix}${cmd} help untuk bantuan.`);
    }
};

handler.help = ["vocalremover", "removevocal", "splitaudio"];
handler.tags = ["tools"];
handler.command = ["vocalremover", "removevocal", "splitaudio", "pisahvocal", "vocalremove"];
handler.limit = true; // Batasi penggunaan karena proses berat

export default handler;