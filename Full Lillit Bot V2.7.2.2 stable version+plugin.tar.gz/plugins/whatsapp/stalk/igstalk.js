const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

// Cache untuk menghindari API call berulang
const cache = new Map();
const CACHE_TTL = 10 * 60 * 1000; // 10 menit

function getCachedData(key) {
    const cached = cache.get(key);
    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
        console.log('💾 Cache hit:', key);
        return cached.data;
    }
    if (cached) cache.delete(key);
    return null;
}

function setCachedData(key, data) {
    cache.set(key, { data, timestamp: Date.now() });
    // Auto cleanup cache jika terlalu besar
    if (cache.size > 50) {
        const firstKey = cache.keys().next().value;
        cache.delete(firstKey);
    }
}

async function igstalk(username) {
    try {
        if (!username) throw new Error('Username required');
        
        // Normalize username (remove @ if present)
        username = username.replace('@', '').trim().toLowerCase();
        
        // Check cache first
        const cached = getCachedData(`stalk_${username}`);
        if (cached) return cached;
        
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 15000);
        
        const response = await fetch(
            'https://api.boostfluence.com/api/instagram-profile-v2',
            {
                method: 'POST',
                signal: controller.signal,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10)',
                    'Content-Type': 'application/json',
                    'origin': 'https://www.boostfluence.com',
                    'referer': 'https://www.boostfluence.com/'
                },
                body: JSON.stringify({ username })
            }
        );
        
        clearTimeout(timeout);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        
        const data = await response.json();
        
        if (!data || !data.username) {
            throw new Error('Invalid response or user not found');
        }
        
        // Cache result
        setCachedData(`stalk_${username}`, data);
        
        return data;
        
    } catch (error) {
        console.error('❌ igstalk error:', error.message);
        return { status: 'error', msg: error.message };
    }
}

function formatNumber(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
}

let processingUsers = new Set(); // Anti-spam per user

let handler = async (m, { conn, args, usedPrefix, command }) => {
    const userId = m.sender;
    
    // Anti-spam check
    if (processingUsers.has(userId)) {
        return m.reply('⏳ Mohon tunggu, request sebelumnya masih diproses...');
    }
    
    const username = args && args.length > 0 ? args[0].trim() : '';
    
    if (!username) {
        let prefix = usedPrefix || '.';
        const cmd = command || 'igstalk';
        
        return m.reply(`╭─❒ *Instagram Stalker* ❒
│
│ 🔍 *Command:*
│ ${prefix}${cmd} <username>
│
│ 📌 *Examples:*
│ ${prefix}${cmd} instagram
│ ${prefix}${cmd} @instagram
│
│ ✨ *Features:*
│ • 👤 Profile Info
│ • 📊 Statistics
│ • 🖼️ Profile Picture HD
│ • ✅ Verification Status
│ • 🔒 Privacy Status
│ • 💾 Smart Caching (10m)
│ • 🚀 Fast Response
│ • 🛡️ Anti-Spam
│
╰─────────────────❒`);
    }
    
    // Set processing flag
    processingUsers.add(userId);
    
    try {
        // React: Searching
        await conn.sendMessage(m.chat, {
            react: { text: '🔍', key: m.key }
        });
        
        const startTime = Date.now();
        const result = await igstalk(username);
        const fetchTime = Date.now() - startTime;
        
        if (result.status === 'error') {
            await conn.sendMessage(m.chat, {
                react: { text: '❌', key: m.key }
            });
            return m.reply(`❌ *Stalk Failed*\n\n*Error:* ${result.msg}\n\n💡 *Tips:*\n• Check username spelling\n• User might not exist\n• Try again later`);
        }
        
        const {
            username: igUsername,
            full_name,
            biography,
            follower_count,
            following_count,
            media_count,
            profile_pic_url,
            profile_pic_url_hd,
            is_verified,
            is_private,
            external_url,
            category
        } = result;
        
        // Build caption
        const caption = `╭─❒ *Instagram Profile* ❒
│
│ 👤 *Username:* @${igUsername}
│ 📝 *Name:* ${full_name || '-'}
│ ${is_verified ? '✅ *Verified Account*' : ''}
│ ${is_private ? '🔒 *Private Account*' : '🔓 *Public Account*'}
│
│ 📊 *Statistics:*
│ • Followers: ${formatNumber(follower_count)}
│ • Following: ${formatNumber(following_count)}
│ • Posts: ${formatNumber(media_count)}
│
${biography ? `│ 📖 *Bio:*\n│ ${biography.split('\n').join('\n│ ')}\n│\n` : ''}${external_url ? `│ 🔗 *Link:* ${external_url}\n│\n` : ''}${category ? `│ 🏷️ *Category:* ${category}\n│\n` : ''}│ ⚡ *Fetch Time:* ${fetchTime}ms
│
╰─────────────────❒`;
        
        // Send profile picture HD
        try {
            const picUrl = profile_pic_url_hd || profile_pic_url;
            
            if (picUrl) {
                await conn.sendMessage(m.chat, {
                    image: { url: picUrl },
                    caption: caption
                }, { quoted: m });
                
                // React: Success
                await conn.sendMessage(m.chat, {
                    react: { text: '✅', key: m.key }
                });
            } else {
                // Send text only if no profile pic
                await m.reply(caption);
                await conn.sendMessage(m.chat, {
                    react: { text: '⚠️', key: m.key }
                });
            }
            
        } catch (sendError) {
            console.error('❌ Failed to send profile pic:', sendError.message);
            // Fallback to text only
            await m.reply(caption);
            await conn.sendMessage(m.chat, {
                react: { text: '⚠️', key: m.key }
            });
        }
        
    } catch (error) {
        console.error('Error in igstalk handler:', error);
        await conn.sendMessage(m.chat, {
            react: { text: '💥', key: m.key }
        });
        m.reply(`❌ *Error Occurred*\n\n\`\`\`${error.message || 'Unknown error'}\`\`\`\n\n💡 Please try again or contact support.`);
    } finally {
        // Remove processing flag
        processingUsers.delete(userId);
    }
};

handler.help = ["igstalk", "instastalk"];
handler.tags = ["tools"];
handler.command = ["igstalk", "instastalk", "stalkig"];
handler.limit = true;
handler.register = false;

export default handler;