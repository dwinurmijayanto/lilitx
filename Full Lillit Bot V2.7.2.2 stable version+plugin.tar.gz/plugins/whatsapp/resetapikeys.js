import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Paths
const failedKeysPath = path.join(__dirname, "../../database/failedKeys.json");
const apiKeysPath = path.join(__dirname, "../../database/apiKeys.json");
const apiKeysStatsPath = path.join(__dirname, "../../database/apiKeysStats.json");


let handler = async (m, { conn, command, args, usedPrefix = '.' }) => {
    try {
        // Cek apakah file exists
        if (!fs.existsSync(failedKeysPath)) {
            fs.writeFileSync(failedKeysPath, JSON.stringify({}));
        }
        if (!fs.existsSync(apiKeysPath)) {
            fs.writeFileSync(apiKeysPath, JSON.stringify([]));
        }
        if (!fs.existsSync(apiKeysStatsPath)) {
            fs.writeFileSync(apiKeysStatsPath, JSON.stringify({}));
        }

        // Load data
        let blacklistedKeys = JSON.parse(fs.readFileSync(failedKeysPath, "utf-8"));
        let apiKeys = JSON.parse(fs.readFileSync(apiKeysPath, "utf-8"));
        let keyStats = JSON.parse(fs.readFileSync(apiKeysStatsPath, "utf-8"));

        const now = Date.now();

        // COMMAND: resetkeys - Reset semua blocked keys
        if (command === "resetkeys" || command === "resetapikeys") {
            const blockedCount = Object.keys(blacklistedKeys).length;
            
            if (blockedCount === 0) {
                return m.reply("✅ Tidak ada API key yang diblokir!");
            }

            // Reset blacklist
            fs.writeFileSync(failedKeysPath, JSON.stringify({}));
            
            return m.reply(`✅ *API Keys Direset!*

📊 Total keys yang di-unblock: ${blockedCount}
🔓 Semua API keys sekarang aktif kembali!

Gunakan .ask untuk mencoba lagi.`);
        }

        // COMMAND: statuskeys - Lihat status semua keys
        else if (command === "statuskeys" || command === "checkkeys") {
            const totalKeys = apiKeys.length;
            const blockedKeys = Object.keys(blacklistedKeys).filter(key => now < blacklistedKeys[key]);
            const activeKeys = totalKeys - blockedKeys.length;

            let response = `📊 *STATUS API KEYS*\n\n`;
            response += `✅ Total Keys: ${totalKeys}\n`;
            response += `🟢 Aktif: ${activeKeys}\n`;
            response += `🔴 Diblokir: ${blockedKeys.length}\n\n`;

            if (blockedKeys.length > 0) {
                response += `🔴 *Keys yang Diblokir:*\n`;
                blockedKeys.forEach((key, i) => {
                    const expiry = blacklistedKeys[key];
                    const remainingTime = Math.ceil((expiry - now) / 1000 / 60);
                    const maskedKey = `${key.substring(0, 10)}...${key.substring(key.length - 4)}`;
                    response += `${i + 1}. ${maskedKey}\n   ⏱️ Unblock dalam: ${remainingTime} menit\n`;
                });
                response += `\n💡 Gunakan .resetkeys untuk unblock semua`;
            }

            return m.reply(response);
        }

        // COMMAND: listkeys - Lihat semua keys dengan stats
        else if (command === "listkeys" || command === "listapikeys") {
            if (apiKeys.length === 0) {
                return m.reply("❌ Tidak ada API keys terdaftar!\n\nGunakan .addkey [key] untuk menambahkan.");
            }

            let response = `📋 *DAFTAR API KEYS*\n\n`;
            
            apiKeys.forEach((key, i) => {
                const maskedKey = `${key.substring(0, 10)}...${key.substring(key.length - 4)}`;
                const stats = keyStats[key] || { usageCount: 0, status: 'active' };
                const isBlocked = blacklistedKeys[key] && now < blacklistedKeys[key];
                const status = isBlocked ? '🔴 BLOCKED' : '🟢 ACTIVE';
                
                response += `${i + 1}. ${maskedKey}\n`;
                response += `   Status: ${status}\n`;
                response += `   Usage: ${stats.usageCount || 0}x\n`;
                
                if (isBlocked) {
                    const remainingTime = Math.ceil((blacklistedKeys[key] - now) / 1000 / 60);
                    response += `   ⏱️ Unblock: ${remainingTime} min\n`;
                }
                response += `\n`;
            });

            response += `\n💡 Commands:\n`;
            response += `• .resetkeys - Unblock semua\n`;
            response += `• .addkey [key] - Tambah key baru\n`;
            response += `• .removekey [index] - Hapus key`;

            return m.reply(response);
        }

        // COMMAND: addkey - Tambah API key baru
        else if (command === "addkey" || command === "addapikey") {
            let newKey = Array.isArray(args) ? args.join(' ') : '';
            
            if (!newKey && m.body) {
                const commandPrefix = usedPrefix + command;
                if (m.body.startsWith(commandPrefix)) {
                    newKey = m.body.slice(commandPrefix.length).trim();
                }
            }

            if (!newKey) {
                return m.reply(`❌ Masukkan API key!\n\nContoh:\n.addkey sk-proj-xxxxx`);
            }

            if (!newKey.startsWith('sk-')) {
                return m.reply(`❌ API key harus dimulai dengan 'sk-'`);
            }

            if (apiKeys.includes(newKey)) {
                return m.reply(`❌ API key sudah terdaftar!`);
            }

            // Add key
            apiKeys.push(newKey);
            fs.writeFileSync(apiKeysPath, JSON.stringify(apiKeys, null, 2));

            // Initialize stats
            keyStats[newKey] = {
                usageCount: 0,
                lastUsed: null,
                dateAdded: new Date().toISOString(),
                status: 'active'
            };
            fs.writeFileSync(apiKeysStatsPath, JSON.stringify(keyStats, null, 2));

            const maskedKey = `${newKey.substring(0, 10)}...${newKey.substring(newKey.length - 4)}`;
            return m.reply(`✅ *API Key Ditambahkan!*

🔑 Key: ${maskedKey}
📊 Total keys: ${apiKeys.length}

Gunakan .listkeys untuk melihat semua keys.`);
        }

        // COMMAND: removekey - Hapus API key
        else if (command === "removekey" || command === "deletekey") {
            let indexStr = Array.isArray(args) ? args[0] : '';
            
            if (!indexStr && m.body) {
                const commandPrefix = usedPrefix + command;
                if (m.body.startsWith(commandPrefix)) {
                    indexStr = m.body.slice(commandPrefix.length).trim();
                }
            }

            if (!indexStr) {
                return m.reply(`❌ Masukkan index key yang ingin dihapus!\n\nGunakan .listkeys untuk melihat index.`);
            }

            const index = parseInt(indexStr) - 1;

            if (isNaN(index) || index < 0 || index >= apiKeys.length) {
                return m.reply(`❌ Index tidak valid! Gunakan .listkeys untuk melihat index yang benar.`);
            }

            const removedKey = apiKeys[index];
            const maskedKey = `${removedKey.substring(0, 10)}...${removedKey.substring(removedKey.length - 4)}`;

            // Remove key
            apiKeys.splice(index, 1);
            fs.writeFileSync(apiKeysPath, JSON.stringify(apiKeys, null, 2));

            // Remove from blacklist if exists
            delete blacklistedKeys[removedKey];
            fs.writeFileSync(failedKeysPath, JSON.stringify(blacklistedKeys, null, 2));

            // Remove stats
            delete keyStats[removedKey];
            fs.writeFileSync(apiKeysStatsPath, JSON.stringify(keyStats, null, 2));

            return m.reply(`✅ *API Key Dihapus!*

🔑 Key: ${maskedKey}
📊 Sisa keys: ${apiKeys.length}`);
        }

        // COMMAND: bulkaddkeys - Tambah banyak keys sekaligus
        else if (command === "bulkaddkeys" || command === "importkeys") {
            let keysText = Array.isArray(args) ? args.join(' ') : '';
            
            if (!keysText && m.body) {
                const commandPrefix = usedPrefix + command;
                if (m.body.startsWith(commandPrefix)) {
                    keysText = m.body.slice(commandPrefix.length).trim();
                }
            }

            if (!keysText) {
                return m.reply(`❌ Masukkan API keys (pisahkan dengan koma atau enter)!

Contoh:
.bulkaddkeys sk-proj-xxx, sk-proj-yyy

Atau:
.bulkaddkeys
sk-proj-xxx
sk-proj-yyy`);
            }

            // Split by comma or newline
            const newKeys = keysText.split(/[,\n]+/).map(k => k.trim()).filter(k => k.length > 0);
            
            let added = 0;
            let skipped = 0;
            let invalid = 0;

            newKeys.forEach(key => {
                if (!key.startsWith('sk-')) {
                    invalid++;
                    return;
                }
                
                if (apiKeys.includes(key)) {
                    skipped++;
                    return;
                }

                apiKeys.push(key);
                keyStats[key] = {
                    usageCount: 0,
                    lastUsed: null,
                    dateAdded: new Date().toISOString(),
                    status: 'active'
                };
                added++;
            });

            if (added > 0) {
                fs.writeFileSync(apiKeysPath, JSON.stringify(apiKeys, null, 2));
                fs.writeFileSync(apiKeysStatsPath, JSON.stringify(keyStats, null, 2));
            }

            let response = `📊 *BULK ADD RESULTS*\n\n`;
            response += `✅ Ditambahkan: ${added}\n`;
            response += `⏭️ Dilewati (duplikat): ${skipped}\n`;
            response += `❌ Invalid: ${invalid}\n`;
            response += `📊 Total keys: ${apiKeys.length}`;

            return m.reply(response);
        }

        // COMMAND: exportkeys - Export semua keys
        else if (command === "exportkeys") {
            if (apiKeys.length === 0) {
                return m.reply("❌ Tidak ada API keys untuk di-export!");
            }

            const exportData = {
                keys: apiKeys,
                stats: keyStats,
                exportDate: new Date().toISOString(),
                totalKeys: apiKeys.length
            };

            const exportJson = JSON.stringify(exportData, null, 2);
            const exportPath = path.join(__dirname, "../database/keys_export.json");
            
            fs.writeFileSync(exportPath, exportJson);

            let response = `✅ *KEYS EXPORTED*\n\n`;
            response += `📊 Total keys: ${apiKeys.length}\n`;
            response += `📁 File: keys_export.json\n\n`;
            response += `Keys:\n`;
            apiKeys.forEach((key, i) => {
                const maskedKey = `${key.substring(0, 10)}...${key.substring(key.length - 4)}`;
                response += `${i + 1}. ${maskedKey}\n`;
            });

            return m.reply(response);
        }

        // COMMAND: clearallkeys - Hapus semua keys (DANGEROUS)
        else if (command === "clearallkeys") {
            if (apiKeys.length === 0) {
                return m.reply("❌ Tidak ada API keys untuk dihapus!");
            }

            const totalKeys = apiKeys.length;

            // Clear all
            fs.writeFileSync(apiKeysPath, JSON.stringify([]));
            fs.writeFileSync(apiKeysStatsPath, JSON.stringify({}));
            fs.writeFileSync(failedKeysPath, JSON.stringify({}));

            return m.reply(`⚠️ *SEMUA KEYS DIHAPUS!*

🗑️ Total keys dihapus: ${totalKeys}

Gunakan .addkey atau .bulkaddkeys untuk menambahkan keys baru.`);
        }

    } catch (e) {
        console.error('Error:', e);
        m.reply(`❌ Terjadi kesalahan!\n\nError: ${e.message}`);
    }
};

handler.help = [
    "resetkeys - Reset/unblock semua API keys",
    "statuskeys - Cek status semua keys",
    "listkeys - Lihat daftar semua keys",
    "addkey [key] - Tambah API key baru",
    "removekey [index] - Hapus API key",
    "bulkaddkeys [keys] - Tambah banyak keys sekaligus",
    "exportkeys - Export semua keys ke file",
    "clearallkeys - Hapus semua keys (HATI-HATI!)"
];

handler.tags = ["tools"];

handler.command = [
    "resetkeys", "resetapikeys",
    "statuskeys", "checkkeys",
    "listkeys", "listapikeys",
    "addkey", "addapikey",
    "removekey", "deletekey",
    "bulkaddkeys", "importkeys",
    "exportkeys",
    "clearallkeys"
];

handler.owner = false;
handler.mods = false;
handler.premium = false;
handler.group = false;
handler.private = false;

export default handler;