import { downloadContentFromMessage } from 'baileys';
import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const execPromise = promisify(exec);

console.log('[Sticker Handler] Loading handler...');

// ========== CONFIGURATION ==========
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const TEMP_DIR = path.join(__dirname, '../tmp');
const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
const TIMEOUT_MS = 45000; // 45 detik timeout

// Pastikan temp directory ada
if (!fs.existsSync(TEMP_DIR)) {
    fs.mkdirSync(TEMP_DIR, { recursive: true });
}

// ========== DOWNLOAD MEDIA FUNCTION ==========
async function downloadMedia(message, type = 'image') {
    try {
        const mimeMap = {
            imageMessage: 'image',
            videoMessage: 'video',
            stickerMessage: 'sticker'
        };

        const msgKeys = Object.keys(message || {});
        if (msgKeys.length === 0) return null;

        const msgType = msgKeys[0];
        if (!msgType) return null;

        const m = message[msgType];
        if (!m) return null;

        const mediaType = mimeMap[msgType];
        if (!mediaType) {
            if (msgType === 'stickerMessage') {
                type = 'sticker';
            } else {
                return null;
            }
        } else {
            type = mediaType;
        }

        console.log(`[Sticker Handler] Downloading ${type}...`);
        
        const stream = await downloadContentFromMessage(m, type);
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        
        const buffer = Buffer.concat(chunks);
        console.log(`[Sticker Handler] Downloaded, size: ${buffer.length} bytes`);
        
        return buffer;
    } catch (error) {
        console.error('[Sticker Handler] Error downloading media:', error);
        return null;
    }
}

// ========== TEXT TO IMAGE FUNCTION ==========
async function textToImage(text, options = {}) {
    const {
        fontSize = 48,
        fontColor = 'white',
        fontFamily = 'DejaVuSans-Bold',
        maxWidth = 450,
        padding = 30,
        lineSpacing = 1.2
    } = options;

    const tempOutputPath = path.join(TEMP_DIR, `text_${Date.now()}.png`);
    
    try {
        console.log('[Sticker Handler] Generating image from text...');
        
        const lines = text.split('\n').filter(line => line.trim().length > 0);
        const lineCount = lines.length;
        
        console.log(`[Sticker Handler] Text lines: ${lineCount}`);
        
        const fontPaths = [
            '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
            '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf',
            '/usr/share/fonts/TTF/DejaVuSans-Bold.ttf',
            '/System/Library/Fonts/Helvetica.ttc',
            'C:\\Windows\\Fonts\\arial.ttf'
        ];
        
        let fontFile = fontPaths[0]; 
        for (const fp of fontPaths) {
            if (fs.existsSync(fp)) {
                fontFile = fp;
                break;
            }
        }
        
        console.log(`[Sticker Handler] Using font: ${fontFile}`);
        
        let drawtextFilters = [];
        const adjustedFontSize = lineCount > 2 ? Math.floor(fontSize * 0.85) : fontSize;
        const lineHeight = adjustedFontSize * lineSpacing;
        
        const totalHeight = lineHeight * lineCount;
        const startY = (512 - totalHeight) / 2;
        
        for (let i = 0; i < lines.length; i++) {
            const line = lines[i].trim();
            
            const escapedLine = line
                .replace(/\\/g, '\\\\')
                .replace(/'/g, "'\\''")
                .replace(/:/g, '\\:');
            
            const yPos = startY + (i * lineHeight);
            
            const drawtextFilter = "drawtext=fontfile='" + fontFile + "':text='" + escapedLine + "':fontcolor=" + fontColor + ":fontsize=" + adjustedFontSize + ":x=(w-text_w)/2:y=" + yPos + ":shadowcolor=black@0.7:shadowx=2:shadowy=2";
            
            drawtextFilters.push(drawtextFilter);
        }
        
        const drawtextChain = drawtextFilters.join(',');
        
        const generateCmd = 'ffmpeg -f lavfi -i "color=c=black@0.0:s=512x512:r=1:d=1,format=rgba" -vf "' + drawtextChain + '" -frames:v 1 -y "' + tempOutputPath + '"';
        
        console.log('[Sticker Handler] FFmpeg command:', generateCmd.substring(0, 150) + '...');
        
        await execPromise(generateCmd, { timeout: TIMEOUT_MS });
        
        console.log('[Sticker Handler] Text image generated');
        
        if (!fs.existsSync(tempOutputPath)) {
            throw new Error('Failed to generate text image');
        }
        
        const imageBuffer = fs.readFileSync(tempOutputPath);
        
        try {
            fs.unlinkSync(tempOutputPath);
        } catch (e) {
            console.error('[Sticker Handler] Cleanup error:', e.message);
        }
        
        return imageBuffer;
        
    } catch (error) {
        console.error('[Sticker Handler] Text to image failed:', error.message);
        
        try {
            if (fs.existsSync(tempOutputPath)) fs.unlinkSync(tempOutputPath);
        } catch (e) {
            console.error('[Sticker Handler] Cleanup error:', e.message);
        }
        
        return null;
    }
}

// ========== CONVERSION FUNCTIONS: STICKER TO IMAGE (WEBP -> PNG) ==========
async function convertStickerToMedia(stickerBuffer, targetFormat = 'png') {
    if (targetFormat !== 'png') {
        throw new Error('Format target tidak didukung. Hanya "png" yang dipertahankan.');
    }

    const tempInputPath = path.join(TEMP_DIR, `sticker_input_${Date.now()}.webp`);
    const tempOutputPath = path.join(TEMP_DIR, `media_output_${Date.now()}.png`);

    try {
        console.log('[Sticker Handler] Writing temp sticker file...');
        fs.writeFileSync(tempInputPath, stickerBuffer);

        console.log(`[Sticker Handler] Converting sticker to PNG...`);

        let ffmpegCmd;

        // Konversi stiker diam/animasi (frame pertama) ke PNG (KUALITAS TERBAIK)
        ffmpegCmd = `ffmpeg -i "${tempInputPath}" -vframes 1 -qscale:v 1 -y "${tempOutputPath}"`;
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Timeout setelah ' + TIMEOUT_MS + 'ms')), TIMEOUT_MS)
        );
        
        const conversionPromise = execPromise(ffmpegCmd);
        await Promise.race([conversionPromise, timeoutPromise]);

        console.log(`[Sticker Handler] Conversion to PNG complete, reading output...`);

        if (!fs.existsSync(tempOutputPath)) {
            throw new Error(`File PNG tidak ditemukan setelah konversi`);
        }

        const mediaBuffer = fs.readFileSync(tempOutputPath);

        console.log(`[Sticker Handler] PNG created, size: ${formatSize(mediaBuffer.length)}`);

        return {
            success: true,
            buffer: mediaBuffer,
            mimetype: 'image/png'
        };

    } catch (error) {
        console.error(`[Sticker Handler] Sticker to PNG failed:`, error.message);
        return {
            success: false,
            message: error.message
        };
    } finally {
        try {
            if (fs.existsSync(tempInputPath)) fs.unlinkSync(tempInputPath);
            if (fs.existsSync(tempOutputPath)) fs.unlinkSync(tempOutputPath);
        } catch (e) {
            console.error('[Sticker Handler] Cleanup error:', e.message);
        }
    }
}

// ========== CONVERSION FUNCTIONS: MEDIA TO STICKER (Gambar/Video -> WEBP) ==========
async function convertToSticker(mediaBuffer, options = {}) {
    const {
        isVideo = false,
        packname = 'Created by',
        author = 'Bot'
    } = options;

    const tempInputPath = path.join(TEMP_DIR, `input_${Date.now()}.${isVideo ? 'mp4' : 'png'}`);
    const tempOutputPath = path.join(TEMP_DIR, `sticker_${Date.now()}.webp`);
    
    try {
        if (mediaBuffer.length > MAX_FILE_SIZE) {
            throw new Error('File terlalu besar! Max ' + (MAX_FILE_SIZE / 1024 / 1024) + 'MB');
        }
        
        console.log('[Sticker Handler] Writing temp file...');
        fs.writeFileSync(tempInputPath, mediaBuffer);
        
        console.log('[Sticker Handler] Converting to sticker...');
        
        let ffmpegCmd;
        
        if (isVideo) {
            // Video ke Sticker Animasi (Meningkatkan Kualitas Animasi: quality 85, fps 15)
            ffmpegCmd = 'ffmpeg -i "' + tempInputPath + '" -t 10 -vf "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000,setsar=1,format=rgba" -c:v libwebp -lossless 0 -qscale:v 85 -preset default -r 15 -loop 0 -an -vsync 0 -y "' + tempOutputPath + '"';
        } else {
            // Gambar ke Sticker Diam (Meningkatkan Kualitas: lossless 1 / qscale 100)
            ffmpegCmd = 'ffmpeg -i "' + tempInputPath + '" -vf "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000,format=rgba" -c:v libwebp -lossless 1 -qscale:v 100 -preset picture -y "' + tempOutputPath + '"';
        }
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Timeout setelah ' + TIMEOUT_MS + 'ms')), TIMEOUT_MS)
        );
        
        const conversionPromise = execPromise(ffmpegCmd);
        
        await Promise.race([conversionPromise, timeoutPromise]);
        
        console.log('[Sticker Handler] Conversion complete, reading output...');
        
        if (!fs.existsSync(tempOutputPath)) {
            throw new Error('File sticker tidak ditemukan setelah konversi');
        }
        
        const stickerBuffer = fs.readFileSync(tempOutputPath);
        const stickerSize = stickerBuffer.length;
        
        console.log('[Sticker Handler] Sticker created, size: ' + stickerSize + ' bytes');
        
        try {
            fs.unlinkSync(tempInputPath);
            fs.unlinkSync(tempOutputPath);
        } catch (e) {
            console.error('[Sticker Handler] Cleanup error:', e.message);
        }
        
        return {
            success: true,
            buffer: stickerBuffer,
            size: stickerSize
        };
        
    } catch (error) {
        console.error('[Sticker Handler] Conversion failed:', error.message);
        
        try {
            if (fs.existsSync(tempInputPath)) fs.unlinkSync(tempInputPath);
            if (fs.existsSync(tempOutputPath)) fs.unlinkSync(tempOutputPath);
        } catch (e) {
            console.error('[Sticker Handler] Cleanup error:', e.message);
        }
        
        return {
            success: false,
            message: error.message
        };
    }
}

// ========== FORMAT FUNCTIONS ==========
function generateUsageHelp(prefix, cmd) {
    const maxSize = MAX_FILE_SIZE / 1024 / 1024;
    return '*🎨 STICKER MAKER*\n\n' +
        '📌 *Cara Penggunaan:*\n\n' +
        '*1. Buat Sticker (Default Command: s)*\n' +
        '• Reply gambar/video → ' + prefix + 's\n' +
        '• Sticker dari Text: ' + prefix + 's [text]\n\n' +
        '*2. Konversi Sticker Balik (WEBP → Gambar) ✨\n' +
        '• **Sticker ke Gambar (PNG):** Reply stiker → ' + prefix + 'toimg\n' +
        '  *(Berlaku untuk stiker diam atau frame pertama stiker animasi)*\n\n' +
        '*3. Custom Metadata:*\n' +
        'Reply media → ' + prefix + 's packname|author\n\n' +
        '📋 *Supported Formats:*\n' +
        '• Input Media: JPG, PNG, WEBP, MP4, MOV\n' +
        '• Output Konversi: PNG (Gambar)\n\n' +
        '⚙️ *Fitur:*\n' +
        '• Konversi Sticker ke Gambar PNG 🔄\n' +
        '• Kualitas stiker diam **dioptimalkan (lossless)** ✨\n' +
        '• Kualitas stiker animasi **ditingkatkan** (FPS 15)\n' +
        '• Sticker dari Text (multi-line, custom size) 📝\n\n' +
        '⚠️ *Batasan:*\n' +
        '• Max file size: ' + maxSize + 'MB\n' +
        '• Video max 10 detik\n\n' +
        '*Contoh Konversi Balik:*\n' +
        'Reply stiker diam/animasi → ' + prefix + 'toimg\n\n' +
        '💡 *Tips:*\n' +
        '• Gunakan size:XX pada command text untuk custom font size.';
}

function formatSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    let prefix = usedPrefix || '.';
    const cmd = command || 's';
    
    try {
        let packname = 'Created by';
        let author = 'Bot';
        let customFontSize = null;
        
        let inputText = '';
        
        // Ambil input text (dengan line breaks)
        if (m.message && m.message.conversation) {
            inputText = m.message.conversation;
        } else if (m.message && m.message.extendedTextMessage && m.message.extendedTextMessage.text) {
            inputText = m.message.extendedTextMessage.text;
        } else if (text) {
            inputText = text;
        } else if (args && args.length > 0) {
            inputText = args.join(' ');
        }
        
        const escapeRegex = (str) => str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const escapedPrefix = escapeRegex(prefix);
        const escapedCmd = escapeRegex(cmd);
        
        const commandPattern = new RegExp('^' + escapedPrefix + escapedCmd + '\\s*', 'i');
        inputText = inputText.replace(commandPattern, '').trim();
        
        if (inputText.toLowerCase().startsWith(cmd.toLowerCase() + ' ')) {
            inputText = inputText.substring(cmd.length).trim();
        } else if (inputText.toLowerCase() === cmd.toLowerCase()) {
            inputText = '';
        }
        
        if (inputText.toLowerCase() === 'help' || inputText === '?') {
            return m.reply(generateUsageHelp(prefix, cmd));
        }
        
        const fontSizeMatch = inputText.match(/(?:^|\s)size:(\d+)(?:\s|$)/i);
        if (fontSizeMatch) {
            customFontSize = parseInt(fontSizeMatch[1]);
            inputText = inputText.replace(/(?:^|\s)size:\d+(?:\s|$)/gi, ' ').trim();
        }
        
        let textForSticker = '';
        if (inputText.includes('|') && !inputText.includes('\n')) {
            const parts = inputText.split('|');
            packname = parts[0].trim() || packname;
            author = parts[1].trim() || author;
        } else if (inputText) {
            textForSticker = inputText;
        }
        
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        let mediaBuffer = null;
        let isVideo = false;
        let mime = '';
        let isFromText = false;
        let isFromSticker = false;
        
        // Cek command adalah STICKER TO IMAGE
        const isStickerToImage = ["toimg", "toimage"].includes(cmd.toLowerCase());
        
        let rawMessage = m.message;
        let contextInfo = null;
        let quotedMessage = null;
        
        if (rawMessage) {
            if (rawMessage.extendedTextMessage) {
                contextInfo = rawMessage.extendedTextMessage.contextInfo;
            } else if (rawMessage.imageMessage || rawMessage.videoMessage || rawMessage.stickerMessage) {
                 contextInfo = rawMessage[Object.keys(rawMessage)[0]].contextInfo;
            }
            if (contextInfo) {
                quotedMessage = contextInfo.quotedMessage;
            }
        }
        
        // ========== GET MEDIA: Cek Quoted/Reply Sticker untuk TOIMG ==========
        let quotedSticker = (m.quoted && m.quoted.message && m.quoted.message.stickerMessage) || (quotedMessage && quotedMessage.stickerMessage);
        
        if (isStickerToImage && quotedSticker) {
            console.log('[Sticker Handler] Processing quoted sticker for PNG conversion');
            mediaBuffer = await downloadMedia({ stickerMessage: quotedSticker }, 'sticker');
            isFromSticker = true;
            isVideo = !!quotedSticker.gifPlayback;
            mime = quotedSticker.mimetype || 'image/webp';
        }
        
        // ========== KONVERSI STICKER KE GAMBAR (TOIMG) ==========
        if (isFromSticker) {
             if (!mediaBuffer) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply('❌ Gagal mengunduh stiker untuk konversi.');
            }

            // Panggil fungsi konversi Stiker ke PNG
            const result = await convertStickerToMedia(mediaBuffer, 'png');

            if (!result.success) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ Gagal mengkonversi stiker ke PNG!\n⚠️ Error: ${result.message}`);
            }

            // Kirim hasil
            await conn.sendMessage(m.chat, { 
                image: result.buffer,
                mimetype: result.mimetype,
                caption: `✅ Konversi Sticker ke Gambar PNG berhasil! (${formatSize(result.buffer.length)})${isVideo ? '\n\n*Catatan:* Jika stiker animasi, hanya frame pertama yang diambil.' : ''}`
            }, { quoted: m });

            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            console.log('[Sticker Handler] Sticker to Image Success!');
            return;
        }

        // ========== GET MEDIA: Cek Gambar/Video untuk Konversi KE STICKER (.s) ==========
        // (Logika download media yang tersisa)
        if (!isFromSticker) {
            if (rawMessage && rawMessage.imageMessage) {
                mediaBuffer = await downloadMedia(rawMessage, 'image');
            } else if (quotedMessage && quotedMessage.imageMessage) {
                mediaBuffer = await downloadMedia(quotedMessage, 'image');
            } else if (m.quoted && m.quoted.message && m.quoted.message.imageMessage) {
                mediaBuffer = await downloadMedia(m.quoted.message, 'image');
            } else if (rawMessage && rawMessage.videoMessage) {
                mediaBuffer = await downloadMedia(rawMessage, 'video');
                isVideo = true;
            } else if (quotedMessage && quotedMessage.videoMessage) {
                mediaBuffer = await downloadMedia(quotedMessage, 'video');
                isVideo = true;
            } else if (m.quoted && m.quoted.message && m.quoted.message.videoMessage) {
                mediaBuffer = await downloadMedia(m.quoted.message, 'video');
                isVideo = true;
            } else if (m.quoted && m.quoted.text) {
                textForSticker = m.quoted.text.trim();
            } else if (quotedMessage && (quotedMessage.conversation || (quotedMessage.extendedTextMessage && quotedMessage.extendedTextMessage.text))) {
                 textForSticker = (quotedMessage.conversation || quotedMessage.extendedTextMessage.text).trim();
            }
        }
        
        // ========== HANDLE TEXT TO STICKER (.s) ==========
        if (!mediaBuffer && textForSticker) {
            if (textForSticker.length > 200) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply('❌ Text terlalu panjang!\n💡 Max 200 karakter untuk sticker text.');
            }
            
            const lineCount = textForSticker.split('\n').length;
            const totalChars = textForSticker.replace(/\n/g, '').length;
            
            let autoFontSize = 48;
            if (customFontSize) {
                autoFontSize = Math.min(Math.max(customFontSize, 16), 72); 
            } else {
                if (totalChars > 100 || lineCount > 4) {
                    autoFontSize = 32;
                } else if (totalChars > 50 || lineCount > 2) {
                    autoFontSize = 40;
                }
            }
            
            const textImageBuffer = await textToImage(textForSticker, {
                fontSize: autoFontSize,
                fontColor: 'white',
                lineSpacing: 1.3
            });
            
            if (!textImageBuffer) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply('❌ Gagal membuat gambar dari text!\n💡 Pastikan FFmpeg terinstall dengan benar.');
            }
            
            mediaBuffer = textImageBuffer;
            isFromText = true;
        }
        
        // Final Check
        if (!mediaBuffer) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply('❌ Tidak ada gambar/video/text/stiker yang di-reply!\n\n💡 Ketik *' + prefix + cmd + ' help* untuk panduan lengkap');
        }
        
        // ========== CONVERT TO STICKER (.s) ==========
        const result = await convertToSticker(mediaBuffer, {
            isVideo,
            packname,
            author
        });
        
        if (!result.success) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            let errorMsg = '❌ Gagal membuat sticker!\n\n';
            if (result.message.includes('FFmpeg')) {
                errorMsg += '⚠️ FFmpeg tidak tersedia di server.';
            } else if (result.message.includes('terlalu besar')) {
                errorMsg += '⚠️ File terlalu besar!\n💡 Max size: ' + (MAX_FILE_SIZE / 1024 / 1024) + 'MB';
            } else {
                errorMsg += '⚠️ Error: ' + result.message;
            }
            return m.reply(errorMsg);
        }
        
        // ========== SEND STICKER (.s) ==========
        try {
            await conn.sendMessage(m.chat, {
                sticker: result.buffer,
                mimetype: 'image/webp'
            }, { quoted: m });
            
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            
        } catch (sendError) {
            console.error('[Sticker Handler] Failed to send:', sendError);
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            return m.reply('❌ Gagal mengirim sticker!\n💡 Coba lagi.');
        }
        
    } catch (error) {
        console.error('[Sticker Handler] CRITICAL ERROR:', error.message);
        
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }).catch(() => {});
        
        return m.reply('❌ Terjadi kesalahan!\n💡 Coba lagi atau ketik ' + (usedPrefix || '.') + (command || 's') + ' help');
    }
};

// ========== HANDLER PROPERTIES ==========
handler.help = [
    "sticker (reply/kirim gambar/video/text)", 
    "s (reply/kirim gambar/video/text)", 
    "toimg (reply sticker)"
];
handler.tags = ["sticker", "converter"];
handler.command = ["s", "sticker", "stiker", "sgif", "stickergif", "toimg", "toimage"];
handler.limit = true;

console.log('[Sticker Handler] Handler loaded successfully');

export default handler;