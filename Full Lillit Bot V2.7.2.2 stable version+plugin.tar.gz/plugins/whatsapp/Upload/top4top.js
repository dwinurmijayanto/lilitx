import fetch from 'node-fetch';
import FormData from 'form-data';
import { downloadContentFromMessage } from 'baileys';
import fs from 'fs';
import { promisify } from 'util';
import { tmpdir } from 'os';
import { join } from 'path';

const writeFile = promisify(fs.writeFile);
const unlink = promisify(fs.unlink);

// ========== DOWNLOAD MEDIA FUNCTION ==========
async function downloadMedia(message) {
    try {
        const mimeMap = {
            imageMessage: 'image',
            videoMessage: 'video',
            documentMessage: 'document',
            audioMessage: 'audio'
        };

        const msgKeys = Object.keys(message || {});
        if (msgKeys.length === 0) return null;

        const type = msgKeys[0];
        if (!type) return null;

        const m = message[type];
        if (!m) return null;

        const mediaType = mimeMap[type];
        if (!mediaType) return null;

        const stream = await downloadContentFromMessage(m, mediaType);
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        
        return Buffer.concat(chunks);
    } catch (error) {
        console.error('[Top4Top] Error downloading media:', error);
        return null;
    }
}

// ========== MEDIA DETECTION FUNCTION ==========
function detectMediaFromMessage(m) {
    console.log('[Top4Top] Detecting media from message...');
    
    let mime = '';
    let filename = '';
    let mediaSource = null;
    
    const rawMessage = m.message;
    
    if (!rawMessage) {
        console.log('[Top4Top] No raw message found');
        return { mime, filename, mediaSource };
    }
    
    console.log('[Top4Top] Raw message keys:', Object.keys(rawMessage));
    
    // Check for direct media in message
    if (rawMessage.imageMessage) {
        console.log('[Top4Top] Found imageMessage');
        mime = rawMessage.imageMessage.mimetype || 'image/jpeg';
        filename = rawMessage.imageMessage.fileName || `image_${Date.now()}.jpg`;
        mediaSource = rawMessage;
    } else if (rawMessage.videoMessage) {
        console.log('[Top4Top] Found videoMessage');
        mime = rawMessage.videoMessage.mimetype || 'video/mp4';
        filename = rawMessage.videoMessage.fileName || `video_${Date.now()}.mp4`;
        mediaSource = rawMessage;
    } else if (rawMessage.documentMessage) {
        console.log('[Top4Top] Found documentMessage');
        mime = rawMessage.documentMessage.mimetype || 'application/octet-stream';
        filename = rawMessage.documentMessage.fileName || `document_${Date.now()}.pdf`;
        mediaSource = rawMessage;
    } else if (rawMessage.audioMessage) {
        console.log('[Top4Top] Found audioMessage');
        mime = rawMessage.audioMessage.mimetype || 'audio/mpeg';
        filename = rawMessage.audioMessage.fileName || `audio_${Date.now()}.mp3`;
        mediaSource = rawMessage;
    } else if (rawMessage.extendedTextMessage) {
        console.log('[Top4Top] Found extendedTextMessage, checking for quoted media');
        const contextInfo = rawMessage.extendedTextMessage.contextInfo;
        const quotedMessage = contextInfo?.quotedMessage;
        
        if (quotedMessage) {
            console.log('[Top4Top] Quoted message keys:', Object.keys(quotedMessage));
            
            if (quotedMessage.imageMessage) {
                console.log('[Top4Top] Found quoted imageMessage');
                mime = quotedMessage.imageMessage.mimetype || 'image/jpeg';
                filename = quotedMessage.imageMessage.fileName || `image_${Date.now()}.jpg`;
                mediaSource = quotedMessage;
            } else if (quotedMessage.videoMessage) {
                console.log('[Top4Top] Found quoted videoMessage');
                mime = quotedMessage.videoMessage.mimetype || 'video/mp4';
                filename = quotedMessage.videoMessage.fileName || `video_${Date.now()}.mp4`;
                mediaSource = quotedMessage;
            } else if (quotedMessage.documentMessage) {
                console.log('[Top4Top] Found quoted documentMessage');
                mime = quotedMessage.documentMessage.mimetype || 'application/octet-stream';
                filename = quotedMessage.documentMessage.fileName || `document_${Date.now()}.pdf`;
                mediaSource = quotedMessage;
            } else if (quotedMessage.audioMessage) {
                console.log('[Top4Top] Found quoted audioMessage');
                mime = quotedMessage.audioMessage.mimetype || 'audio/mpeg';
                filename = quotedMessage.audioMessage.fileName || `audio_${Date.now()}.mp3`;
                mediaSource = quotedMessage;
            }
        }
    }
    
    console.log('[Top4Top] Media detection result:', {
        found: !!mediaSource,
        mime: mime,
        filename: filename
    });
    
    return { mime, filename, mediaSource };
}

async function uploadToTop4Top(filePath) {
    try {
        const form = new FormData();
        form.append('file_0_', fs.createReadStream(filePath), filePath.split('/').pop());
        form.append('submitr', '[ رفع الملفات ]');
        
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 60000);
        
        const response = await fetch('https://top4top.io/index.php', {
            method: 'POST',
            signal: controller.signal,
            headers: {
                ...form.getHeaders(),
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10)',
                'Accept': 'text/html'
            },
            body: form
        });
        
        clearTimeout(timeout);
        
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        
        const html = await response.text();
        
        if (!html) return { status: 'error', msg: 'Empty response' };
        
        const get = (regex) => {
            const match = html.match(regex);
            return match ? match[1] : null;
        };
        
        const result = 
            get(/value="(https:\/\/[a-z]\.top4top\.io\/m_[^"]+)"/) ||
            html.match(/https:\/\/[a-z]\.top4top\.io\/m_[^"]+/)?.[0] ||
            get(/value="(https:\/\/[a-z]\.top4top\.io\/p_[^"]+)"/) ||
            html.match(/https:\/\/[a-z]\.top4top\.io\/p_[^"]+/)?.[0];
        
        const deleteUrl = 
            get(/value="(https:\/\/top4top\.io\/del[^"]+)"/) ||
            html.match(/https:\/\/top4top\.io\/del[^"]+/)?.[0];
        
        if (!result) {
            throw new Error('Upload failed - no result URL');
        }
        
        return {
            status: 'success',
            result,
            delete: deleteUrl
        };
        
    } catch (error) {
        console.error('[Top4Top] Upload error:', error.message);
        return { status: 'error', msg: error.message };
    }
}

function formatFileSize(bytes) {
    if (bytes >= 1024 * 1024 * 1024) {
        return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
    } else if (bytes >= 1024 * 1024) {
        return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
    } else if (bytes >= 1024) {
        return (bytes / 1024).toFixed(2) + ' KB';
    }
    return bytes + ' B';
}

let processingUsers = new Set();

let handler = async (m, { conn, usedPrefix, command }) => {
    const userId = m.sender;
    let prefix = usedPrefix || '.';
    const cmd = command || 'up2';
    
    if (processingUsers.has(userId)) {
        return m.reply('⏳ Tunggu upload sebelumnya...');
    }
    
    // Detect media menggunakan fungsi yang robust
    const detection = detectMediaFromMessage(m);
    
    if (!detection.mediaSource) {
        return m.reply(`*Top4Top Uploader*

Kirim/Reply file yang ingin diupload dengan caption:
${prefix}${cmd}

Support: Gambar, Video, Audio, Dokumen`);
    }
    
    processingUsers.add(userId);
    
    try {
        await conn.sendMessage(m.chat, {
            react: { text: '⏳', key: m.key }
        });
        
        console.log('[Top4Top] Downloading media...');
        const mediaBuffer = await downloadMedia(detection.mediaSource);
        
        if (!mediaBuffer) {
            throw new Error('Gagal download media');
        }
        
        const fileSize = mediaBuffer.length;
        
        if (fileSize > 500 * 1024 * 1024) {
            throw new Error('File terlalu besar (max 500MB)');
        }
        
        let ext = 'bin';
        const mime = detection.mime;
        if (mime.includes('image')) ext = mime.split('/')[1] || 'jpg';
        else if (mime.includes('video')) ext = 'mp4';
        else if (mime.includes('audio')) ext = 'mp3';
        else if (mime.includes('pdf')) ext = 'pdf';
        else if (mime.includes('document')) ext = 'doc';
        
        const tmpFile = join(tmpdir(), `${Date.now()}.${ext}`);
        
        await writeFile(tmpFile, mediaBuffer);
        
        await m.reply(`📤 Uploading ${formatFileSize(fileSize)}...`);
        
        const startTime = Date.now();
        const result = await uploadToTop4Top(tmpFile);
        const uploadTime = ((Date.now() - startTime) / 1000).toFixed(1);
        
        try {
            await unlink(tmpFile);
        } catch (e) {}
        
        if (result.status === 'error') {
            throw new Error(result.msg || 'Upload gagal');
        }
        
        const response = `✅ *Upload Sukses*

📁 Size: ${formatFileSize(fileSize)}
⏱️ Time: ${uploadTime}s

🔗 *Link:*
${result.result}

${result.delete ? `🗑️ *Delete Link:*\n${result.delete}` : ''}`;
        
        await m.reply(response);
        
        await conn.sendMessage(m.chat, {
            react: { text: '✅', key: m.key }
        });
        
    } catch (error) {
        console.error('[Top4Top] Error:', error);
        
        await conn.sendMessage(m.chat, {
            react: { text: '❌', key: m.key }
        });
        
        m.reply(`❌ Error: ${error.message}`);
    } finally {
        processingUsers.delete(userId);
    }
};

handler.help = ["up2"];
handler.tags = ["tools"];
handler.command = ["up2", "upload2", "top4top"];
handler.limit = true;
handler.register = false;

export default handler;