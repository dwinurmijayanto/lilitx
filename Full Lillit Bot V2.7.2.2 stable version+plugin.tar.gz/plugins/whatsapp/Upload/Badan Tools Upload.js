import fetch from 'node-fetch';
import FormData from 'form-data';
import { downloadContentFromMessage } from 'baileys';
import fs from 'fs';
import { promisify } from 'util';
import { tmpdir } from 'os';
import { join } from 'path';

const writeFile = promisify(fs.writeFile);
const unlink = promisify(fs.unlink);

// ========== CONFIGURATION ==========
const TIMEOUT_MS = 30000; // 30 seconds
const UPLOAD_TIMEOUT_MS = 120000; // 2 minutes
const MAX_FILE_SIZE = 500 * 1024 * 1024; // 500MB

// ========== URL VALIDATION & FUNCTIONS ==========
function isValidUrl(string) {
    try {
        const url = new URL(string);
        return url.protocol === 'http:' || url.protocol === 'https:';
    } catch (_) {
        return false;
    }
}

function extractURL(text) {
    if (!text) return null;
    
    const trimmed = text.trim();
    if (isValidUrl(trimmed)) return trimmed;
    
    const urlRegex = /(https?:\/\/[^\s]+)/gi;
    const match = trimmed.match(urlRegex);
    
    return match ? match[0] : null;
}

function getFilenameFromUrl(url, mimetype = null) {
    try {
        const urlObj = new URL(url);
        const pathname = urlObj.pathname;
        const segments = pathname.split('/');
        let filename = segments[segments.length - 1];
        
        if (filename.includes('?')) {
            filename = filename.split('?')[0];
        }
        
        if (!filename || filename === '' || !filename.includes('.')) {
            const ext = getExtensionFromMimetype(mimetype) || 'bin';
            filename = `download_${Date.now()}.${ext}`;
        }
        
        return filename;
    } catch (e) {
        const ext = getExtensionFromMimetype(mimetype) || 'bin';
        return `download_${Date.now()}.${ext}`;
    }
}

function getExtensionFromMimetype(mimetype) {
    if (!mimetype) return 'bin';
    
    const mimeToExt = {
        'image/jpeg': 'jpg',
        'image/jpg': 'jpg',
        'image/png': 'png',
        'image/gif': 'gif',
        'image/webp': 'webp',
        'image/bmp': 'bmp',
        'video/mp4': 'mp4',
        'video/mpeg': 'mpeg',
        'video/quicktime': 'mov',
        'video/x-msvideo': 'avi',
        'video/x-matroska': 'mkv',
        'audio/mpeg': 'mp3',
        'audio/mp3': 'mp3',
        'audio/wav': 'wav',
        'audio/ogg': 'ogg',
        'audio/flac': 'flac',
        'audio/aac': 'aac',
        'application/pdf': 'pdf',
        'application/zip': 'zip',
        'application/x-zip-compressed': 'zip',
        'application/x-rar-compressed': 'rar',
        'text/plain': 'txt',
        'application/msword': 'doc',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx'
    };
    
    return mimeToExt[mimetype] || mimetype.split('/')[1].split(';')[0];
}

// ========== DOWNLOAD FROM URL ==========
async function downloadFromUrl(url) {
    try {
        const downloadPromise = fetch(url, {
            method: 'GET',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': '*/*'
            },
            redirect: 'follow'
        });
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error(`Timeout downloading from URL (${TIMEOUT_MS}ms)`)), TIMEOUT_MS)
        );
        
        const response = await Promise.race([downloadPromise, timeoutPromise]);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const contentType = response.headers.get('content-type') || 'application/octet-stream';
        const contentLength = response.headers.get('content-length');
        
        if (contentLength) {
            const size = parseInt(contentLength);
            if (size > MAX_FILE_SIZE) {
                throw new Error(`File terlalu besar (${(size / 1024 / 1024).toFixed(2)}MB). Maksimal 500MB`);
            }
        }
        
        let filename = '';
        const contentDisposition = response.headers.get('content-disposition');
        if (contentDisposition) {
            const match = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/);
            if (match && match[1]) {
                filename = match[1].replace(/['"]/g, '');
            }
        }
        
        if (!filename) {
            filename = getFilenameFromUrl(url, contentType);
        }
        
        const arrayBuffer = await response.arrayBuffer();
        const buffer = Buffer.from(arrayBuffer);
        
        return {
            buffer: buffer,
            mimetype: contentType,
            filename: filename
        };
    } catch (error) {
        throw error;
    }
}

// ========== DOWNLOAD MEDIA FUNCTION ==========
async function downloadMedia(message) {
    try {
        const mimeMap = {
            imageMessage: 'image',
            videoMessage: 'video',
            documentMessage: 'document',
            audioMessage: 'audio'
        };

        const msgKeys = Object.keys(message || {});
        if (msgKeys.length === 0) return null;

        const type = msgKeys[0];
        if (!type) return null;

        const m = message[type];
        if (!m) return null;

        const mediaType = mimeMap[type];
        if (!mediaType) return null;

        const stream = await downloadContentFromMessage(m, mediaType);
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        
        return Buffer.concat(chunks);
    } catch (error) {
        return null;
    }
}

// ========== MEDIA DETECTION FUNCTION ==========
function detectMediaFromMessage(m) {
    let mime = '';
    let filename = '';
    let mediaSource = null;
    
    const rawMessage = m.message;
    if (!rawMessage) return { mime, filename, mediaSource };
    
    if (rawMessage.imageMessage) {
        mime = rawMessage.imageMessage.mimetype || 'image/jpeg';
        filename = rawMessage.imageMessage.fileName || `image_${Date.now()}.jpg`;
        mediaSource = rawMessage;
    } else if (rawMessage.videoMessage) {
        mime = rawMessage.videoMessage.mimetype || 'video/mp4';
        filename = rawMessage.videoMessage.fileName || `video_${Date.now()}.mp4`;
        mediaSource = rawMessage;
    } else if (rawMessage.documentMessage) {
        mime = rawMessage.documentMessage.mimetype || 'application/octet-stream';
        filename = rawMessage.documentMessage.fileName || `document_${Date.now()}.pdf`;
        mediaSource = rawMessage;
    } else if (rawMessage.audioMessage) {
        mime = rawMessage.audioMessage.mimetype || 'audio/mpeg';
        filename = rawMessage.audioMessage.fileName || `audio_${Date.now()}.mp3`;
        mediaSource = rawMessage;
    } else if (rawMessage.extendedTextMessage) {
        const contextInfo = rawMessage.extendedTextMessage.contextInfo;
        const quotedMessage = contextInfo?.quotedMessage;
        
        if (quotedMessage) {
            if (quotedMessage.imageMessage) {
                mime = quotedMessage.imageMessage.mimetype || 'image/jpeg';
                filename = quotedMessage.imageMessage.fileName || `image_${Date.now()}.jpg`;
                mediaSource = quotedMessage;
            } else if (quotedMessage.videoMessage) {
                mime = quotedMessage.videoMessage.mimetype || 'video/mp4';
                filename = quotedMessage.videoMessage.fileName || `video_${Date.now()}.mp4`;
                mediaSource = quotedMessage;
            } else if (quotedMessage.documentMessage) {
                mime = quotedMessage.documentMessage.mimetype || 'application/octet-stream';
                filename = quotedMessage.documentMessage.fileName || `document_${Date.now()}.pdf`;
                mediaSource = quotedMessage;
            } else if (quotedMessage.audioMessage) {
                mime = quotedMessage.audioMessage.mimetype || 'audio/mpeg';
                filename = quotedMessage.audioMessage.fileName || `audio_${Date.now()}.mp3`;
                mediaSource = quotedMessage;
            }
        }
    }
    
    return { mime, filename, mediaSource };
}

// ========== UPLOAD TO BADAN TOOLS ==========
async function uploadToBadanTools(filePath, filename) {
    try {
        const form = new FormData();
        form.append('uploadedFile', fs.createReadStream(filePath), filename);
        
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), UPLOAD_TIMEOUT_MS);
        
        const response = await fetch('https://badan-tools-web.onrender.com/upload', {
            method: 'POST',
            signal: controller.signal,
            headers: {
                ...form.getHeaders(),
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36',
                'Accept': 'application/json, text/plain, */*'
            },
            body: form
        });
        
        clearTimeout(timeout);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const result = await response.json();
        
        if (result.success) {
            return {
                status: 'success',
                url: result.url,
                metadata: result.metadata || {}
            };
        } else {
            throw new Error(result.message || 'Upload failed');
        }
        
    } catch (error) {
        return { 
            status: 'error', 
            msg: error.message 
        };
    }
}

// ========== FORMAT FILE SIZE ==========
function formatFileSize(bytes) {
    if (bytes >= 1024 * 1024 * 1024) {
        return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
    } else if (bytes >= 1024 * 1024) {
        return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
    } else if (bytes >= 1024) {
        return (bytes / 1024).toFixed(2) + ' KB';
    }
    return bytes + ' B';
}

// ========== FORMAT TIME ==========
function formatJakartaTime(date) {
    return date.toLocaleString('id-ID', { 
        timeZone: 'Asia/Jakarta',
        dateStyle: 'medium',
        timeStyle: 'short'
    });
}

function getWIBTimestamp() {
    const now = new Date();
    return formatJakartaTime(now);
}

// ========== GENERATE HELP ==========
function generateUsageHelp(prefix, cmd) {
    return `*🌐 BADAN TOOLS WEB UPLOADER*

📌 *Cara Penggunaan:*

*1. Upload Media WhatsApp:*
Kirim/Reply media dengan caption:
${prefix}${cmd}

*2. Upload dari URL:* 🆕
${prefix}${cmd} <url>

*Contoh:*
${prefix}${cmd} https://i.imgur.com/example.jpg
${prefix}${cmd} https://cdn.example.com/video.mp4

📋 *Supported Formats:*
• Images: JPG, PNG, GIF, WEBP, BMP
• Videos: MP4, MKV, AVI, MOV
• Audio: MP3, WAV, OGG, FLAC, AAC
• Documents: PDF, DOC, DOCX, TXT, ZIP, RAR

⚙️ *Fitur:*
✅ Upload dari WhatsApp media
✅ Upload dari URL (download otomatis)
✅ Support file hingga 500MB
✅ Timestamp WIB otomatis
✅ Metadata lengkap
✅ Error handling robust

🌐 *Powered by:* Badan Tools Web
📦 *Max Size:* 500MB per file
⏱️ *Timeout:* 2 menit upload

💡 *Tips:*
- Pastikan URL dapat diakses publik
- Format URL harus lengkap (https://)
- File dari URL max 500MB`;
}

// ========== PROCESSING USERS SET ==========
let processingUsers = new Set();

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, usedPrefix, command, text, args }) => {
    const userId = m.sender;
    let prefix = usedPrefix || '.';
    const cmd = command || 'upbadan';
    
    let inputText = '';
    if (text) {
        inputText = text.trim();
    } else if (args && args.length > 0) {
        inputText = args.join(' ').trim();
    }
    
    if (inputText.toLowerCase() === 'help' || inputText === '?') {
        return m.reply(generateUsageHelp(prefix, cmd));
    }
    
    if (processingUsers.has(userId)) {
        return m.reply('⏳ Tunggu upload sebelumnya selesai...');
    }
    
    const urlFromText = extractURL(inputText);
    const detection = !urlFromText ? detectMediaFromMessage(m) : { mediaSource: null };
    
    if (!detection.mediaSource && !urlFromText) {
        return m.reply(generateUsageHelp(prefix, cmd));
    }
    
    processingUsers.add(userId);
    
    try {
        await conn.sendMessage(m.chat, {
            react: { text: '⏳', key: m.key }
        });
        
        let mediaBuffer, mime, filename, fileSize;
        let fromUrl = false;
        
        if (urlFromText) {
            fromUrl = true;
            
            try {
                const urlData = await downloadFromUrl(urlFromText);
                mediaBuffer = urlData.buffer;
                mime = urlData.mimetype;
                filename = urlData.filename;
                fileSize = mediaBuffer.length;
            } catch (error) {
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ Gagal mengunduh dari URL:\n${error.message}\n\n💡 Pastikan URL valid dan file dapat diakses publik.`);
            }
        } else {
            mediaBuffer = await downloadMedia(detection.mediaSource);
            
            if (!mediaBuffer) {
                throw new Error('Gagal mendownload media');
            }
            
            mime = detection.mime;
            filename = detection.filename;
            fileSize = mediaBuffer.length;
        }
        
        if (fileSize > MAX_FILE_SIZE) {
            throw new Error(`File terlalu besar (${formatFileSize(fileSize)})! Maksimal 500MB`);
        }
        
        let ext = getExtensionFromMimetype(mime) || 'bin';
        
        const tmpFile = join(tmpdir(), `badan_${Date.now()}.${ext}`);
        if (!filename) filename = `file_${Date.now()}.${ext}`;
        
        await writeFile(tmpFile, mediaBuffer);
        
        const startTime = Date.now();
        const result = await uploadToBadanTools(tmpFile, filename);
        const uploadTime = ((Date.now() - startTime) / 1000).toFixed(1);
        
        try {
            await unlink(tmpFile);
        } catch (e) {
            // Silent fail
        }
        
        if (result.status === 'error') {
            throw new Error(result.msg || 'Upload gagal');
        }
        
        const response = `✅ *Upload Sukses!*

${fromUrl ? '🔗 *Source:* From URL\n' : ''}📁 *File Info:*
• Nama: ${result.metadata.originalName || filename}
• Size: ${formatFileSize(result.metadata.size || fileSize)}
• Type: ${result.metadata.mimeType || mime}

⏱️ *Upload Time:* ${uploadTime}s
📅 *Timestamp:* ${getWIBTimestamp()}

🔗 *Link:*
${result.url}

🌐 *Server:* Badan Tools Web`;
        
        await m.reply(response);
        
        await conn.sendMessage(m.chat, {
            react: { text: '✅', key: m.key }
        });
        
    } catch (error) {
        await conn.sendMessage(m.chat, {
            react: { text: '❌', key: m.key }
        });
        
        m.reply(`❌ *Upload Gagal*

Error: ${error.message}

💡 Silakan coba lagi atau ketik:
${prefix}${cmd} help`);
    } finally {
        processingUsers.delete(userId);
    }
};

handler.help = ["upbadan", "uploadbadan", "badanup"];
handler.tags = ["tools"];
handler.command = ["upbadan", "uploadbadan", "badanup"];
handler.limit = true;
handler.register = false;

export default handler;