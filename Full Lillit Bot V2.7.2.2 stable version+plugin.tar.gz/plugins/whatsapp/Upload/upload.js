import fetch from 'node-fetch';
import FormData from 'form-data';
import { downloadContentFromMessage } from 'baileys';
import fs from 'fs';
import { promisify } from 'util';
import { tmpdir } from 'os';
import { join } from 'path';
import { v4 as uuidv4 } from 'uuid';

const writeFile = promisify(fs.writeFile);
const unlink = promisify(fs.unlink);

console.log('[Upload Handler] Loading handler with 5 Upload Servers + Videy + URL support integration...');

// ========== TIME FORMATTING FUNCTIONS ==========
function formatJakartaTime(date) {
    return date.toLocaleString('id-ID', { 
        timeZone: 'Asia/Jakarta',
        dateStyle: 'medium',
        timeStyle: 'short'
    });
}

function getWIBTimestamp() {
    const now = new Date();
    return formatJakartaTime(now);
}

// ========== CONFIGURATION ==========
const UPLOAD_SERVERS = {
    hf: {
        url: 'https://ikyy-upload-file.hf.space/upload',
        name: 'Ikky',
        baseUrl: 'https://ikyy-upload-file.hf.space',
        supportedTypes: ['image', 'video', 'audio', 'document']
    },
    tmpfiles: {
        url: 'https://tmpfiles.org/api/v1/upload',
        name: 'TmpFiles',
        supportedTypes: ['image', 'video', 'audio', 'document']
    },
    zynnaa: {
        url: 'https://zynnaa-uploader.hf.space/upload',
        name: 'Zynnaa Uploader',
        baseUrl: 'https://zynnaa-uploader.hf.space',
        supportedTypes: ['image', 'video', 'audio', 'document']
    },
    vbi: {
        url: 'https://upload.vbi1.my.id/index.php',
        name: 'VBI Upload',
        supportedTypes: ['image']
    },
    uguu: {
        url: 'https://uguu.se/upload.php',
        name: 'Uguu.se',
        supportedTypes: ['image', 'video', 'audio', 'document']
    },
    videy: {
        url: 'https://videy.co/api/upload',
        name: 'Videy',
        cdnUrl: 'https://cdn.videy.co/',
        adApiUrl: 'https://ads-api.videy.co/api/ad_type',
        supportedTypes: ['video']
    }
};

const TIMEOUT_MS = 30000;
const UPLOAD_TIMEOUT_MS = 120000;

// ========== URL VALIDATION & DOWNLOAD FUNCTIONS ==========
function isValidUrl(string) {
    try {
        const url = new URL(string);
        return url.protocol === 'http:' || url.protocol === 'https:';
    } catch (_) {
        return false;
    }
}

function getFilenameFromUrl(url, mimetype = null) {
    try {
        const urlObj = new URL(url);
        const pathname = urlObj.pathname;
        const segments = pathname.split('/');
        let filename = segments[segments.length - 1];
        
        if (!filename || filename === '' || !filename.includes('.')) {
            const ext = getExtensionFromMimetype(mimetype) || 'bin';
            filename = `download_${Date.now()}.${ext}`;
        }
        
        return filename;
    } catch (e) {
        const ext = getExtensionFromMimetype(mimetype) || 'bin';
        return `download_${Date.now()}.${ext}`;
    }
}

function getExtensionFromMimetype(mimetype) {
    if (!mimetype) return 'bin';
    
    const mimeToExt = {
        'image/jpeg': 'jpg',
        'image/jpg': 'jpg',
        'image/png': 'png',
        'image/gif': 'gif',
        'image/webp': 'webp',
        'video/mp4': 'mp4',
        'video/avi': 'avi',
        'video/mkv': 'mkv',
        'audio/mpeg': 'mp3',
        'audio/mp3': 'mp3',
        'audio/wav': 'wav',
        'audio/flac': 'flac',
        'application/pdf': 'pdf',
        'application/zip': 'zip',
        'application/x-zip-compressed': 'zip',
        'text/plain': 'txt'
    };
    
    return mimeToExt[mimetype] || mimetype.split('/')[1].split(';')[0];
}

async function downloadFromUrl(url) {
    try {
        console.log('[Upload Handler] Downloading from URL:', url);
        
        const downloadPromise = fetch(url, {
            method: 'GET',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error(`Timeout downloading from URL after ${TIMEOUT_MS}ms`)), TIMEOUT_MS)
        );
        
        const response = await Promise.race([downloadPromise, timeoutPromise]);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const contentType = response.headers.get('content-type') || 'application/octet-stream';
        const contentLength = response.headers.get('content-length');
        
        if (contentLength) {
            const sizeMB = parseInt(contentLength) / (1024 * 1024);
            if (sizeMB > 100) {
                throw new Error(`File terlalu besar (${sizeMB.toFixed(2)}MB). Maksimal 100MB`);
            }
        }
        
        const arrayBuffer = await response.arrayBuffer();
        const buffer = Buffer.from(arrayBuffer);
        
        console.log('[Upload Handler] Downloaded successfully:', {
            size: buffer.length,
            contentType: contentType
        });
        
        return {
            buffer: buffer,
            mimetype: contentType,
            filename: getFilenameFromUrl(url, contentType)
        };
    } catch (error) {
        console.error('[Upload Handler] Error downloading from URL:', error.message);
        throw error;
    }
}

// ========== DOWNLOAD MEDIA FUNCTION ==========
async function downloadMedia(message) {
    try {
        const mimeMap = {
            imageMessage: 'image',
            videoMessage: 'video',
            stickerMessage: 'sticker',
            documentMessage: 'document',
            audioMessage: 'audio'
        };

        const msgKeys = Object.keys(message || {});
        if (msgKeys.length === 0) return null;

        const type = msgKeys[0];
        if (!type) return null;

        const m = message[type];
        if (!m) return null;

        const mediaType = mimeMap[type];
        if (!mediaType) return null;

        const stream = await downloadContentFromMessage(m, mediaType);
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        
        return Buffer.concat(chunks);
    } catch (error) {
        console.error('[Upload Handler] Error downloading media:', error);
        return null;
    }
}

// ========== MEDIA DETECTION FUNCTION ==========
function detectMediaFromMessage(m) {
    console.log('[Upload Handler] Detecting media from message...');
    
    let mediaBuffer = null;
    let mime = '';
    let filename = '';
    let mediaSource = null;
    
    const rawMessage = m.message;
    
    if (!rawMessage) {
        console.log('[Upload Handler] No raw message found');
        return { mediaBuffer, mime, filename, mediaSource };
    }
    
    console.log('[Upload Handler] Raw message keys:', Object.keys(rawMessage));
    
    // Check for direct media in message
    if (rawMessage.imageMessage) {
        console.log('[Upload Handler] Found imageMessage');
        mime = rawMessage.imageMessage.mimetype || 'image/jpeg';
        filename = rawMessage.imageMessage.fileName || `image_${Date.now()}.jpg`;
        mediaSource = rawMessage;
    } else if (rawMessage.videoMessage) {
        console.log('[Upload Handler] Found videoMessage');
        mime = rawMessage.videoMessage.mimetype || 'video/mp4';
        filename = rawMessage.videoMessage.fileName || `video_${Date.now()}.mp4`;
        mediaSource = rawMessage;
    } else if (rawMessage.documentMessage) {
        console.log('[Upload Handler] Found documentMessage');
        mime = rawMessage.documentMessage.mimetype || 'application/octet-stream';
        filename = rawMessage.documentMessage.fileName || `document_${Date.now()}.pdf`;
        mediaSource = rawMessage;
    } else if (rawMessage.audioMessage) {
        console.log('[Upload Handler] Found audioMessage');
        mime = rawMessage.audioMessage.mimetype || 'audio/mpeg';
        filename = rawMessage.audioMessage.fileName || `audio_${Date.now()}.mp3`;
        mediaSource = rawMessage;
    } else if (rawMessage.extendedTextMessage) {
        console.log('[Upload Handler] Found extendedTextMessage, checking for quoted media');
        const contextInfo = rawMessage.extendedTextMessage.contextInfo;
        const quotedMessage = contextInfo?.quotedMessage;
        
        if (quotedMessage) {
            console.log('[Upload Handler] Quoted message keys:', Object.keys(quotedMessage));
            
            if (quotedMessage.imageMessage) {
                console.log('[Upload Handler] Found quoted imageMessage');
                mime = quotedMessage.imageMessage.mimetype || 'image/jpeg';
                filename = quotedMessage.imageMessage.fileName || `image_${Date.now()}.jpg`;
                mediaSource = quotedMessage;
            } else if (quotedMessage.videoMessage) {
                console.log('[Upload Handler] Found quoted videoMessage');
                mime = quotedMessage.videoMessage.mimetype || 'video/mp4';
                filename = quotedMessage.videoMessage.fileName || `video_${Date.now()}.mp4`;
                mediaSource = quotedMessage;
            } else if (quotedMessage.documentMessage) {
                console.log('[Upload Handler] Found quoted documentMessage');
                mime = quotedMessage.documentMessage.mimetype || 'application/octet-stream';
                filename = quotedMessage.documentMessage.fileName || `document_${Date.now()}.pdf`;
                mediaSource = quotedMessage;
            } else if (quotedMessage.audioMessage) {
                console.log('[Upload Handler] Found quoted audioMessage');
                mime = quotedMessage.audioMessage.mimetype || 'audio/mpeg';
                filename = quotedMessage.audioMessage.fileName || `audio_${Date.now()}.mp3`;
                mediaSource = quotedMessage;
            }
        }
    }
    
    // Try m.quoted as fallback
    if (!mediaSource && m.quoted?.message) {
        console.log('[Upload Handler] Trying m.quoted.message');
        const quotedMsg = m.quoted.message;
        console.log('[Upload Handler] m.quoted.message keys:', Object.keys(quotedMsg));
        
        if (quotedMsg.imageMessage) {
            console.log('[Upload Handler] Found m.quoted imageMessage');
            mime = quotedMsg.imageMessage.mimetype || 'image/jpeg';
            filename = quotedMsg.imageMessage.fileName || `image_${Date.now()}.jpg`;
            mediaSource = m.quoted.message;
        } else if (quotedMsg.videoMessage) {
            console.log('[Upload Handler] Found m.quoted videoMessage');
            mime = quotedMsg.videoMessage.mimetype || 'video/mp4';
            filename = quotedMsg.videoMessage.fileName || `video_${Date.now()}.mp4`;
            mediaSource = m.quoted.message;
        } else if (quotedMsg.documentMessage) {
            console.log('[Upload Handler] Found m.quoted documentMessage');
            mime = quotedMsg.documentMessage.mimetype || 'application/octet-stream';
            filename = quotedMsg.documentMessage.fileName || `document_${Date.now()}.pdf`;
            mediaSource = m.quoted.message;
        } else if (quotedMsg.audioMessage) {
            console.log('[Upload Handler] Found m.quoted audioMessage');
            mime = quotedMsg.audioMessage.mimetype || 'audio/mpeg';
            filename = quotedMsg.audioMessage.fileName || `audio_${Date.now()}.mp3`;
            mediaSource = m.quoted.message;
        }
    }
    
    console.log('[Upload Handler] Media detection result:', {
        found: !!mediaSource,
        mime: mime,
        filename: filename
    });
    
    return { mediaBuffer, mime, filename, mediaSource };
}

// ========== VIDEY UPLOAD FUNCTIONS ==========
function generateVisitorId() {
    return uuidv4();
}

async function getAdType() {
    try {
        const url = `${UPLOAD_SERVERS.videy.adApiUrl}?uploader=true&width=1536&ad_group=90`;
        const response = await fetch(url);
        
        if (!response.ok) {
            console.log('[Upload Handler] Videy Ad API failed, continuing without ad data');
            return null;
        }
        
        const data = await response.json();
        console.log('[Upload Handler] Videy Ad type fetched:', data);
        return data;
    } catch (error) {
        console.log('[Upload Handler] Videy Ad API error:', error.message);
        return null;
    }
}

async function uploadToVidey(mediaBuffer, filename = 'video.mp4') {
    try {
        console.log('[Upload Handler] Uploading to Videy, size:', mediaBuffer.length, 'bytes');
        
        const maxSize = 100 * 1024 * 1024;
        if (mediaBuffer.length > maxSize) {
            throw new Error(`File terlalu besar (${(mediaBuffer.length / 1024 / 1024).toFixed(2)}MB). Videy maksimal 100MB`);
        }
        
        const visitorId = generateVisitorId();
        console.log(`[Upload Handler] Generated Videy visitor ID: ${visitorId}`);
        
        await getAdType();
        
        const form = new FormData();
        form.append('file', mediaBuffer, {
            filename: filename,
            contentType: 'video/mp4'
        });
        
        const uploadUrl = `${UPLOAD_SERVERS.videy.url}?visitorId=${visitorId}`;
        console.log(`[Upload Handler] Uploading to Videy: ${uploadUrl}`);
        
        const uploadPromise = fetch(uploadUrl, {
            method: 'POST',
            body: form,
            headers: {
                ...form.getHeaders(),
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error(`Timeout setelah ${UPLOAD_TIMEOUT_MS}ms`)), UPLOAD_TIMEOUT_MS)
        );
        
        const response = await Promise.race([uploadPromise, timeoutPromise]);
        
        if (!response.ok) {
            const errorText = await response.text().catch(() => 'Unknown error');
            throw new Error(`HTTP ${response.status}: ${errorText.substring(0, 200)}`);
        }
        
        const result = await response.json();
        console.log('[Upload Handler] Videy Upload success:', JSON.stringify(result));
        
        if (result && result.id) {
            return {
                success: true,
                server: 'videy',
                data: {
                    original_name: filename,
                    url: `https://videy.co/v/?id=${result.id}`,
                    cdn_url: `${UPLOAD_SERVERS.videy.cdnUrl}${result.id}.mp4`,
                    size_formatted: `${(mediaBuffer.length / 1024).toFixed(2)} KB`,
                    uploaded_at: getWIBTimestamp(),
                    file_id: result.id,
                    file_type: 'video/mp4',
                    visitor_id: visitorId
                }
            };
        } else {
            throw new Error('Upload gagal: Format response tidak valid');
        }
    } catch (error) {
        console.error('[Upload Handler] Videy Upload failed:', error.message);
        return { success: false, message: error.message, server: 'videy' };
    }
}

// ========== UPLOAD FUNCTIONS ==========
async function uploadToUguu(mediaBuffer, filename = 'file.jpg', mimetype = 'image/jpeg') {
    let tempPath = null;
    try {
        console.log('[Upload Handler] Uploading to Uguu.se, size:', mediaBuffer.length, 'bytes');
        
        const maxSize = 100 * 1024 * 1024;
        if (mediaBuffer.length > maxSize) {
            throw new Error(`File terlalu besar (${(mediaBuffer.length / 1024 / 1024).toFixed(2)}MB). Maksimal 100MB`);
        }

        tempPath = join(tmpdir(), `uguu_${Date.now()}_${filename}`);
        await writeFile(tempPath, mediaBuffer);
        await new Promise(resolve => setTimeout(resolve, 100));
        
        const form = new FormData();
        form.append('files[]', fs.createReadStream(tempPath), {
            filename: filename,
            contentType: mimetype
        });
        
        const uploadPromise = fetch(UPLOAD_SERVERS.uguu.url, {
            method: 'POST',
            body: form,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                ...form.getHeaders()
            }
        });
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error(`Timeout setelah ${TIMEOUT_MS}ms`)), TIMEOUT_MS)
        );
        
        const response = await Promise.race([uploadPromise, timeoutPromise]);
        
        if (!response.ok) {
            const errorText = await response.text().catch(() => 'Unknown error');
            throw new Error(`HTTP ${response.status}: ${errorText.substring(0, 200)}`);
        }
        
        const result = await response.json();
        console.log('[Upload Handler] Uguu Upload success:', JSON.stringify(result));
        
        if (result && result.files && result.files[0] && result.files[0].url) {
            return {
                success: true,
                server: 'uguu',
                data: {
                    original_name: filename,
                    url: result.files[0].url,
                    size_formatted: `${(mediaBuffer.length / 1024).toFixed(2)} KB`,
                    uploaded_at: getWIBTimestamp(),
                    file_id: result.files[0].url.split('/').pop(),
                    file_type: mimetype
                }
            };
        } else {
            throw new Error('Upload gagal: Format response tidak valid');
        }
    } catch (error) {
        console.error('[Upload Handler] Uguu Upload failed:', error.message);
        return { success: false, message: error.message, server: 'uguu' };
    } finally {
        if (tempPath) {
            try {
                await new Promise(resolve => setTimeout(resolve, 200));
                if (fs.existsSync(tempPath)) {
                    await unlink(tempPath);
                }
            } catch (e) {
                console.error('[Upload Handler] Failed to delete temp file:', e.message);
            }
        }
    }
}

async function uploadToTmpFiles(mediaBuffer, filename = 'file.jpg', mimetype = 'image/jpeg') {
    try {
        console.log('[Upload Handler] Uploading to TmpFiles, size:', mediaBuffer.length, 'bytes');
        
        const maxSize = 100 * 1024 * 1024;
        if (mediaBuffer.length > maxSize) {
            throw new Error(`File terlalu besar (${(mediaBuffer.length / 1024 / 1024).toFixed(2)}MB). Maksimal 100MB`);
        }
        
        const formData = new FormData();
        formData.append('file', mediaBuffer, {
            filename: filename,
            contentType: mimetype
        });
        
        const uploadPromise = fetch(UPLOAD_SERVERS.tmpfiles.url, {
            method: 'POST',
            body: formData,
            headers: {
                ...formData.getHeaders(),
                'Accept': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error(`Timeout setelah ${TIMEOUT_MS}ms`)), TIMEOUT_MS)
        );
        
        const response = await Promise.race([uploadPromise, timeoutPromise]);
        
        if (!response.ok) {
            const errorText = await response.text().catch(() => 'Unknown error');
            throw new Error(`HTTP ${response.status}: ${errorText.substring(0, 200)}`);
        }
        
        const result = await response.json();
        console.log('[Upload Handler] TmpFiles Upload response:', JSON.stringify(result));
        
        if (result.status === 'success' && result.data && result.data.url) {
            let originalUrl = result.data.url;
            let parts = originalUrl.split('/');
            let fileId = parts[parts.length - 2];
            let fileName = parts[parts.length - 1];
            let directUrl = `https://tmpfiles.org/dl/${fileId}/${fileName}`;
            
            console.log('[Upload Handler] TmpFiles Direct URL:', directUrl);
            
            return {
                success: true,
                server: 'tmpfiles',
                data: {
                    original_name: filename,
                    url: directUrl,
                    original_url: originalUrl,
                    size_formatted: `${(mediaBuffer.length / 1024).toFixed(2)} KB`,
                    uploaded_at: getWIBTimestamp(),
                    file_id: fileId,
                    file_type: mimetype,
                    message: 'File uploaded successfully to TmpFiles'
                }
            };
        } else {
            throw new Error(result.message || 'Upload gagal: Format response tidak valid');
        }
        
    } catch (error) {
        console.error('[Upload Handler] TmpFiles Upload failed:', error.message);
        return { success: false, message: error.message, server: 'tmpfiles' };
    }
}

async function uploadToHFSpace(mediaBuffer, filename = 'file.jpg', mimetype = 'image/jpeg') {
    try {
        console.log('[Upload Handler] Uploading to HF Space, size:', mediaBuffer.length, 'bytes');
        
        const maxSize = 100 * 1024 * 1024;
        if (mediaBuffer.length > maxSize) {
            throw new Error(`File terlalu besar (${(mediaBuffer.length / 1024 / 1024).toFixed(2)}MB). Maksimal 100MB`);
        }
        
        const formData = new FormData();
        formData.append('file', mediaBuffer, {
            filename: filename,
            contentType: mimetype
        });
        
        const uploadPromise = fetch(UPLOAD_SERVERS.hf.url, {
            method: 'POST',
            body: formData,
            headers: {
                ...formData.getHeaders(),
                'Accept': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error(`Timeout setelah ${TIMEOUT_MS}ms`)), TIMEOUT_MS)
        );
        
        const response = await Promise.race([uploadPromise, timeoutPromise]);
        
        if (!response.ok) {
            const errorText = await response.text().catch(() => 'Unknown error');
            throw new Error(`HTTP ${response.status}: ${errorText.substring(0, 200)}`);
        }
        
        const result = await response.json();
        console.log('[Upload Handler] HF Space Upload success:', JSON.stringify(result));
        
        if (result.fileUrl) {
            return {
                success: true,
                server: 'hf',
                data: {
                    original_name: filename,
                    url: result.fileUrl,
                    size_formatted: `${(mediaBuffer.length / 1024).toFixed(2)} KB`,
                    uploaded_at: getWIBTimestamp(),
                    file_id: result.fileUrl.split('/').pop(),
                    file_type: mimetype,
                    message: result.message || 'File uploaded successfully'
                }
            };
        } else {
            throw new Error(result.message || 'Upload gagal: Format response tidak valid');
        }
        
    } catch (error) {
        console.error('[Upload Handler] HF Space Upload failed:', error.message);
        return { success: false, message: error.message, server: 'hf' };
    }
}

async function uploadToZynnaa(mediaBuffer, filename = 'file.jpg', mimetype = 'image/jpeg', userId = null) {
    try {
        console.log('[Upload Handler] Uploading to Zynnaa, size:', mediaBuffer.length, 'bytes');
        
        const maxSize = 50 * 1024 * 1024;
        if (mediaBuffer.length > maxSize) {
            throw new Error(`File terlalu besar (${(mediaBuffer.length / 1024 / 1024).toFixed(2)}MB). Maksimal 50MB`);
        }
        
        const formData = new FormData();
        formData.append('file', mediaBuffer, {
            filename: filename,
            contentType: mimetype
        });
        
        const headers = {
            ...formData.getHeaders(),
            'Accept': 'application/json',
            'User-Agent': 'Mozilla/5.0'
        };
        
        if (userId) {
            headers['X-User-ID'] = userId;
        }
        
        const uploadPromise = fetch(UPLOAD_SERVERS.zynnaa.url, {
            method: 'POST',
            body: formData,
            headers: headers
        });
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error(`Timeout setelah ${TIMEOUT_MS}ms`)), TIMEOUT_MS)
        );
        
        const response = await Promise.race([uploadPromise, timeoutPromise]);
        
        if (!response.ok) {
            const errorText = await response.text().catch(() => 'Unknown error');
            throw new Error(`HTTP ${response.status}: ${errorText.substring(0, 200)}`);
        }
        
        const result = await response.json();
        console.log('[Upload Handler] Zynnaa Upload success:', JSON.stringify(result));
        
        if (result.success && result.filename && result.url) {
            return {
                success: true,
                server: 'zynnaa',
                data: {
                    original_name: filename,
                    url: result.url,
                    size_formatted: `${(mediaBuffer.length / 1024).toFixed(2)} KB`,
                    uploaded_at: getWIBTimestamp(),
                    file_id: result.filename,
                    file_type: mimetype,
                    user_id: result.userId,
                    uuid: result.fileId
                }
            };
        } else {
            throw new Error(result.message || 'Upload gagal');
        }
        
    } catch (error) {
        console.error('[Upload Handler] Zynnaa Upload failed:', error.message);
        return { success: false, message: error.message, server: 'zynnaa' };
    }
}

async function uploadToVBI(mediaBuffer, filename = 'image.jpg') {
    try {
        console.log('[Upload Handler] Uploading to VBI, size:', mediaBuffer.length, 'bytes');
        
        const formData = new FormData();
        formData.append('file', mediaBuffer, {
            filename: filename,
            contentType: 'image/jpeg'
        });
        formData.append('permanent', '1');
        formData.append('never_delete', 'true');
        
        const uploadPromise = fetch(UPLOAD_SERVERS.vbi.url, {
            method: 'POST',
            body: formData,
            headers: {
                ...formData.getHeaders(),
                'Accept': 'application/json'
            }
        });
        
        const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error(`Timeout setelah ${TIMEOUT_MS}ms`)), TIMEOUT_MS)
        );
        
        const response = await Promise.race([uploadPromise, timeoutPromise]);
        
        if (!response.ok) {
            const errorText = await response.text().catch(() => 'Unknown error');
            throw new Error(`HTTP ${response.status}: ${errorText}`);
        }
        
        const result = await response.json();
        console.log('[Upload Handler] VBI Upload success:', JSON.stringify(result));
        
        if (result.success && result.data) {
            return {
                success: true,
                server: 'vbi',
                data: {
                    original_name: result.data.original_name || result.data.filename,
                    url: result.data.url,
                    size_formatted: result.data.size_formatted,
                    uploaded_at: getWIBTimestamp(),
                    file_id: result.data.filename,
                    file_type: 'image/jpeg'
                }
            };
        } else {
            throw new Error(result.message || 'Upload gagal');
        }
        
    } catch (error) {
        console.error('[Upload Handler] VBI Upload failed:', error.message);
        return { success: false, message: error.message, server: 'vbi' };
    }
}

// ========== MULTI-SERVER UPLOAD ==========
async function uploadMultiServer(mediaBuffer, filename, mimetype, imageOnly = false, userId = null) {
    console.log('[Upload Handler] Starting multi-server upload (parallel - 5 servers + Videy for videos)');
    
    const results = {
        hf: null,
        tmpfiles: null,
        zynnaa: null,
        vbi: null,
        uguu: null,
        videy: null
    };
    
    const uploadPromises = [];
    const isVideo = mimetype.startsWith('video/');
    
    console.log('[Upload Handler] Starting HF Space upload...');
    uploadPromises.push(
        uploadToHFSpace(mediaBuffer, filename, mimetype)
            .then(result => { results.hf = result; })
            .catch(err => { 
                console.error('[Upload Handler] HF upload error:', err.message);
                results.hf = { success: false, message: err.message, server: 'hf' };
            })
    );
    
    console.log('[Upload Handler] Starting TmpFiles upload...');
    uploadPromises.push(
        uploadToTmpFiles(mediaBuffer, filename, mimetype)
            .then(result => { results.tmpfiles = result; })
            .catch(err => { 
                console.error('[Upload Handler] TmpFiles upload error:', err.message);
                results.tmpfiles = { success: false, message: err.message, server: 'tmpfiles' };
            })
    );
    
    console.log('[Upload Handler] Starting Zynnaa upload...');
    uploadPromises.push(
        uploadToZynnaa(mediaBuffer, filename, mimetype, userId)
            .then(result => { results.zynnaa = result; })
            .catch(err => { 
                console.error('[Upload Handler] Zynnaa upload error:', err.message);
                results.zynnaa = { success: false, message: err.message, server: 'zynnaa' };
            })
    );
    
    if (imageOnly) {
        console.log('[Upload Handler] Starting VBI upload...');
        uploadPromises.push(
            uploadToVBI(mediaBuffer, filename)
                .then(result => { results.vbi = result; })
                .catch(err => { 
                    console.error('[Upload Handler] VBI upload error:', err.message);
                    results.vbi = { success: false, message: err.message, server: 'vbi' };
                })
        );
    }
    
    console.log('[Upload Handler] Starting Uguu.se upload...');
    uploadPromises.push(
        uploadToUguu(mediaBuffer, filename, mimetype)
            .then(result => { results.uguu = result; })
            .catch(err => { 
                console.error('[Upload Handler] Uguu upload error:', err.message);
                results.uguu = { success: false, message: err.message, server: 'uguu' };
            })
    );
    
    if (isVideo) {
        console.log('[Upload Handler] Starting Videy upload...');
        uploadPromises.push(
            uploadToVidey(mediaBuffer, filename)
                .then(result => { results.videy = result; })
                .catch(err => { 
                    console.error('[Upload Handler] Videy upload error:', err.message);
                    results.videy = { success: false, message: err.message, server: 'videy' };
                })
        );
    }
    
    await Promise.allSettled(uploadPromises);
    
    const successfulUploads = [];
    if (results.hf?.success) successfulUploads.push('hf');
    if (results.tmpfiles?.success) successfulUploads.push('tmpfiles');
    if (results.zynnaa?.success) successfulUploads.push('zynnaa');
    if (results.vbi?.success) successfulUploads.push('vbi');
    if (results.uguu?.success) successfulUploads.push('uguu');
    if (results.videy?.success) successfulUploads.push('videy');
    
    console.log('[Upload Handler] Upload results:', {
        hf: results.hf?.success ? 'SUCCESS' : 'FAILED',
        tmpfiles: results.tmpfiles?.success ? 'SUCCESS' : 'FAILED',
        zynnaa: results.zynnaa?.success ? 'SUCCESS' : 'FAILED',
        vbi: results.vbi?.success ? 'SUCCESS' : (imageOnly ? 'FAILED' : 'SKIPPED'),
        uguu: results.uguu?.success ? 'SUCCESS' : 'FAILED',
        videy: results.videy?.success ? 'SUCCESS' : (isVideo ? 'FAILED' : 'SKIPPED'),
        totalSuccess: successfulUploads.length
    });
    
    if (isVideo && results.videy?.success) {
        return { ...results.videy, multiUpload: true, backupResults: results };
    } else if (results.hf?.success) {
        return { ...results.hf, multiUpload: true, backupResults: results };
    } else if (results.tmpfiles?.success) {
        return { ...results.tmpfiles, multiUpload: true, backupResults: results };
    } else if (results.zynnaa?.success) {
        return { ...results.zynnaa, multiUpload: true, backupResults: results };
    } else if (results.uguu?.success) {
        return { ...results.uguu, multiUpload: true, backupResults: results };
    } else if (results.vbi?.success) {
        return { ...results.vbi, multiUpload: true, backupResults: results };
    } else {
        return { 
            success: false,
            multiUpload: true, 
            message: `Upload gagal ke semua server yang dicoba`,
            backupResults: results
        };
    }
}

// ========== FORMAT FUNCTIONS ==========
function formatUploadResult(result, fromUrl = false) {
    const serverNames = {
        hf: 'Ikky HF',
        tmpfiles: 'TmpFiles',
        zynnaa: 'Zynnaa',
        vbi: 'VBI Upload',
        uguu: 'Uguu.se',
        videy: 'Videy'
    };
    const serverName = serverNames[result.server] || 'Unknown Server';
    let message = `*📤 UPLOAD RESULT*\n\n`;
    
    if (result.success && result.data) {
        message += `┌─「 🌐 *${serverName}* 」\n`;
        message += `├ ✅ Status: *BERHASIL*\n`;
        if (fromUrl) {
            message += `├ 🔗 Source: *From URL*\n`;
        }
        message += `├ 📄 File: *${result.data.original_name}*\n`;
        message += `├ 📦 Size: *${result.data.size_formatted}*\n`;
        message += `├ 📅 Uploaded: ${result.data.uploaded_at}\n`;
        
        if (result.data.user_id) {
            message += `├ 👤 User ID: ${result.data.user_id}\n`;
        }
        
        if (result.data.file_id) {
            message += `├ 🆔 File ID: ${result.data.file_id}\n`;
        }
        
        message += `├ 🔗 URL:\n`;
        message += `│    ${result.data.url}\n`;
        
        if (result.server === 'videy' && result.data.cdn_url) {
            message += `├ 📦 CDN URL:\n`;
            message += `│    ${result.data.cdn_url}\n`;
        }
        
        if (result.multiUpload && result.backupResults) {
            const backupOrder = ['videy', 'hf', 'tmpfiles', 'zynnaa', 'uguu', 'vbi'];
            for (const srv of backupOrder) {
                if (result.backupResults[srv]?.success && srv !== result.server) {
                    const name = serverNames[srv];
                    message += `├ 💾 Backup ${name}:\n`;
                    message += `│    ${result.backupResults[srv].data.url}\n`;
                }
            }
        }
        
        message += `└─────────────\n\n`;
        message += `🎉 *Upload berhasil!*`;
        
        if (result.multiUpload && result.backupResults) {
            const successCount = Object.values(result.backupResults).filter(r => r?.success).length;
            if (successCount > 1) {
                message += `\n✨ *File tersimpan di ${successCount} server untuk backup maksimal*`;
            }
        }
    } else {
        message += `┌─「 🌐 *Upload Server* 」\n`;
        message += `├ ❌ Status: *GAGAL*\n`;
        message += `├ ⚠️ Error: ${result.message || 'Unknown error'}\n`;
        
        if (result.multiUpload && result.backupResults) {
            message += `├ 📊 Details:\n`;
            for (const [srv, res] of Object.entries(result.backupResults)) {
                if (res) {
                    const status = res.success ? '✅' : '❌';
                    const name = serverNames[srv];
                    message += `│    ${status} ${name}\n`;
                }
            }
        }
        
        message += `└─────────────\n\n`;
        message += `❌ *Upload gagal ke semua server*`;
    }
    
    return message;
}

function generateUsageHelp(prefix, cmd) {
    return `*📤 UPLOAD FILE TO CLOUD*

📌 *Cara Penggunaan:*

*1. Upload dari Reply Media:*
Reply gambar/video/dokumen, lalu ketik: ${prefix}${cmd}

*2. Upload Langsung:*
Kirim media dengan caption: ${prefix}${cmd}

*3. Upload dari URL:* 🆕
${prefix}${cmd} <url>
Contoh: ${prefix}${cmd} https://example.com/image.jpg

📋 *Supported Formats:*
- Images: JPG, PNG, GIF, WEBP
- Videos: MP4, MKV, AVI
- Documents: PDF, DOCX, TXT, XLSX
- Audio: MP3, WAV, FLAC

💡 *Fitur:*
- Multi-server upload (6 server simultan!)
- Ikky HF + TmpFiles + Zynnaa + VBI + Uguu.se
- Videy (khusus video) 🎬
- Support upload dari URL 🆕
- Penyimpanan permanen
- Link tidak expired (tergantung server)
- Auto backup di multiple server
- Max 100MB per file (bervariasi per server)
- Timestamp otomatis (WIB)

🌐 *Upload Strategy:*
- Video → Videy (prioritas) + 4 server backup
- Gambar → 5 server (HF, TmpFiles, Zynnaa, Uguu, VBI)
- File lain → 4 server

*Contoh:*
${prefix}${cmd}
(kirim atau reply media)

${prefix}${cmd} https://i.imgur.com/example.jpg
(upload dari URL)
`;
}

// ========== MAIN HANDLER ==========
let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    let prefix = usedPrefix || '.';
    const cmd = command || 'upload';
    
    try {
        let inputText = '';
        if (text) {
            inputText = text.trim();
        } else if (args && args.length > 0) {
            inputText = args.join(' ').trim();
        }
        
        if (inputText.toLowerCase() === 'help' || inputText === '?') {
            return m.reply(generateUsageHelp(prefix, cmd));
        }
        
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        let result;
        let previewUrl = null;
        let mediaBuffer = null;
        let mime = '';
        let filename = '';
        let fromUrl = false;
        
        const userId = m.sender?.split('@')[0] || null;
        
        if (inputText && isValidUrl(inputText)) {
            console.log('[Upload Handler] Processing URL:', inputText);
            fromUrl = true;
            
            try {
                await m.reply('🔄 Mengunduh file dari URL...');
                
                const downloadResult = await downloadFromUrl(inputText);
                mediaBuffer = downloadResult.buffer;
                mime = downloadResult.mimetype;
                filename = downloadResult.filename;
                
                console.log('[Upload Handler] Downloaded from URL:', {
                    filename: filename,
                    size: mediaBuffer.length,
                    mimetype: mime
                });
                
                await m.reply(`✅ Download berhasil!\n📦 Size: ${(mediaBuffer.length / 1024).toFixed(2)} KB\n📤 Mengupload ke server...`);
            } catch (error) {
                console.error('[Upload Handler] Failed to download from URL:', error.message);
                await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                return m.reply(`❌ Gagal mengunduh dari URL:\n${error.message}\n\n💡 Pastikan URL valid dan file dapat diakses.`);
            }
        } else {
            const detection = detectMediaFromMessage(m);
            
            if (detection.mediaSource) {
                console.log('[Upload Handler] Media detected, downloading...');
                mime = detection.mime;
                filename = detection.filename;
                
                try {
                    mediaBuffer = await downloadMedia(detection.mediaSource);
                    
                    if (!mediaBuffer) {
                        throw new Error('Failed to download media buffer');
                    }
                    
                    console.log('[Upload Handler] Media downloaded successfully:', {
                        size: mediaBuffer.length,
                        mime: mime,
                        filename: filename
                    });
                } catch (error) {
                    console.error('[Upload Handler] Error downloading media:', error.message);
                    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
                    return m.reply(`❌ Gagal mengunduh media: ${error.message}`);
                }
            }
        }
        
        if (mediaBuffer && mime && filename) {
            const isImage = mime.startsWith('image/');
            const isVideo = mime.startsWith('video/');
            
            console.log(`[Upload Handler] Starting multi-server upload for ${isImage ? 'image' : (isVideo ? 'video' : 'file')}`);
            
            if (isVideo && !fromUrl) {
                await conn.sendMessage(m.chat, { 
                    text: '🎬 Video terdeteksi! Upload ke Videy + 4 server backup...'
                }, { quoted: m });
            }
            
            result = await uploadMultiServer(mediaBuffer, filename, mime, isImage, userId);
            
            if (result.success && result.data) {
                previewUrl = result.data.url;
            }
        }
        
        if (!result) {
            console.log('[Upload Handler] No valid input detected');
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            
            return m.reply(`❌ Tidak ada media yang terdeteksi!\n\n💡 Cara penggunaan:\n\n*Upload Media:*\nKirim atau reply media dengan caption:\n${prefix}${cmd}\n\n*Upload dari URL:* 🆕\n${prefix}${cmd} <url>\nContoh: ${prefix}${cmd} https://i.imgur.com/example.jpg\n\n📌 Ketik ${prefix}${cmd} help untuk panduan lengkap`);
        }
        
        const resultMessage = formatUploadResult(result, fromUrl);
        
        if (previewUrl) {
            console.log('[Upload Handler] Success - sending result');
            
            if (mime.startsWith('image/') && !result.data?.converted) {
                await conn.sendMessage(m.chat, {
                    image: { url: previewUrl },
                    caption: resultMessage
                }, { quoted: m });
            } else {
                await conn.sendMessage(m.chat, {
                    text: resultMessage
                }, { quoted: m });
            }
            
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } else {
            console.log('[Upload Handler] Failed - sending error message');
            
            await conn.sendMessage(m.chat, {
                text: resultMessage
            }, { quoted: m });
            
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        }
    } catch (error) {
        console.error('[Upload Handler] CRITICAL ERROR:', error.message);
        console.error('[Upload Handler] Stack:', error.stack);
        
        try {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        } catch (reactError) {
            console.error('[Upload Handler] Failed to send error reaction:', reactError.message);
        }
        
        return m.reply(`❌ Terjadi kesalahan saat upload.\n💡 Coba lagi atau ketik ${usedPrefix || '.'}${command || 'upload'} help`);
    }
};

handler.help = ["upload - Upload media ke cloud (6 servers) + URL support"];
handler.tags = ["tools"];
handler.command = ["upload", "up", "tourl", "imgup"];
handler.limit = true;

console.log('[Upload Handler] Handler loaded successfully with 6 Servers (HF + TmpFiles + Zynnaa + VBI + Uguu + Videy) + URL Support + WIB Timestamp');

export default handler;